// Connectors: every outside service the hub talks to, in one place.
//
//   Core (already used by the hub, status detected here): Discord, GitHub, Stripe, Cloudflare, Gmail, YouTube
//   Social: X (API v2), LinkedIn, Mastodon, Telegram (Bot API), DEV Community (Forem API v1), Discord (public channel)
//   Stores: itch.io (API + butler), Chrome Web Store (Publish API)
//   AI: Ollama (local models write posts for any platform)
//
// Posts go through one queue (data/connectors.json): drafts waiting for review, scheduled posts, history with links.
// Automation rules turn hub events (new app, release, video, announcement, milestone) into posts per platform,
// written from templates or by an Ollama model, posted straight away or held for review.
// Secrets live in secrets.json → connectors.<id>; nothing here is sent anywhere except the service it belongs to.
import { createHmac, randomBytes, createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { readFileSync, existsSync, writeFileSync, mkdtempSync, rmSync } from 'node:fs';
import { join, extname, basename } from 'node:path';
import { tmpdir } from 'node:os';

const UA = 'PyleriumHub/1.0 (+https://pylerium.github.io)';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const rid = () => randomBytes(6).toString('hex');
const clip = (s, n) => (String(s || '').length > n ? String(s).slice(0, n - 1).trimEnd() + '…' : String(s || ''));
const form = o => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== undefined && v !== null && v !== '').map(([k, v]) => [k, String(v)])).toString();
const pctEnc = s => encodeURIComponent(s).replace(/[!'()*]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
const MIME = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif' };

// ---------- the services ----------
// fields: what the UI asks for (secret: stored in secrets.json, never sent back to the UI in full)
export const DEFS = [
  { id: 'discord', name: 'Discord', icon: 'discord', group: 'Core', kind: 'core', blurb: 'Private alerts, public announcements, the Post tab and buyer emails.' },
  { id: 'github', name: 'GitHub', icon: 'github', group: 'Core', kind: 'core', blurb: 'Publishes your site and keeps paid-download files in private repositories.' },
  { id: 'stripe', name: 'Stripe', icon: 'stripe', group: 'Core', kind: 'core', blurb: 'Payments, products, checkout links, Stripe Tax and sales alerts.' },
  { id: 'cloudflare', name: 'Cloudflare', icon: 'cloudflare', group: 'Core', kind: 'core', blurb: 'Runs your free delivery service for paid downloads and licence checks.' },
  { id: 'gmail', name: 'Gmail', icon: 'mail', group: 'Core', kind: 'core', blurb: 'Sends download links, licence keys, supporter codes and thank-yous.' },
  { id: 'youtube', name: 'YouTube', icon: 'youtube', group: 'Core', kind: 'core', blurb: 'Pulls your latest videos and shorts onto the site and into alerts.' },
  { id: 'x', name: 'X (Twitter)', icon: 'xlogo', group: 'Social', kind: 'social', maxLen: 280, oauth: true, docs: 'https://console.x.com',
    blurb: 'Post to X with API v2: images through the v2 media upload, long posts as numbered threads, reply controls.',
    steps: ['In the X developer console, open your app → User authentication settings → Set up. App permissions: “Read and write”. Type of App: “Web App, Automated App or Bot”. Callback URI: the one below. Website: your site.', 'The X API is pay-per-use: the developer account needs credits (console → Billing), or every call fails with “credits depleted”.', 'Recommended: copy the OAuth 2.0 Client ID and Client Secret (Keys and tokens tab) here and press “Sign in with X”. The hub keeps a refresh token and renews access by itself.', 'Or use OAuth 1.0a: paste the Consumer Key and Secret and sign in (X shows a PIN if no Callback URI is set), or paste an Access Token and Secret generated after setting Read and write.'],
    fields: [{ k: 'clientId', l: 'OAuth 2.0 Client ID', opt: true, help: 'Recommended: sign-in with a refresh token' }, { k: 'clientSecret', l: 'OAuth 2.0 Client Secret', secret: true, opt: true }, { k: 'apiKey', l: 'Consumer Key', opt: true, help: 'OAuth 1.0a (instead of OAuth 2.0)' }, { k: 'apiSecret', l: 'Consumer Key Secret', secret: true, opt: true }, { k: 'accessToken', l: 'Access Token', opt: true, help: 'OAuth 1.0a: filled in by Sign in with X' }, { k: 'accessSecret', l: 'Access Token Secret', secret: true, opt: true }] },
  { id: 'linkedin', name: 'LinkedIn', icon: 'linkedin', group: 'Social', kind: 'social', maxLen: 3000, oauth: true, docs: 'https://www.linkedin.com/developers/apps',
    blurb: 'Share to your profile (or a company page) with a link preview card.',
    steps: ['Create an app at linkedin.com/developers/apps (a company page is required to create one).', 'Under Products, add “Share on LinkedIn” and “Sign In with LinkedIn using OpenID Connect”.', 'Under Auth, add the redirect URL shown below, then copy the Client ID and Client Secret here and press Connect.', 'Posting as a company page needs the Community Management product (w_organization_social).'],
    fields: [{ k: 'clientId', l: 'Client ID' }, { k: 'clientSecret', l: 'Client secret', secret: true }, { k: 'orgId', l: 'Company page ID', opt: true, help: 'Optional: post as this organization instead of yourself' }] },
  { id: 'mastodon', name: 'Mastodon', icon: 'mastodon', group: 'Social', kind: 'social', maxLen: 500, docs: '',
    blurb: 'Toot to any Mastodon server with visibility, content warnings, language and images.',
    steps: ['On your Mastodon server open Preferences → Development → New application.', 'Give it the scopes read:accounts, write:statuses and write:media, then submit.', 'Open the app and copy “Your access token”, and enter your server address (for example mastodon.social).'],
    fields: [{ k: 'instance', l: 'Server', placeholder: 'mastodon.social' }, { k: 'token', l: 'Access token', secret: true }] },
  { id: 'telegram', name: 'Telegram', icon: 'telegram', group: 'Social', kind: 'social', maxLen: 4096, docs: 'https://t.me/BotFather',
    blurb: 'A bot posts to your channels and groups, with photos, buttons, silent posts and pinning.',
    steps: ['Message @BotFather, send /newbot and follow the steps; copy the token it gives you.', 'Add the bot to your channel or group as an admin (allowed to post, and to pin if you want pinning).', 'Enter the token, then press “Find chats” after posting anything in the chat, or type @channelname.'],
    fields: [{ k: 'token', l: 'Bot token', secret: true }, { k: 'chats', l: 'Chats', placeholder: '@mychannel, -1001234567890', help: 'Comma-separated channel usernames or chat IDs' }] },
  { id: 'itch', name: 'itch.io', icon: 'itch', group: 'Stores', kind: 'store', docs: 'https://itch.io/user/settings/api-keys',
    blurb: 'See views, downloads and purchases for your games, and push builds with butler, automatically on release.',
    steps: ['Open itch.io → Settings → API keys and generate a key.', 'For uploads, install butler (itch.io/docs/butler) or set its path below; it uses the same key.', 'Map each app to its itch.io page (user/game) and channel, and choose whether new releases are pushed automatically.'],
    fields: [{ k: 'apiKey', l: 'API key', secret: true }, { k: 'butlerPath', l: 'butler path', opt: true, placeholder: 'butler (on PATH)' }] },
  { id: 'cws', name: 'Chrome Web Store', icon: 'chrome', group: 'Stores', kind: 'store', oauth: true, docs: 'https://console.cloud.google.com/apis/credentials',
    blurb: 'Upload new extension versions with the Chrome Web Store API v2 and publish them: straight away or staged, with rollout percentage and review status.',
    steps: ['In Google Cloud Console, enable the “Chrome Web Store API” for a project.', 'Create an OAuth client ID of type “Desktop app” and copy its client ID and secret.', 'Copy your Publisher ID from the Chrome Web Store Developer Dashboard → Publisher → Settings.', 'Press “Sign in with Google” with the account that owns your extensions.', 'Map each app to its extension ID (the 32-letter ID in its store URL). The first version of an extension must be uploaded in the dashboard.'],
    fields: [{ k: 'clientId', l: 'OAuth client ID' }, { k: 'clientSecret', l: 'OAuth client secret', secret: true }, { k: 'publisherId', l: 'Publisher ID' }] },
  { id: 'devto', name: 'DEV Community', icon: 'devto', group: 'Social', kind: 'social', maxLen: 100000, docs: 'https://dev.to/settings/extensions',
    blurb: 'Publish articles to dev.to: Markdown, up to four tags, series, cover image and canonical link, as drafts or live.',
    steps: ['Open dev.to → Settings → Extensions → DEV Community API Keys.', 'Give the key a name (for example “Studio Hub”) and press Generate API Key.', 'Paste it here. Articles are saved as drafts unless you switch on “Publish immediately”.'],
    fields: [{ k: 'apiKey', l: 'API key', secret: true }] },
  { id: 'ollama', name: 'Ollama', icon: 'ollama', group: 'AI', kind: 'ai', docs: 'https://ollama.com/download',
    blurb: 'Local AI models write posts for every platform, for any topic, in your voice. Nothing leaves your computer.',
    steps: ['Install Ollama from ollama.com and start it.', 'Pull a model, for example: ollama pull qwen3:4b-instruct (fast) or llama3.1:8b.', 'Pick the model here and describe your voice; posts can then be drafted for any platform.'],
    fields: [{ k: 'host', l: 'Server', placeholder: 'http://127.0.0.1:11434', opt: true }] }
];
const SOCIAL = DEFS.filter(d => d.kind === 'social').map(d => d.id).concat('discord');
export const EVENTS = [
  { id: 'app.new', label: 'New app on the site' }, { id: 'app.available', label: 'App released (coming soon → available)' },
  { id: 'app.updated', label: 'New version or release notes' }, { id: 'app.featured', label: 'App featured' },
  { id: 'yt.video', label: 'New YouTube video' }, { id: 'yt.short', label: 'New YouTube Short' },
  { id: 'site.announcement', label: 'New site announcement' }, { id: 'sale.milestone', label: 'Sales milestone' }
];
const DEFAULT_TPL = {
  'app.new': '🚀 New: {name}. {tagline}\n\n{url}', 'app.available': '{name} is out now! {tagline}\n\n{url}',
  'app.updated': '{name} {version} is out. {notes}\n\n{url}', 'app.featured': '⭐ Featured: {name}. {tagline}\n\n{url}',
  'yt.video': '🎬 New video: {title}\n\n{url}', 'yt.short': '⚡ New Short: {title}\n\n{url}',
  'site.announcement': '📣 {text}\n\n{url}', 'sale.milestone': '🎉 Thank you! Supporters just passed {amount}.\n\n{url}', manual: '{text}'
};
const DEFAULT_TITLE = { 'app.new': '{name}: {tagline}', 'app.available': '{name} is out: {tagline}', 'app.updated': '{name} {version}: {notes}', 'app.featured': '{name}: {tagline}', 'yt.video': '{title}', 'yt.short': '{title}', 'site.announcement': '{text}', 'sale.milestone': 'Thank you, supporters!', manual: '{title}' };

export function createConnectors(ctx) {
  // ctx: readJson, writeJson, secrets, saveSecrets, fetchT, loadApps, loadSite, siteUrl(), brand(), port, mediaDir,
  //      core() → statuses of the built-in connections, discordPost(text), releaseAsset({ appId, pattern }), alert(title, desc), log
  const load = () => {
    const d = ctx.readJson('connectors.json', {});
    return { settings: {}, rules: {}, queue: [], history: [], ...d };
  };
  const save = d => ctx.writeJson('connectors.json', d, false);
  const sec = id => (ctx.secrets().connectors || {})[id] || {};
  const setSec = (id, patch) => { const all = { ...(ctx.secrets().connectors || {}) }; all[id] = { ...(all[id] || {}), ...patch }; for (const k of Object.keys(all[id])) if (all[id][k] === '' || all[id][k] == null) delete all[id][k]; ctx.saveSecrets({ connectors: all }); };
  const settings = id => load().settings[id] || {};
  const setSettings = (id, patch) => { const d = load(); d.settings[id] = { ...(d.settings[id] || {}), ...patch }; save(d); };
  const siteUrl = () => String(ctx.siteUrl() || '').replace(/\/$/, '');
  const pending = new Map(); // OAuth state → { id, at, verifier }

  async function http(url, opt = {}, what = 'request') {
    // tests: HUB_CONNECTOR_MOCK=http://127.0.0.1:port sends every service call to a local fake (host kept in the path)
    if (process.env.HUB_CONNECTOR_MOCK && /^https:\/\//.test(url)) url = `${process.env.HUB_CONNECTOR_MOCK}/${url.slice(8)}`;
    const r = await ctx.fetchT(url, { ...opt, headers: { 'User-Agent': UA, ...(opt.headers || {}) } }, opt.timeout || 30000);
    const text = await r.text();
    let j = null; try { j = text ? JSON.parse(text) : {}; } catch { j = { raw: text }; }
    if (!r.ok) {
      const xml = /<error[^>]*>([^<]+)<\/error>/.exec(j?.raw || '')?.[1];
      const m = xml || j?.error_description || j?.message || j?.error?.message || (typeof j?.error === 'string' ? j.error : '') || j?.detail || j?.errors?.[0]?.message || j?.title || j?.description || (j?.raw || '').slice(0, 200) || `HTTP ${r.status}`;
      throw Object.assign(new Error(`${what}: ${m}`), { status: r.status, body: j });
    }
    return { json: j, headers: r.headers, status: r.status };
  }

  // ================================================================ X (Twitter) API v2, OAuth 1.0a user context
  // tok/tokSecret: the user's access token (posting), a request token (during sign-in) or none (requesting one)
  function oauth1(method, url, c, extra = {}) {
    const tok = 'tok' in extra ? extra.tok : c.accessToken, tokSecret = 'tokSecret' in extra ? extra.tokSecret : c.accessSecret;
    const o = { oauth_consumer_key: c.apiKey, oauth_nonce: randomBytes(16).toString('hex'), oauth_signature_method: 'HMAC-SHA1', oauth_timestamp: String(Math.floor(Date.now() / 1000)), ...(tok ? { oauth_token: tok } : {}), oauth_version: '1.0', ...extra.oauth };
    const u = new URL(url), all = { ...Object.fromEntries(u.searchParams), ...(extra.params || {}), ...o };
    const base = [method.toUpperCase(), pctEnc(u.origin + u.pathname), pctEnc(Object.keys(all).sort().map(k => `${pctEnc(k)}=${pctEnc(all[k])}`).join('&'))].join('&');
    o.oauth_signature = createHmac('sha1', `${pctEnc(c.apiSecret)}&${pctEnc(tokSecret || '')}`).update(base).digest('base64');
    return 'OAuth ' + Object.keys(o).sort().map(k => `${pctEnc(k)}="${pctEnc(o[k])}"`).join(', ');
  }
  const xLen = s => String(s).replace(/https?:\/\/\S+/g, 'x'.repeat(23)).replace(/[\u1100-\u115F\u2E80-\uA4CF\uAC00-\uD7A3\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFF60\uFFE0-\uFFE6]/g, 'xx').length;
  const formOf = j => Object.fromEntries(new URLSearchParams(j?.raw ?? ''));
  const x = {
    base: () => (settings('x').apiBase || 'https://api.x.com'),
    redirect: () => `http://127.0.0.1:${ctx.port}/oauth/x`,
    oauth2: () => !!sec('x').clientId,
    // OAuth 2.0: access tokens last 2 hours; the refresh token renews them (X rotates it: the new one is saved every time)
    async token(force = false) {
      const s = settings('x');
      if (!force && s.token && s.tokenExp > Date.now() + 60000) return s.token;
      return x._refreshing ||= (async () => {
        const c = sec('x'); if (!c.refreshToken) throw new Error('Press “Sign in with X” so the hub can post for your account.');
        const j = await x.tokenCall({ grant_type: 'refresh_token', refresh_token: c.refreshToken, client_id: c.clientId }).catch(e => { if (e.status === 400 || e.status === 401) throw new Error('X ended the sign-in (the refresh token was revoked or expired). Press “Sign in with X” again.'); throw e; });
        return j.access_token;
      })().finally(() => { x._refreshing = null; });
    },
    async tokenCall(params) {
      const c = sec('x');
      const j = (await http(`${x.base()}/2/oauth2/token`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...(c.clientSecret ? { Authorization: 'Basic ' + Buffer.from(`${encodeURIComponent(c.clientId)}:${encodeURIComponent(c.clientSecret)}`).toString('base64') } : {}) }, body: form(params) }, 'X sign-in')).json;
      if (!j.access_token) throw new Error('X didn’t return an access token.');
      if (j.refresh_token) setSec('x', { refreshToken: j.refresh_token });
      setSettings('x', { token: j.access_token, tokenExp: Date.now() + (j.expires_in || 7200) * 1000, scope: j.scope || '' });
      return j;
    },
    async auth(method, url) {
      const c = sec('x');
      if (c.refreshToken) return `Bearer ${await x.token()}`;
      if (c.accessToken && c.accessSecret && c.apiKey && c.apiSecret) return oauth1(method, url, c);
      throw new Error('Press “Sign in with X” so the hub can post for your account.');
    },
    // every X call: user auth, one silent token renewal on 401, and X's errors in plain words
    async req(method, path, opt = {}) {
      const url = path.startsWith('http') ? path : `${x.base()}${path}`;
      const go = async () => http(url, { method, ...opt, headers: { ...(opt.headers || {}), Authorization: await x.auth(method, url) } }, opt.what || 'X');
      try { return await go(); } catch (e) {
        if (e.status === 401 && sec('x').refreshToken) { try { await x.token(true); return await go(); } catch (e2) { e = e2; } }
        throw x.explain(e);
      }
    },
    explain(e) {
      const b = e.body || {}, t = `${b.type || ''} ${b.detail || ''} ${b.title || ''} ${b.reason || ''} ${e.message}`;
      let m = '';
      if (e.status === 402 || /credits.depleted/i.test(t)) m = 'Your X developer account has no API credits. The X API is pay-per-use: add credits in the X developer console (Billing), then try again.';
      else if (/client-not-enrolled|not.*enrolled|attached to a project/i.test(t)) m = 'This X app isn’t attached to a Project in the developer console. Move it into a Project, then try again.';
      else if (e.status === 403 && /oauth1-permissions|not permitted|write/i.test(t)) m = 'Your X app is set to Read only. Change App permissions to “Read and write”, then press Sign in with X again (old sign-ins keep the old permission).';
      else if (e.status === 401 && !/ended the sign-in/.test(e.message)) m = 'X refused the saved sign-in: it was revoked, or the keys were regenerated. Press “Sign in with X” again (and paste the new keys if you regenerated them).';
      else if (e.status === 429) m = 'X rate limit reached. The hub tries again later.';
      return m ? Object.assign(new Error(m), { status: e.status, body: e.body }) : e;
    },
    async call(method, path, json) {
      return (await x.req(method, path, { headers: json ? { 'Content-Type': 'application/json' } : {}, body: json ? JSON.stringify(json) : undefined })).json;
    },
    // Sign in with X: OAuth 2.0 PKCE when a Client ID is set (keeps a refresh token), otherwise 3-legged OAuth 1.0a.
    // OAuth 1.0a: if the X app has no Callback URI registered, X only allows PIN sign-in ("oob"): X shows a PIN that the user types into the hub.
    async authUrl() {
      const c = sec('x');
      if (c.clientId) {
        const state = rid(), verifier = randomBytes(32).toString('base64url');
        pending.set(state, { id: 'x', at: Date.now(), verifier });
        return { url: `https://x.com/i/oauth2/authorize?${form({ response_type: 'code', client_id: c.clientId, redirect_uri: x.redirect(), scope: 'tweet.read tweet.write users.read media.write offline.access', state, code_challenge: createHash('sha256').update(verifier).digest('base64url'), code_challenge_method: 'S256' })}`, pin: false };
      }
      if (!c.apiKey || !c.apiSecret) throw new Error('Enter the OAuth 2.0 Client ID and Secret (or the Consumer Key and Secret) first.');
      const url = `${x.base()}/oauth/request_token`;
      const ask = cb => http(url, { method: 'POST', headers: { Authorization: oauth1('POST', url, c, { tok: null, tokSecret: '', oauth: { oauth_callback: cb } }) } }, 'X sign-in').then(r => formOf(r.json));
      let f, pin = false;
      try { f = await ask(x.redirect()); } catch (e) { if (!/oob|callback/i.test(e.message)) throw x.explain(e); f = await ask('oob'); pin = true; }
      if (!f.oauth_token || f.oauth_callback_confirmed !== 'true') throw new Error('X didn’t return a sign-in token. Check the Consumer Key and Secret.');
      pending.set(f.oauth_token, { id: 'x', at: Date.now(), secret: f.oauth_token_secret });
      if (pin) x.pinToken = f.oauth_token;
      return { url: `${x.base()}/oauth/authorize?oauth_token=${encodeURIComponent(f.oauth_token)}`, pin };
    },
    async callback2(code, st) {
      await x.tokenCall({ code, grant_type: 'authorization_code', redirect_uri: x.redirect(), code_verifier: st.verifier, client_id: sec('x').clientId });
      const me = await x.call('GET', '/2/users/me').catch(() => null);
      if (me?.data?.username) setSettings('x', { username: me.data.username });
    },
    async pin(code) {
      const tok = x.pinToken, st = tok && pending.get(tok);
      if (!st || Date.now() - st.at > 15 * 60000) throw new Error('This sign-in expired. Press Sign in with X again.');
      if (!/^\d{4,10}$/.test(String(code || '').trim())) throw new Error('Type the PIN X showed you (digits only).');
      await x.callback(tok, String(code).trim(), st);
      pending.delete(tok); x.pinToken = null; checks.delete('x');
      return { status: await check('x', true) };
    },
    async callback(token, verifier, st) {
      const c = sec('x'), url = `${x.base()}/oauth/access_token`;
      const r = await http(url, { method: 'POST', headers: { Authorization: oauth1('POST', url, c, { tok: token, tokSecret: st.secret, oauth: { oauth_verifier: verifier } }), 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ oauth_verifier: verifier }) }, 'X sign-in');
      const f = formOf(r.json);
      if (!f.oauth_token || !f.oauth_token_secret) throw new Error('X didn’t return an access token.');
      setSec('x', { accessToken: f.oauth_token, accessSecret: f.oauth_token_secret });
      if (f.screen_name) setSettings('x', { username: f.screen_name });
    },
    async test() {
      const c = sec('x');
      if (!c.refreshToken && !(c.accessToken && c.accessSecret)) throw new Error('Keys saved. Press “Sign in with X” so the hub can post for your account.');
      const r = await x.req('GET', '/2/users/me?user.fields=public_metrics,verified_type');
      const me = r.json;
      setSettings('x', { username: me.data.username, premium: !!me.data.verified_type && me.data.verified_type !== 'none' });
      const level = r.headers.get('x-access-level'), scope = settings('x').scope;
      if (level === 'read' || (c.refreshToken && scope && !/tweet\.write/.test(scope))) throw new Error(`Signed in as @${me.data.username}, but only to read. Set App permissions to “Read and write”, then press Sign in with X again.`);
      return { ok: true, account: `@${me.data.username}`, detail: `${(me.data.public_metrics?.followers_count ?? 0).toLocaleString()} followers${c.refreshToken ? ' · OAuth 2.0, renews itself' : ''}` };
    },
    // v2 media upload (the v1.1 upload endpoint is retired): one image, multipart, OAuth 2.0 (media.write) or 1.0a
    async uploadImage(file) {
      const fd = new FormData();
      fd.append('media', new Blob([readFileSync(file)], { type: MIME[extname(file).toLowerCase()] || 'image/png' }), basename(file));
      fd.append('media_category', 'tweet_image');
      const j = (await x.req('POST', '/2/media/upload', { body: fd, timeout: 120000, what: 'X media' })).json;
      const id = j?.data?.id || j?.media_id_string || j?.data?.media_id_string;
      if (!id) throw new Error('X media upload returned no id');
      return String(id);
    },
    async publish(p) {
      const o = p.options || {}, limit = o.premium || settings('x').premium && o.premium !== false ? 25000 : 280;
      const parts = o.thread === false ? [p.text] : splitThread(p.text, limit, xLen);
      let media = null, note = '';
      const img = o.image !== false ? imageFile(p) : null;
      if (img) { try { media = await x.uploadImage(img); } catch (e) { note = `posted without the image (${e.message})`; } }
      let prev = null, first = null;
      for (const [i, t] of parts.entries()) {
        const body = { text: t, ...(prev ? { reply: { in_reply_to_tweet_id: prev } } : {}), ...(o.replySettings && !prev ? { reply_settings: o.replySettings } : {}), ...(media && i === 0 ? { media: { media_ids: [media] } } : {}) };
        const j = await x.call('POST', '/2/tweets', body);
        prev = j.data.id; first ||= prev;
      }
      const me = settings('x').username;
      return { id: first, url: me ? `https://x.com/${me}/status/${first}` : `https://x.com/i/web/status/${first}`, parts: parts.length, ...(note ? { note } : {}) };
    }
  };

  // ================================================================ LinkedIn (OAuth 2.0, Posts API)
  const liVersion = () => settings('linkedin').version || (() => { const d = new Date(); d.setMonth(d.getMonth() - 2); return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}`; })();
  const linkedin = {
    redirect: () => `http://127.0.0.1:${ctx.port}/oauth/linkedin`,
    authUrl() {
      const c = sec('linkedin'); if (!c.clientId) throw new Error('Enter the Client ID and secret first.');
      const state = rid(); pending.set(state, { id: 'linkedin', at: Date.now() });
      const scope = ['openid', 'profile', 'w_member_social', ...(c.orgId ? ['w_organization_social'] : [])].join(' ');
      return `https://www.linkedin.com/oauth/v2/authorization?${form({ response_type: 'code', client_id: c.clientId, redirect_uri: linkedin.redirect(), state, scope })}`;
    },
    async callback(code) {
      const c = sec('linkedin');
      const { json } = await http('https://www.linkedin.com/oauth/v2/accessToken', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ grant_type: 'authorization_code', code, redirect_uri: linkedin.redirect(), client_id: c.clientId, client_secret: c.clientSecret }) }, 'LinkedIn sign-in');
      setSec('linkedin', { accessToken: json.access_token, refreshToken: json.refresh_token || '' });
      const me = (await http('https://api.linkedin.com/v2/userinfo', { headers: { Authorization: `Bearer ${json.access_token}` } }, 'LinkedIn profile')).json;
      setSettings('linkedin', { personUrn: `urn:li:person:${me.sub}`, name: me.name, expiresAt: Date.now() + (json.expires_in || 5184000) * 1000 });
    },
    async test() {
      const c = sec('linkedin'), s = settings('linkedin');
      if (!c.accessToken) throw new Error('Press Connect to sign in to LinkedIn.');
      const me = (await http('https://api.linkedin.com/v2/userinfo', { headers: { Authorization: `Bearer ${c.accessToken}` } }, 'LinkedIn')).json;
      const days = s.expiresAt ? Math.round((s.expiresAt - Date.now()) / 864e5) : null;
      return { ok: true, account: me.name, detail: days != null ? (days > 0 ? `sign-in valid for ${days} more days` : 'sign-in expired: press Connect again') : '' };
    },
    async publish(p) {
      const c = sec('linkedin'), s = settings('linkedin'), o = p.options || {};
      if (!c.accessToken) throw new Error('LinkedIn isn’t connected.');
      const author = o.asOrg && c.orgId ? `urn:li:organization:${c.orgId}` : s.personUrn;
      const body = { author, commentary: clip(p.text, 3000), visibility: o.visibility || 'PUBLIC', distribution: { feedDistribution: 'MAIN_FEED', targetEntities: [], thirdPartyDistributionChannels: [] }, lifecycleState: 'PUBLISHED', isReshareDisabledByAuthor: !!o.noReshare,
        ...(p.link && o.card !== false ? { content: { article: { source: p.link, title: clip(p.title || p.source?.name || p.link, 200), description: clip(p.source?.tagline || '', 250) } } } : {}) };
      const r = await http('https://api.linkedin.com/rest/posts', { method: 'POST', headers: { Authorization: `Bearer ${c.accessToken}`, 'LinkedIn-Version': liVersion(), 'X-Restli-Protocol-Version': '2.0.0', 'Content-Type': 'application/json' }, body: JSON.stringify(body) }, 'LinkedIn');
      const urn = r.headers.get('x-restli-id') || r.headers.get('x-linkedin-id') || '';
      return { id: urn, url: urn ? `https://www.linkedin.com/feed/update/${urn}/` : '' };
    }
  };

  // ================================================================ Mastodon
  const mastodon = {
    base() { const i = String(sec('mastodon').instance || settings('mastodon').instance || '').trim().replace(/\/+$/, ''); if (!i) throw new Error('Enter your Mastodon server.'); return /^https?:\/\//.test(i) ? i : `https://${i}`; },
    async call(path, opt = {}) { const t = sec('mastodon').token; if (!t) throw new Error('Mastodon isn’t set up yet.'); return (await http(`${mastodon.base()}${path}`, { ...opt, headers: { Authorization: `Bearer ${t}`, ...(opt.headers || {}) } }, 'Mastodon')).json; },
    async test() { const a = await mastodon.call('/api/v1/accounts/verify_credentials'); setSettings('mastodon', { acct: a.acct, url: a.url }); return { ok: true, account: `@${a.acct}@${new URL(mastodon.base()).host}`, detail: `${(a.followers_count ?? 0).toLocaleString()} followers` }; },
    async publish(p) {
      const o = p.options || {}, parts = o.thread === false ? [p.text] : splitThread(p.text, settings('mastodon').maxLen || 500);
      let media = [];
      const img = imageFile(p);
      if (img && o.image !== false) {
        const fd = new FormData(); fd.append('file', new Blob([readFileSync(img)], { type: MIME[extname(img).toLowerCase()] || 'image/png' }), basename(img)); if (p.source?.name) fd.append('description', p.source.name);
        try { media = [(await mastodon.call('/api/v2/media', { method: 'POST', body: fd })).id]; } catch { /* post without the image */ }
      }
      let prev = null, first = null;
      for (const [i, t] of parts.entries()) {
        const body = { status: t, visibility: o.visibility || 'public', sensitive: !!o.sensitive, spoiler_text: o.cw || '', language: o.language || undefined, media_ids: i === 0 ? media : [], in_reply_to_id: prev || undefined };
        const s = await mastodon.call('/api/v1/statuses', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Idempotency-Key': `${p.id}-${i}` }, body: JSON.stringify(body) });
        prev = s.id; first ||= s;
      }
      return { id: first.id, url: first.url };
    }
  };

  // ================================================================ Telegram Bot API
  const telegram = {
    async call(method, body, multipart) {
      const t = sec('telegram').token; if (!t) throw new Error('Telegram isn’t set up yet.');
      const r = await http(`https://api.telegram.org/bot${t}/${method}`, multipart ? { method: 'POST', body } : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) }, 'Telegram');
      if (!r.json.ok) throw new Error(`Telegram: ${r.json.description}`);
      return r.json.result;
    },
    chats: () => String(sec('telegram').chats || settings('telegram').chats || '').split(/[,\s]+/).filter(Boolean),
    async test() { const me = await telegram.call('getMe'); setSettings('telegram', { bot: me.username }); return { ok: true, account: `@${me.username}`, detail: `${telegram.chats().length} chat(s)` }; },
    async findChats() {
      const ups = await telegram.call('getUpdates', { limit: 100, allowed_updates: ['message', 'channel_post', 'my_chat_member'] });
      const m = new Map();
      for (const u of ups) { const c = u.message?.chat || u.channel_post?.chat || u.my_chat_member?.chat; if (c && c.type !== 'private') m.set(String(c.id), { id: String(c.id), title: c.title || c.username, type: c.type, username: c.username || '' }); }
      return [...m.values()];
    },
    async publish(p) {
      const o = p.options || {}, chats = o.chats ? String(o.chats).split(/[,\s]+/).filter(Boolean) : telegram.chats();
      if (!chats.length) throw new Error('Add a Telegram chat or channel first.');
      const html = esc(p.text).replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1">$1</a>');
      const markup = o.button && (o.buttonUrl || p.link) ? { inline_keyboard: [[{ text: o.button, url: o.buttonUrl || p.link }]] } : undefined;
      const img = o.photo !== false ? imageFile(p) : null, out = [];
      for (const chat of chats) {
        let msg;
        if (img && html.length <= 1024) {
          const fd = new FormData(); fd.append('chat_id', chat); fd.append('caption', html); fd.append('parse_mode', 'HTML'); if (o.silent) fd.append('disable_notification', 'true');
          if (markup) fd.append('reply_markup', JSON.stringify(markup)); fd.append('photo', new Blob([readFileSync(img)], { type: MIME[extname(img).toLowerCase()] || 'image/png' }), basename(img));
          msg = await telegram.call('sendPhoto', fd, true);
        } else msg = await telegram.call('sendMessage', { chat_id: chat, text: html, parse_mode: 'HTML', link_preview_options: { is_disabled: !!o.noPreview }, disable_notification: !!o.silent, reply_markup: markup });
        if (o.pin) await telegram.call('pinChatMessage', { chat_id: chat, message_id: msg.message_id, disable_notification: true }).catch(() => {});
        const user = msg.chat?.username;
        out.push({ id: `${chat}:${msg.message_id}`, url: user ? `https://t.me/${user}/${msg.message_id}` : '' });
      }
      return { id: out.map(r => r.id).join(','), url: out.find(r => r.url)?.url || '' };
    }
  };

  // ================================================================ Discord (public announcements channel, via the existing notifier)
  const discord = { async publish(p) { await ctx.discordPost(p.text); return { id: '', url: '' }; } };

  // ================================================================ itch.io (server API + butler)
  const itch = {
    async api(path) { const k = sec('itch').apiKey; if (!k) throw new Error('itch.io isn’t set up yet.'); return (await http(`https://itch.io/api/1/${encodeURIComponent(k)}${path}`, {}, 'itch.io')).json; },
    async test() { const me = await itch.api('/me'); if (me.errors) throw new Error(me.errors.join(', ')); const g = await itch.api('/my-games').catch(() => ({ games: [] })); return { ok: true, account: me.user.username, detail: `${(g.games || []).length} game(s)` }; },
    async games() {
      const g = await itch.api('/my-games');
      return (g.games || []).map(x => ({ id: x.id, title: x.title, url: x.url, cover: x.cover_url, published: !!x.published, views: x.views_count || 0, downloads: x.downloads_count || 0, purchases: x.purchases_count || 0, earnings: (x.earnings || []).map(e => e.amount_formatted).join(', '), type: x.classification, price: x.min_price ? `$${(x.min_price / 100).toFixed(2)}` : 'Free' }));
    },
    butler: () => settings('itch').butlerPath || sec('itch').butlerPath || 'butler',
    run(args, env = {}) {
      return new Promise((res, rej) => {
        const p = spawn(itch.butler(), args, { env: { ...process.env, BUTLER_API_KEY: sec('itch').apiKey || '', ...env }, windowsHide: true });
        let out = ''; p.stdout.on('data', d => out += d); p.stderr.on('data', d => out += d);
        p.on('error', e => rej(new Error(e.code === 'ENOENT' ? 'butler wasn’t found. Install it from itch.io/docs/butler or set its path.' : e.message)));
        p.on('close', c => (c ? rej(new Error(`butler failed: ${out.trim().split('\n').slice(-3).join(' ')}`)) : res(out)));
      });
    },
    async butlerVersion() { try { return (await itch.run(['-V'])).trim().split('\n')[0]; } catch (e) { return ''; } },
    async push({ file, target, channel, version, ifChanged = true }) {
      if (!/^[\w-]+\/[\w-]+$/.test(target || '')) throw new Error('Set the itch.io page as user/game.');
      if (!/^[\w.-]+$/.test(channel || '')) throw new Error('Set a channel, for example windows or html5.');
      const args = ['push', file, `${target}:${channel}`, ...(version ? ['--userversion', version] : []), ...(ifChanged ? ['--if-changed'] : [])];
      const out = await itch.run(args);
      return { url: `https://${target.split('/')[0]}.itch.io/${target.split('/')[1]}`, log: out.trim().split('\n').slice(-4).join('\n') };
    }
  };

  // ================================================================ Chrome Web Store API v2
  // (v1.1 was supported until 15 October 2026; v2 addresses items as publishers/{publisherId}/items/{itemId})
  const CWS = 'https://chromewebstore.googleapis.com';
  const cws = {
    redirect: () => `http://127.0.0.1:${ctx.port}/oauth/google`,
    authUrl() {
      const c = sec('cws'); if (!c.clientId) throw new Error('Enter the OAuth client ID and secret first.');
      const state = rid(), verifier = randomBytes(32).toString('base64url');
      pending.set(state, { id: 'cws', at: Date.now(), verifier });
      return `https://accounts.google.com/o/oauth2/v2/auth?${form({ client_id: c.clientId, redirect_uri: cws.redirect(), response_type: 'code', scope: 'https://www.googleapis.com/auth/chromewebstore', access_type: 'offline', prompt: 'consent', state, code_challenge: createHash('sha256').update(verifier).digest('base64url'), code_challenge_method: 'S256' })}`;
    },
    async callback(code, st) {
      const c = sec('cws');
      const { json } = await http('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ code, client_id: c.clientId, client_secret: c.clientSecret, redirect_uri: cws.redirect(), grant_type: 'authorization_code', code_verifier: st.verifier }) }, 'Google sign-in');
      if (!json.refresh_token) throw new Error('Google didn’t return a refresh token. Remove the app’s access at myaccount.google.com/permissions and connect again.');
      setSec('cws', { refreshToken: json.refresh_token });
      setSettings('cws', { token: json.access_token, tokenExp: Date.now() + (json.expires_in || 3600) * 1000 });
    },
    async token() {
      const c = sec('cws'), s = settings('cws');
      if (s.token && s.tokenExp > Date.now() + 60000) return s.token;
      if (!c.refreshToken) throw new Error('Press “Sign in with Google” first.');
      const { json } = await http('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ client_id: c.clientId, client_secret: c.clientSecret, refresh_token: c.refreshToken, grant_type: 'refresh_token' }) }, 'Google');
      setSettings('cws', { token: json.access_token, tokenExp: Date.now() + (json.expires_in || 3600) * 1000 });
      return json.access_token;
    },
    name(itemId) {
      const pub = String(sec('cws').publisherId || settings('cws').publisherId || '').trim();
      if (!pub) throw new Error('Enter your Publisher ID (Developer Dashboard → Publisher → Settings).');
      if (!/^[a-p]{32}$/.test(itemId || '')) throw new Error('That isn’t a Chrome extension ID (32 letters a–p).');
      return `publishers/${encodeURIComponent(pub)}/items/${itemId}`;
    },
    async call(method, path, body, what) { const t = await cws.token(); return (await http(`${CWS}${path}`, { method, headers: { Authorization: `Bearer ${t}`, ...(body !== undefined && !(body instanceof Uint8Array) ? { 'Content-Type': 'application/json' } : {}) }, body: body === undefined ? undefined : body instanceof Uint8Array ? body : JSON.stringify(body), timeout: 300000 }, what || 'Chrome Web Store')).json; },
    // fetchStatus: what's live, what's in review, the last async upload
    async item(itemId) {
      const j = await cws.call('GET', `/v2/${cws.name(itemId)}:fetchStatus`);
      const rev = r => r ? { state: r.state || '', channels: (r.distributionChannels || []).map(d => ({ version: d.crxVersion, percent: d.deployPercentage })) } : null;
      const pub = rev(j.publishedItemRevisionStatus), sub = rev(j.submittedItemRevisionStatus);
      return { id: j.itemId, published: pub, submitted: sub, version: pub?.channels?.[0]?.version || '', state: sub?.state || pub?.state || 'NOT_PUBLISHED', upload: j.lastAsyncUploadState || '', takenDown: !!j.takenDown, warned: !!j.warned };
    },
    async test() {
      await cws.token();
      const items = (settings('cws').items || []).filter(i => i.itemId);
      if (!items.length) return { ok: true, account: 'Google account connected', detail: 'map an extension to see its status' };
      const it = await cws.item(items[0].itemId);
      return { ok: true, account: 'Google account connected', detail: `${items[0].itemId.slice(0, 8)}… ${stateLabel(it.state)}${it.version ? ` · live v${it.version}` : ''}` };
    },
    async upload(itemId, buffer) {
      let j = await cws.call('POST', `/upload/v2/${cws.name(itemId)}:upload`, new Uint8Array(buffer), 'Chrome Web Store upload');
      // big packages finish asynchronously: poll fetchStatus for up to two minutes
      for (let i = 0; j.uploadState === 'IN_PROGRESS' && i < 24; i++) { await sleep(5000); const st = await cws.item(itemId); if (st.upload && st.upload !== 'IN_PROGRESS') j = { ...j, uploadState: st.upload }; }
      if (j.uploadState === 'FAILED') throw new Error('The Chrome Web Store rejected the package. Check the manifest version is higher than the live one.');
      return { state: j.uploadState, version: j.crxVersion || '' };
    },
    async publish(itemId, { staged = false, percent, skipReview = false, blockOnWarnings = false } = {}) {
      const body = { publishType: staged ? 'STAGED_PUBLISH' : 'DEFAULT_PUBLISH', ...(percent && +percent < 100 ? { deployInfos: [{ deployPercentage: Math.max(0, Math.min(100, Math.round(+percent))) }] } : {}), ...(skipReview ? { skipReview: true } : {}), ...(blockOnWarnings ? { blockOnWarnings: true } : {}) };
      const j = await cws.call('POST', `/v2/${cws.name(itemId)}:publish`, body, 'Chrome Web Store publish');
      return { state: j.state || '', status: stateLabel(j.state), warnings: (j.warningInfo?.warnings || []).map(w => w.description || w.reason) };
    },
    async rollout(itemId, percent) { await cws.call('POST', `/v2/${cws.name(itemId)}:setPublishedDeployPercentage`, { deployPercentage: Math.round(+percent) }, 'Chrome Web Store rollout'); return { percent: Math.round(+percent) }; },
    async cancel(itemId) { await cws.call('POST', `/v2/${cws.name(itemId)}:cancelSubmission`, {}, 'Chrome Web Store'); return { cancelled: true }; }
  };
  function stateLabel(st) { return ({ PENDING_REVIEW: 'in review', STAGED: 'approved, staged', PUBLISHED: 'published', PUBLISHED_TO_TESTERS: 'published to testers', REJECTED: 'rejected', CANCELLED: 'submission cancelled', NOT_PUBLISHED: 'not published yet' })[st] || (st ? st.toLowerCase().replace(/_/g, ' ') : 'unknown'); }

  // ================================================================ DEV Community (Forem API v1)
  const devto = {
    async call(method, path, body) {
      const k = sec('devto').apiKey; if (!k) throw new Error('DEV isn’t set up yet.');
      return (await http(`https://dev.to/api${path}`, { method, headers: { 'api-key': k, Accept: 'application/vnd.forem.api-v1+json', ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined }, 'DEV')).json;
    },
    async test() { const me = await devto.call('GET', '/users/me'); setSettings('devto', { username: me.username }); return { ok: true, account: `@${me.username}`, detail: me.name || '' }; },
    async articles() {
      const list = await devto.call('GET', '/articles/me/all?per_page=30');
      return (list || []).map(a => ({ id: a.id, title: a.title, url: a.url, published: !!a.published, views: a.page_views_count || 0, reactions: a.public_reactions_count ?? a.positive_reactions_count ?? 0, comments: a.comments_count || 0, date: a.published_at || a.created_at || '' }));
    },
    // "Show DEV, web dev" → showdev, webdev; with no commas, spaces separate tags ("webdev rust")
    tags: t => String(t || '').split(String(t || '').includes(',') ? /,+/ : /[\s#]+/).map(x => x.toLowerCase().replace(/[^a-z0-9]/g, '')).filter(Boolean).slice(0, 4),
    async publish(p) {
      const o = p.options || {}, src = p.source?.app;
      const cover = o.cover !== false && src?.cover && !/^https?:/.test(src.cover) ? `${siteUrl()}/assets/apps/${src.cover}` : (/^https?:/.test(src?.cover || '') ? src.cover : undefined);
      const title = clip(p.title || p.text.split('\n')[0].replace(/^#+\s*/, ''), 128);
      const body = { article: { title, body_markdown: p.text, published: !!o.published, tags: devto.tags(o.tags), series: o.series || undefined,
        canonical_url: o.canonical && p.link ? p.link : undefined, description: clip(o.description || src?.tagline || '', 150) || undefined, main_image: cover, organization_id: o.orgId ? +o.orgId : undefined } };
      const a = await devto.call('POST', '/articles', body);
      return { id: String(a.id), url: a.url || `https://dev.to/dashboard`, draft: !a.published };
    }
  };

  // ================================================================ Ollama
  const OLLAMA_STYLE = {
    x: 'An X (Twitter) post. At most 260 characters including the link. Punchy, one or two short sentences, at most two relevant hashtags at the end. No quotation marks.',
    devto: 'A DEV Community article in Markdown. 400 to 900 words, written by the developer for other developers: a short intro, ## headings, what it is, how it works or what you learned building it, code or steps only if they are in the facts, and a closing line with the link. Helpful, not salesy. No hashtags in the body.',
    mastodon: 'A Mastodon post. At most 450 characters including the link. Friendly and genuine, no hype words, up to three CamelCase hashtags at the end.',
    linkedin: 'A LinkedIn post. 600 to 1200 characters. A strong first line, short paragraphs, what it does and who it is for, a clear call to action with the link, 3 to 5 hashtags at the end. No emoji spam.',
    telegram: 'A Telegram channel post. 200 to 600 characters. Lead with one emoji, a bold-feeling first line, what is new, then the link.',
    discord: 'A Discord announcement. 150 to 600 characters. Casual and excited, one or two emoji, the link on its own line.',
  };
  const ollama = {
    host: () => String(sec('ollama').host || settings('ollama').host || 'http://127.0.0.1:11434').replace(/\/$/, ''),
    async models() { const j = (await http(`${ollama.host()}/api/tags`, { timeout: 5000 }, 'Ollama')).json; return (j.models || []).map(m => ({ name: m.name, size: m.size, params: m.details?.parameter_size || '', family: m.details?.family || '' })); },
    async test() { const m = await ollama.models(); const s = settings('ollama'); return { ok: true, account: ollama.host().replace(/^https?:\/\//, ''), detail: `${m.length} model(s)${s.model ? ` · using ${s.model}` : ''}` }; },
    async chat(messages, { json = false, temperature } = {}) {
      const s = settings('ollama');
      const model = s.model || (await ollama.models())[0]?.name;
      if (!model) throw new Error('No Ollama models installed. Run: ollama pull qwen3:4b-instruct');
      const { json: j } = await http(`${ollama.host()}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, timeout: 240000,
        body: JSON.stringify({ model, messages, stream: false, think: false, format: json ? 'json' : undefined, options: { temperature: temperature ?? s.temperature ?? 0.7, num_ctx: 8192 }, keep_alive: '10m' }) }, 'Ollama');
      return String(j.message?.content || '').replace(/<think>[\s\S]*?<\/think>/g, '').trim();
    },
    // Draft one post per platform for an event or any free topic.
    async draft({ platforms, brief, source, tone, extra }) {
      const s = settings('ollama'), brand = ctx.brand();
      const facts = source ? factsFor(source) : '';
      const sys = `You write social media posts for ${brand}, an independent software studio. ${s.voice ? `Brand voice: ${s.voice}. ` : ''}${tone ? `Tone for this post: ${tone}. ` : ''}Never invent features, prices, numbers, quotes, testimonials or facts that are not given, and never claim personal experiences or stories that are not in the facts. Always include the link exactly as given when one is provided. Write in ${s.language || 'English'}.`;
      const out = {};
      for (const pl of platforms) {
        const style = OLLAMA_STYLE[pl] || 'A short social media post.';
        const wantTitle = pl === 'devto'; // articles need a title
        const user = `${style}\n\n${facts ? `Facts:\n${facts}\n\n` : ''}${brief ? `What to write about: ${brief}\n\n` : ''}${extra ? `Extra instructions: ${extra}\n\n` : ''}${wantTitle ? 'Reply as JSON: {"title": "...", "body": "..."} where the title is at most 120 characters and not clickbait.' : 'Reply with the post text only.'}`;
        const raw = await ollama.chat([{ role: 'system', content: sys }, { role: 'user', content: user }], { json: wantTitle });
        if (wantTitle) { let j = {}; try { j = JSON.parse(raw); } catch { j = { title: raw.split('\n')[0], body: raw }; } out[pl] = { title: clip(j.title, 300), text: String(j.body || '').trim() }; }
        else out[pl] = { text: raw.replace(/^["“]|["”]$/g, '').trim() };
      }
      return out;
    }
  };

  // ---------- facts, templates and images for a post ----------
  function sourceVars(src = {}) {
    const a = src.app || {}, v = src.video || {};
    const url = src.url || (a.id ? `${siteUrl()}/apps/${a.id}/` : v.id ? (v.short ? `https://youtube.com/shorts/${v.id}` : `https://youtu.be/${v.id}`) : siteUrl());
    return { name: a.name || '', tagline: a.tagline || '', version: a.version || '', notes: a.changelog?.[0]?.note || '', price: a.price || '', platform: a.platform || '',
      title: v.title || src.title || '', text: src.text || '', amount: src.amount || '', url, brand: ctx.brand(), site: siteUrl() };
  }
  function factsFor(src) {
    const v = sourceVars(src), a = src.app || {};
    return [a.name && `App: ${a.name}`, a.tagline && `Tagline: ${a.tagline}`, a.description && `Description: ${clip(String(a.description).replace(/[#*_`>]/g, ''), 900)}`, a.version && `Version: ${a.version}`,
      v.notes && `What's new: ${v.notes}`, a.platform && `Platforms: ${a.platform}`, a.price && `Price: ${a.price}`, (a.features || []).length && `Highlights: ${a.features.join('; ')}`,
      v.title && `Video title: ${v.title}`, v.text && `Announcement: ${v.text}`, v.amount && `Milestone: ${v.amount}`, `Link: ${v.url}`].filter(Boolean).join('\n');
  }
  const fill = (t, v) => String(t || '').replace(/\{(\w+)\}/g, (m, k) => v[k] ?? '').replace(/\s+\.\s/g, '. ').replace(/\n{3,}/g, '\n\n').trim();
  function imageFile(p) {
    const rel = p.image || p.source?.app?.cover || p.source?.app?.iconImage;
    if (!rel || /^https?:/.test(rel)) return null;
    const f = join(ctx.mediaDir, rel);
    return existsSync(f) && MIME[extname(f).toLowerCase()] ? f : null;
  }
  function splitThread(text, limit, len = s => s.length) {
    if (len(text) <= limit) return [text];
    // whole sentences per post where possible, words only when a sentence alone is too long
    const room = limit - 6, parts = []; // " 1/9" numbering
    let cur = '';
    const push = () => { if (cur.trim()) parts.push(cur.trim()); cur = ''; };
    for (const s of text.match(/[\s\S]+?(?:[.!?]+(?=\s|$)|\n+|$)\s*/g) || [text]) { // a full stop only ends a sentence before a space, so URLs stay whole
      if (len(cur + s) <= room) { cur += s; continue; }
      push();
      if (len(s) <= room) { cur = s; continue; }
      for (const w of s.split(/(\s+)/)) { if (len(cur + w) > room && cur.trim()) { push(); cur = w.trimStart(); } else cur += w; }
    }
    push();
    return parts.map((p, i) => `${p} ${i + 1}/${parts.length}`);
  }

  // ---------- queue ----------
  const PUB = { x, linkedin, mastodon, telegram, devto, discord };
  function addPost(p) {
    const d = load();
    const post = { id: 'p' + rid(), createdAt: new Date().toISOString(), tries: 0, status: 'review', options: {}, ...p };
    d.queue.unshift(post); save(d);
    return post;
  }
  async function publishPost(post) {
    const pub = PUB[post.platform];
    if (!pub) throw new Error(`Unknown platform ${post.platform}`);
    if (post.platform !== 'discord' && !post.text?.trim()) throw new Error('The post is empty.');
    return pub.publish(post);
  }
  let working = false;
  async function work() {
    if (working) return; working = true;
    try {
      // One post at a time, re-reading the queue around each one, so edits and approvals made meanwhile are never lost.
      const tried = new Set();
      for (;;) {
        const d = load(), now = Date.now(), last = d.lastPost || {};
        const post = d.queue.find(p => !tried.has(p.id) && (p.status === 'approved' || ((p.status === 'scheduled' || p.status === 'retry') && Date.parse(p.at) <= now))
          && !(last[p.platform] && now - last[p.platform] < 45000)); // one post per platform every 45 s
        if (!post) break;
        tried.add(post.id);
        post.status = 'posting'; save(d);
        const upd = {};
        try {
          const r = await publishPost(post);
          Object.assign(upd, { status: 'posted', postedAt: new Date().toISOString(), result: r, error: undefined });
        } catch (e) {
          const tries = (post.tries || 0) + 1, permanent = e.status && e.status >= 400 && e.status < 500 && e.status !== 429;
          Object.assign(upd, { tries, error: e.message }, tries < 3 && !permanent ? { status: 'retry', at: new Date(Date.now() + 2 ** tries * 60000).toISOString() } : { status: 'failed' });
          if (upd.status === 'failed') ctx.alert?.(`⚠️ ${DEFS.find(x => x.id === post.platform)?.name || post.platform} post failed`, `${clip(post.text, 200)}\n${e.message}`);
        }
        const d2 = load(), cur = d2.queue.find(p => p.id === post.id);
        if (cur) Object.assign(cur, upd);
        d2.lastPost = { ...(d2.lastPost || {}), ...(upd.status === 'posted' ? { [post.platform]: Date.now() } : {}) };
        d2.history = [...d2.queue.filter(x => x.status === 'posted'), ...d2.history].slice(0, 300);
        d2.queue = d2.queue.filter(x => x.status !== 'posted');
        save(d2);
      }
    } finally { working = false; }
  }
  setInterval(() => work().catch(e => ctx.log?.('connectors:', e.message)), 20000).unref?.();

  // ---------- automation: hub events → posts ----------
  async function onEvent(event, src) {
    const d = load(), rule = d.rules[event];
    const plats = (rule?.platforms || []).filter(p => PUB[p]);
    if (!rule?.enabled || !plats.length) return;
    const v = sourceVars(src);
    let drafts = {};
    if (rule.ai) { try { drafts = await ollama.draft({ platforms: plats, source: src, tone: rule.tone, extra: rule.prompt }); } catch (e) { ctx.log?.('Ollama draft failed, using templates:', e.message); } }
    for (const pl of plats) {
      const t = rule.templates?.[pl] || rule.template || DEFAULT_TPL[event];
      const text = drafts[pl]?.text || fill(t, v), title = drafts[pl]?.title || fill(rule.titles?.[pl] || DEFAULT_TITLE[event], v);
      addPost({ platform: pl, text, title, link: v.url, source: { event, ...pickSource(src) }, options: { ...(d.settings[pl]?.defaults || {}), ...(rule.options?.[pl] || {}) },
        status: rule.mode === 'auto' ? (rule.delayMin ? 'scheduled' : 'approved') : 'review', at: rule.delayMin ? new Date(Date.now() + rule.delayMin * 60000).toISOString() : undefined, ai: !!drafts[pl] });
    }
    if (rule.mode !== 'auto') ctx.alert?.(`📝 ${plats.length} post${plats.length > 1 ? 's' : ''} waiting for review`, `${EVENTS.find(e => e.id === event)?.label || event}: ${v.name || v.title || v.text}. Open Connectors → Queue to approve.`);
    work().catch(() => {});
    // stores: new release → push to itch / upload to the Chrome Web Store
    if (event === 'app.updated' || event === 'app.available') await deploy(src.app).catch(e => ctx.alert?.('⚠️ Store upload failed', e.message));
  }
  const pickSource = src => ({ app: src.app ? { id: src.app.id, name: src.app.name, tagline: src.app.tagline, version: src.app.version, cover: src.app.cover, iconImage: src.app.iconImage } : undefined, video: src.video ? { id: src.video.id, title: src.video.title, short: src.video.short } : undefined, text: src.text, url: src.url });
  async function deploy(app, { force = false } = {}) {
    if (!app) return [];
    const done = [];
    const it = (settings('itch').maps || []).find(m => m.appId === app.id && (m.auto || force));
    if (it && sec('itch').apiKey) {
      const asset = await ctx.releaseAsset({ appId: app.id, pattern: it.pattern || '' });
      const dir = mkdtempSync(join(tmpdir(), 'itch-')); const f = join(dir, asset.name);
      try { writeFileSync(f, asset.buffer); const r = await itch.push({ file: f, target: it.target, channel: it.channel, version: app.version || asset.tag }); done.push(`itch.io ${it.target}:${it.channel}`); ctx.alert?.(`🎮 Pushed ${app.name} ${app.version || ''} to itch.io`, `${it.target}:${it.channel}\n${r.url}`); }
      finally { rmSync(dir, { recursive: true, force: true }); }
    }
    const cw = (settings('cws').items || []).find(m => m.appId === app.id && (m.auto || force));
    if (cw && sec('cws').refreshToken) {
      const asset = await ctx.releaseAsset({ appId: app.id, pattern: cw.pattern || '.zip' });
      const up = await cws.upload(cw.itemId, asset.buffer);
      let pub = null; if (cw.publish) pub = await cws.publish(cw.itemId, { staged: cw.staged, percent: cw.percent, skipReview: cw.skipReview, blockOnWarnings: cw.blockOnWarnings });
      done.push(`Chrome Web Store ${cw.itemId}`);
      ctx.alert?.(`🧩 Uploaded ${app.name} to the Chrome Web Store`, `Package v${up.version || '?'} · upload ${String(up.state).toLowerCase()}${pub ? `\nSubmitted: ${pub.status}${pub.warnings.length ? ` · ${pub.warnings.join('; ')}` : ''}` : '\nNot submitted yet: publish it from the hub or the developer dashboard.'}`);
    }
    return done;
  }

  // ---------- status of everything ----------
  const TESTS = { x: x.test, devto: devto.test, linkedin: linkedin.test, mastodon: mastodon.test, telegram: telegram.test, itch: itch.test, cws: cws.test, ollama: ollama.test };
  const configured = id => { const c = sec(id); return id === 'ollama' ? true : id === 'linkedin' ? !!c.accessToken : id === 'cws' ? !!c.refreshToken : id === 'x' ? !!(c.clientId || c.refreshToken || (c.apiKey && c.apiSecret) || c.accessToken) : DEFS.find(d => d.id === id).fields.filter(f => !f.opt).every(f => c[f.k] || settings(id)[f.k]); };
  const checks = new Map(); // id → { at, result }
  async function check(id, force = false) {
    const hit = checks.get(id);
    if (!force && hit && Date.now() - hit.at < 5 * 60000) return hit.result;
    let result;
    if (!configured(id)) result = { ok: false, state: 'off' };
    else try { result = { ...(await TESTS[id]()), state: 'on' }; } catch (e) { result = { ok: false, state: 'error', error: e.message }; }
    checks.set(id, { at: Date.now(), result });
    return result;
  }
  async function overview(force) {
    const core = await ctx.core(force).catch(() => ({}));
    const list = await Promise.all(DEFS.map(async d => {
      const st = d.kind === 'core' ? (core[d.id] || { state: 'off' }) : await check(d.id, force);
      const c = sec(d.id);
      // secrets: dots only (plus the last 4 characters of long keys, so you can tell which key is saved)
      const mask = v => (v ? '•'.repeat(8) + (String(v).length >= 16 ? String(v).slice(-4) : '') : '');
      return { ...d, status: st, values: Object.fromEntries((d.fields || []).map(f => [f.k, f.secret ? mask(c[f.k]) : (c[f.k] ?? settings(d.id)[f.k] ?? '')])), settings: publicSettings(d.id) };
    }));
    const dd = load();
    dd.queue = dd.queue.filter(p => PUB[p.platform]);
    for (const r of Object.values(dd.rules || {})) if (r.platforms) r.platforms = r.platforms.filter(p => PUB[p]);
    return { connectors: list, events: EVENTS, defaults: { templates: DEFAULT_TPL, titles: DEFAULT_TITLE }, rules: dd.rules, port: ctx.port,
      redirects: { linkedin: linkedin.redirect(), google: cws.redirect(), x: x.redirect() },
      queue: dd.queue, history: dd.history.slice(0, 60), apps: ctx.loadApps().filter(a => a.published).map(a => ({ id: a.id, name: a.name, version: a.version, cover: a.cover, iconImage: a.iconImage, glyph: a.glyph })) };
  }
  const publicSettings = id => { const { token, tokenExp, ...s } = settings(id); return s; };

  // ---------- OAuth callbacks (no hub token: protected by a one-time state) ----------
  async function oauthCallback(path, url) {
    const page = (ok, msg) => `<!doctype html><meta charset="utf-8"><title>${ok ? 'Connected' : 'Not connected'}</title><body style="font:16px system-ui;background:#07080E;color:#EEF0F8;display:grid;place-items:center;height:100vh;margin:0"><div style="text-align:center;max-width:520px"><div style="font-size:42px">${ok ? '✅' : '⚠️'}</div><h2>${ok ? 'Connected' : 'Something went wrong'}</h2><p style="color:#9AA1BC">${esc(msg)}</p><p style="color:#9AA1BC">You can close this tab and go back to the hub.</p></div><script>setTimeout(()=>{try{window.close()}catch{}},2500)</script>`;
    if (path === '/oauth/x' && !url.searchParams.get('state')) {
      const tok = url.searchParams.get('oauth_token'), ver = url.searchParams.get('oauth_verifier'), sx = pending.get(tok);
      if (url.searchParams.get('denied')) return page(false, 'Sign-in was cancelled on X.');
      if (!sx || Date.now() - sx.at > 15 * 60000) return page(false, 'This sign-in link expired. Press Sign in with X in the hub again.');
      pending.delete(tok);
      try { await x.callback(tok, ver, sx); checks.delete('x'); return page(true, 'X is connected.'); } catch (e) { return page(false, e.message); }
    }
    const state = url.searchParams.get('state'), code = url.searchParams.get('code'), st = pending.get(state);
    if (url.searchParams.get('error')) return page(false, url.searchParams.get('error_description') || url.searchParams.get('error'));
    if (!st || Date.now() - st.at > 15 * 60000) return page(false, 'This sign-in link expired. Press Connect in the hub again.');
    pending.delete(state);
    try {
      if (path === '/oauth/linkedin' && st.id === 'linkedin') await linkedin.callback(code);
      else if (path === '/oauth/google' && st.id === 'cws') await cws.callback(code, st);
      else if (path === '/oauth/x' && st.id === 'x') await x.callback2(code, st);
      else return page(false, 'Unknown sign-in.');
      checks.delete(st.id);
      return page(true, `${DEFS.find(d => d.id === st.id).name} is connected.`);
    } catch (e) { return page(false, e.message); }
  }

  // ---------- API ----------
  async function route(path, M, body, url) {
    const id = path.split('/')[3];
    if (path === '/api/connectors' && M === 'GET') return overview(url?.searchParams.get('force') === '1');
    if (path === '/api/connectors/rules' && M === 'PUT') { const d = load(); d.rules = { ...d.rules, ...(body.rules || {}) }; save(d); return { rules: d.rules }; }
    if (path === '/api/connectors/draft' && M === 'POST') {
      const src = body.appId ? { app: ctx.loadApps().find(a => a.id === body.appId), url: body.url || undefined } : body.videoId ? { video: (ctx.loadSite().youtube?.videos || []).find(v => v.id === body.videoId) } : body.text ? { text: body.text, url: body.url } : null;
      if (body.ai) return { drafts: await ollama.draft({ platforms: body.platforms, brief: body.brief, source: src, tone: body.tone, extra: body.extra }) };
      const v = sourceVars(src || {}), ev = body.event || 'manual';
      return { drafts: Object.fromEntries(body.platforms.map(pl => [pl, { text: fill(DEFAULT_TPL[ev] || '{text}', { ...v, text: v.text || body.brief || '' }), title: fill(DEFAULT_TITLE[ev] || '{title}', { ...v, title: v.title || v.name || clip(body.brief, 120) }) }])), link: v.url };
    }
    if (path === '/api/connectors/queue' && M === 'POST') {
      const created = (body.posts || []).map(p => addPost({ platform: p.platform, text: p.text, title: p.title, link: p.link, image: p.image, options: p.options || {}, source: p.source || { event: 'manual' },
        status: body.when === 'now' ? 'approved' : body.when === 'later' ? 'scheduled' : 'review', at: body.when === 'later' ? new Date(body.at).toISOString() : undefined, ai: !!p.ai }));
      work().catch(() => {}); return { created: created.length, ...(await overview(false)) };
    }
    const qm = path.match(/^\/api\/connectors\/queue\/(p[0-9a-f]+)$/);
    if (qm) {
      const d = load(), p = d.queue.find(x => x.id === qm[1]) || d.history.find(x => x.id === qm[1]);
      if (!p) throw new Error('That post is gone.');
      if (M === 'PUT') { for (const k of ['text', 'title', 'link', 'options', 'at']) if (k in body) p[k] = body[k]; if (body.action === 'approve') p.status = p.at && Date.parse(p.at) > Date.now() ? 'scheduled' : 'approved'; if (body.action === 'reject') p.status = 'rejected'; if (body.action === 'retry') { p.status = 'approved'; p.tries = 0; } save(d); work().catch(() => {}); }
      if (M === 'DELETE') { d.queue = d.queue.filter(x => x.id !== p.id); d.history = d.history.filter(x => x.id !== p.id); save(d); }
      return overview(false);
    }
    if (!id || !DEFS.some(d => d.id === id)) return undefined;
    const def = DEFS.find(d => d.id === id);
    if (path === `/api/connectors/${id}` && M === 'PUT') {
      const patch = {};
      for (const f of def.fields || []) if (f.k in (body.values || {})) { const v = String(body.values[f.k] ?? '').trim(); if (f.secret && /^•+/.test(v)) continue; patch[f.k] = v; }
      setSec(id, patch);
      if (body.settings) { const { token, tokenExp, ...rest } = body.settings; setSettings(id, rest); }
      checks.delete(id);
      return { status: await check(id, true), settings: publicSettings(id) };
    }
    if (path === `/api/connectors/${id}` && M === 'DELETE') { const all = { ...(ctx.secrets().connectors || {}) }; delete all[id]; ctx.saveSecrets({ connectors: all }); const d = load(); delete d.settings[id]; save(d); checks.delete(id); return overview(false); }
    if (path === `/api/connectors/${id}/test` && M === 'POST') return { status: await check(id, true) };
    if (path === `/api/connectors/${id}/connect` && M === 'POST') return id === 'x' ? await x.authUrl() : { url: id === 'linkedin' ? linkedin.authUrl() : cws.authUrl() };
    if (id === 'x' && path.endsWith('/pin') && M === 'POST') return await x.pin(body.pin);
    if (id === 'devto' && path.endsWith('/articles') && M === 'GET') return { articles: await devto.articles() };
    if (id === 'telegram' && path.endsWith('/chats') && M === 'GET') return { chats: await telegram.findChats() };
    if (id === 'ollama' && path.endsWith('/models') && M === 'GET') return { models: await ollama.models() };
    if (id === 'itch' && path.endsWith('/games') && M === 'GET') return { games: await itch.games(), butler: await itch.butlerVersion() };
    if (id === 'itch' && path.endsWith('/push') && M === 'POST') {
      const app = ctx.loadApps().find(a => a.id === body.appId); const map = (settings('itch').maps || []).find(m => m.appId === body.appId);
      if (!app || !map) throw new Error('Map this app to an itch.io page first.');
      return { done: await deploy(app, { force: true }) };
    }
    if (id === 'cws' && path.endsWith('/items') && M === 'GET') return { items: await Promise.all((settings('cws').items || []).map(async m => ({ ...m, live: await cws.item(m.itemId).catch(e => ({ error: e.message })) }))) };
    if (id === 'cws' && path.endsWith('/upload') && M === 'POST') {
      const buf = Buffer.from(String(body.data || ''), 'base64'); if (!buf.length) throw new Error('Choose the extension .zip.');
      const up = await cws.upload(body.itemId, buf);
      const pub = body.publish ? await cws.publish(body.itemId, { staged: !!body.staged, percent: +body.percent || undefined, skipReview: !!body.skipReview, blockOnWarnings: !!body.blockOnWarnings }) : null;
      return { upload: up, publish: pub };
    }
    if (id === 'cws' && path.endsWith('/publish') && M === 'POST') return { publish: await cws.publish(body.itemId, { staged: !!body.staged, percent: +body.percent || undefined, skipReview: !!body.skipReview, blockOnWarnings: !!body.blockOnWarnings }) };
    if (id === 'cws' && path.endsWith('/rollout') && M === 'POST') return await cws.rollout(body.itemId, body.percent);
    if (id === 'cws' && path.endsWith('/cancel') && M === 'POST') return await cws.cancel(body.itemId);
    if (id === 'cws' && path.endsWith('/deploy') && M === 'POST') { const app = ctx.loadApps().find(a => a.id === body.appId); return { done: await deploy(app, { force: true }) }; }
    return undefined;
  }

  return { route, onEvent, oauthCallback, overview, work, _test: { oauth1, splitThread, xLen, fill, sourceVars } };
}
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
