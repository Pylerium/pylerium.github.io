// Pylerium Manager: a local app that builds and runs a creator's whole studio site on GitHub Pages:
// apps catalog, publishing, Stripe sales, supporter codes, automatic emails and Discord alerts.
// Zero dependencies. Listens on 127.0.0.1 only. Start it with the "Pylerium Manager" launcher.
import { createServer } from 'node:http';
import { readFileSync, writeFileSync, existsSync, mkdirSync, statSync, readdirSync, rmSync, renameSync, createReadStream } from 'node:fs';
import { join, resolve, extname, sep, basename } from 'node:path';
import { spawn } from 'node:child_process';
import { randomBytes, randomInt, createHash } from 'node:crypto';
import { HUB, ROOT, DATA, MEDIA as MEDIA_DIR, SITE, PRODUCT, loadConfig, loadApps, loadSite, loadSupporters, buildSite, publishedApps, markPaid, sortApps, publicData, brandName, setPerksProvider } from './build.mjs';
import { createGitHub, siteUrlFor } from './github.mjs';
import { createLicensing } from './license.mjs';
import { createNotifier } from './notify.mjs';
import { createStore } from './store.mjs';
import { createPerks } from './perks.mjs';
import { createDelivery } from './delivery.mjs';
import { createLicences, KITS } from './licences.mjs';
import { createTax } from './tax.mjs';
import { createSync } from './sync.mjs';
import { createConnectors } from './connectors.mjs';

const cfg = loadConfig();
const PORT = +(process.env.PM_PORT || cfg.port || PRODUCT.port || 4380);
const TOKEN = randomBytes(18).toString('hex');
const DATA_DIR = DATA;
const BACKUPS = join(DATA_DIR, 'backups');
const MEDIA = MEDIA_DIR;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.mp4': 'video/mp4', '.webm': 'video/webm',
  '.gif': 'image/gif', '.avif': 'image/avif', '.ico': 'image/x-icon', '.xml': 'application/xml', '.txt': 'text/plain; charset=utf-8' };
const IMG_EXT = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif', '.svg', '.avif']);
const UA = `Mozilla/5.0 (compatible) PyleriumManager/${PRODUCT.version}`;

// ---------- data files ----------
const readJson = (f, d) => { try { return JSON.parse(readFileSync(join(DATA_DIR, f), 'utf8')); } catch { return d; } };
function writeJson(f, value, backup = true) {
  const p = join(DATA_DIR, f);
  mkdirSync(BACKUPS, { recursive: true });
  if (backup && existsSync(p)) {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const pre = f.replace('.json', '');
    writeFileSync(join(BACKUPS, `${pre}-${stamp}.json`), readFileSync(p));
    const old = readdirSync(BACKUPS).filter(n => n.startsWith(pre + '-')).sort();
    for (const n of old.slice(0, Math.max(0, old.length - 30))) rmSync(join(BACKUPS, n));
  }
  writeFileSync(p + '.tmp', JSON.stringify(value, null, 2) + '\n');
  renameSync(p + '.tmp', p);
}
const saveApps = apps => writeJson('apps.json', sortApps(apps));
const saveSite = s => writeJson('site.json', s);
const saveSupporters = s => writeJson('supporters.json', s);
const secrets = () => readJson('secrets.json', {});
const saveSecrets = patch => writeJson('secrets.json', { ...secrets(), ...patch }, false);
let N = null, STORE = null, PERKS = null, CONNECTORS = null; // Discord notifier + Stripe store, created at the bottom
const LICENCES = createLicences({ dataDir: DATA_DIR }); // licence keys for the apps you sell (not Pylerium Manager's own licence)
// First run: give the customer a starter site and one sample app.
if (!existsSync(join(DATA_DIR, 'site.json'))) {
  const site = JSON.parse(readFileSync(join(HUB, 'defaults', 'site.json'), 'utf8'));
  site.community.salt = randomBytes(12).toString('hex');
  writeJson('site.json', site, false);
}
if (!existsSync(join(DATA_DIR, 'apps.json'))) writeJson('apps.json', JSON.parse(readFileSync(join(HUB, 'defaults', 'apps.json'), 'utf8')), false);
const GH = createGitHub({ token: () => secrets().githubToken || '', fetchT: (...a) => fetchT(...a) });
const LIC = createLicensing({ product: PRODUCT, readJson, writeJson, fetchT: (...a) => fetchT(...a) });
function saveConfig(patch) {
  const cur = readJson('config.json', {});
  const next = { ...cur, ...patch };
  writeJson('config.json', next, false);
  Object.assign(cfg, next, { siteDirAbs: SITE });
  N?.reconfig?.();
}
let lastSubs = null;
const today = () => new Date().toISOString().slice(0, 10);
const slug = s => String(s || '').toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '').trim().replace(/[\s_]+/g, '-').replace(/-+/g, '-').slice(0, 48) || 'app';
const sha = s => createHash('sha256').update(s).digest('hex');

function clean(a) {
  const str = v => (typeof v === 'string' ? v.trim() : '');
  const arr = v => (Array.isArray(v) ? v.map(x => (typeof x === 'string' ? x.trim() : x)).filter(Boolean) : []);
  return {
    id: slug(a.id || a.name), name: str(a.name) || 'Untitled app', tagline: str(a.tagline), description: str(a.description),
    category: str(a.category) || 'desktop', status: str(a.status) || 'dev', version: str(a.version), platform: str(a.platform),
    price: str(a.price), licensed: a.licensed ? true : undefined, repoPrivate: a.repoPrivate ? true : undefined, requirements: str(a.requirements), badge: str(a.badge),
    featured: !!a.featured, published: !!a.published, order: Number.isFinite(+a.order) ? +a.order : 999,
    accent: str(a.accent) || 'studio', glyph: str(a.glyph) || 'code', iconImage: str(a.iconImage), cover: str(a.cover), screenshots: arr(a.screenshots),
    metricLabel: str(a.metricLabel), metricValue: str(a.metricValue), techStack: arr(a.techStack),
    primaryLabel: str(a.primaryLabel), primaryUrl: str(a.primaryUrl), pageUrl: str(a.pageUrl), repoUrl: str(a.repoUrl), docsUrl: str(a.docsUrl), videoUrl: str(a.videoUrl),
    installCommand: str(a.installCommand), features: arr(a.features), embedTitle: str(a.embedTitle), embedCode: typeof a.embedCode === 'string' ? a.embedCode : '',
    changelog: (Array.isArray(a.changelog) ? a.changelog : []).map(c => ({ ver: str(c.ver), date: str(c.date), note: str(c.note) })).filter(c => c.ver || c.note),
    community: !!a.community, author: a.author && (a.author.name || a.author.url) ? { name: str(a.author.name), url: str(a.author.url) } : undefined,
    submission: a.submission || undefined,
    createdAt: /^\d{4}-\d{2}-\d{2}$/.test(a.createdAt) ? a.createdAt : undefined,
    updatedAt: /^\d{4}-\d{2}-\d{2}$/.test(a.updatedAt) ? a.updatedAt : today(),
    localPath: str(a.localPath), notes: typeof a.notes === 'string' ? a.notes : ''
  };
}
function upsertApp(body, prevId) {
  const apps = loadApps();
  const a = clean(body);
  const idx = prevId ? apps.findIndex(x => x.id === prevId) : -1; // no prevId = brand-new app, never overwrite
  let id = a.id, n = 2;
  while (apps.some((x, i) => x.id === id && i !== idx)) id = `${a.id}-${n++}`;
  a.id = id;
  if (idx >= 0) { a.createdAt = a.createdAt || apps[idx].createdAt; apps[idx] = a; }
  else { a.createdAt = a.createdAt || today(); a.order = Math.min(1, ...apps.map(x => x.order ?? 1)) - 1; apps.push(a); }
  saveApps(apps);
  return a;
}

// ---------- processes ----------
function run(cmd, args, cwd, input) {
  return new Promise(res => {
    const p = spawn(cmd, args, { cwd, windowsHide: true });
    let out = '', err = '';
    p.stdout.on('data', d => (out += d)); p.stderr.on('data', d => (err += d));
    p.on('error', e => res({ code: -1, out, err: String(e.message) }));
    p.on('close', code => res({ code, out, err }));
    if (input) p.stdin.end(input);
  });
}
async function fetchT(url, opts = {}, ms = 15000) {
  const ac = new AbortController(); const t = setTimeout(() => ac.abort(), ms);
  try { return await fetch(url, { ...opts, signal: ac.signal, headers: { 'User-Agent': UA, ...(opts.headers || {}) } }); } finally { clearTimeout(t); }
}

// ---------- change detection ----------
// What the public site is built from. Compared with the snapshot saved at the last publish.
function publicSnapshot() {
  const site = loadSite();
  const pub = markPaid(publishedApps(loadApps()));
  const { youtube, community, ...rest } = site;
  return {
    apps: pub,
    site: { ...rest, youtube: { ...(youtube || {}), lastSync: undefined }, community: { ...(community || {}) } },
    data: publicData(pub, site, loadSupporters(), cfg),
    wall: loadSupporters().filter(s => s.wall).map(s => s.wallName || s.name)
  };
}
function diffCatalog(before, after) {
  const b = new Map(before.map(a => [a.id, a])), out = [];
  for (const a of after) {
    if (!b.has(a.id)) out.push({ kind: 'added', name: a.name });
    else if (JSON.stringify(b.get(a.id)) !== JSON.stringify(a)) out.push({ kind: 'updated', name: a.name });
    b.delete(a.id);
  }
  for (const a of b.values()) out.push({ kind: 'removed', name: a.name });
  return out;
}
async function siteStatus() {
  const snap = publicSnapshot();
  const last = readJson('published.json', null);
  const changes = diffCatalog(last?.apps || [], snap.apps);
  if (last) {
    const S = snap.site, L = last.site || {};
    const lbl = { hero: 'Hero text', announcement: 'Announcement bar', sections: 'Sections', categories: 'Categories', socials: 'Social links', embeds: 'Embeds', donate: 'Supply caffeine button', brand: 'Brand', community: 'Community settings', youtube: 'YouTube videos', principles: 'Studio highlights' };
    for (const k of Object.keys(lbl)) if (JSON.stringify(S[k]) !== JSON.stringify(L[k])) changes.push({ kind: 'updated', name: lbl[k] });
    if (JSON.stringify(snap.data.community?.codes) !== JSON.stringify(last.data?.community?.codes)) changes.push({ kind: 'updated', name: 'Supporter codes' });
    if (JSON.stringify(snap.data.perks || null) !== JSON.stringify(last.data?.perks || null)) changes.push({ kind: 'updated', name: 'Perks' });
    if (JSON.stringify(snap.wall) !== JSON.stringify(last.wall)) changes.push({ kind: 'updated', name: 'Supporters wall' });
  } else changes.push({ kind: 'added', name: 'Your whole site (first publish)' });
  const m = last?.meta;
  return { repoOk: !!(cfg.repo && secrets().githubToken), connected: !!secrets().githubToken, changes, workingFiles: 0, ahead: 0,
    lastCommit: m ? { hash: m.commit, subject: m.message, date: m.at, url: m.commitUrl } : null, siteUrl: cfg.siteUrl, repo: cfg.repo || '' };
}

let publishing = false;
async function publish(message) {
  if (publishing) throw new Error('A publish is already running.');
  publishing = true;
  const log = [];
  const auto = /^Auto-publish/.test(message || '');
  const before = readJson('published.json', null);
  let pending = [];
  try { pending = (await siteStatus()).changes; } catch {}
  const step = async (label, p) => { const r = await p; log.push(`$ ${label}\n${(r.out + r.err).trim()}`); if (r.code !== 0) throw Object.assign(new Error(`${label} failed`), { log }); return r; };
  try {
    const site = loadSite();
    if (site.youtube?.autoSync && site.youtube.channelUrl) {
      try { const y = await youtubeSync(); log.push(`YouTube: ${y.videos.length} videos (${y.added} new)`); } catch (e) { log.push(`YouTube sync skipped: ${e.message}`); }
    }
    if (!LIC.canPublish()) throw new Error(`${LIC.state().msg || 'No licence.'} Activate your licence in Settings → Licence to publish.`);
    if (!cfg.repo || !secrets().githubToken) throw new Error('Connect GitHub and pick your site first (Settings → GitHub).');
    const b = buildSite();
    log.push(`Built ${b.published} published app(s)` + (b.missing.length ? `\nMissing images: ${b.missing.join(', ')}` : ''));
    const r = await GH.pushDir(cfg.repo, cfg.branch || 'main', SITE, { message: message || `Update ${brandName(loadSite())}`, previous: before?.files || {}, onStep: t => log.push(t) });
    log.push(r.nothing ? 'Everything was already up to date on GitHub.' : `GitHub commit ${r.commit}: ${r.uploaded} file(s) uploaded${r.removed ? `, ${r.removed} removed` : ''}.`);
    const after = { ...publicSnapshot(), files: r.files, meta: { commit: r.commit, commitUrl: r.commitUrl, at: new Date().toISOString(), message: message || 'Update site' } };
    writeJson('published.json', after, false);
    N?.afterPublish(before, after, { message, auto, changes: pending, commit: r.commit, commitUrl: r.commitUrl }).catch(() => {});
    return { ok: true, log: log.join('\n\n'), url: cfg.siteUrl };
  } catch (e) { log.push(e.message); e.log = (Array.isArray(e.log) ? e.log : log).join('\n\n'); N?.publishFailed(e, auto).catch(() => {}); throw e; }
  finally { publishing = false; }
}

// ---------- GitHub ----------
async function ghApi(path, method = 'GET', fields = {}) {
  if (secrets().githubToken) return GH.api('/' + path, { method, body: method === 'GET' ? undefined : fields, ok404: method === 'GET' });
  const res = await fetchT('https://api.github.com/' + path, { headers: { Accept: 'application/vnd.github+json' } });
  if (res.status === 404) return null;
  if (!res.ok) throw new Error(`GitHub API ${res.status}`);
  return res.json();
}
async function githubInfo(repoUrl) {
  const m = String(repoUrl).match(/github\.com\/([\w.-]+)\/([\w.-]+?)(?:\.git)?(?:[/#?].*)?$/i);
  if (!m) throw new Error('Not a GitHub repository URL.');
  const full = `${m[1]}/${m[2]}`;
  const repo = await ghApi(`repos/${full}`);
  if (!repo) throw new Error('Repository not found (or it is private).');
  let release = null;
  try { release = await ghApi(`repos/${full}/releases/latest`); } catch {}
  return { description: repo.description || '', homepage: repo.homepage || '', language: repo.language || '', topics: repo.topics || [],
    pushedAt: repo.pushed_at, private: repo.private, htmlUrl: repo.html_url,
    release: release && release.tag_name ? { tag: release.tag_name, name: release.name, date: release.published_at, url: release.html_url, body: (release.body || '').slice(0, 600) } : null };
}

// ---------- YouTube (public RSS feed, no API key) ----------
async function resolveChannel(input) {
  const s = String(input || '').trim();
  let m = s.match(/(UC[\w-]{22})/);
  if (m) return { id: m[1], url: s.startsWith('http') ? s : `https://www.youtube.com/channel/${m[1]}` };
  let url = s;
  if (/^@[\w.-]+$/.test(s)) url = `https://www.youtube.com/${s}`;
  if (!/^https?:\/\//.test(url)) throw new Error('Enter a YouTube channel link, like https://www.youtube.com/@YourChannel');
  const res = await fetchT(url, { headers: { 'Accept-Language': 'en' } });
  const html = await res.text();
  m = html.match(/<link rel="canonical" href="https:\/\/www\.youtube\.com\/channel\/(UC[\w-]{22})"/) || html.match(/"externalId":"(UC[\w-]{22})"/) || html.match(/"channelId":"(UC[\w-]{22})"/);
  if (!m) throw new Error("Couldn't find that channel. Check the link.");
  return { id: m[1], url: url.replace(/\/(videos|shorts|featured|streams)\/?$/, '') };
}
const decodeXml = s => String(s || '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
async function isShort(id) {
  try { const r = await fetchT(`https://www.youtube.com/shorts/${id}`, { method: 'HEAD', redirect: 'manual' }, 8000); return r.status === 200; } catch { return false; }
}
async function youtubeSync(channelInput, { quiet = false } = {}) {
  const site = loadSite();
  const y = site.youtube = site.youtube || { videos: [] };
  if (channelInput && channelInput !== y.channelUrl) { y.channelUrl = channelInput; y.channelId = ''; }
  if (!y.channelUrl) throw new Error('Add your YouTube channel link first.');
  if (!y.channelId) { const c = await resolveChannel(y.channelUrl); y.channelId = c.id; y.channelUrl = c.url; }
  const res = await fetchT(`https://www.youtube.com/feeds/videos.xml?channel_id=${y.channelId}`);
  if (!res.ok) throw new Error(`YouTube feed returned ${res.status}`);
  const xml = await res.text();
  y.title = decodeXml((xml.match(/<title>([^<]*)<\/title>/) || [])[1] || y.title || '');
  const entries = [...xml.matchAll(/<entry>([\s\S]*?)<\/entry>/g)].map(e => e[1]);
  const byId = new Map((y.videos || []).map(v => [v.id, v]));
  let added = 0; const fresh = [];
  for (const e of entries) {
    const id = (e.match(/<yt:videoId>([^<]+)/) || [])[1];
    if (!id) continue;
    const v = byId.get(id) || { id, hidden: false, pinned: false };
    const isNew = !byId.has(id);
    if (isNew) { added++; v.short = await isShort(id); }
    v.title = decodeXml((e.match(/<title>([^<]*)<\/title>/) || [])[1] || v.title);
    v.published = (e.match(/<published>([^<]+)/) || [])[1] || v.published;
    v.views = +((e.match(/<media:statistics views="(\d+)"/) || [])[1] || v.views || 0);
    if (isNew && /^\s*(\S+\s+){0,4}(test|testing)\s*$/i.test(v.title)) v.hidden = true; // quick tests stay off the site
    v.description = decodeXml((e.match(/<media:description>([\s\S]*?)<\/media:description>/) || [])[1] || '').slice(0, 300);
    byId.set(id, v);
    if (isNew) fresh.push(v);
  }
  y.videos = [...byId.values()].sort((a, b) => (b.published || '').localeCompare(a.published || ''));
  y.lastSync = new Date().toISOString();
  writeJson('site.json', site, !quiet); // the background watcher doesn't fill the backups folder
  if (fresh.length) N?.newVideos(fresh).catch(() => {});
  return { ...y, added, fresh };
}
async function youtubeAdd(url) {
  const id = (String(url).match(/(?:youtu\.be\/|v=|shorts\/|embed\/|live\/)([\w-]{11})/) || [])[1];
  if (!id) throw new Error('That is not a YouTube video link.');
  const site = loadSite();
  const y = site.youtube = site.youtube || { videos: [] };
  if (y.videos.some(v => v.id === id)) throw new Error('That video is already in the list.');
  let title = 'Video';
  try { const o = await (await fetchT(`https://www.youtube.com/oembed?format=json&url=${encodeURIComponent('https://www.youtube.com/watch?v=' + id)}`)).json(); title = o.title || title; } catch {}
  y.videos.unshift({ id, title, published: new Date().toISOString(), views: 0, short: /shorts\//.test(url) || (await isShort(id)), hidden: false, pinned: false, manual: true });
  saveSite(site);
  return y;
}

// ---------- supporters ----------
const CODE_ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const normCode = c => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
function newCode() {
  const g = () => Array.from({ length: 4 }, () => CODE_ABC[randomInt(CODE_ABC.length)]).join('');
  return `${(loadSite().community?.codePrefix || 'CAFE').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8) || 'CAFE'}-${g()}-${g()}-${g()}`;
}
function revokeCode(id) {
  const list = loadSupporters(), s = list.find(x => x.id === id);
  if (!s) throw new Error('Supporter not found');
  s.revoked = true; s.revokedAt = new Date().toISOString();
  saveSupporters(list);
  return s;
}
// perkOnly: a code made just to open perks; it doesn't unlock app submissions (see perks.mjs submitAllowed).
function upgradeCode(id) {
  const list = loadSupporters(), s = list.find(x => x.id === id);
  if (!s) throw new Error('Supporter not found');
  delete s.codeFor; saveSupporters(list); return s;
}
function issueCode(id, { perkOnly = false } = {}) {
  const site = loadSite(), list = loadSupporters();
  const s = list.find(x => x.id === id);
  if (!s) throw new Error('Supporter not found');
  if (perkOnly) s.codeFor = 'perks'; else delete s.codeFor;
  s.code = newCode();
  s.codeHash = sha(`${site.community.salt}:${normCode(s.code)}`);
  s.issuedAt = new Date().toISOString();
  s.revoked = false;
  saveSupporters(list);
  return s;
}
async function stripeGet(path, key) {
  const res = await fetchT((process.env.PM_STRIPE_API || 'https://api.stripe.com/v1') + '/' + path, { headers: { Authorization: `Bearer ${key}` } });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(j.error?.message || `Stripe returned ${res.status}`);
  return j;
}
async function stripeList(path, key, max = 20) {
  const out = []; let after = '';
  for (let i = 0; i < max; i++) {
    const j = await stripeGet(`${path}${path.includes('?') ? '&' : '?'}limit=100${after ? `&starting_after=${after}` : ''}`, key);
    out.push(...j.data);
    if (!j.has_more || !j.data.length) break;
    after = j.data[j.data.length - 1].id;
  }
  return out;
}
async function stripeSync() {
  const key = secrets().stripeKey;
  if (!key) throw new Error('Add a Stripe restricted key in Community → Settings first.');
  const site = loadSite();
  const donateLink = (site.donate?.url || '').match(/(?:buy|donate)\.stripe\.com\/(?:test_)?([\w]+)/)?.[1];
  const charges = await stripeList('charges', key);
  let sessions = [];
  try { sessions = await stripeList('checkout/sessions?status=complete', key, 10); } catch {}
  const agg = new Map();
  const get = email => { const k = email.toLowerCase(); if (!agg.has(k)) agg.set(k, { email: k, name: '', total: 0, other: 0, count: 0, firstAt: null, lastAt: null, donation: false, wallName: '' }); return agg.get(k); };
  for (const c of charges) {
    if (!c.paid || c.status !== 'succeeded') continue;
    const email = c.billing_details?.email || c.receipt_email;
    if (!email) continue;
    const a = get(email);
    const net = (c.amount - (c.amount_refunded || 0)) / 100;
    if (net <= 0) continue;
    if ((c.currency || '').toLowerCase() === (site.community?.currency || 'AUD').toLowerCase()) a.total += net; else a.other += net;
    a.count++; a.name = a.name || c.billing_details?.name || '';
    const at = new Date(c.created * 1000).toISOString();
    a.firstAt = !a.firstAt || at < a.firstAt ? at : a.firstAt; a.lastAt = !a.lastAt || at > a.lastAt ? at : a.lastAt;
  }
  for (const s of sessions) {
    const email = s.customer_details?.email; if (!email) continue;
    const a = get(email);
    a.name = a.name || s.customer_details?.name || '';
    if (donateLink && String(s.payment_link || '').length && site.donate?.url) a.donation = true;
    const f = (s.custom_fields || []).find(f => /name|wall|credit/i.test(f.key + ' ' + (f.label?.custom || '')));
    if (f?.text?.value) a.wallName = f.text.value.slice(0, 40);
  }
  const list = loadSupporters();
  let added = 0, updated = 0;
  for (const a of agg.values()) {
    let s = list.find(x => (x.email || '').toLowerCase() === a.email);
    if (!s) { s = { id: 'sp-' + randomBytes(5).toString('hex'), email: a.email, wall: false, notes: '', type: a.donation ? 'donation' : 'purchase', source: 'stripe' }; list.push(s); added++; } else updated++;
    Object.assign(s, { name: s.name || a.name, total: Math.round(a.total * 100) / 100, otherCurrency: Math.round(a.other * 100) / 100, payments: a.count, firstAt: a.firstAt, lastAt: a.lastAt, source: 'stripe' });
    if (a.wallName && !s.wallName) { s.wallName = a.wallName; s.wall = true; }
  }
  saveSupporters(list);
  return { added, updated, supporters: list };
}

// ---------- submissions ----------
const MARK = '<!-- pylerium-submission -->';
function parseSubmission(text) {
  const m = String(text || '').match(/```json\s*([\s\S]*?)```/) || String(text || '').match(/(\{[\s\S]*"v"\s*:\s*1[\s\S]*\})/);
  if (!m) return null;
  try { const d = JSON.parse(m[1]); return d && d.name ? d : null; } catch { return null; }
}
function verify(d) {
  if (!d?.proof) return null;
  for (const s of loadSupporters()) {
    if (!s.code || s.revoked) continue;
    if (sha(`proof:${normCode(s.code)}:${d.name}:${d.submittedAt}`) === d.proof) return { id: s.id, name: s.wallName || s.name || s.email, total: s.total || 0, type: s.type };
  }
  return null;
}
async function listSubmissions() {
  const r = await listSubmissionsRaw();
  lastSubs = { at: Date.now(), pending: (r.items || []).filter(i => !i.handled && i.state !== 'closed').length, total: (r.items || []).length };
  N?.seenSubmissions(r.items).catch(() => {});
  return r;
}
async function listSubmissionsRaw() {
  const site = loadSite(), st = readJson('submissions.json', { handled: {}, manual: [] });
  const repo = site.community?.repo || cfg.repo || '';
  if (!repo) return { items: (st.manual || []).map(m => ({ ...m, verified: verify(m.data), handled: st.handled[m.key] || null })), ghError: 'Connect GitHub first', repo };
  const out = []; let ghError = '';
  try {
    const issues = (await ghApi(`repos/${repo}/issues?state=all&per_page=100&sort=created&direction=desc`)) || [];
    for (const i of issues) {
      if (i.pull_request || !(i.body || '').includes('```json') || !/^\[Submission\]/i.test(i.title) && !(i.body || '').includes(MARK)) continue;
      const d = parseSubmission(i.body);
      out.push({ key: 'gh-' + i.number, source: 'github', number: i.number, url: i.html_url, user: i.user?.login, state: i.state, createdAt: i.created_at, data: d, verified: verify(d), handled: st.handled['gh-' + i.number] || null });
    }
  } catch (e) { ghError = e.message; }
  for (const m of st.manual || []) out.push({ ...m, verified: verify(m.data), handled: st.handled[m.key] || null });
  out.sort((a, b) => (!!a.handled - !!b.handled) || (b.createdAt || '').localeCompare(a.createdAt || ''));
  return { items: out, ghError, repo };
}
async function downloadImage(url, dir, base) {
  const res = await fetchT(url, {}, 20000);
  const type = res.headers.get('content-type') || '';
  if (!res.ok || !type.startsWith('image/')) throw new Error('not an image');
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length > 12 * 1024 * 1024) throw new Error('too large');
  const ext = { 'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp', 'image/gif': '.gif', 'image/avif': '.avif' }[type.split(';')[0]] || '.png';
  mkdirSync(dir, { recursive: true });
  writeFileSync(join(dir, base + ext), buf);
  return base + ext;
}
async function acceptSubmission(key, { publish: pub = false, reply = '', close = false } = {}) {
  const { items, repo } = await listSubmissions();
  const it = items.find(x => x.key === key);
  if (!it?.data) throw new Error('Submission not found or unreadable.');
  const d = it.data, site = loadSite();
  const cats = site.categories || [];
  const cat = cats.find(c => c.id === d.category) || cats[0] || { id: 'desktop', icon: 'code' };
  const accents = ['studio', 'violet', 'sky', 'emerald', 'amber', 'ember', 'rose'];
  const app = upsertApp({ name: d.name, tagline: d.tagline, description: d.description, category: cat.id, platform: d.platform, status: 'live',
    community: true, author: d.author, published: false, glyph: cat.icon || 'puzzle', accent: accents[randomInt(accents.length)],
    primaryLabel: 'Download', primaryUrl: d.url, repoUrl: d.repoUrl, videoUrl: d.videoUrl,
    submission: { key, source: it.source, url: it.url || '', user: it.user || '', supporter: it.verified?.name || '', at: d.submittedAt },
    notes: `Community submission from ${d.author?.name || 'unknown'}${it.user ? ` (@${it.user})` : ''}${it.verified ? `, verified supporter: ${it.verified.name}` : ', NOT verified'}.\n${it.url || ''}` });
  const dir = join(MEDIA, app.id), apps = loadApps(), a = apps.find(x => x.id === app.id);
  const m = String(d.icon || '').match(/^data:image\/(png|webp|jpeg);base64,([A-Za-z0-9+/=]+)$/);
  if (m) { mkdirSync(dir, { recursive: true }); const f = `icon.${m[1] === 'jpeg' ? 'jpg' : m[1]}`; writeFileSync(join(dir, f), Buffer.from(m[2], 'base64')); a.iconImage = `${app.id}/${f}`; }
  const shots = [];
  for (const [i, u] of (d.screenshots || []).slice(0, 8).entries()) { try { shots.push(`${app.id}/` + await downloadImage(u, dir, `shot-${i + 1}`)); } catch {} }
  if (shots.length) { a.cover = shots[0]; a.screenshots = shots.slice(1); }
  a.published = !!pub;
  saveApps(apps);
  const st = readJson('submissions.json', { handled: {}, manual: [] });
  st.handled[key] = 'accepted';
  writeJson('submissions.json', st, false);
  if (it.source === 'github' && it.number && (reply || close)) {
    if (reply) await ghApi(`repos/${repo}/issues/${it.number}/comments`, 'POST', { body: reply });
    if (close) await ghApi(`repos/${repo}/issues/${it.number}`, 'PATCH', { state: 'closed', state_reason: 'completed' });
  }
  return a;
}
async function rejectSubmission(key, { reply = '', close = false } = {}) {
  const { items, repo } = await listSubmissions();
  const it = items.find(x => x.key === key);
  const st = readJson('submissions.json', { handled: {}, manual: [] });
  st.handled[key] = 'rejected';
  writeJson('submissions.json', st, false);
  if (it?.source === 'github' && it.number && (reply || close)) {
    if (reply) await ghApi(`repos/${repo}/issues/${it.number}/comments`, 'POST', { body: reply });
    if (close) await ghApi(`repos/${repo}/issues/${it.number}`, 'PATCH', { state: 'closed', state_reason: 'not_planned' });
  }
}

// ---------- http ----------
function send(res, code, body, type = 'application/json; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
function serveFile(res, root, rel) {
  const p = resolve(root, '.' + sep + decodeURIComponent(rel).replace(/\//g, sep));
  if (!(p === resolve(root) || p.startsWith(resolve(root) + sep))) return send(res, 403, { error: 'Forbidden' });
  let f = p;
  if (existsSync(f) && statSync(f).isDirectory()) f = join(f, 'index.html');
  if (!existsSync(f)) return send(res, 404, 'Not found', 'text/plain');
  res.writeHead(200, { 'Content-Type': MIME[extname(f).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-store' });
  createReadStream(f).pipe(res);
}
function readBody(req, limit = 40 * 1024 * 1024) {
  return new Promise((ok, fail) => {
    const chunks = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > limit) { fail(new Error('Upload too large (40 MB max).')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { ok(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { fail(new Error('Invalid JSON body')); } });
    req.on('error', fail);
  });
}
const maskKey = k => (k ? `${k.slice(0, 8)}…${k.slice(-4)}` : '');

const server = createServer(async (req, res) => {
  const host = (req.headers.host || '').toLowerCase();
  if (host !== `127.0.0.1:${PORT}` && host !== `localhost:${PORT}`) return send(res, 421, { error: 'Wrong host' });
  const url = new URL(req.url, `http://${host}`);
  const path = url.pathname;
  try {
    if (path === '/' || path === '/index.html') return send(res, 200, readFileSync(join(HUB, 'ui', 'index.html'), 'utf8').replace('__HUB_TOKEN__', TOKEN), MIME['.html']);
    if (path.startsWith('/ui/')) return serveFile(res, join(HUB, 'ui'), path.slice(4));
    if (path.startsWith('/shared/')) return serveFile(res, join(HUB, 'shared'), path.slice(8));
    if (path.startsWith('/media/')) return serveFile(res, MEDIA, path.slice(7));
    if (path === '/site') { res.writeHead(302, { Location: '/site/' }); return res.end(); }
    if (path.startsWith('/site/')) return serveFile(res, cfg.siteDirAbs, path.slice(6));
    if (path.startsWith('/oauth/')) return send(res, 200, await CONNECTORS.oauthCallback(path, url), MIME['.html']); // LinkedIn / Google sign-in (one-time state, no hub token)
    if (!path.startsWith('/api/')) return send(res, 404, 'Not found', 'text/plain');
    if (req.headers['x-hub-token'] !== TOKEN) return send(res, 403, { error: 'Missing or invalid hub token. Reload the page.' });
    if (path === '/api/delivery/upload' && req.method === 'POST') return send(res, 200, await DELIVERY.upload(req, url)); // streamed, so before the JSON body reader
    const M = req.method;
    const body = M === 'GET' || M === 'DELETE' ? {} : await readBody(req);
    const ok = v => send(res, 200, v);

    // apps
    if (path === '/api/state' && M === 'GET') return ok({ apps: sortApps(loadApps()), site: loadSite(), config: { siteUrl: cfg.siteUrl, githubUrl: cfg.githubUrl, siteDir: cfg.siteDirAbs, hubDir: ROOT, supportEmail: cfg.supportEmail, repo: cfg.repo || '', setupDone: !!cfg.setupDone }, product: PRODUCT, license: LIC.state() });
    const sr0 = await setupRoute(path, M, body);
    if (sr0 !== undefined) return ok(sr0);
    if (path === '/api/status' && M === 'GET') return ok(await siteStatus());
    if (path === '/api/apps' && M === 'POST') { const a = upsertApp(body.app || {}, body.prevId); return ok({ app: a, apps: sortApps(loadApps()) }); }
    if (path === '/api/apps' && M === 'PUT') {
      if (!Array.isArray(body.apps) || !body.apps.length) return send(res, 400, { error: 'Expected a non-empty array of apps.' });
      const seen = new Set();
      saveApps(body.apps.map((x, i) => { const a = clean(x); if (!Number.isFinite(+x.order)) a.order = i + 1; while (seen.has(a.id)) a.id += '-2'; seen.add(a.id); return a; }));
      return ok({ apps: sortApps(loadApps()) });
    }
    if (path.startsWith('/api/apps/') && M === 'DELETE') { saveApps(loadApps().filter(a => a.id !== decodeURIComponent(path.slice(10)))); return ok({ apps: sortApps(loadApps()) }); }
    if (path === '/api/reorder' && M === 'POST') {
      const apps = loadApps();
      body.ids.forEach((id, i) => { const a = apps.find(x => x.id === id); if (a) a.order = i + 1; });
      saveApps(apps); return ok({ apps: sortApps(loadApps()) });
    }
    if (path === '/api/patch' && M === 'POST') {
      const apps = loadApps(), a = apps.find(x => x.id === body.id);
      if (!a) return send(res, 404, { error: 'App not found' });
      for (const k of ['published', 'featured']) if (k in body.set) a[k] = !!body.set[k];
      if (body.set.status) a.status = String(body.set.status);
      saveApps(apps); return ok({ apps: sortApps(loadApps()) });
    }
    if (path === '/api/upload' && M === 'POST') {
      const ext = extname(String(body.name || '')).toLowerCase();
      if (!IMG_EXT.has(ext)) return send(res, 400, { error: 'Images only: PNG, JPG, WebP, GIF, SVG or AVIF.' });
      const dir = join(MEDIA, slug(body.appId));
      mkdirSync(dir, { recursive: true });
      const base = slug(basename(String(body.name), ext)) || 'image';
      let file = base + ext, n = 2;
      while (existsSync(join(dir, file))) file = `${base}-${n++}${ext}`;
      writeFileSync(join(dir, file), Buffer.from(String(body.data).replace(/^data:[^,]*,/, ''), 'base64'));
      return ok({ path: `${slug(body.appId)}/${file}` });
    }

    // site settings
    if (path === '/api/site' && M === 'PUT') {
      const s = body.site;
      if (!s || !Array.isArray(s.categories) || !s.categories.length) return send(res, 400, { error: 'Keep at least one category.' });
      const ids = new Set();
      s.categories = s.categories.map(c => ({ id: slug(c.id || c.label), label: String(c.label || 'Category').trim(), icon: c.icon || 'code' })).filter(c => !ids.has(c.id) && ids.add(c.id));
      s.community = { ...loadSite().community, ...s.community, salt: loadSite().community?.salt || randomBytes(12).toString('hex') };
      if (body.reassign) { const apps = loadApps(); for (const a of apps) if (body.reassign[a.category]) a.category = body.reassign[a.category]; saveApps(apps); }
      saveSite(s); return ok({ site: loadSite(), apps: sortApps(loadApps()) });
    }
    if (path === '/api/youtube/sync' && M === 'POST') { const y = await youtubeSync(body.channelUrl); return ok({ youtube: y, site: loadSite() }); }
    if (path === '/api/youtube/add' && M === 'POST') { await youtubeAdd(body.url); return ok({ site: loadSite() }); }

    // supporters
    if (path === '/api/supporters' && M === 'GET') return ok({ supporters: loadSupporters(), stripeKey: maskKey(secrets().stripeKey) });
    if (path === '/api/supporters' && M === 'POST') {
      const list = loadSupporters(), s = body.supporter || {};
      const clean2 = { id: s.id || 'sp-' + randomBytes(5).toString('hex'), name: String(s.name || '').trim(), email: String(s.email || '').trim(), type: s.type || 'manual',
        total: Math.max(0, +s.total || 0), wall: !!s.wall, wallName: String(s.wallName || '').trim().slice(0, 40), notes: String(s.notes || ''), source: s.source || 'manual' };
      const i = list.findIndex(x => x.id === clean2.id);
      if (i >= 0) list[i] = { ...list[i], ...clean2 }; else list.push({ ...clean2, firstAt: new Date().toISOString() });
      saveSupporters(list); return ok({ supporters: list });
    }
    if (path.startsWith('/api/supporters/') && M === 'DELETE') { saveSupporters(loadSupporters().filter(s => s.id !== path.slice(16))); return ok({ supporters: loadSupporters() }); }
    if (path === '/api/supporters/code' && M === 'POST') { const s = issueCode(body.id); N.codeIssued(s).catch(() => {}); return ok({ supporter: s, supporters: loadSupporters() }); }
    if (path === '/api/supporters/revoke' && M === 'POST') { const list = loadSupporters(); const s = list.find(x => x.id === body.id); if (s) { s.revoked = true; N.codeRevoked(s).catch(() => {}); } saveSupporters(list); return ok({ supporters: list }); }
    if (path === '/api/stripe/sync' && M === 'POST') return ok(await stripeSync());
    if (path === '/api/secrets' && M === 'PUT') {
      const k = String(body.stripeKey || '').trim();
      if (k && !/^(rk|sk)_(live|test)_[\w]+$/.test(k)) return send(res, 400, { error: 'That does not look like a Stripe key (rk_live_… recommended).' });
      writeJson('secrets.json', { ...secrets(), stripeKey: k }, false);
      return ok({ stripeKey: maskKey(k) });
    }

    // submissions
    if (path === '/api/submissions' && M === 'GET') return ok(await listSubmissions());
    if (path === '/api/submissions/paste' && M === 'POST') {
      const d = parseSubmission(body.text);
      if (!d) return send(res, 400, { error: "Couldn't find submission data in that text. Paste the whole email." });
      const st = readJson('submissions.json', { handled: {}, manual: [] });
      const key = 'm-' + sha(JSON.stringify(d)).slice(0, 10);
      if (!st.manual.some(m => m.key === key)) st.manual.push({ key, source: 'email', createdAt: d.submittedAt || new Date().toISOString(), data: d });
      writeJson('submissions.json', st, false);
      return ok(await listSubmissions());
    }
    if (path === '/api/submissions/accept' && M === 'POST') { const it = (await listSubmissionsRaw()).items.find(x => x.key === body.key); const a = await acceptSubmission(body.key, body); N.submissionDone(true, it, a).catch(() => {}); return ok({ app: a, apps: sortApps(loadApps()) }); }
    if (path === '/api/submissions/reject' && M === 'POST') { const it = (await listSubmissionsRaw()).items.find(x => x.key === body.key); await rejectSubmission(body.key, body); N.submissionDone(false, it).catch(() => {}); return ok(await listSubmissions()); }
    if (path === '/api/submissions/reopen' && M === 'POST') { const st = readJson('submissions.json', { handled: {}, manual: [] }); delete st.handled[body.key]; writeJson('submissions.json', st, false); return ok(await listSubmissions()); }

    // build / publish / misc
    if (path === '/api/build' && M === 'POST') { const b = buildSite(); return ok({ ...b, status: await siteStatus() }); }
    if (path === '/api/publish' && M === 'POST') {
      try { const r = await publish(String(body.message || '').slice(0, 200)); return ok({ ...r, status: await siteStatus() }); }
      catch (e) { return send(res, 500, { error: e.message, log: e.log }); }
    }
    if (path === '/api/github' && M === 'GET') {
      try { return ok(await githubInfo(url.searchParams.get('repo'))); } catch (e) { return send(res, 400, { error: e.message }); }
    }
    if (path === '/api/open' && M === 'POST') {
      if (body.url && /^https:\/\//.test(body.url)) { openUrl(body.url); return ok({ ok: true }); }
      const p = String(body.target || '');
      if (!p || !existsSync(p) || !statSync(p).isDirectory()) return send(res, 400, { error: 'That folder does not exist on this computer.' });
      if (body.with === 'code') spawn(process.platform === 'win32' ? 'cmd' : 'code', process.platform === 'win32' ? ['/c', 'code', p] : [p], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
      else spawn(process.platform === 'win32' ? 'explorer.exe' : process.platform === 'darwin' ? 'open' : 'xdg-open', [p], { detached: true, stdio: 'ignore' }).unref();
      return ok({ ok: true });
    }
    if (path === '/api/live' && M === 'GET') return ok(await liveSnapshot());
    const dr = path.startsWith('/api/delivery') ? await DELIVERY.route(path, M, body, url) : undefined;
    if (dr !== undefined) {
      if (/^\/api\/delivery\/(sell|stop|target)$/.test(path)) setTimeout(() => SYNC.run('sale').catch(() => {}), 1500); // price/button/version follow at once
      return ok(dr);
    }
    const sr = path.startsWith('/api/store') ? await STORE.route(path, M, body) : undefined;
    if (sr !== undefined) return ok(sr);
    const pr = path.startsWith('/api/perks') ? await PERKS.route(path, M, body) : undefined;
    if (pr !== undefined) return ok(pr);
    if (path.startsWith('/api/licences')) { const lr = await licenceRoute(path, M, body, url); if (lr !== undefined) return ok(lr); }
    const tr = path.startsWith('/api/tax') ? await TAX.route(path, M, body, url) : undefined;
    if (tr !== undefined) return ok(tr);
    const cr = path.startsWith('/api/connectors') ? await CONNECTORS.route(path, M, body, url) : undefined;
    if (cr !== undefined) return ok(cr);
    const yr = path.startsWith('/api/sync') ? await SYNC.route(path, M, body) : undefined;
    if (yr !== undefined) return ok(yr);
    const nr = await N.route(path, M, body, url);
    if (nr !== undefined) return ok(nr);
    return send(res, 404, { error: 'Unknown API route' });
  } catch (e) {
    return send(res, 500, { error: e.message || String(e), ...(e.step != null ? { step: e.step } : {}), ...(e.newUrl ? { newUrl: e.newUrl } : {}) });
  }
});

N = createNotifier({
  cfg, HUB, port: PORT, readJson, writeJson, secrets, saveSecrets, loadSite, loadApps, loadSupporters, fetchT,
  stripeGet, stripeSync, issueCode, revokeCode, upgradeCode, siteStatus, publish,
  perksSync: email => PERKS.sync(email), perkMark: (h, id) => PERKS.mark(h, id),
  downloadFor: id => DELIVERY.downloadFor(id), downloadUrl: id => DELIVERY.downloadUrl(id),
  // Paid download of an app marked "Licensed" → a signed licence key for the buyer (same purchase, same key).
  social: (kind, data) => CONNECTORS?.onEvent(kind, data), // new app/release/video/announcement → social posts and store uploads
  licenceFor: (appId, email, name, ref) => (loadApps().find(a => a.id === appId)?.licensed ? LICENCES.issue({ app: appId, email, name, ref }) : null),
  listSubmissions, listSubmissionsQuiet: listSubmissionsRaw, youtubeSync: () => youtubeSync(undefined, { quiet: true })
});

STORE = createStore({
  secrets, saveSecrets, fetchT, loadSite, saveSite, loadApps, saveApps, get siteUrl() { return cfg.siteUrl; },
  perkProducts: () => N.settings().perks.products,
  addPerk: id => N.setPerks(l => [...l, id]),
  swapPerkLink: (oldId, newId) => N.setPerks(l => (l.includes(oldId) ? [...l.filter(x => x !== oldId), newId] : l)),
  alert: (title, desc) => N.fire('store.changed', () => ({ content: title, embeds: desc ? [{ description: desc, color: 0x8B5CF6 }] : undefined, __title: title.replace(/[*🏷️]/g, '').trim() })).catch(() => {})
});

PERKS = createPerks({
  readJson, writeJson, loadSite, loadApps, loadSupporters, saveSupporters, issueCode,
  purchases: e => N.purchases(e), qualTotal: e => N.qualTotal(e), supportEmail: () => cfg.supportEmail,
  stripeWrite: () => !!(secrets().stripeWriteKey || secrets().stripeKey),
  createProduct: async b => (await STORE.route('/api/store/product', 'POST', b)).result,
  // Stripe payment link / product id → the apps it sells (an app's buy button, or a paid download)
  linkApps: async () => {
    const m = new Map(); if (!secrets().stripeKey) return m;
    const o = await STORE.overview(false);
    for (const l of o.links) { const ids = [...new Set([...l.apps.map(a => a.id), l.deliver?.app].filter(Boolean))]; if (ids.length) { m.set(l.id, ids); if (l.product.id) m.set(l.product.id, ids); } }
    return m;
  },
  onGranted: (sup, perks, via) => N.perkGranted(sup, perks, via)
});
setPerksProvider(PERKS);

const storeAlert = (title, desc, color) => N.fire('store.changed', () => ({ content: title, embeds: desc ? [{ description: desc, color }] : undefined, __title: title.replace(/[*\p{Extended_Pictographic}\uFE0F]/gu, '').trim() })).catch(() => {});
const TAX = createTax({ dir: HUB, dataDir: DATA_DIR, readJson, writeJson, store: STORE, alert: (t, d) => storeAlert(t, d, 0xF59E0B) });

const DELIVERY = createDelivery({
  dir: HUB, readJson, writeJson, secrets, saveSecrets, fetchT, loadApps, saveApps, loadSite, store: STORE, label: 'pylerium-manager', taxAuto: () => TAX.collecting(),
  createApp: ({ name, version }) => upsertApp({ name, version, status: 'live', published: true, glyph: 'package', licensed: true, updatedAt: today() }, null),
  siteUrl: () => cfg.siteUrl, supportEmail: () => cfg.supportEmail, brand: () => brandName(loadSite()), githubClientId: () => PRODUCT.githubClientId || '',
  guard: () => { if (!LIC.canPublish()) throw new Error(`${LIC.state().msg || 'No licence.'} Activate your licence in Settings → Licence to sell downloads.`); },
  alert: (title, desc) => N.fire('store.changed', () => ({ content: title, embeds: desc ? [{ description: desc, color: 0x2DD4BF }] : undefined, __title: title.replace(/[*🔐📦⏸️]/g, '').trim() })).catch(() => {})
});

// Auto-sync: versions, release notes and privacy from GitHub, prices and buy buttons from Stripe (sync.mjs).
const SYNC = createSync({ readJson, writeJson, loadApps, saveApps, delivery: DELIVERY, publish, alert: (t, d) => storeAlert(t, d, 0x38BDF8), log: console.log });

// ---------- connectors (connectors.mjs): every outside service, social posting and store uploads ----------
const coreCache = { at: 0, v: null };
async function coreStatus(force) {
  if (!force && coreCache.v && Date.now() - coreCache.at < 60000) return coreCache.v;
  const s = secrets(), L = (() => { try { return N.live(); } catch { return {}; } })(), site = loadSite(), dl = readJson('delivery.json', {});
  const out = {};
  const d = L.discord || {};
  out.discord = d.private?.set || d.public?.set
    ? { state: 'on', ok: true, account: [d.private?.set && `Private${d.private.name ? `: ${d.private.name}` : ''}`, d.public?.set && `Public${d.public.name ? `: ${d.public.name}` : ''}`].filter(Boolean).join(' · '), detail: `${d.sentToday || 0} sent today${d.failedToday ? ` · ${d.failedToday} failed` : ''}` }
    : { state: 'off' };
  const e = L.email || {};
  out.gmail = e.connected ? { state: e.smtp?.authFail ? 'error' : 'on', ok: !e.smtp?.authFail, account: e.user, detail: e.smtp?.authFail ? 'Gmail rejected the app password' : `${e.sentToday || 0} sent today · ${e.ready || 0} ready`, error: e.smtp?.authFail ? e.smtp.error : undefined } : { state: 'off' };
  const ghTok = s.githubToken || s.deliveryGithubToken;
  if (ghTok) {
    try { const r = await fetchT((process.env.PM_GITHUB_API || 'https://api.github.com') + '/user', { headers: { Authorization: `Bearer ${ghTok}`, Accept: 'application/vnd.github+json' } }, 10000); const u = await r.json(); out.github = r.ok ? { state: 'on', ok: true, account: u.login, detail: cfg.siteUrl ? cfg.siteUrl.replace(/^https?:\/\//, '') : '' } : { state: 'error', error: u.message || `GitHub ${r.status}` }; }
    catch (x) { out.github = { state: 'error', error: x.message }; }
  } else out.github = cfg.siteUrl ? { state: 'on', ok: true, account: (cfg.githubUrl || '').replace(/^https?:\/\/github.com\//, '') || 'git sign-in', detail: cfg.siteUrl.replace(/^https?:\/\//, '') } : { state: 'off' };
  if (s.stripeKey || s.stripeWriteKey) {
    try { await STORE.stripe('GET', 'products?limit=1'); const k = s.stripeWriteKey || s.stripeKey; out.stripe = { state: 'on', ok: true, account: /_live_/.test(k) ? 'Live mode' : 'Test mode', detail: `${/^rk_/.test(k) ? 'Restricted key' : 'Secret key'} · ${dl.apps?.length || 0} paid download(s)` }; }
    catch (x) { out.stripe = { state: 'error', error: x.message }; }
  } else out.stripe = { state: 'off' };
  out.cloudflare = s.cfToken && dl.cf ? { state: 'on', ok: true, account: dl.cf.accountName || 'Connected', detail: dl.worker ? `Delivery service v${dl.worker.version}` : 'No delivery service yet' } : { state: 'off' };
  const y = site.youtube || {};
  out.youtube = y.channelUrl ? { state: 'on', ok: true, account: y.channelTitle || y.channelUrl.replace(/^https?:\/\/(www\.)?youtube\.com\//, ''), detail: `${(y.videos || []).length} videos${y.lastSync ? ` · synced ${new Date(y.lastSync).toLocaleDateString()}` : ''}` } : { state: 'off' };
  for (const [k, link] of Object.entries({ discord: '#/connectors/discord', gmail: '#/connectors/discord/emails', github: '#/settings', stripe: '#/community/settings', cloudflare: '#/store/apps', youtube: '#/media' })) out[k].manage = link;
  coreCache.at = Date.now(); coreCache.v = out;
  return out;
}
CONNECTORS = createConnectors({
  readJson, writeJson, secrets, saveSecrets, fetchT, loadApps, loadSite, port: PORT, mediaDir: MEDIA,
  siteUrl: () => cfg.siteUrl, brand: () => brandName(loadSite()), core: coreStatus, log: console.log,
  discordPost: async text => { const r = await N.send('public', { content: text, __title: 'Connectors post' }, { event: 'connectors.post' }); if (r && r.status && r.status !== 'sent') throw new Error(r.error || 'Discord didn’t accept the post.'); },
  releaseAsset: o => DELIVERY.releaseAsset(o),
  alert: (t, d) => N.fire('store.changed', () => ({ content: t, embeds: d ? [{ description: d, color: 0x8B5CF6 }] : undefined, __title: t.replace(/[*\p{Extended_Pictographic}\uFE0F]/gu, '').trim() })).catch(() => {})
});

// ---------- licences (licences.mjs): issued keys, manual keys, drop-in kits ----------
async function licenceRoute(path, M, body, url) {
  const apps = () => loadApps();
  if (path === '/api/licences' && M === 'GET') {
    const issued = LICENCES.list();
    const per = issued.reduce((m, r) => (m[r.app] = (m[r.app] || 0) + 1, m), {});
    return {
      publicKey: LICENCES.publicKey(), keyFile: LICENCES.keyFile,
      kits: Object.entries(KITS).map(([id, k]) => ({ id, label: k.label, files: k.files })),
      apps: sortApps(apps()).map(a => ({ id: a.id, name: a.name, licensed: !!a.licensed, published: !!a.published, version: a.version || '', price: a.price || '', glyph: a.glyph, accent: a.accent, iconImage: a.iconImage, issued: per[a.id] || 0 })),
      issued: issued.slice(0, 500).map(({ key, ...r }) => ({ ...r, appName: apps().find(a => a.id === r.app)?.name || r.app, keyTail: key.slice(-10) }))
    };
  }
  if (path === '/api/licences' && M === 'POST') {
    const a = apps().find(x => x.id === body.app);
    if (!a) throw new Error('Pick the app this licence is for.');
    const rec = LICENCES.issue({ app: a.id, email: body.email, name: body.name, ref: body.ref ? `manual:${String(body.ref).slice(0, 60)}` : '' });
    const mail = body.send ? N.sendLicence({ ...rec, appName: a.name }) : null;
    return { licence: rec, mailed: !!mail };
  }
  if (path === '/api/licences/key' && M === 'POST') { const r = LICENCES.list().find(x => x.id === body.id); if (!r) throw new Error('Licence not found.'); return { key: r.key }; }
  if (path === '/api/licences/resend' && M === 'POST') {
    const r = LICENCES.list().find(x => x.id === body.id); if (!r) throw new Error('Licence not found.');
    N.sendLicence({ ...r, appName: apps().find(a => a.id === r.app)?.name || r.app }); return { ok: true };
  }
  if (path === '/api/licences/verify' && M === 'POST') return LICENCES.check(body.key);
  if (path === '/api/licences/kit' && M === 'GET') {
    const a = apps().find(x => x.id === url.searchParams.get('app'));
    if (!a) throw new Error('Pick an app.');
    return LICENCES.kit(url.searchParams.get('lang'), a, cfg.siteUrl);
  }
  if (path === '/api/licences/app' && M === 'PUT') {
    const list = apps(), a = list.find(x => x.id === body.app);
    if (!a) throw new Error('App not found.');
    if (body.licensed) a.licensed = true; else delete a.licensed;
    saveApps(list); return { ok: true };
  }
  return undefined;
}

// ---------- setup wizard, licence and GitHub connection ----------
function openUrl(u) {
  const [cmd, args] = process.platform === 'win32' ? ['cmd', ['/c', 'start', '', u]] : process.platform === 'darwin' ? ['open', [u]] : ['xdg-open', [u]];
  try { spawn(cmd, args, { detached: true, stdio: 'ignore', windowsHide: true }).unref(); } catch {}
}
let ghUser = null;
async function githubState(fresh = false) {
  if (!secrets().githubToken) return { connected: false };
  if (!ghUser || fresh) { try { ghUser = await GH.me(); } catch (e) { return { connected: false, error: e.message }; } }
  return { connected: true, user: ghUser };
}
async function saveToken(tok) {
  const t = String(tok || '').trim();
  if (!/^(gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,})$/.test(t)) throw new Error('That doesn’t look like a GitHub token (it starts with ghp_ or github_pat_).');
  const prev = secrets().githubToken;
  saveSecrets({ githubToken: t });
  try { ghUser = await GH.me(); } catch (e) { saveSecrets({ githubToken: prev || '' }); throw e; }
  if (!cfg.githubUrl) saveConfig({ githubUrl: ghUser.url });
  return githubState();
}
// Newer version on the product page? (product.updateUrl → latest.json, checked twice a day)
let UPDATE = null;
const newer = (a, b) => { const x = String(a).split('.').map(n => +n || 0), y = String(b).split('.').map(n => +n || 0); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
async function checkUpdate() {
  if (!PRODUCT.updateUrl) return;
  try { const r = await fetchT(PRODUCT.updateUrl + '?cb=' + Date.now(), {}, 10000); if (!r.ok) return; const v = await r.json(); UPDATE = v?.version && newer(v.version, PRODUCT.version) ? { version: v.version, date: v.date || '', notes: v.notes || '', url: PRODUCT.website || PRODUCT.updateUrl.replace(/latest.json$/, '') } : null; } catch {}
}
async function setupState() {
  return { done: !!cfg.setupDone, product: PRODUCT, update: UPDATE, license: LIC.state(), github: await githubState(), deviceFlow: !!PRODUCT.githubClientId,
    config: { repo: cfg.repo || '', siteUrl: cfg.siteUrl || '', supportEmail: cfg.supportEmail || '', brandDone: !!cfg.brandDone }, site: loadSite(), home: ROOT };
}
// GitHub's own 403 text ("Resource not accessible by personal access token") tells a customer nothing.
// Fine-grained tokens can't create repositories unless they were made with the right permissions, so explain exactly what to do.
function repoError(e, g, owner, name) {
  if (e.status !== 403 && e.status !== 404) return e;
  const newUrl = `https://github.com/new?name=${encodeURIComponent(name)}&visibility=public`;
  if (g.user?.fineGrained) return Object.assign(new Error(`GitHub wouldn’t let this token create ${owner}/${name}. You used a fine-grained token (github_pat_…), which can only create repositories with “All repositories” access and the Administration, Contents and Pages permissions set to “Read and write”. Easiest fix: make a classic token with the “Create a token on GitHub” button on the GitHub step (it starts with ghp_). Or create the repository yourself at ${newUrl} and press the button again.`), { status: e.status, fix: 'token', newUrl });
  return Object.assign(new Error(`GitHub wouldn’t let this token create ${owner}/${name}. Make sure it has the “public_repo” (or “repo”) permission, or create the repository yourself at ${newUrl} and press the button again.`), { status: e.status, fix: 'token', newUrl });
}
async function setupRoute(path, M, body) {
  if (path === '/api/setup' && M === 'GET') return setupState();
  if (path === '/api/license/activate' && M === 'POST') { LIC.activate(body.key); await LIC.refreshSubscription(); return setupState(); }
  if (path === '/api/license/refresh' && M === 'POST') { await LIC.refreshSubscription(); await LIC.refreshRevoked(); return setupState(); }
  if (path === '/api/license/deactivate' && M === 'POST') { LIC.deactivate(); return setupState(); }
  if (path === '/api/github/token' && M === 'POST') { await saveToken(body.token); return setupState(); }
  if (path === '/api/github/device/start' && M === 'POST') { if (!PRODUCT.githubClientId) throw new Error('Sign-in with GitHub isn’t set up in this copy. Use a token.'); const d = await GH.deviceStart(PRODUCT.githubClientId); openUrl(d.url); return d; }
  if (path === '/api/github/device/poll' && M === 'POST') { const r = await GH.devicePoll(PRODUCT.githubClientId, body.deviceCode); if (r.token) { await saveToken(r.token); return { done: true, ...(await setupState()) }; } return r; }
  if (path === '/api/github/disconnect' && M === 'POST') { saveSecrets({ githubToken: '' }); ghUser = null; return setupState(); }
  if (path === '/api/github/repos' && M === 'GET') return { repos: await GH.listRepos(), user: (await githubState()).user };
  if (path === '/api/setup/site' && M === 'POST') {
    const g = await githubState(true); if (!g.connected) throw new Error(g.error || 'Connect GitHub first.');
    const owner = g.user.login, name = String(body.repo || `${owner}.github.io`).trim().replace(/^.*\//, '') || `${owner}.github.io`;
    if (!/^[\w.-]{1,100}$/.test(name)) throw new Error('Repository names can use letters, numbers, dots, dashes and underscores.');
    let r; try { r = await GH.ensureRepo(owner, name, `${brandName(loadSite())}: built with Pylerium Manager`); } catch (e) { throw repoError(e, g, owner, name); }
    let pages = { url: '' }; try { pages = await GH.ensurePages(r.full, r.branch); } catch (e) { pages = { url: '', error: e.message }; }
    const siteUrl = (pages.cname ? `https://${pages.cname}` : '') || siteUrlFor(owner, name);
    saveConfig({ repo: r.full, branch: r.branch, siteUrl, githubUrl: `https://github.com/${owner}` });
    const site = loadSite(); site.community = { ...site.community, repo: r.full }; saveSite(site);
    return { repo: r, pages, siteUrl, ...(await setupState()) };
  }
  if (path === '/api/setup/brand' && M === 'POST') {
    const site = loadSite(), b = body || {};
    site.brand = { ...site.brand, name: String(b.name || site.brand?.name || 'My Studio').trim().slice(0, 60), tagline: String(b.tagline ?? site.brand?.tagline ?? '').trim().slice(0, 80) };
    if (b.logo === '') delete site.brand.logo;
    else if (/^data:image\/(png|jpeg|webp|svg\+xml);base64,/.test(b.logo || '')) {
      const ext = { png: '.png', jpeg: '.jpg', webp: '.webp', 'svg+xml': '.svg' }[b.logo.match(/^data:image\/([\w+]+)/)[1]];
      mkdirSync(join(MEDIA, 'brand'), { recursive: true });
      const file = `logo-${Date.now().toString(36)}${ext}`;
      writeFileSync(join(MEDIA, 'brand', file), Buffer.from(b.logo.split(',')[1], 'base64'));
      site.brand.logo = `brand/${file}`;
    }
    for (const k of ['title', 'highlight', 'lead']) if (typeof b[k] === 'string' && b[k].trim()) site.hero[k] = b[k].trim();
    if (b.currency && /^[A-Z]{3}$/.test(b.currency)) site.community = { ...site.community, currency: b.currency };
    if (b.youtube) site.youtube = { ...site.youtube, channelUrl: String(b.youtube).trim() };
    saveSite(site);
    saveConfig({ brandDone: true, ...(b.email != null ? { supportEmail: String(b.email).trim() } : {}) });
    return setupState();
  }
  if (path === '/api/setup/finish' && M === 'POST') {
    // Never mark setup finished without a site to publish to: that left customers on a dashboard saying "GitHub not connected".
    if (!(await githubState()).connected) throw Object.assign(new Error('Connect GitHub first.'), { step: 2 });
    if (!cfg.repo) throw Object.assign(new Error('Pick your site first: Pylerium Manager needs a GitHub repository to publish to.'), { step: 3 });
    if (body.publish === false) { saveConfig({ setupDone: true }); return setupState(); }
    const site = loadSite();
    if (site.youtube?.channelUrl) { try { await youtubeSync(site.youtube.channelUrl, { quiet: true }); } catch {} }
    const r = await publish(`Launch ${brandName(site)} with Pylerium Manager`);
    saveConfig({ setupDone: true });
    return { publish: r, ...(await setupState()) };
  }
  if (path === '/api/pages' && M === 'GET') { if (!cfg.repo) return { status: 'none' }; const p = await GH.pagesStatus(cfg.repo).catch(() => null); let live = false; try { live = (await fetchT(`${cfg.siteUrl.replace(/\/$/, '')}/apps.json?cb=${Date.now()}`, {}, 8000)).ok; } catch {} return { status: p?.status || 'unknown', url: cfg.siteUrl, live }; }
  if (path === '/api/quit' && M === 'POST') { setTimeout(() => process.exit(0), 300); return { bye: true }; }
  return undefined;
}

// ---------- live dashboard: everything at a glance ----------
let statusCache = { at: 0, v: null }, pingCache = { at: 0, v: null };
async function liveSnapshot() {
  const now = Date.now();
  if (now - statusCache.at > 15000) { try { statusCache = { at: now, v: await siteStatus() }; } catch (e) { statusCache = { at: now, v: { repoOk: false, error: e.message } }; } }
  if (now - pingCache.at > 120000) {
    const t0 = Date.now();
    try { if (!cfg.siteUrl) throw new Error('No site yet'); const r = await fetchT(`${cfg.siteUrl}?cb=${t0}`, { method: 'HEAD' }, 10000); pingCache = { at: now, v: { ok: r.ok, status: r.status, ms: Date.now() - t0, at: new Date().toISOString() } }; }
    catch (e) { pingCache = { at: now, v: { ok: false, error: e.message, at: new Date().toISOString() } }; }
  }
  const apps = loadApps(), site = loadSite();
  let store = null;
  try { const o = await STORE.overview(false); const d = o.links.find(l => l.isDonate); store = { links: o.links.filter(l => l.active).length, donate: d ? { label: d.label, name: d.product.name, active: d.active } : null, products: o.products.filter(p => p.active).length }; }
  catch (e) { store = { error: e.message }; }
  const st = statusCache.v || {};
  return {
    ...N.live(),
    license: LIC.state(), repo: cfg.repo || '',
    site: { url: cfg.siteUrl, ping: cfg.siteUrl ? pingCache.v : null, repoOk: st.repoOk !== false, pending: (st.changes || []).length + (!(st.changes || []).length && (st.workingFiles || st.ahead) ? 1 : 0),
      changes: (st.changes || []).slice(0, 8), lastPublish: st.lastCommit || null, publishing, error: st.error || '' },
    apps: { total: apps.length, published: apps.filter(a => a.published).length, featured: apps.filter(a => a.published && a.featured).length, community: apps.filter(a => a.community).length },
    videos: { total: (site.youtube?.videos || []).filter(v => !v.hidden).length, latest: (site.youtube?.videos || []).filter(v => !v.hidden).sort((a, b) => String(b.published).localeCompare(String(a.published)))[0] || null, lastSync: site.youtube?.lastSync || null },
    submissions: lastSubs, store, donateOn: !!(site.donate?.enabled && site.donate?.url)
  };
}

server.on('error', e => {
  if (e.code === 'EADDRINUSE') {
    console.log(`Pylerium Manager is already running: http://localhost:${PORT}/`);
    if (!process.argv.includes('--no-open')) openUrl(`http://localhost:${PORT}/`);
    setTimeout(() => process.exit(0), 300); return;
  }
  throw e;
});
server.listen(PORT, '127.0.0.1', () => {
  const link = `http://localhost:${PORT}/`;
  console.log(`\n  Pylerium Manager ${PRODUCT.version}  →  ${link}\n  Your data: ${ROOT}\n  Press Ctrl+C to stop.\n`);
  N.start();
  TAX.start();
  SYNC.start();
  LIC.refreshRevoked(); setInterval(() => LIC.refreshRevoked(), 12 * 3600e3).unref();
  LIC.refreshSubscription(); setInterval(() => LIC.refreshSubscription(), 12 * 3600e3).unref();
  checkUpdate(); setInterval(checkUpdate, 12 * 3600e3).unref();
  if (!process.argv.includes('--no-open')) openUrl(link);
});
