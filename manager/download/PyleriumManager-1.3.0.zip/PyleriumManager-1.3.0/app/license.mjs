// Licences for Pylerium Manager. Keys are Ed25519-signed by the vendor (see vendor/ in the source tree) and checked
// offline with the public key in product.json, so the app never needs a licence server. A short trial runs first.
import { createPublicKey, verify } from 'node:crypto';

const b64u = s => Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
export const KEY_RE = /^PM1-([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/;

export function parseKey(key, publicKey) {
  const k = String(key || '').replace(/\s+/g, '');
  const m = k.match(KEY_RE);
  if (!m) throw new Error('That doesn’t look like a Pylerium Manager licence key. It starts with PM1- and is one long line.');
  if (!publicKey) throw new Error('This copy has no licence public key (product.json).');
  const pub = createPublicKey({ key: Buffer.from(publicKey, 'base64'), format: 'der', type: 'spki' });
  if (!verify(null, Buffer.from(m[1]), pub, b64u(m[2]))) throw new Error('That licence key isn’t valid. Copy it again from your email, all of it.');
  let p;
  try { p = JSON.parse(b64u(m[1]).toString('utf8')); } catch { throw new Error('That licence key is damaged.'); }
  if (p.v !== 1 || !p.id) throw new Error('That licence key is from an unsupported version.');
  return { key: k, ...p };
}

export function createLicensing({ product, readJson, writeJson, fetchT }) {
  const day = 864e5;
  let revoked = new Set(readJson('license-revoked.json', []));
  function state() {
    const L = readJson('license.json', {});
    if (!L.trialStart) { L.trialStart = new Date().toISOString(); writeJson('license.json', L, false); }
    if (L.key) {
      try {
        const p = parseKey(L.key, product.publicKey);
        if (revoked.has(p.id)) return { state: 'revoked', email: p.email, msg: 'This licence was refunded or cancelled.' };
        if (p.sub) { // subscription: valid while Stripe says it's paid (checked online, cached for offline use)
          const s = L.subStatus || null;
          // Before the first successful check: the first month. A subscription Stripe doesn't know isn't valid at all.
          const until = s?.status === 'missing' ? -Infinity : s?.paidUntil ? Date.parse(s.paidUntil) : Date.parse(p.iat) + 35 * day;
          const info = { email: p.email, name: p.name || '', plan: p.plan || 'monthly', id: p.id, issued: p.iat, sub: p.sub, status: s?.status || 'active', exp: s?.periodEnd || s?.paidUntil || null, cancelAtPeriodEnd: !!s?.cancelAtPeriodEnd, checkedAt: s?.checkedAt || null };
          if (Date.now() > until + 3 * day) {
            const why = s?.status === 'canceled' || s?.status === 'missing' || s?.status === 'incomplete_expired' ? 'Your subscription has ended.' : s && s.status !== 'active' && s.status !== 'trialing' ? 'Your last subscription payment didn’t go through.' : 'Your subscription couldn’t be confirmed.';
            return { ...info, state: 'expired', msg: `${why} Renew or update your payment to keep publishing.` };
          }
          return { ...info, state: 'licensed' };
        }
        if (p.exp && Date.now() > Date.parse(p.exp) + 3 * day) return { state: 'expired', email: p.email, plan: p.plan, exp: p.exp, msg: 'Your licence has expired. Renew to keep publishing.' };
        return { state: 'licensed', email: p.email, name: p.name || '', plan: p.plan || 'lifetime', exp: p.exp || null, id: p.id, issued: p.iat };
      } catch (e) { return { state: 'invalid', msg: e.message }; }
    }
    const left = Math.ceil((Date.parse(L.trialStart) + (product.trialDays || 14) * day - Date.now()) / day);
    return left > 0 ? { state: 'trial', daysLeft: left, trialDays: product.trialDays || 14 } : { state: 'trial-over', daysLeft: 0, msg: 'Your free trial has ended. Activate a licence to keep publishing.' };
  }
  const canPublish = () => ['licensed', 'trial'].includes(state().state);
  function activate(key) {
    const p = parseKey(key, product.publicKey);
    if (revoked.has(p.id)) throw new Error('That licence was refunded or cancelled.');
    const prev = readJson('license.json', {});
    writeJson('license.json', { ...prev, key: p.key, activatedAt: new Date().toISOString(), ...(prev.key !== p.key ? { subStatus: undefined } : {}) }, false);
    return state();
  }
  // Subscription keys: ask the store's licence service whether the subscription is paid. Network trouble keeps the
  // last answer, so the app works offline until the paid-through date it last saw (plus 3 days).
  async function refreshSubscription() {
    const L = readJson('license.json', {});
    let p; try { p = L.key && parseKey(L.key, product.publicKey); } catch { return state(); }
    if (!p?.sub || !product.licenceApi) return state();
    try {
      const r = await fetchT(`${product.licenceApi.replace(/\/$/, '')}/api/subscription?sub=${encodeURIComponent(p.sub)}`, {}, 10000);
      const j = await r.json().catch(() => null);
      if (r.ok && j?.ok) writeJson('license.json', { ...readJson('license.json', {}), subStatus: { status: j.status, paidUntil: j.paidUntil, periodEnd: j.periodEnd, cancelAtPeriodEnd: j.cancelAtPeriodEnd, checkedAt: new Date().toISOString() } }, false);
    } catch { /* offline: keep the cached status */ }
    return state();
  }
  function deactivate() { const L = readJson('license.json', {}); delete L.key; writeJson('license.json', L, false); return state(); }
  // Optional refund list published by the vendor (product.revokedUrl): a JSON array of licence ids.
  async function refreshRevoked() {
    if (!product.revokedUrl) return;
    try { const r = await fetchT(`${product.revokedUrl}?cb=${Date.now()}`, {}, 10000); if (r.ok) { const ids = await r.json(); if (Array.isArray(ids)) { revoked = new Set(ids.map(String)); writeJson('license-revoked.json', [...revoked], false); } } } catch {}
  }
  return { state, canPublish, activate, deactivate, refreshRevoked, refreshSubscription };
}
