// Connectors: every outside service in one tab (Core, Social, Stores, AI), the post composer with Ollama drafts,
// automation rules for hub events, and the post queue. Discord keeps its own screens (alerts.js) as a sub-tab.
import { R, S, $, $$, esc, api, toast, confirmBox, rel } from './core.js';
import * as Alerts from './alerts.js';

const I = n => R.icon(n);
let C = null, loading = false, tab = 'overview', sub = '', busy = '';
const LIM = { x: 280, mastodon: 500, linkedin: 3000, telegram: 4096, devto: 100000, discord: 2000 };
const POSTERS = ['x', 'mastodon', 'linkedin', 'telegram', 'devto', 'discord'];
const extra = {};                      // per-tab loaded data (games, models, chats, items)
const draft = { source: 'topic', appId: '', videoId: '', event: 'app.updated', brief: '', tone: 'friendly', extra: '', platforms: [], posts: {}, when: 'review', at: '' };
const TONES = ['friendly', 'excited', 'professional', 'casual', 'technical', 'playful', 'humble'];
const GROUPS = [['Start', ['overview', 'compose', 'automation', 'queue']], ['Core', ['discord', 'github', 'stripe', 'cloudflare', 'gmail', 'youtube']], ['Social', ['x', 'linkedin', 'mastodon', 'telegram', 'devto']], ['Stores', ['itch', 'cws']], ['AI', ['ollama']]];
const PAGES = { overview: ['Overview', 'grid'], compose: ['Compose a post', 'sparkle'], automation: ['Automation', 'zap'], queue: ['Queue & history', 'list'] };

export function init() {
  const P = $('#cxPanel');
  $('#cxNav').addEventListener('click', e => { const a = e.target.closest('[data-cx]'); if (a) location.hash = '#/connectors/' + a.dataset.cx; });
  P.addEventListener('click', onClick);
  P.addEventListener('change', onChange);
  P.addEventListener('input', onInput);
  P.addEventListener('submit', onSubmit);
  setInterval(() => { if (!$('main[data-view="connectors"]').hidden && (tab === 'queue' || tab === 'overview')) load(false, true); }, 20000);
}
export async function show(t, s) {
  tab = t || 'overview'; sub = s || '';
  const isDiscord = tab === 'discord';
  $('#cxDiscord').hidden = !isDiscord; $('#cxPanel').hidden = isDiscord;
  navRender();
  if (isDiscord) { await Alerts.show(sub || undefined); return; }
  if (!C) await load();
  else render();
  loadExtra();
}
async function load(force, quiet) {
  if (loading) return; loading = true;
  if (!C && !quiet) $('#cxPanel').innerHTML = `<div class="card lv-loading"><span class="spinner"></span>Checking your connections…</div>`;
  try { C = await api('GET', '/api/connectors' + (force ? '?force=1' : '')); } catch (e) { if (!quiet) toast(e.message, 'err'); }
  loading = false;
  if (!draft.platforms.length && C) draft.platforms = POSTERS.filter(p => def(p)?.status?.ok);
  navRender(); if (!(quiet && document.activeElement?.closest('#cxPanel'))) render();
}
const def = id => C?.connectors.find(c => c.id === id);
const stateOf = d => d?.status?.state === 'on' ? 'on' : d?.status?.state === 'error' ? 'error' : 'off';
const pill = d => { const s = stateOf(d); return `<span class="cx-pill ${s}">${s === 'on' ? `${I('check')}Connected` : s === 'error' ? `${I('alert')}Needs attention` : 'Not connected'}</span>`; };
const logo = (d, big) => `<span class="cx-logo ${big ? 'big' : ''} b-${esc(d.id)}">${I(d.icon)}</span>`;

function navRender() {
  const N = $('#cxNav'); if (!N) return;
  const review = (C?.queue || []).filter(p => p.status === 'review').length, failed = (C?.queue || []).filter(p => p.status === 'failed').length;
  N.innerHTML = GROUPS.map(([g, ids]) => `<div class="cx-ng"><span class="cx-gl">${esc(g)}</span>${ids.map(id => {
    const d = def(id), page = PAGES[id];
    const label = page ? page[0] : d?.name || id, icon = page ? page[1] : d?.icon || 'plug';
    const badge = id === 'queue' && (review || failed) ? `<em class="${failed ? 'bad' : ''}">${review + failed}</em>` : '';
    return `<button type="button" data-cx="${id}" class="${tab === id ? 'on' : ''}"><span class="cx-ni b-${id}">${I(icon)}</span><span>${esc(label)}</span>${badge}${d && !page ? `<i class="cx-dot ${stateOf(d)}"></i>` : ''}</button>`;
  }).join('')}</div>`).join('');
}

// ============================================================ render
function render() {
  const P = $('#cxPanel'); if (!C || P.hidden) return;
  const d = def(tab);
  P.innerHTML = tab === 'overview' ? overview() : tab === 'compose' ? compose() : tab === 'automation' ? automation() : tab === 'queue' ? queue()
    : d?.kind === 'core' ? core(d) : d ? service(d) : overview();
}

function overview() {
  const on = C.connectors.filter(d => stateOf(d) === 'on').length, review = C.queue.filter(p => p.status === 'review').length;
  const week = C.history.filter(p => Date.now() - Date.parse(p.postedAt || p.createdAt) < 7 * 864e5).length;
  const rules = Object.values(C.rules || {}).filter(r => r.enabled).length;
  return `<div class="lc-tiles">
      <div class="tile"><span>Connected</span><b>${on}<small> of ${C.connectors.length}</small></b></div>
      <div class="tile"><span>Waiting for review</span><b>${review}</b></div>
      <div class="tile"><span>Posted this week</span><b>${week}</b></div>
      <div class="tile"><span>Automations on</span><b>${rules}<small> of ${C.events.length}</small></b></div></div>
    <div class="row cx-bar"><button type="button" class="hbtn primary sm" data-go="compose">${I('sparkle')}Compose a post</button><button type="button" class="hbtn ghost sm" data-go="automation">${I('zap')}Automation</button><span class="sp"></span><button type="button" class="hbtn ghost sm" data-recheck>${I('refresh')}Recheck all</button></div>
    ${GROUPS.slice(1).map(([g, ids]) => `<h4 class="cx-h">${esc(g)}</h4><div class="cx-grid">${ids.map(id => { const d = def(id); return `
      <button type="button" class="cx-card ${stateOf(d)}" data-go="${id}">${logo(d)}<div class="cx-ct"><b>${esc(d.name)}</b>${pill(d)}</div>
        <p>${esc(d.status?.account ? `${d.status.account}${d.status.detail ? ` · ${d.status.detail}` : ''}` : d.status?.error || d.blurb)}</p></button>`; }).join('')}</div>`).join('')}`;
}

function core(d) {
  const st = d.status || {};
  return `<div class="card cx-hero">${logo(d, true)}<div><h3>${esc(d.name)}</h3><p class="sub">${esc(d.blurb)}</p></div><span class="sp"></span>${pill(d)}</div>
    <div class="st-grid"><div class="st-main"><div class="card"><h3>${I('activity')}Status</h3>
      ${stateOf(d) === 'off' ? `<p class="sub">Not set up yet.</p>` : `<div class="tx-kv"><span>Account</span><b>${esc(st.account || '—')}</b>${st.detail ? `<span>Details</span><b>${esc(st.detail)}</b>` : ''}</div>`}
      ${st.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(st.error)}</p>` : ''}
      <div class="row"><a class="hbtn primary sm" href="${esc(st.manage || '#/connectors')}">${I('sliders')}${stateOf(d) === 'off' ? 'Set it up' : 'Manage'}</a><button type="button" class="hbtn ghost sm" data-recheck>${I('refresh')}Recheck</button></div></div></div>
    <div class="st-side"><div class="card"><h3>${I('info')}Where it’s used</h3><p class="sub">${esc(coreUse[d.id] || '')}</p></div></div></div>`;
}
const coreUse = {
  github: 'Publishing your website, private repositories for paid downloads, release versions and notes for auto-sync, and release files for itch.io and Chrome Web Store uploads.',
  stripe: 'Store prices and checkout links, paid downloads, licence keys, sales alerts, supporter codes and the Tax tab.',
  cloudflare: 'The delivery service that hands out paid downloads and answers subscription licence checks.',
  gmail: 'Download links, licence keys, supporter codes and thank-you emails (Discord → Emails shows the outbox).',
  youtube: 'Your latest videos and shorts on the site, YouTube alerts, and video posts in Automation.'
};

// ---------- a service (social, store, AI) ----------
function service(d) {
  const s = d.settings || {}, dflt = s.defaults || {};
  return `<div class="card cx-hero">${logo(d, true)}<div><h3>${esc(d.name)}</h3><p class="sub">${esc(d.blurb)}</p></div><span class="sp"></span>${pill(d)}</div>
  <div class="st-grid"><div class="st-main">
    ${d.id === 'x' ? xPanel(dflt) : d.id === 'devto' ? devtoPanel(d, dflt) : d.id === 'linkedin' ? linkedinPanel(d, dflt) : d.id === 'mastodon' ? mastodonPanel(dflt) : d.id === 'telegram' ? telegramPanel(d, dflt) : d.id === 'itch' ? itchPanel(d) : d.id === 'cws' ? cwsPanel(d) : d.id === 'ollama' ? ollamaPanel(d) : ''}
  </div><div class="st-side">${setupCard(d)}</div></div>`;
}
function setupCard(d) {
  const st = d.status || {};
  return `<div class="card"><div class="card-head"><h3>${I('key')}Connection</h3>${d.docs ? `<a class="hbtn ghost sm" href="${esc(d.docs)}" target="_blank" rel="noopener">${I('external')}Open</a>` : ''}</div>
    ${stateOf(d) === 'on' ? `<div class="tx-kv"><span>Account</span><b>${esc(st.account || '')}</b>${st.detail ? `<span>Details</span><b>${esc(st.detail)}</b>` : ''}</div>` : ''}
    ${st.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(st.error)}</p>` : ''}
    <details class="cx-steps"${stateOf(d) === 'on' ? '' : ' open'}><summary>${I('book')}How to connect</summary><ol>${(d.steps || []).map(x => `<li>${esc(x)}</li>`).join('')}</ol>
      ${d.oauth ? `<p class="sub">${d.id === 'x' ? 'Callback URI' : 'Redirect URL'}: <code>${esc(redirectOf(d.id))}</code> <button type="button" class="act" data-copy="${esc(redirectOf(d.id))}">${I('copy')}</button></p>` : ''}</details>
    <form class="fb" data-save="${d.id}">${(d.fields || []).map(f => `<label class="fld"><span>${esc(f.l)}${f.opt ? ' <small>optional</small>' : ''}</span><input name="${f.k}" ${f.secret ? 'type="password" autocomplete="off"' : ''} value="${esc(d.values?.[f.k] || '')}" placeholder="${esc(f.placeholder || '')}" spellcheck="false">${f.help ? `<small class="muted">${esc(f.help)}</small>` : ''}</label>`).join('')}
      <div class="row"><button class="hbtn primary sm" type="submit">${I('check')}Save &amp; test</button>${d.oauth ? `<button type="button" class="hbtn ghost sm" data-oauth="${d.id}">${I(d.id === 'x' ? 'xlogo' : 'link')}${d.id === 'cws' ? 'Sign in with Google' : d.id === 'x' ? 'Sign in with X' : 'Connect LinkedIn'}</button>` : ''}<button type="button" class="hbtn ghost sm" data-test="${d.id}">${I('zap')}Test</button>${stateOf(d) !== 'off' ? `<span class="sp"></span><button type="button" class="hbtn ghost sm danger" data-forget="${d.id}">Disconnect</button>` : ''}</div></form>
    <p class="muted small">${I('lock')} Keys stay on this computer (data/secrets.json) and are only sent to ${esc(d.name)}.</p></div>`;
}
const redirectOf = id => C.redirects[id === 'cws' ? 'google' : id] || '';
const chk = (k, v, label, attr = 'data-def') => `<label class="switch"><input type="checkbox" ${attr}="${k}"${v ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">${esc(label)}</span></label>`;
const sel = (k, v, opts, label, attr = 'data-def') => `<label class="fld"><span>${esc(label)}</span><select ${attr}="${k}">${opts.map(([val, l]) => `<option value="${esc(val)}"${String(v ?? '') === String(val) ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`;
const txt = (k, v, label, ph = '', attr = 'data-def') => `<label class="fld"><span>${esc(label)}</span><input ${attr}="${k}" value="${esc(v ?? '')}" placeholder="${esc(ph)}"></label>`;
const defaultsCard = (id, body, title = 'Posting defaults') => `<div class="card" data-defs="${id}"><div class="card-head"><h3>${I('sliders')}${esc(title)}</h3><button type="button" class="hbtn ghost sm" data-savedefs="${id}">${I('save')}Save</button></div>${body}</div>`;

const xPanel = o => defaultsCard('x', `<div class="cx-sw">${chk('thread', o.thread !== false, 'Split long posts into a numbered thread')}${chk('image', o.image !== false, 'Attach the app’s cover image (v2 media upload)')}${chk('premium', o.premium, 'X Premium account: posts up to 25,000 characters')}</div>
  ${sel('replySettings', o.replySettings || '', [['', 'Everyone can reply'], ['following', 'People you follow'], ['mentionedUsers', 'Only people you mention'], ['subscribers', 'Your subscribers'], ['verified', 'Verified accounts']], 'Who can reply')}
  <p class="note"><span>${I('info')}</span>Links count as 23 characters. The X API is pay-per-use: your developer account needs credits (console → Billing). X allows up to 100 posts per 15 minutes per account.</p>`);
const linkedinPanel = (d, o) => defaultsCard('linkedin', `<div class="f2">${sel('visibility', o.visibility || 'PUBLIC', [['PUBLIC', 'Anyone'], ['CONNECTIONS', 'Connections only']], 'Who can see it')}${sel('asOrg', o.asOrg ? '1' : '', [['', 'Me'], ['1', 'Company page']], 'Post as')}</div>
  <div class="cx-sw">${chk('card', o.card !== false, 'Show a link preview card')}${chk('noReshare', o.noReshare, 'Turn off resharing')}</div>
  ${txt('version', d.settings?.version || '', 'API version (advanced)', 'auto: two months ago, e.g. 202609', 'data-setting')}
  <p class="note"><span>${I('info')}</span>LinkedIn sign-ins last 60 days. The status here shows how long is left; press Connect LinkedIn again before it runs out.</p>`);
const mastodonPanel = o => defaultsCard('mastodon', `<div class="f2">${sel('visibility', o.visibility || 'public', [['public', 'Public'], ['unlisted', 'Unlisted (quiet public)'], ['private', 'Followers only'], ['direct', 'Mentioned people only']], 'Visibility')}${txt('language', o.language, 'Language', 'en')}</div>
  ${txt('cw', o.cw, 'Content warning', 'optional')}
  <div class="cx-sw">${chk('image', o.image !== false, 'Attach the app’s cover image')}${chk('sensitive', o.sensitive, 'Mark media as sensitive')}${chk('thread', o.thread !== false, 'Split long posts into a thread')}</div>`);
function telegramPanel(d, o) {
  const chats = extra.telegram;
  return defaultsCard('telegram', `<div class="cx-sw">${chk('photo', o.photo !== false, 'Send with the app’s cover image')}${chk('silent', o.silent, 'Send silently (no notification)')}${chk('pin', o.pin, 'Pin the message')}${chk('noPreview', o.noPreview, 'Turn off link previews')}</div>
    <div class="f2">${txt('button', o.button, 'Button label', 'Get it')}${txt('buttonUrl', o.buttonUrl, 'Button link', 'the post’s link')}</div>`) +
    `<div class="card"><div class="card-head"><h3>${I('users')}Chats &amp; channels</h3><button type="button" class="hbtn ghost sm" data-findchats>${I('search')}Find chats</button></div>
      <p class="sub">Post anything in your group or channel (with the bot added as admin), then press Find chats.</p>
      ${chats ? (chats.length ? `<div class="cx-list">${chats.map(c => `<div class="cx-li"><b>${esc(c.title)}</b><small>${esc(c.type)} · ${esc(c.username ? '@' + c.username : c.id)}</small><span class="sp"></span><button type="button" class="hbtn ghost sm" data-addchat="${esc(c.username ? '@' + c.username : c.id)}">${I('plus')}Add</button></div>`).join('')}</div>` : '<p class="muted small">No chats found yet. Post a message where the bot is, then try again.</p>') : ''}</div>`;
}
function itchPanel(d) {
  const g = extra.itch, maps = d.settings?.maps || [];
  return `<div class="card"><div class="card-head"><h3>${I('chart')}Your games</h3>${g?.butler ? `<span class="dc-pill ok">${I('check')}${esc(g.butler)}</span>` : g ? `<span class="dc-pill warn">butler not found</span>` : ''}</div>
      ${!g ? (stateOf(d) === 'on' ? '<p class="muted"><span class="spinner sm"></span> Loading…</p>' : '<p class="sub">Connect itch.io to see your games.</p>') : g.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(g.error)}</p>` : g.games.length ? `<div class="cx-table"><div class="cx-tr h"><span>Game</span><span>Views</span><span>Downloads</span><span>Purchases</span><span>Earnings</span></div>${g.games.map(x => `<div class="cx-tr"><a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.title)}</a><span>${x.views.toLocaleString()}</span><span>${x.downloads.toLocaleString()}</span><span>${x.purchases.toLocaleString()}</span><span>${esc(x.earnings || '—')}</span></div>`).join('')}</div>` : '<p class="muted">No games on this account yet.</p>'}</div>
    <div class="card"><div class="card-head"><h3>${I('upload')}Builds with butler</h3><button type="button" class="hbtn ghost sm" data-addmap="itch">${I('plus')}Add an app</button></div>
      <p class="sub">On a new release, the hub downloads the matching file from the app’s GitHub release and pushes it to itch.io with butler.</p>
      ${maps.map((m, i) => `<div class="cx-map" data-mapi="${i}" data-mapof="itch">${sel('appId', m.appId, appOpts(), 'App', 'data-map')}${txt('target', m.target, 'itch.io page', 'yourname/game', 'data-map')}${txt('channel', m.channel, 'Channel', 'windows', 'data-map')}${txt('pattern', m.pattern, 'File name contains', 'win, .zip', 'data-map')}
        <div class="row cx-mapf">${chk('auto', m.auto, 'Push new releases automatically', 'data-map')}<span class="sp"></span><button type="button" class="hbtn ghost sm" data-pushnow="${esc(m.appId)}">${I('upload')}Push latest now</button><button type="button" class="act" data-delmap="${i}" data-mapof2="itch" title="Remove">${I('trash')}</button></div></div>`).join('') || '<p class="muted small">No apps mapped yet.</p>'}
      ${maps.length ? `<div class="row"><button type="button" class="hbtn primary sm" data-savemaps="itch">${I('save')}Save mappings</button></div>` : ''}</div>`;
}
function cwsPanel(d) {
  const items = d.settings?.items || [], live = extra.cws;
  const lbl = st => ({ PENDING_REVIEW: 'In review', STAGED: 'Approved, staged', PUBLISHED: 'Published', PUBLISHED_TO_TESTERS: 'Published to testers', REJECTED: 'Rejected', CANCELLED: 'Submission cancelled', NOT_PUBLISHED: 'Not published yet' })[st] || st || '';
  return `<div class="card"><div class="card-head"><h3>${I('chrome')}Extensions</h3><button type="button" class="hbtn ghost sm" data-addmap="cws">${I('plus')}Add an extension</button></div>
      <p class="sub">Uses the Chrome Web Store API v2. Map an app to its extension: new releases upload the .zip from the app’s GitHub release and can be submitted straight away, or staged to publish when you choose.</p>
      ${items.map((m, i) => { const L = live?.find(x => x.itemId === m.itemId)?.live; return `<div class="cx-map" data-mapi="${i}" data-mapof="cws">${sel('appId', m.appId, appOpts(), 'App', 'data-map')}${txt('itemId', m.itemId, 'Extension ID', '32 letters from the store URL', 'data-map')}${txt('pattern', m.pattern || '.zip', 'File name contains', '.zip', 'data-map')}${txt('percent', m.percent, 'Rollout %', '100', 'data-map')}
        <div class="row cx-mapf">${chk('auto', m.auto, 'Upload new releases automatically', 'data-map')}${chk('publish', m.publish, 'Submit for review after upload', 'data-map')}${chk('staged', m.staged, 'Stage when approved (publish later)', 'data-map')}${chk('skipReview', m.skipReview, 'Skip review when allowed', 'data-map')}${chk('blockOnWarnings', m.blockOnWarnings, 'Stop on warnings', 'data-map')}</div>
        ${L ? (L.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(L.error)}</p>` : `<div class="row cx-wrap cx-cwsst"><span class="dc-pill${L.state === 'PUBLISHED' ? ' ok' : L.state === 'REJECTED' || L.takenDown ? ' bad' : ' warn'}">${esc(lbl(L.state))}</span>${L.version ? `<span class="dc-pill">Live v${esc(L.version)}${L.published?.channels?.[0]?.percent != null && L.published.channels[0].percent < 100 ? ` · ${L.published.channels[0].percent}%` : ''}</span>` : ''}${L.submitted && L.published ? `<span class="dc-pill">Submitted v${esc(L.submitted.channels?.[0]?.version || '?')}</span>` : ''}${L.takenDown ? '<span class="dc-pill bad">Taken down</span>' : ''}${L.warned ? '<span class="dc-pill warn">Warning from Google</span>' : ''}</div>`) : ''}
        <div class="row cx-wrap"><button type="button" class="hbtn ghost sm" data-cwsdeploy="${esc(m.appId)}">${I('upload')}Upload latest release</button><label class="hbtn ghost sm cx-file">${I('folder')}Upload a .zip<input type="file" accept=".zip" data-cwszip="${esc(m.itemId)}" hidden></label><button type="button" class="hbtn ghost sm" data-cwspub="${esc(m.itemId)}">${I('rocket')}Submit for review</button>${L?.state === 'PENDING_REVIEW' ? `<button type="button" class="hbtn ghost sm" data-cwscancel="${esc(m.itemId)}">Cancel submission</button>` : ''}${L?.version ? `<button type="button" class="hbtn ghost sm" data-cwsroll="${esc(m.itemId)}">${I('chart')}Raise rollout</button>` : ''}<span class="sp"></span><button type="button" class="act" data-delmap="${i}" data-mapof2="cws" title="Remove">${I('trash')}</button></div></div>`; }).join('') || '<p class="muted small">No extensions mapped yet.</p>'}
      ${items.length ? `<div class="row"><button type="button" class="hbtn primary sm" data-savemaps="cws">${I('save')}Save mappings</button></div>` : ''}</div>`;
}
function devtoPanel(d, o) {
  const a = extra.devto;
  return defaultsCard('devto', `<div class="cx-sw">${chk('published', o.published, 'Publish immediately (off: save as a draft on dev.to)')}${chk('cover', o.cover !== false, 'Use the app’s cover as the article cover')}${chk('canonical', o.canonical, 'Point the canonical link at the app’s page')}</div>
      <div class="f2">${txt('tags', o.tags, 'Tags (up to 4)', 'showdev, webdev, opensource')}${txt('series', o.series, 'Series', 'optional')}</div>
      <div class="f2">${txt('orgId', o.orgId, 'Organization ID', 'optional: post under your org')}${txt('description', o.description, 'Description', 'optional: the app’s tagline')}</div>`) +
    `<div class="card"><div class="card-head"><h3>${I('chart')}Your articles</h3>${a?.length ? `<span class="muted small">${a.length} latest</span>` : ''}</div>
      ${!a ? (stateOf(d) === 'on' ? '<p class="muted"><span class="spinner sm"></span> Loading…</p>' : '<p class="sub">Connect DEV to see your articles.</p>') : a.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(a.error)}</p>` : a.length ? `<div class="cx-table"><div class="cx-tr h"><span>Article</span><span>Views</span><span>Reactions</span><span>Comments</span><span>Status</span></div>${a.map(x => `<div class="cx-tr"><a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.title)}</a><span>${x.views.toLocaleString()}</span><span>${x.reactions.toLocaleString()}</span><span>${x.comments.toLocaleString()}</span><span>${x.published ? 'Live' : 'Draft'}</span></div>`).join('')}</div>` : '<p class="muted">No articles yet.</p>'}</div>`;
}
function ollamaPanel(d) {
  const s = d.settings || {}, models = extra.ollama;
  return `<div class="card" data-defs="ollama"><div class="card-head"><h3>${I('ollama')}Writer</h3><button type="button" class="hbtn ghost sm" data-saveollama>${I('save')}Save</button></div>
      ${models?.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(models.error)} Is Ollama running?</p>` : ''}
      <div class="f2"><label class="fld"><span>Model</span><select data-oset="model">${(models?.models || []).map(m => `<option value="${esc(m.name)}"${m.name === s.model ? ' selected' : ''}>${esc(m.name)}${m.params ? ` · ${esc(m.params)}` : ''}</option>`).join('') || `<option>${models ? 'No models: run ollama pull qwen3:4b-instruct' : 'Loading…'}</option>`}</select></label>
        <label class="fld"><span>Creativity <small>${esc(String(s.temperature ?? 0.7))}</small></span><input type="range" min="0" max="1.2" step="0.1" value="${esc(String(s.temperature ?? 0.7))}" data-oset="temperature"></label></div>
      <label class="fld"><span>Your voice</span><textarea data-oset="voice" rows="3" placeholder="friendly, precise, no hype, indie developer who loves pixel art">${esc(s.voice || '')}</textarea></label>
      ${txt('language', s.language, 'Write in', 'English', 'data-oset')}
      <p class="note"><span>${I('lock')}</span>Drafts are written on this computer by your own model. Nothing is sent to an online AI.</p></div>
    <div class="card"><h3>${I('sparkle')}Try it</h3><form class="fb" data-otry><label class="fld"><span>Write a post about</span><input name="brief" placeholder="our new pixel-art editor beta" value="${esc(extra.otry?.brief || '')}"></label>
      <div class="row"><button class="hbtn primary sm" type="submit"${busy === 'otry' ? ' disabled' : ''}>${busy === 'otry' ? '<span class="spinner sm"></span>Writing…' : `${I('sparkle')}Draft for X`}</button></div></form>
      ${extra.otry?.text ? `<div class="cx-out">${esc(extra.otry.text)}</div>` : ''}</div>`;
}
const appOpts = () => [['', 'Choose…'], ...C.apps.map(a => [a.id, a.name])];

// ---------- compose ----------
function compose() {
  const ok = POSTERS.filter(p => def(p)?.status?.ok), ai = def('ollama')?.status?.ok;
  return `<div class="st-grid"><div class="st-main"><div class="card"><h3>${I('sparkle')}What’s it about?</h3>
      <div class="seg wide">${[['topic', 'Anything'], ['app', 'An app'], ['video', 'A video']].map(([v, l]) => `<button type="button" data-src="${v}" class="${draft.source === v ? 'on' : ''}">${l}</button>`).join('')}</div>
      ${draft.source === 'app' ? `<div class="f2">${sel('appId', draft.appId, appOpts(), 'App', 'data-dr')}${sel('event', draft.event, [['app.new', 'Introducing it'], ['app.available', 'It’s out now'], ['app.updated', 'A new version'], ['app.featured', 'Featured'], ['manual', 'Something else']], 'Angle', 'data-dr')}</div>` : ''}
      ${draft.source === 'video' ? sel('videoId', draft.videoId, [['', 'Choose…'], ...(S.site?.youtube?.videos || []).slice(0, 30).map(v => [v.id, v.title])], 'Video', 'data-dr') : ''}
      <label class="fld"><span>${draft.source === 'topic' ? 'Topic' : 'Anything to mention'} </span><textarea data-dr="brief" rows="3" placeholder="${draft.source === 'topic' ? 'We just hit 1,000 downloads, thank everyone and tease what’s next' : 'optional: a discount code, a thank-you, a question for the community'}">${esc(draft.brief)}</textarea></label>
      <div class="f2">${sel('tone', draft.tone, TONES.map(t => [t, t[0].toUpperCase() + t.slice(1)]), 'Tone', 'data-dr')}${txt('extra', draft.extra, 'Extra instructions', 'e.g. end with a question', 'data-dr')}</div>
      <div class="fld"><span>Post to</span><div class="row cx-wrap">${POSTERS.map(p => { const d = def(p); const on = draft.platforms.includes(p); return `<button type="button" class="cx-chip${on ? ' on' : ''}${d?.status?.ok ? '' : ' dis'}" data-plat="${p}" title="${d?.status?.ok ? '' : 'Not connected'}">${I(d?.icon || 'plug')}${esc(d?.name || p)}</button>`; }).join('')}</div>${ok.length ? '' : `<p class="sub">Connect a social account first (left).</p>`}</div>
      <div class="row"><button type="button" class="hbtn primary" data-draft="ai"${!ai || busy === 'draft' ? ' disabled' : ''} title="${ai ? '' : 'Connect Ollama first'}">${busy === 'draft' ? '<span class="spinner sm"></span>Writing drafts…' : `${I('ollama')}Draft with Ollama`}</button><button type="button" class="hbtn ghost" data-draft="tpl">${I('edit')}Start from a template</button></div>
      ${busy === 'draft' ? `<p class="muted small">Your local model is writing one post per platform. This takes 20–40 seconds each.</p>` : ''}</div></div>
    <div class="st-side">${draftsCard()}</div></div>`;
}
function draftsCard() {
  const plats = draft.platforms.filter(p => draft.posts[p]);
  if (!plats.length) return `<div class="card"><h3>${I('edit')}Drafts</h3><div class="emptystate">${I('sparkle')}<h4>No drafts yet</h4><p>Pick platforms and press Draft with Ollama, or start from a template.</p></div></div>`;
  return `<div class="card"><h3>${I('edit')}Drafts</h3>${plats.map(p => { const d = def(p), post = draft.posts[p], n = (post.text || '').length, lim = LIM[p];
      return `<div class="cx-draft"><div class="row"><span class="cx-ni b-${p}">${I(d.icon)}</span><b>${esc(d.name)}</b>${post.ai ? `<span class="dc-pill violet">${I('sparkle')}AI</span>` : ''}<span class="sp"></span><small class="cx-count${n > lim ? ' over' : ''}">${n}/${lim}${p === 'x' || p === 'mastodon' ? (n > lim ? ' · thread' : '') : ''}</small></div>
        ${p === 'devto' ? `<input data-post="${p}" data-pf="title" value="${esc(post.title || '')}" placeholder="Article title" class="cx-title">` : ''}
        <textarea data-post="${p}" data-pf="text" rows="${p === 'devto' ? 12 : p === 'linkedin' ? 8 : 4}"${p === 'devto' ? ' class="mono"' : ''}>${esc(post.text || '')}</textarea>
        ${p === 'devto' ? `<input data-post="${p}" data-pf="tags" value="${esc(post.options?.tags ?? def('devto').settings?.defaults?.tags ?? '')}" placeholder="Tags, up to 4: showdev, webdev" class="mono">` : ''}</div>`; }).join('')}
    <div class="fld"><span>When</span><div class="seg wide">${[['review', 'Queue for review'], ['now', 'Post now'], ['later', 'Schedule']].map(([v, l]) => `<button type="button" data-when="${v}" class="${draft.when === v ? 'on' : ''}">${l}</button>`).join('')}</div></div>
    ${draft.when === 'later' ? `<label class="fld"><span>Post at</span><input type="datetime-local" data-dr="at" value="${esc(draft.at)}"></label>` : ''}
    <button type="button" class="hbtn primary" data-send>${I('send')}${draft.when === 'now' ? `Post to ${plats.length} platform${plats.length > 1 ? 's' : ''}` : draft.when === 'later' ? 'Schedule' : 'Add to the queue'}</button></div>`;
}

// ---------- automation ----------
function automation() {
  const ai = def('ollama')?.status?.ok;
  return `<div class="card"><h3>${I('zap')}When something happens, post about it</h3><p class="sub">Each event can post to any connected platform, written from a template or by Ollama, posted automatically or held in the queue for you to approve. New releases can also be pushed to itch.io and the Chrome Web Store (set that up in their tabs).</p></div>
    ${C.events.map(ev => { const r = C.rules[ev.id] || {}; const plats = (r.platforms || []).filter(p => POSTERS.includes(p));
      return `<div class="card cx-rule${r.enabled ? ' on' : ''}" data-rule="${ev.id}"><div class="row"><label class="switch"><input type="checkbox" data-r="enabled"${r.enabled ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl"><b>${esc(ev.label)}</b></span></label><span class="sp"></span><code class="muted small">${esc(ev.id)}</code></div>
      ${r.enabled ? `<div class="row cx-wrap">${POSTERS.map(p => { const d = def(p); return `<button type="button" class="cx-chip${plats.includes(p) ? ' on' : ''}${d?.status?.ok ? '' : ' dis'}" data-rplat="${p}">${I(d?.icon || 'plug')}${esc(d?.name || p)}</button>`; }).join('')}</div>
        <div class="f3">${sel('mode', r.mode || 'review', [['review', 'Hold for my review'], ['auto', 'Post automatically']], 'Posting', 'data-r')}${txt('delayMin', r.delayMin, 'Delay (minutes)', '0', 'data-r')}${sel('ai', r.ai ? '1' : '', [['', 'Template'], ...(ai ? [['1', 'Ollama writes it']] : [])], 'Writer', 'data-r')}</div>
        ${r.ai ? `<div class="f2">${sel('tone', r.tone || 'friendly', TONES.map(t => [t, t]), 'Tone', 'data-r')}${txt('prompt', r.prompt, 'Extra instructions', 'e.g. mention it’s on sale', 'data-r')}</div>`
          : `<label class="fld"><span>Template <small>{name} {tagline} {version} {notes} {url} {title} {text} {amount} {brand}</small></span><textarea data-r="template" rows="3">${esc(r.template || C.defaults.templates[ev.id] || '')}</textarea></label>`}` : ''}</div>`; }).join('')}
    <div class="row"><button type="button" class="hbtn primary" data-saverules>${I('save')}Save automation</button></div>`;
}

// ---------- queue ----------
function queue() {
  const Q = C.queue, groups = [['review', 'Waiting for your review', 'eye'], ['scheduled', 'Scheduled', 'calendar'], ['approved', 'Sending', 'send'], ['posting', 'Sending', 'send'], ['retry', 'Retrying', 'refresh'], ['failed', 'Failed', 'alert']];
  const item = p => { const d = def(p.platform); const editing = p.status === 'review' || p.status === 'failed' || p.status === 'scheduled';
    return `<div class="cx-q ${p.status}" data-q="${p.id}"><div class="row"><span class="cx-ni b-${p.platform}">${I(d?.icon || 'plug')}</span><b>${esc(d?.name || p.platform)}</b>${p.ai ? `<span class="dc-pill violet">${I('sparkle')}AI</span>` : ''}<small class="muted">${esc(p.source?.app?.name || p.source?.video?.title || (p.source?.event === 'manual' ? 'Composed' : p.source?.event || ''))}${p.at ? ` · ${new Date(p.at).toLocaleString()}` : ''}</small><span class="sp"></span><small class="muted">${esc(rel(p.createdAt))}</small></div>
      ${p.title ? (editing ? `<input data-qf="title" value="${esc(p.title)}" class="cx-title">` : `<b>${esc(p.title)}</b>`) : ''}
      ${editing ? `<textarea data-qf="text" rows="4">${esc(p.text)}</textarea>` : `<p class="cx-qt">${esc(p.text)}</p>`}
      ${p.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(p.error)}</p>` : ''}
      <div class="row">${p.status === 'review' ? `<button type="button" class="hbtn primary sm" data-qa="approve">${I('check')}Approve &amp; post</button>` : ''}${p.status === 'failed' ? `<button type="button" class="hbtn primary sm" data-qa="retry">${I('refresh')}Try again</button>` : ''}${editing ? `<button type="button" class="hbtn ghost sm" data-qa="save">${I('save')}Save edits</button>` : ''}<span class="sp"></span>${p.status === 'review' ? `<button type="button" class="hbtn ghost sm" data-qa="reject">Reject</button>` : ''}<button type="button" class="act" data-qa="delete" title="Delete">${I('trash')}</button></div></div>`; };
  const live = groups.map(([st, label, icon]) => { const list = Q.filter(p => p.status === st); return list.length ? `<div class="card"><h3>${I(icon)}${esc(label)} <small class="muted">${list.length}</small></h3>${list.map(item).join('')}</div>` : ''; }).join('');
  const rejected = Q.filter(p => p.status === 'rejected');
  return `${live || `<div class="card"><div class="emptystate">${I('check')}<h4>Nothing waiting</h4><p>New posts from Compose and Automation appear here.</p></div></div>`}
    <div class="card"><h3>${I('list')}Posted</h3>${C.history.length ? `<div class="cx-hist">${C.history.map(p => { const d = def(p.platform); return `<div class="cx-hi"><span class="cx-ni b-${p.platform}">${I(d?.icon || 'plug')}</span><span class="muted small">${esc(rel(p.postedAt || p.createdAt))}</span><span class="cx-ht">${esc(p.title || p.text.split('\n')[0])}</span>${p.result?.url ? `<a href="${esc(p.result.url)}" target="_blank" rel="noopener" class="hbtn ghost sm">${I('external')}Open</a>` : ''}</div>`; }).join('')}</div>` : '<p class="muted">Nothing posted yet.</p>'}
    ${rejected.length ? `<p class="muted small">${rejected.length} rejected draft(s) kept for reference.</p>` : ''}</div>`;
}

// ============================================================ extra data per tab
async function loadExtra() {
  try {
    if (tab === 'itch' && stateOf(def('itch')) === 'on' && !extra.itch) { extra.itch = await api('GET', '/api/connectors/itch/games').catch(e => ({ error: e.message, games: [] })); render(); }
    if (tab === 'devto' && stateOf(def('devto')) === 'on' && !extra.devto) { extra.devto = (await api('GET', '/api/connectors/devto/articles').catch(e => ({ articles: { error: e.message } }))).articles; render(); }
    if (tab === 'ollama' && !extra.ollama) { extra.ollama = await api('GET', '/api/connectors/ollama/models').catch(e => ({ error: e.message, models: [] })); render(); }
    if (tab === 'cws' && stateOf(def('cws')) === 'on' && !extra.cws && (def('cws').settings?.items || []).length) { extra.cws = (await api('GET', '/api/connectors/cws/items').catch(() => ({ items: [] }))).items; render(); }
  } catch {}
}

// ============================================================ events
const collect = (root, attr) => { const o = {}; root.querySelectorAll(`[${attr}]`).forEach(el => { const k = el.getAttribute(attr); o[k] = el.type === 'checkbox' ? el.checked : el.type === 'number' || el.type === 'range' ? +el.value : el.value; }); return o; };
async function saveService(id, patch) {
  const r = await api('PUT', `/api/connectors/${id}`, patch);
  const d = def(id); d.status = r.status; d.settings = r.settings;
  navRender(); render();
  return r;
}
async function onClick(e) {
  const b = e.target.closest('button, [data-go]'); if (!b) return;
  const P = $('#cxPanel');
  try {
    if (b.dataset.go) { location.hash = '#/connectors/' + b.dataset.go; return; }
    if (b.dataset.recheck != null) { toast('Checking every connection…', 'info'); await load(true); return; }
    if (b.dataset.copy) { await navigator.clipboard.writeText(b.dataset.copy); toast('Copied'); return; }
    if (b.dataset.test) { b.disabled = true; const r = await api('POST', `/api/connectors/${b.dataset.test}/test`); def(b.dataset.test).status = r.status; navRender(); render(); toast(r.status.ok ? `Connected: ${r.status.account}` : (r.status.error || 'Not connected'), r.status.ok ? 'ok' : 'err', 6000); return; }
    if (b.dataset.forget) { if (!(await confirmBox(`Disconnect ${def(b.dataset.forget).name}?`, 'Its keys and settings are removed from this computer. Queued posts for it will fail.', 'Disconnect'))) return; C = await api('DELETE', `/api/connectors/${b.dataset.forget}`); navRender(); render(); return; }
    if (b.dataset.oauth) {
      const r = await api('POST', `/api/connectors/${b.dataset.oauth}/connect`); window.open(r.url, '_blank', 'noopener');
      if (!r.pin) { toast('Finish signing in in the new tab, then press Test here.', 'info', 8000); return; }
      // X app without a Callback URI: X shows a PIN after you authorise
      const pin = prompt('Authorise the app in the new tab. X then shows a PIN: type it here.');
      if (!pin) return;
      const v = await api('POST', `/api/connectors/x/pin`, { pin });
      toast(v.status?.ok ? `X is connected${v.status.account ? ` as ${v.status.account}` : ''}` : (v.status?.error || 'X sign-in failed'), v.status?.ok ? 'ok' : 'error', 8000); load(true); return;
    }
    if (b.dataset.savedefs) { const id = b.dataset.savedefs, card = P.querySelector(`[data-defs="${id}"]`); const defaults = collect(card, 'data-def'); if ('asOrg' in defaults) defaults.asOrg = !!defaults.asOrg; const settings = { ...(def(id).settings || {}), defaults, ...collect(card, 'data-setting') }; await saveService(id, { settings }); toast('Saved'); return; }
    if (b.dataset.saveollama != null) { const card = P.querySelector('[data-defs="ollama"]'); const o = collect(card, 'data-oset'); await saveService('ollama', { settings: { ...(def('ollama').settings || {}), ...o } }); toast('Saved'); return; }
    if (b.dataset.findchats != null) { b.disabled = true; extra.telegram = (await api('GET', '/api/connectors/telegram/chats')).chats; render(); return; }
    if (b.dataset.addchat) { const d = def('telegram'); const cur = String(d.values.chats || '').split(/[,\s]+/).filter(Boolean); if (!cur.includes(b.dataset.addchat)) cur.push(b.dataset.addchat); await saveService('telegram', { values: { chats: cur.join(', ') } }); d.values.chats = cur.join(', '); toast('Chat added'); return; }
    if (b.dataset.addmap) { const id = b.dataset.addmap, d = def(id), key = id === 'itch' ? 'maps' : 'items'; const list = [...(d.settings?.[key] || []), id === 'itch' ? { appId: '', target: '', channel: 'windows', pattern: '', auto: false } : { appId: '', itemId: '', pattern: '.zip', auto: false, publish: false, staged: false }]; d.settings = { ...(d.settings || {}), [key]: list }; render(); return; }
    if (b.dataset.delmap) { const id = b.dataset.mapof2, d = def(id), key = id === 'itch' ? 'maps' : 'items'; const list = [...(d.settings?.[key] || [])]; list.splice(+b.dataset.delmap, 1); await saveService(id, { settings: { ...(d.settings || {}), [key]: list } }); return; }
    if (b.dataset.savemaps) { const id = b.dataset.savemaps, key = id === 'itch' ? 'maps' : 'items'; const list = [...P.querySelectorAll(`[data-mapof="${id}"]`)].map(el => { const o = collect(el, 'data-map'); if ('percent' in o) o.percent = +o.percent || undefined; return o; }).filter(m => m.appId); await saveService(id, { settings: { ...(def(id).settings || {}), [key]: list } }); extra.cws = null; loadExtra(); toast('Mappings saved'); return; }
    if (b.dataset.pushnow) { b.disabled = true; toast('Downloading the release and pushing with butler…', 'info', 8000); const r = await api('POST', '/api/connectors/itch/push', { appId: b.dataset.pushnow }); toast(r.done.length ? `Pushed: ${r.done.join(', ')}` : 'Nothing was pushed', r.done.length ? 'ok' : 'err', 8000); b.disabled = false; return; }
    if (b.dataset.cwsdeploy) { b.disabled = true; toast('Uploading the latest release…', 'info', 8000); const r = await api('POST', '/api/connectors/cws/deploy', { appId: b.dataset.cwsdeploy }); toast(r.done.length ? `Uploaded: ${r.done.join(', ')}` : 'Nothing was uploaded', r.done.length ? 'ok' : 'err', 8000); extra.cws = null; loadExtra(); b.disabled = false; return; }
    if (b.dataset.cwspub) { const m = (def('cws').settings?.items || []).find(x => x.itemId === b.dataset.cwspub); if (!(await confirmBox('Submit the uploaded package for review?', `${m?.staged ? 'When Google approves it, it waits for you to publish it.' : 'It goes live as soon as Google approves it.'}${m?.percent ? ` Rollout: ${m.percent}%.` : ''}`, 'Submit', false))) return; const r = await api('POST', '/api/connectors/cws/publish', { itemId: b.dataset.cwspub, staged: m?.staged, percent: m?.percent, skipReview: m?.skipReview, blockOnWarnings: m?.blockOnWarnings }); toast(`Submitted: ${r.publish.status}${r.publish.warnings.length ? ` · ${r.publish.warnings.join('; ')}` : ''}`, 'ok', 9000); extra.cws = null; loadExtra(); return; }
    if (b.dataset.cwscancel) { if (!(await confirmBox('Cancel the submission?', 'The version in review is withdrawn. The live version stays as it is.', 'Cancel submission'))) return; await api('POST', '/api/connectors/cws/cancel', { itemId: b.dataset.cwscancel }); toast('Submission cancelled'); extra.cws = null; loadExtra(); return; }
    if (b.dataset.cwsroll) { const pct = prompt('Raise the rollout to what percent? (must be higher than now; only for extensions with over 10,000 weekly users)', '50'); if (!pct) return; await api('POST', '/api/connectors/cws/rollout', { itemId: b.dataset.cwsroll, percent: +pct }); toast(`Rollout raised to ${+pct}%`); extra.cws = null; loadExtra(); return; }
    if (b.dataset.src) { draft.source = b.dataset.src; render(); return; }
    if (b.dataset.plat) { const p = b.dataset.plat; if (b.classList.contains('dis')) return toast(`Connect ${def(p)?.name} first`, 'err'); draft.platforms = draft.platforms.includes(p) ? draft.platforms.filter(x => x !== p) : [...draft.platforms, p]; render(); return; }
    if (b.dataset.when) { draft.when = b.dataset.when; render(); return; }
    if (b.dataset.draft) {
      if (!draft.platforms.length) return toast('Pick at least one platform.', 'err');
      if (draft.source === 'app' && !draft.appId) return toast('Choose the app.', 'err');
      if (draft.source === 'topic' && !draft.brief.trim()) return toast('Write a topic first.', 'err');
      busy = 'draft'; render();
      try {
        const r = await api('POST', '/api/connectors/draft', { ai: b.dataset.draft === 'ai', platforms: draft.platforms, brief: draft.brief, tone: draft.tone, extra: draft.extra, event: draft.source === 'app' ? draft.event : draft.source === 'video' ? 'yt.video' : 'manual', appId: draft.source === 'app' ? draft.appId : '', videoId: draft.source === 'video' ? draft.videoId : '', text: draft.source === 'topic' ? draft.brief : '' });
        for (const [p, v] of Object.entries(r.drafts)) draft.posts[p] = { ...v, ai: b.dataset.draft === 'ai', link: r.link };
      } finally { busy = ''; render(); }
      return;
    }
    if (b.dataset.send != null) {
      const plats = draft.platforms.filter(p => draft.posts[p]);
      if (draft.when === 'later' && !draft.at) return toast('Choose when to post.', 'err');
      const app = C.apps.find(a => a.id === draft.appId);
      const posts = plats.map(p => { const post = draft.posts[p]; return { platform: p, text: post.text, title: post.title, link: post.link || '', image: draft.source === 'app' ? app?.cover || app?.iconImage : undefined, ai: post.ai,
        options: { ...(def(p).settings?.defaults || {}), ...(post.options || {}) }, source: { event: draft.source === 'app' ? draft.event : 'manual', app: app ? { id: app.id, name: app.name, cover: app.cover } : undefined } }; });
      C = await api('POST', '/api/connectors/queue', { posts, when: draft.when, at: draft.at });
      toast(draft.when === 'now' ? `Posting to ${posts.length} platform(s)…` : draft.when === 'later' ? 'Scheduled' : 'Added to the queue for review');
      draft.posts = {}; location.hash = '#/connectors/queue'; return;
    }
    if (b.dataset.rplat) { const card = b.closest('[data-rule]'), ev = card.dataset.rule, r = { ...(C.rules[ev] || {}) }; const p = b.dataset.rplat; if (b.classList.contains('dis')) return toast(`Connect ${def(p)?.name} first`, 'err'); r.platforms = (r.platforms || []).includes(p) ? r.platforms.filter(x => x !== p) : [...(r.platforms || []), p]; C.rules[ev] = r; render(); return; }
    if (b.dataset.saverules != null) { syncRules(); C.rules = (await api('PUT', '/api/connectors/rules', { rules: C.rules })).rules; toast('Automation saved'); render(); return; }
    if (b.dataset.qa) {
      const el = b.closest('[data-q]'), id = el.dataset.q, a = b.dataset.qa;
      if (a === 'delete') { if (!(await confirmBox('Delete this post?', 'It’s removed from the queue (already-posted posts stay on the platform).', 'Delete'))) return; C = await api('DELETE', `/api/connectors/queue/${id}`); render(); navRender(); return; }
      const patch = { text: el.querySelector('[data-qf="text"]')?.value, title: el.querySelector('[data-qf="title"]')?.value };
      if (a !== 'save') patch.action = a;
      C = await api('PUT', `/api/connectors/queue/${id}`, Object.fromEntries(Object.entries(patch).filter(([, v]) => v !== undefined)));
      toast(a === 'approve' ? 'Approved: posting now' : a === 'retry' ? 'Trying again' : a === 'reject' ? 'Rejected' : 'Saved'); render(); navRender(); return;
    }
  } catch (x) { toast(x.message, 'err', 9000); busy = ''; render(); }
}
function syncRules() {
  $$('#cxPanel [data-rule]').forEach(card => {
    const ev = card.dataset.rule, r = { ...(C.rules[ev] || {}) };
    card.querySelectorAll('[data-r]').forEach(el => { const k = el.dataset.r; r[k] = el.type === 'checkbox' ? el.checked : k === 'ai' ? !!el.value : k === 'delayMin' ? (+el.value || 0) : el.value; });
    C.rules[ev] = r;
  });
}
function onChange(e) {
  const t = e.target;
  if (t.dataset.r === 'enabled' || t.dataset.r === 'ai') { syncRules(); render(); return; }
  if (t.dataset.dr === 'appId' || t.dataset.dr === 'videoId' || t.dataset.dr === 'event') draft[t.dataset.dr] = t.value;
  if (t.dataset.cwszip) uploadZip(t);
}
function onInput(e) {
  const t = e.target;
  if (t.dataset.dr) draft[t.dataset.dr] = t.value;
  if (t.dataset.post) { const p = draft.posts[t.dataset.post]; if (t.dataset.pf === 'tags') p.options = { ...(p.options || {}), tags: t.value }; else p[t.dataset.pf] = t.value; const c = t.closest('.cx-draft')?.querySelector('.cx-count'); if (c && t.dataset.pf === 'text') { const n = t.value.length, lim = LIM[t.dataset.post]; c.textContent = `${n}/${lim}${n > lim && (t.dataset.post === 'x' || t.dataset.post === 'mastodon') ? ' · thread' : ''}`; c.classList.toggle('over', n > lim); } }
  if (t.dataset.oset === 'temperature') t.closest('label').querySelector('small').textContent = t.value;
}
async function onSubmit(e) {
  e.preventDefault();
  const f = e.target;
  try {
    if (f.dataset.save) { const btn = f.querySelector('[type=submit]'); btn.disabled = true; const values = Object.fromEntries(new FormData(f)); const r = await saveService(f.dataset.save, { values }); toast(r.status.ok ? `Connected: ${r.status.account}` : (r.status.error || 'Saved, but the test failed'), r.status.ok ? 'ok' : 'err', 8000); extra[f.dataset.save] = null; loadExtra(); return; }
    if (f.dataset.otry != null) { const brief = f.elements.brief.value.trim(); if (!brief) return; extra.otry = { brief }; busy = 'otry'; render(); try { const r = await api('POST', '/api/connectors/draft', { ai: true, platforms: ['x'], brief, text: brief }); extra.otry.text = r.drafts.x.text; } finally { busy = ''; render(); } return; }
  } catch (x) { toast(x.message, 'err', 9000); busy = ''; render(); }
}
function uploadZip(input) {
  const file = input.files?.[0]; if (!file) return;
  const m = (def('cws').settings?.items || []).find(x => x.itemId === input.dataset.cwszip);
  const fr = new FileReader();
  fr.onload = async () => {
    try {
      const data = String(fr.result).split(',')[1];
      const publish = await confirmBox('Upload this package?', `Upload ${file.name}${m?.publish ? ' and submit it for review' : ''}. You can also submit it later from here.`, m?.publish ? 'Upload & submit' : 'Upload', false);
      if (!publish && m?.publish) return;
      toast('Uploading to the Chrome Web Store…', 'info', 8000);
      const r = await api('POST', '/api/connectors/cws/upload', { itemId: input.dataset.cwszip, data, publish: !!m?.publish, staged: m?.staged, percent: m?.percent, skipReview: m?.skipReview, blockOnWarnings: m?.blockOnWarnings });
      toast(`Uploaded v${r.upload.version || '?'} (${String(r.upload.state).toLowerCase()})${r.publish ? ` · ${r.publish.status}` : ''}`, 'ok', 9000);
      extra.cws = null; loadExtra();
    } catch (x) { toast(x.message, 'err', 9000); }
  };
  fr.readAsDataURL(file);
}
