// Paid downloads: sell an app whose files live in a private GitHub repository. Buyers pay through Stripe and get the
// files from a small delivery service the hub deploys to the owner's own Cloudflare account.
import { R, S, $, esc, api, toast, confirmBox, formBox, rel, refreshStatus, emit, slug } from './core.js';

const NEW = '__new__';                // "＋ New app…" in the Sell form

const I = n => R.icon(n);
const TOKEN = document.querySelector('meta[name="hub-token"]').content;
const sleep = ms => new Promise(r => setTimeout(r, ms));
let D = null, err = '', loading = false, health = null, checking = false;
let dev = null;                      // GitHub device sign-in in progress
let owners = null, repos = null;     // GitHub lists for the sell form
const rels = {};                     // repo -> releases
const open = new Set();              // products whose files panel is open
let up = null;                       // upload panel: { linkId, repo, file, tag, notes }
let check = {};                      // linkId -> test result
const F = { appId: '', repoMode: 'new', owner: '', repoName: '', repo: '', file: null, tag: '', notes: '', mode: 'fixed', amount: '', min: '', preset: '', max: '', buttonLabel: '', promo: false, invoice: true, newName: '' };
let steps = null;                    // progress of "Start selling"

export function init() {
  const P = $('#dlPanel');
  P.addEventListener('click', onClick);
  P.addEventListener('submit', onSubmit);
  P.addEventListener('change', onChange);
  P.addEventListener('input', e => {
    const t = e.target; if (t.dataset.f) F[t.dataset.f] = t.type === 'checkbox' ? t.checked : t.value; if (t.dataset.u && up) up[t.dataset.u] = t.value;
    if (t.dataset.f === 'newName') { F.repoName = F.newName.trim() ? `${slug(F.newName)}-releases` : ''; const r = $('#dlPanel [data-f="repoName"]'); if (r) r.value = F.repoName; }
  });
  P.addEventListener('dragover', e => { const z = e.target.closest('[data-drop]'); if (z) { e.preventDefault(); z.classList.add('over'); } });
  P.addEventListener('dragleave', e => e.target.closest('[data-drop]')?.classList.remove('over'));
  P.addEventListener('drop', e => { const z = e.target.closest('[data-drop]'); if (!z) return; e.preventDefault(); const f = e.dataTransfer.files?.[0]; if (f) pickFile(z.dataset.drop, f); });
}
export async function show() { await load(false); }

async function load(force) {
  if (loading) return; loading = true; err = '';
  if (!D) render();
  try { D = await api('GET', '/api/delivery' + (force ? '?force=1' : '')); } catch (e) { err = e.message; }
  loading = false;
  if (D && !F.appId) { const a = D.apps.find(x => !D.products.some(p => p.appId === x.id && p.active)); setApp(a ? a.id : NEW); }
  render();
  if (D?.worker && !health && !checking) runCheck();
}
async function runCheck() {
  checking = true; render();
  try { health = await api('POST', '/api/delivery/check', {}); } catch (e) { health = { ok: false, error: e.message }; }
  checking = false; render();
}

// ---------- render ----------
const ready = () => !!(D?.github?.connected && D.github.canPrivate && D.cloudflare?.connected && D.stripe?.key && D.worker);
const tokenUrl = () => `https://github.com/settings/tokens/new?scopes=repo&description=${encodeURIComponent(`${S.site?.brand?.name || 'Studio'} paid downloads`)}`;
const CF_TOKEN_URL = 'https://dash.cloudflare.com/profile/api-tokens';
const size = n => (n >= 1073741824 ? `${(n / 1073741824).toFixed(2)} GB` : n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

function render() {
  const P = $('#dlPanel');
  if (!D) { P.innerHTML = err ? `<div class="card"><p class="note lock"><span>${I('alert')}</span>${esc(err)}</p><div class="row"><button class="hbtn ghost sm" data-reload>${I('refresh')}Try again</button></div></div>` : `<div class="card lv-loading"><span class="spinner"></span>Loading paid downloads…</div>`; return; }
  P.innerHTML = `<div class="st-grid">
    <div class="st-main">
      ${waitingCard()}
      ${setupCard()}
      ${productsCard()}
      ${sellCard()}
    </div>
    <div class="st-side">
      ${howCard()}
      ${D.worker ? serviceCard() : ''}
    </div>
  </div>`;
}

// Published apps that nobody can get: no buy or download button (e.g. the repo went private) and not for sale yet.
function waitingCard() {
  const list = D.apps.filter(a => a.published && !a.reachable && !['soon', 'dev'].includes(a.status) && !D.products.some(p => p.appId === a.id && p.active));
  if (!list.length) return '';
  return `<div class="card pd-wait"><h3>${I('alert')}${list.length === 1 ? `${esc(list[0].name)} has` : `${list.length} apps have`} no way to download</h3>
    <p class="sub">These apps are on your site without a download or buy button${list.some(a => a.repoPrivate) ? ' (their GitHub repository is private, so the old download link was removed)' : ''}. Put them on sale and the buy button appears by itself.</p>
    <div class="pd-wlist">${list.map(a => `<div class="pd-w">${appIcon(a.id)}<div><b>${esc(a.name)}</b><small>${[a.version, a.repo && a.repoPrivate ? `files in ${a.repo}` : '', a.licensed ? 'licence keys on' : ''].filter(Boolean).map(esc).join(' · ')}</small></div><span class="sp"></span><button type="button" class="hbtn primary sm" data-sellthis="${esc(a.id)}">${I('rocket')}Sell this</button></div>`).join('')}</div></div>`;
}
function stepHTML(n, done, title, sub, body, on) {
  return `<div class="pd-step${done ? ' done' : ''}${on ? ' on' : ''}"><span class="pd-num">${done ? I('check') : n}</span><div class="pd-sbody"><div class="pd-shead"><b>${title}</b>${sub ? `<small>${sub}</small>` : ''}</div>${on || !done ? body : ''}</div></div>`;
}
function setupCard() {
  const g = D.github, c = D.cloudflare, s = D.stripe, w = D.worker;
  const gDone = g.connected && g.canPrivate, cDone = c.connected, sDone = s.key, wDone = !!w;
  const all = gDone && cDone && sDone && wDone;
  const cur = !gDone ? 1 : !cDone ? 2 : !sDone ? 3 : !wDone ? 4 : 0;
  const ghBody = `<p class="sub">Your files go in <b>private</b> GitHub repositories, so the hub needs permission to create them and upload releases.</p>
    ${g.connected && !g.canPrivate ? `<p class="note lock"><span>${I('lock')}</span>Connected as ${esc(g.login)}, but that sign-in only covers public repositories. Add private access below.</p>` : g.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(g.error)}</p>` : ''}
    ${D.deviceFlow ? (dev ? `<div class="pd-device"><span>Enter this code on the GitHub page that just opened:</span><div class="su-code"><b>${esc(dev.userCode)}</b><button type="button" class="act" data-copy="${esc(dev.userCode)}" title="Copy">${I('copy')}</button></div><small class="muted"><span class="spinner sm"></span> Waiting for you to approve…</small></div>`
      : `<button type="button" class="hbtn primary" data-ghdevice>${I('github')}Sign in with GitHub</button><div class="pd-or"><span>or use a token</span></div>`) : ''}
    <ol class="pd-list"><li><a class="hbtn ${D.deviceFlow ? 'ghost' : 'primary'} sm" href="${tokenUrl()}" target="_blank" rel="noopener">${I('external')}Create a token on GitHub</a> The <b>repo</b> permission is already ticked. Pick an expiry (or “No expiration”), then press <b>Generate token</b>.</li><li>Copy the token (it starts with <code>ghp_</code>) and paste it here:</li></ol>
    <form class="inrow" id="pdGh"><input name="token" type="password" class="mono" autocomplete="off" spellcheck="false" placeholder="ghp_…"><button class="hbtn primary" type="submit">${I('check')}Connect</button></form>`;
  const cfBody = `<p class="sub">A tiny delivery service checks each purchase with Stripe and hands out the files. It runs on Cloudflare’s free plan in <b>your</b> account, so there’s nothing to pay and no server to look after.</p>
    <ol class="pd-list"><li>No account yet? <a href="https://dash.cloudflare.com/sign-up/workers" target="_blank" rel="noopener">Sign up free</a> (about a minute). Confirm your email address.</li>
      <li><a class="hbtn primary sm" href="${CF_TOKEN_URL}" target="_blank" rel="noopener">${I('external')}Open Cloudflare API tokens</a> Press <b>Create Token</b>, then <b>Use template</b> next to <b>Edit Cloudflare Workers</b>.</li>
      <li>Under <b>Account Resources</b> pick your account. Leave Zone Resources as they are. Press <b>Continue to summary</b>, then <b>Create Token</b>.</li>
      <li>Copy the token and paste it here:</li></ol>
    <form class="inrow" id="pdCf"><input name="token" type="password" class="mono" autocomplete="off" spellcheck="false" placeholder="Cloudflare API token"><button class="hbtn primary" type="submit">${I('check')}Connect</button></form>`;
  const sBody = `<p class="sub">The delivery service reads purchases with ${s.separate ? 'the separate key you added' : 'the Stripe key the hub already uses'}. It needs <b>Read</b> access to Checkout Sessions, Payment Links, PaymentIntents and Charges, and it can’t move money.</p>
    <div class="row"><button type="button" class="hbtn ghost sm" data-scheck>${I('shield')}Check the key</button><button type="button" class="hbtn ghost sm" data-skey>${I('key')}${s.separate ? 'Change' : 'Use a separate'} key</button></div>`;
  const wBody = `<p class="sub">One click puts the delivery service live at a free <code>workers.dev</code> address and adds a download page to your site.</p>
    <div class="f2 tight"><label class="fld"><span>Service name</span><input id="pdName" value="${esc(D.workerName)}" class="mono" ${w ? 'disabled' : ''}></label><label class="fld"><span>Download links work for</span><select id="pdDays">${[[0, 'Forever'], [30, '30 days'], [90, '90 days'], [365, '1 year']].map(([v, l]) => `<option value="${v}"${+D.days === v ? ' selected' : ''}>${l}</option>`).join('')}</select></label></div>
    <div class="row"><button type="button" class="hbtn primary" data-deploy>${I('rocket')}Deploy the delivery service</button></div>`;
  return `<div class="card pd-setup${all ? ' ok' : ''}"><div class="card-head"><h3>${I('shield')}Setup</h3>${all ? `<span class="dc-pill ok">${I('check')}Ready to sell</span>` : `<span class="dc-pill warn">${4 - [gDone, cDone, sDone, wDone].filter(Boolean).length} step${4 - [gDone, cDone, sDone, wDone].filter(Boolean).length === 1 ? '' : 's'} left</span>`}</div>
    ${all ? '' : `<p class="sub">About five minutes, once. After that, selling an app is one form.</p>`}
    <div class="pd-steps">
      ${stepHTML(1, gDone, 'GitHub: private file storage', gDone ? `Connected as <b>${esc(g.login)}</b> <button type="button" class="linkbtn" data-ghchange>change</button>` : '', ghBody, cur === 1)}
      ${stepHTML(2, cDone, 'Cloudflare: free delivery service', cDone ? `${esc(c.accountName || 'Connected')} ${(c.accounts || []).length > 1 ? `<select class="pd-mini" id="pdAcc">${c.accounts.map(a => `<option value="${esc(a.id)}"${a.id === c.accountId ? ' selected' : ''}>${esc(a.name)}</option>`).join('')}</select>` : ''} <button type="button" class="linkbtn" data-cfchange>change</button>` : '', cfBody, cur === 2)}
      ${stepHTML(3, sDone, 'Stripe: purchase checks', sDone ? `${s.separate ? 'Separate read key' : 'Using your hub’s Stripe key'} <button type="button" class="linkbtn" data-scheck>check</button>` : '', sBody, cur === 3)}
      ${stepHTML(4, wDone, 'Go live', wDone ? `<a href="${esc(w.url)}/health" target="_blank" rel="noopener">${esc(w.url.replace(/^https:\/\//, ''))}</a>` : '', wBody, cur === 4)}
    </div></div>`;
}

function productsCard() {
  const list = D.products.filter(p => p.active);
  if (!list.length && (!D.productsError || !D.stripe.key)) return '';
  return `<div class="card"><div class="card-head"><h3>${I('package')}For sale</h3><button type="button" class="hbtn ghost sm" data-reload>${I('refresh')}Refresh</button></div>
    ${D.productsError ? `<p class="note lock"><span>${I('alert')}</span>${esc(D.productsError)}</p>` : ''}
    <div class="pd-prods">${list.map(productRow).join('')}</div></div>`;
}
const licPill = id => { const a = D.apps.find(x => x.id === id); return a?.licensed ? `<a class="dc-pill violet" href="#/store/licences">${I('key')}Licence keys</a>` : `<a class="dc-pill" href="#/store/licences">${I('key')}No licence keys</a>`; };
function appIcon(id) {
  const a = D.apps.find(x => x.id === id);
  return a?.iconImage ? `<img src="/media/${esc(a.iconImage)}" alt="">` : `<span class="st-ic">${I(a?.glyph || 'package')}</span>`;
}
function productRow(p) {
  const r = rels[p.repo], t = check[p.linkId];
  const relFor = r && (p.tag === 'latest' ? r.find(x => x.latest) : r.find(x => x.tag === p.tag));
  return `<div class="st-link pd-prod">
    <div class="st-lh">${appIcon(p.appId)}<div><b>${esc(p.appName)}</b><small>${I('lock')} ${esc(p.repo)} · ${p.tag === 'latest' ? 'latest release' : esc(p.tag)}</small></div>
      <div class="st-price"><b>${esc(p.label || '—')}</b><small>${p.live ? 'Live' : 'Test mode'}</small></div></div>
    <div class="row st-tags">${p.onApp ? `<span class="dc-pill ok">${I('check')}Buy button on the app</span>` : `<span class="dc-pill warn">${I('alert')}Not on the app’s button</span>`}${p.published ? '' : `<span class="dc-pill">App is a draft</span>`}${licPill(p.appId)}<a class="dc-pill${D.taxAuto ? ' ok' : ''}" href="#/store/tax">${I('shield')}${D.taxAuto ? 'Tax collected' : 'Tax off'}</a></div>
    ${t ? `<div class="pd-test ${t.ok ? 'ok' : 'bad'}">${t.busy ? `<span class="spinner sm"></span>Testing delivery…` : t.ok ? `${I('check')}<span>Delivery works. Buyers get: ${(t.checks?.release?.files || []).map(f => `<b>${esc(f.name)}</b> (${size(f.size)})`).join(', ') || 'no files yet'}${t.checks?.release?.tag ? ` from ${esc(t.checks.release.tag)}` : ''}.</span>` : `${I('alert')}<span>${esc(t.error || 'The test failed.')}</span>`}</div>` : ''}
    ${open.has(p.linkId) ? filesPanel(p, r, relFor) : ''}
    <div class="row"><button type="button" class="hbtn ghost sm" data-files="${esc(p.linkId)}">${I('folder')}${open.has(p.linkId) ? 'Hide files' : 'Files & versions'}</button>
      <button type="button" class="hbtn ghost sm" data-upnew="${esc(p.linkId)}">${I('upload')}Upload new version</button>
      <button type="button" class="hbtn ghost sm" data-test="${esc(p.linkId)}">${I('zap')}Test delivery</button>
      <a class="hbtn ghost sm" href="#/store/prices" data-editlink="${esc(p.linkId)}">${I('tag')}Change price</a>
      <span class="sp"></span><button type="button" class="hbtn ghost sm" data-stop="${esc(p.linkId)}">Stop selling</button></div>
    ${up?.linkId === p.linkId ? uploadPanel(p) : ''}
  </div>`;
}
function filesPanel(p, r, relFor) {
  if (!r) return `<div class="pd-files"><span class="spinner sm"></span> Loading releases…</div>`;
  if (!r.length) return `<div class="pd-files"><p class="muted">No releases yet. Upload the first version.</p></div>`;
  return `<div class="pd-files">${r.map(x => `<div class="pd-rel${relFor?.id === x.id ? ' cur' : ''}"><div class="pd-relh"><b>${esc(x.tag)}</b>${x.name !== x.tag ? `<span>${esc(x.name)}</span>` : ''}${x.latest ? `<span class="dc-pill ok">Latest</span>` : ''}${relFor?.id === x.id ? `<span class="dc-pill violet">Buyers get this</span>` : `<button type="button" class="linkbtn" data-pin="${esc(p.linkId)}" data-tag="${esc(x.tag)}">sell this version</button>`}<small class="muted">${esc(rel(x.date))}</small></div>
      ${x.files.length ? x.files.map(f => `<div class="pd-file">${I('package')}<span>${esc(f.name)}</span><small>${size(f.size)} · ${f.downloads} download${f.downloads === 1 ? '' : 's'}</small><button type="button" class="act" title="Delete this file" data-delfile="${esc(p.repo)}" data-id="${f.id}">${I('trash')}</button></div>`).join('') : '<small class="muted">No files in this release.</small>'}</div>`).join('')}
    ${p.tag !== 'latest' ? `<button type="button" class="linkbtn" data-pin="${esc(p.linkId)}" data-tag="latest">Always sell the latest release instead</button>` : ''}</div>`;
}
function uploadPanel(p) {
  return `<form class="fb pd-up" data-upform="${esc(p.linkId)}">
    ${dropZone('up', up.file)}
    <div class="f2"><label class="fld"><span>Version tag</span><input data-u="tag" value="${esc(up.tag)}" class="mono" placeholder="v1.1.0" required></label><label class="fld"><span>What’s new <small>optional, shown on the download page</small></span><input data-u="notes" value="${esc(up.notes)}" placeholder="Faster start-up, new export option"></label></div>
    ${progressHTML('up')}
    <div class="row"><button class="hbtn primary sm" type="submit">${I('upload')}Upload</button><button class="hbtn ghost sm" type="button" data-upcancel>Cancel</button></div>
    <p class="muted small">${p.tag === 'latest' ? 'Buyers, including everyone who already bought it, get this version as soon as the upload finishes.' : `This product is pinned to ${esc(p.tag)}. After uploading you can switch buyers to the new version.`}</p>
  </form>`;
}
const dropZone = (key, file) => `<label class="pd-drop${file ? ' has' : ''}" data-drop="${key}"><input type="file" hidden data-pick="${key}">${file ? `${I('package')}<span><b>${esc(file.name)}</b><small>${size(file.size)} · click to change</small></span>` : `${I('upload')}<span><b>Drop the file buyers get</b><small>An installer, zip or any file up to 2 GB · or click to choose</small></span>`}</label>`;
const progressHTML = key => `<div class="pd-prog" id="prog-${key}" hidden><div class="pd-bar"><i></i></div><small></small></div>`;
function setProgress(key, label, frac) {
  const el = document.getElementById('prog-' + key); if (!el) return;
  el.hidden = false; el.querySelector('i').style.width = `${Math.round(Math.max(0, Math.min(1, frac)) * 100)}%`; el.querySelector('small').textContent = label;
}

function sellCard() {
  const avail = D.apps;
  const a = D.apps.find(x => x.id === F.appId);
  const selling = a && D.products.find(p => p.appId === a.id && p.active);
  const disabled = !ready();
  const cur = D.currency;
  return `<div class="card pd-sell${disabled ? ' locked' : ''}"><h3>${I('plus')}Sell an app</h3>
    <p class="sub">${disabled ? 'Finish the setup above first. You can look around in the meantime.' : 'The hub creates the private repository, uploads the file, makes the Stripe checkout and puts a buy button on the app.'}</p>
    <form class="fb" id="pdSell">
      <label class="fld"><span>App</span><select data-f="appId" id="pdApp"><option value="${NEW}"${F.appId === NEW ? ' selected' : ''}>＋ New app…</option>${avail.map(x => `<option value="${esc(x.id)}"${x.id === F.appId ? ' selected' : ''}>${esc(x.name)}${x.published ? '' : ' (draft)'}${D.products.some(p => p.appId === x.id && p.active) ? ' · already for sale' : ''}</option>`).join('')}</select></label>
      ${F.appId === NEW ? `<label class="fld"><span>App name</span><input data-f="newName" id="pdNewName" value="${esc(F.newName)}" placeholder="e.g. PixelForge" maxlength="80" required></label>
        <p class="note"><span>${I('info')}</span>The app is added to your site (Apps) when you press Start selling. Add its description, icon and screenshots there afterwards.</p>` : ''}
      ${selling ? `<p class="note lock"><span>${I('info')}</span>${esc(a.name)} is already for sale (${esc(selling.label)}). Selling it again makes a second checkout and moves the buy button to it.</p>` : ''}
      ${a && a.primaryUrl && !selling ? `<p class="note"><span>${I('info')}</span>The app’s main button currently opens <code>${esc(a.primaryUrl.slice(0, 60))}</code>. It will open the checkout instead.</p>` : ''}
      <div class="fld"><span>Where the files live</span>
        <div class="seg">${[['new', 'New private repository'], ['existing', 'One I already have']].map(([v, l]) => `<button type="button" data-repomode="${v}" class="${F.repoMode === v ? 'on' : ''}">${l}</button>`).join('')}</div></div>
      ${F.repoMode === 'new' ? `<div class="f2 tight"><label class="fld"><span>Owner</span><select data-f="owner">${(owners || [D.github.login || '']).map(o => `<option${o === F.owner ? ' selected' : ''}>${esc(o)}</option>`).join('')}</select></label><label class="fld"><span>Repository name <small>private</small></span><input data-f="repoName" value="${esc(F.repoName)}" class="mono" placeholder="my-app-releases"></label></div>`
        : `<label class="fld"><span>Private repository</span><select data-f="repo" id="pdRepo"><option value="">${repos ? (repos.length ? 'Choose…' : 'No private repositories found') : 'Loading…'}</option>${(repos || []).map(r => `<option value="${esc(r.full)}"${r.full === F.repo ? ' selected' : ''}>${esc(r.full)}</option>`).join('')}</select></label>
          ${F.repo && rels[F.repo] ? (rels[F.repo].length ? `<p class="muted small">Latest release: <b>${esc(rels[F.repo].find(x => x.latest)?.tag || rels[F.repo][0].tag)}</b> · ${(rels[F.repo].find(x => x.latest) || rels[F.repo][0]).files.map(f => esc(f.name)).join(', ') || 'no files'}. Add a file below to publish a new version, or leave it empty to sell what’s there.</p>` : `<p class="muted small">No releases yet: add the file below.</p>`) : ''}`}
      ${dropZone('sell', F.file)}
      ${tinyExe(F.file) ? `<p class="note lock"><span>${I('alert')}</span><span><b>${esc(F.file.name)}</b> is only ${Math.round(F.file.size / 1024)} KB. An .exe that small is usually the launcher from <code>bin\\</code>, which won’t run on its own. Use the published build (for .NET: the <code>publish</code> folder of a self-contained single-file build) or a zip of the whole app.</span></p>` : ''}
      <div class="f2"><label class="fld"><span>Version tag</span><input data-f="tag" value="${esc(F.tag)}" class="mono" placeholder="v1.0.0"></label><label class="fld"><span>What’s new <small>optional</small></span><input data-f="notes" value="${esc(F.notes)}" placeholder="First release"></label></div>
      <div class="fld"><span>Price (${esc(cur)})</span><div class="seg">${[['fixed', 'Fixed price'], ['custom', 'Pay what you want']].map(([v, l]) => `<button type="button" data-pmode="${v}" class="${F.mode === v ? 'on' : ''}">${l}</button>`).join('')}</div></div>
      ${F.mode === 'fixed' ? `<label class="fld"><span>Price</span><input type="number" step="0.01" min="0.5" data-f="amount" value="${esc(F.amount)}" placeholder="9.99"></label>`
        : `<div class="f3"><label class="fld"><span>Minimum</span><input type="number" step="0.01" min="0.5" data-f="min" value="${esc(F.min)}" placeholder="5"></label><label class="fld"><span>Suggested</span><input type="number" step="0.01" data-f="preset" value="${esc(F.preset)}" placeholder="10"></label><label class="fld"><span>Maximum</span><input type="number" step="0.01" data-f="max" value="${esc(F.max)}" placeholder="none"></label></div>`}
      <label class="fld"><span>Button text <small>optional</small></span><input data-f="buttonLabel" value="${esc(F.buttonLabel)}" placeholder="Buy · ${esc(cur)} price"></label>
      <label class="switch"><input type="checkbox" data-f="invoice"${F.invoice ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Email buyers a Stripe invoice and receipt</span></label>
      <label class="switch"><input type="checkbox" data-f="promo"${F.promo ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Allow promotion codes</span></label>
      ${steps ? `<ol class="pd-progress">${steps.map(s => `<li class="${s.state}">${s.state === 'busy' ? '<span class="spinner sm"></span>' : s.state === 'done' ? I('check') : s.state === 'err' ? I('x') : '<i></i>'}<span>${esc(s.label)}</span></li>`).join('')}</ol>` : ''}
      ${progressHTML('sell')}
      <div class="row"><button class="hbtn primary" type="submit"${disabled ? ' disabled' : ''}>${I('rocket')}Start selling</button></div>
    </form></div>`;
}

function howCard() {
  return `<div class="card"><h3>${I('info')}How it works</h3>
    <ol class="pd-how">
      <li>${I('lock')}<span>Your files sit in a <b>private</b> GitHub repository. Nobody can see or download them directly.</span></li>
      <li>${I('card')}<span>The app’s button opens a <b>Stripe checkout</b>. Stripe handles cards, Apple Pay, Google Pay and receipts.</span></li>
      <li>${I('download')}<span>After paying, the buyer lands on <b>${esc((D.siteUrl || 'your site').replace(/^https?:\/\//, ''))}/download/</b>. The delivery service checks the purchase with Stripe and starts the download.</span></li>
      <li>${I('mail')}<span>The hub also <b>emails</b> them their personal download link (Discord → Emails).</span></li>
      <li>${I('refresh')}<span>Upload a new version any time. Past buyers get it from the same link. Refunds and disputes switch the link off automatically.</span></li>
    </ol>
    <p class="note"><span>${I('shield')}</span>Your Stripe key and GitHub token are stored as encrypted secrets in your Cloudflare account. Buyers only ever get a GitHub link that’s signed for one file and expires within minutes.</p></div>`;
}
function serviceCard() {
  const w = D.worker, h = health;
  const outdated = w.version !== D.latestVersion;
  return `<div class="card"><div class="card-head"><h3>${I('activity')}Delivery service</h3>${checking ? `<span class="dc-pill"><span class="spinner sm"></span>Checking</span>` : h ? (h.ok ? `<span class="dc-pill ok">${I('check')}Healthy</span>` : `<span class="dc-pill bad">${I('alert')}Needs attention</span>`) : ''}</div>
    <div class="kv"><span>Address</span><b><a href="${esc(w.url)}/health" target="_blank" rel="noopener">${esc(w.url.replace(/^https:\/\//, ''))}</a></b>
      <span>Download page</span><b><a href="${esc(D.siteUrl)}/download/?demo=1" target="_blank" rel="noopener">${esc(D.siteUrl.replace(/^https?:\/\//, ''))}/download/</a></b>
      <span>Links last</span><b>${+w.days ? `${w.days} days` : 'Forever'}</b>
      <span>Version</span><b>${esc(w.version)}${outdated ? ` <span class="dc-pill warn">Update ${esc(D.latestVersion)} available</span>` : ''}</b>
      <span>Updated</span><b>${esc(rel(w.deployedAt))}</b></div>
    ${h && !h.ok && h.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(h.error)}</p>` : ''}
    <div class="row"><button type="button" class="hbtn ghost sm" data-hcheck>${I('zap')}Run self-test</button><button type="button" class="hbtn ${outdated ? 'primary' : 'ghost'} sm" data-deploy>${I('refresh')}${outdated ? 'Update' : 'Redeploy'}</button>
      <label class="pd-inl">Links last <select id="pdDays">${[[0, 'Forever'], [30, '30 days'], [90, '90 days'], [365, '1 year']].map(([v, l]) => `<option value="${v}"${+D.days === v ? ' selected' : ''}>${l}</option>`).join('')}</select></label></div>
    <p class="muted small">Open the download page with <code>?demo=1</code> to preview it with sample files. Redeploy after changing your Stripe key or GitHub sign-in.</p></div>`;
}

// ---------- helpers ----------
const tinyExe = f => !!f && /\.exe$/i.test(f.name) && f.size < 1024 * 1024;
function setApp(id) {
  F.appId = id;
  if (id === NEW) {
    F.repoName = F.newName ? `${slug(F.newName)}-releases` : '';
    F.tag = F.tag || 'v1.0.0';
    F.owner = F.owner || D?.github.login || '';
    return;
  }
  const a = D?.apps.find(x => x.id === id);
  if (!a) return;
  F.repoName = `${a.id}-releases`;
  F.tag = a.version ? (/^\d/.test(a.version) ? `v${a.version}` : a.version) : 'v1.0.0';
  F.owner = F.owner || D.github.login || '';
}
function pickFile(key, f) {
  if (f.size > 2 * 1024 ** 3 - 1) return toast('GitHub stores files up to 2 GB each.', 'err');
  if (key === 'up' && up) up.file = f; else F.file = f;
  // New app with no name yet: take it from the file (PixelForge-v1.2.0-win-x64.zip → PixelForge)
  if (key !== 'up' && F.appId === NEW && !F.newName.trim()) {
    F.newName = f.name.replace(/\.[^.]+$/, '').replace(/[-_ ]v?\d+(\.\d+)*.*$/i, '').replace(/[-_]+/g, ' ').trim();
    setApp(NEW);
  }
  render();
}
async function loadRels(repo, force) {
  if (!repo || (rels[repo] && !force)) return;
  try { rels[repo] = (await api('GET', '/api/delivery/releases?repo=' + encodeURIComponent(repo))).releases; } catch (e) { rels[repo] = []; toast(e.message, 'err'); }
  render();
}
async function ensureLists() {
  if (!D.github.connected || !D.github.canPrivate) return;
  if (!owners) { try { owners = (await api('GET', '/api/delivery/owners')).owners; if (!F.owner) F.owner = owners[0]; } catch { owners = [D.github.login]; } }
  if (!repos && F.repoMode === 'existing') { try { repos = (await api('GET', '/api/delivery/repos')).repos; } catch (e) { repos = []; toast(e.message, 'err'); } }
  render();
}
function uploadFile(repo, tag, file, extra, key) {
  const qs = new URLSearchParams({ repo, tag, name: file.name, title: extra.title || '', notes: extra.notes || '' });
  return new Promise((ok, fail) => {
    const x = new XMLHttpRequest();
    x.open('POST', '/api/delivery/upload?' + qs);
    x.setRequestHeader('X-Hub-Token', TOKEN);
    x.upload.onprogress = e => setProgress(key, `Reading the file… ${size(e.loaded)} of ${size(e.total)}`, (e.loaded / e.total) * 0.15);
    x.onload = () => { let j = {}; try { j = JSON.parse(x.responseText); } catch {} x.status === 200 ? ok(j.job) : fail(new Error(j.error || `Upload failed (${x.status})`)); };
    x.onerror = () => fail(new Error('The upload was interrupted.'));
    x.send(file);
  }).then(async job => {
    for (;;) {
      await sleep(700);
      const j = await api('GET', '/api/delivery/job?id=' + job);
      setProgress(key, j.state === 'done' ? 'Uploaded to GitHub' : `Uploading to GitHub… ${size(j.sent)} of ${size(j.total)}`, 0.15 + (j.sent / j.total) * 0.85);
      if (j.state === 'done') return j;
      if (j.state === 'error') throw new Error(j.error);
    }
  });
}
async function reloadSite() {
  const st = await api('GET', '/api/state');
  S.apps = st.apps; S.site = st.site; S.siteDraft = structuredClone(st.site);
  emit('apps'); refreshStatus();
}
async function askPublish(what) {
  if (!(await confirmBox('Publish the site now?', `${what} Publish so visitors see it (about a minute).`, 'Publish now', false))) return false;
  toast('Publishing…', 'info');
  try { await api('POST', '/api/publish', { message: 'Update paid downloads' }); toast('Published ✓'); refreshStatus(); return true; }
  catch (e) { toast(e.message, 'err', 9000); return false; }
}
async function pollDevice() {
  while (dev) {
    await sleep((dev.interval || 5) * 1000);
    if (!dev) return;
    try {
      const r = await api('POST', '/api/delivery/github/poll', { deviceCode: dev.deviceCode });
      if (r.done) { dev = null; D = r; owners = repos = null; toast(`Connected as ${D.github.login} ✓`); render(); ensureLists(); return; }
      if (r.slow) dev.interval = (dev.interval || 5) + 5;
    } catch (e) { dev = null; toast(e.message, 'err', 8000); render(); return; }
  }
}

// ---------- events ----------
async function onChange(e) {
  const t = e.target;
  try {
    if (t.dataset.pick) { const f = t.files?.[0]; if (f) pickFile(t.dataset.pick, f); return; }
    if (t.id === 'pdApp') { setApp(t.value); render(); return; }
    if (t.id === 'pdRepo') { F.repo = t.value; render(); loadRels(F.repo); return; }
    if (t.id === 'pdAcc') { D = await api('POST', '/api/delivery/cloudflare/account', { id: t.value }); toast('Account switched. Deploy again to use it.'); render(); return; }
    if (t.id === 'pdDays') {
      if (D.worker) toast('Updating the delivery service…', 'info');
      const r = await api('POST', '/api/delivery/settings', { days: +t.value }); D = r; toast(D.worker ? 'Download links updated ✓' : 'Saved'); render(); return;
    }
    if (t.id === 'pdName') { D = await api('POST', '/api/delivery/settings', { workerName: t.value }); render(); return; }
    if (t.dataset.f) F[t.dataset.f] = t.type === 'checkbox' ? t.checked : t.value;
  } catch (x) { toast(x.message, 'err', 9000); render(); }
}
async function onClick(e) {
  const st = e.target.closest('[data-sellthis]');
  if (st) {
    const a = D.apps.find(x => x.id === st.dataset.sellthis); if (!a) return;
    setApp(a.id);
    if (a.repo && a.repoPrivate) { F.repoMode = 'existing'; F.repo = a.repo; if (!repos) repos = [{ full: a.repo }]; else if (!repos.some(r => r.full === a.repo)) repos.unshift({ full: a.repo }); loadRels(a.repo); }
    render();
    setTimeout(() => { const el = $('#pdSell'); el?.scrollIntoView({ behavior: 'smooth', block: 'start' }); el?.querySelector('[data-f="amount"]')?.focus(); }, 60);
    return;
  }
  const q = s => e.target.closest(s);
  let b;
  try {
    if (q('[data-reload]')) { await load(true); return; }
    if ((b = q('[data-copy]'))) { await navigator.clipboard.writeText(b.dataset.copy); toast('Copied'); return; }
    if (q('[data-ghdevice]')) { dev = await api('POST', '/api/delivery/github/device'); window.open(dev.url, '_blank', 'noopener'); render(); pollDevice(); return; }
    if (q('[data-ghchange]')) { if (!(await confirmBox('Change the GitHub connection?', 'Downloads keep working with the current connection until you connect a new one and redeploy.', 'Change', false))) return; D.github = { connected: false }; render(); return; }
    if (q('[data-cfchange]')) { D.cloudflare = { connected: false }; render(); return; }
    if (q('[data-scheck]')) { const r = await api('POST', '/api/delivery/stripe/check'); toast(`Stripe key works ✓ (${r.live ? 'live' : 'test'} mode)`); return; }
    if (q('[data-skey]')) {
      const r = await formBox('Stripe key for downloads', 'Optional. Create a restricted key in Stripe → Developers → API keys with <b>Read</b> access to Checkout Sessions, Payment Links, PaymentIntents and Charges. Leave empty to use the hub’s key.', [{ name: 'key', label: 'Restricted key', placeholder: 'rk_live_…', mono: true }], 'Save');
      if (!r) return; D = await api('PUT', '/api/delivery/stripe', { key: r.key }); toast(r.key ? 'Key checked and saved ✓' : 'Using the hub’s key'); render(); return;
    }
    if ((b = q('[data-deploy]'))) {
      b.disabled = true; b.innerHTML = `<span class="spinner sm"></span>Deploying… (about 20 seconds)`;
      const r = await api('POST', '/api/delivery/deploy'); D = r; health = r.result.health;
      toast(r.result.health?.ok ? 'Delivery service is live ✓' : 'Deployed. It can take a minute to answer the first time.', r.result.health?.ok ? 'ok' : 'info', 6000);
      render(); ensureLists();
      if (r.result.siteChanged) await askPublish('Your site gets its new download page.');
      return;
    }
    if (q('[data-hcheck]')) { health = null; await runCheck(); toast(health.ok ? 'Self-test passed ✓' : 'Self-test found a problem', health.ok ? 'ok' : 'err'); return; }
    if ((b = q('[data-repomode]'))) { F.repoMode = b.dataset.repomode; render(); ensureLists(); return; }
    if ((b = q('[data-pmode]'))) { F.mode = b.dataset.pmode; render(); return; }
    if ((b = q('[data-files]'))) { const p = D.products.find(x => x.linkId === b.dataset.files); open.has(p.linkId) ? open.delete(p.linkId) : open.add(p.linkId); render(); if (open.has(p.linkId)) loadRels(p.repo, true); return; }
    if ((b = q('[data-upnew]'))) { const p = D.products.find(x => x.linkId === b.dataset.upnew); const a = D.apps.find(x => x.id === p.appId); up = { linkId: p.linkId, repo: p.repo, file: null, tag: a?.version ? (/^\d/.test(a.version) ? `v${a.version}` : a.version) : '', notes: '' }; render(); return; }
    if (q('[data-upcancel]')) { up = null; render(); return; }
    if ((b = q('[data-test]'))) {
      const id = b.dataset.test; check[id] = { busy: true }; render();
      const r = await api('POST', '/api/delivery/check', { linkId: id }); check[id] = r; render(); return;
    }
    if ((b = q('[data-pin]'))) {
      const p = D.products.find(x => x.linkId === b.dataset.pin);
      if (!(await confirmBox(b.dataset.tag === 'latest' ? 'Always sell the latest release?' : `Sell ${b.dataset.tag}?`, b.dataset.tag === 'latest' ? 'Buyers, including past buyers, get whichever release is marked latest on GitHub.' : `Buyers, including past buyers, get ${b.dataset.tag} until you change it.`, 'Switch', false))) return;
      D = await api('POST', '/api/delivery/target', { linkId: p.linkId, repo: p.repo, tag: b.dataset.tag }); check = {}; toast('Updated ✓'); render(); loadRels(p.repo, true); return;
    }
    if ((b = q('[data-delfile]'))) {
      if (!(await confirmBox('Delete this file from GitHub?', 'Buyers stop seeing it on their download page straight away. This can’t be undone.'))) return;
      rels[b.dataset.delfile] = (await api('DELETE', `/api/delivery/file?repo=${encodeURIComponent(b.dataset.delfile)}&id=${b.dataset.id}`)).releases; render(); return;
    }
    if ((b = q('[data-stop]'))) {
      const p = D.products.find(x => x.linkId === b.dataset.stop);
      if (!(await confirmBox(`Stop selling ${p.appName}?`, 'The checkout link is switched off and the buy button is removed from the app. People who already bought it can still download it.', 'Stop selling'))) return;
      const r = await api('POST', '/api/delivery/stop', { linkId: p.linkId }); D = r; render(); await reloadSite();
      if (r.result.siteChanged) await askPublish('The buy button is removed from the app.');
      return;
    }
  } catch (x) { toast(x.message, 'err', 10000); render(); }
}

async function onSubmit(e) {
  e.preventDefault();
  const f = e.target, btn = f.querySelector('button[type=submit]');
  const busy = t => { if (btn) { btn.disabled = true; btn.innerHTML = `<span class="spinner sm"></span>${t}`; } };
  try {
    if (f.id === 'pdGh') { busy('Connecting…'); D = await api('PUT', '/api/delivery/github', { token: f.token.value }); owners = repos = null; toast(`Connected as ${D.github.login} ✓`); render(); ensureLists(); return; }
    if (f.id === 'pdCf') { busy('Connecting…'); D = await api('PUT', '/api/delivery/cloudflare', { token: f.token.value }); toast(`Cloudflare connected: ${D.cloudflare.accountName} ✓`); render(); return; }
    if (f.dataset.upform) {
      const p = D.products.find(x => x.linkId === f.dataset.upform);
      if (!up.file) return toast('Choose the file first.', 'err');
      if (!up.tag.trim()) return toast('Give this version a tag, like v1.1.0.', 'err');
      busy('Uploading…');
      await uploadFile(p.repo, up.tag.trim(), up.file, { notes: up.notes }, 'up');
      toast(`${up.file.name} uploaded ✓`); const tag = up.tag.trim(); up = null; check = {};
      await loadRels(p.repo, true); open.add(p.linkId); render();
      if (p.tag !== 'latest' && p.tag !== tag && await confirmBox(`Sell ${tag} now?`, `This product is pinned to ${p.tag}. Switch buyers (including past buyers) to ${tag}?`, 'Switch', false)) {
        D = await api('POST', '/api/delivery/target', { linkId: p.linkId, repo: p.repo, tag }); render();
      }
      return;
    }
    if (f.id === 'pdSell') {
      const isNew = F.appId === NEW;
      if (isNew && !F.newName.trim()) return toast('Give the new app a name.', 'err');
      let a = isNew ? { id: '', name: F.newName.trim() } : D.apps.find(x => x.id === F.appId);
      if (!a) return toast('Pick an app.', 'err');
      if (F.mode === 'fixed' && !(+F.amount >= 0.5)) return toast('Enter a price.', 'err');
      if (F.repoMode === 'existing' && !F.repo) return toast('Pick the repository with the files.', 'err');
      if (F.repoMode === 'new' && !F.file) return toast('Add the file buyers get.', 'err');
      if (F.file && !F.tag.trim()) return toast('Give this version a tag, like v1.0.0.', 'err');
      steps = [isNew && { k: 'newapp', label: `Add ${a.name} to your apps` }, F.repoMode === 'new' && { k: 'repo', label: `Create private repository ${F.owner}/${F.repoName}` }, F.file && { k: 'file', label: `Upload ${F.file.name} as ${F.tag}` }, { k: 'stripe', label: 'Create the Stripe product, price and checkout' }, { k: 'app', label: `Put the buy button on ${a.name}` }].filter(Boolean).map(s => ({ ...s, state: 'todo' }));
      const mark = (k, state) => { const s = steps.find(x => x.k === k); if (s) s.state = state; render(); };
      busy('Working…');
      let repo = F.repo, k = '';
      try {
        if (isNew) { k = 'newapp'; mark(k, 'busy'); const c = await api('POST', '/api/delivery/app', { name: a.name, version: F.tag.trim() }); a = c.app; D.apps = c.apps; F.appId = a.id; mark(k, 'done'); }
        if (F.repoMode === 'new') { k = 'repo'; mark(k, 'busy'); repo = (await api('POST', '/api/delivery/repos', { owner: F.owner, name: F.repoName, description: `Release files for ${a.name} (paid download). Keep private.` })).full; mark(k, 'done'); }
        if (F.file) { k = 'file'; mark(k, 'busy'); await uploadFile(repo, F.tag.trim(), F.file, { title: `${a.name} ${F.tag.trim()}`, notes: F.notes }, 'sell'); mark(k, 'done'); }
        k = 'stripe'; mark(k, 'busy');
        const r = await api('POST', '/api/delivery/sell', { appId: a.id, repo, tag: 'latest', mode: F.mode, amount: F.amount, min: F.min, preset: F.preset, max: F.max, buttonLabel: F.buttonLabel, promo: F.promo, invoice: F.invoice });
        mark('stripe', 'done'); mark('app', 'done');
        D = r; repos = null;
        toast(`${a.name} is for sale at ${r.result.label} ✓`, 'ok', 6000);
        Object.assign(F, { file: null, notes: '', amount: '', min: '', preset: '', max: '', buttonLabel: '', repo: '', newName: '' });
        steps = null; render();
        await reloadSite();
        await askPublish(`${a.name} now has a buy button (${r.result.label}).`);
      } catch (x) { mark(k, 'err'); throw x; }
      return;
    }
  } catch (x) { toast(x.message, 'err', 12000); render(); }
}
