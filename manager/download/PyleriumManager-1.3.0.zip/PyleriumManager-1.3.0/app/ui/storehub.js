// Store tab: everything about selling in one place.
//   Apps for sale     paid downloads (private files, buy buttons, versions) + auto-sync   (downloads.js, sync.js)
//   Products & prices every Stripe product, price, payment link and perk rule            (store.js)
//   Licences          keys for licensed apps and drop-in key checks                       (licences.js)
//   Tax               Stripe Tax, sales per country, reports                              (tax.js)
import { $, $$ } from './core.js';
import * as Store from './store.js';
import * as Downloads from './downloads.js';
import * as Licences from './licences.js';
import * as Tax from './tax.js';
import * as Sync from './sync.js';

const TABS = ['apps', 'prices', 'licences', 'tax'];
// Old addresses (#/downloads, #/licences, #/tax, #/store/perks) land on the right sub-tab.
export const LEGACY = { downloads: 'apps', licences: 'licences', tax: 'tax' };

export function init() {
  Store.init(); Downloads.init(); Licences.init(); Tax.init(); Sync.init();
  $('#storeTabs').addEventListener('click', e => { const b = e.target.closest('[data-stt]'); if (b) location.hash = '#/store/' + b.dataset.stt; });
  // "Change price" on an app for sale opens that price in Products & prices
  document.addEventListener('click', e => { const a = e.target.closest('[data-editlink]'); if (a) sessionStorage.setItem('store.edit', a.dataset.editlink); }, true);
}

export async function show(sub) {
  const tab = sub === 'perks' ? 'prices' : TABS.includes(sub) ? sub : 'apps';
  $$('#storeTabs [data-stt]').forEach(b => b.classList.toggle('on', b.dataset.stt === tab));
  $$('main[data-view="store"] [data-st]').forEach(s => (s.hidden = s.dataset.st !== tab));
  if (tab === 'apps') { Sync.show(); return Downloads.show(); }
  if (tab === 'prices') return Store.show(sub === 'perks' ? 'perks' : undefined);
  if (tab === 'licences') return Licences.show();
  return Tax.show();
}
