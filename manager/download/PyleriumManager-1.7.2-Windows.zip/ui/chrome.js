// App shell behaviour shared by Pylerium Manager and the Studio Hub: navigation indicator, mobile menu sheet, keyboard
// navigation and ARIA state for tab groups, header scroll state, view-header reveal, the shortcuts sheet, skip link and
// footer. Visual rules live in design.css. Everything here is created once; observers, listeners and animation frames
// are tracked and released by teardown(). DOM reads and writes are batched per frame (read first, then write).
import { R, S, $, $$, esc, on } from './core.js';

const I = n => R.icon(n);
const live = { observers: [], listeners: [], frames: new Set() };
const listen = (target, type, fn, opts) => { target.addEventListener(type, fn, opts); live.listeners.push([target, type, fn, opts]); };
const frame = fn => { const id = requestAnimationFrame(t => { live.frames.delete(id); fn(t); }); live.frames.add(id); return id; };
const reducedMotion = () => matchMedia('(prefers-reduced-motion: reduce)').matches || document.documentElement.dataset.motion === 'reduced';
const typing = () => { const a = document.activeElement; return !!a && (a.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)); };
const isManager = () => !!document.querySelector('[data-set="phone"]');

export function init() {
  if (live.started) return; live.started = true;
  skipLink(); navIndicator(); mobileMenu(); tabKeys(); ariaSync(); headerState(); reveal(); shortcuts(); footer();
}
export function teardown() {
  for (const o of live.observers) o.disconnect();
  for (const [t, type, fn, opts] of live.listeners) t.removeEventListener(type, fn, opts);
  for (const id of live.frames) cancelAnimationFrame(id);
  live.observers = []; live.listeners = []; live.frames.clear(); live.started = false;
}

// ---------- skip link: straight to the visible view ----------
function skipLink() {
  const a = Object.assign(document.createElement('a'), { className: 'skip', href: '#', textContent: 'Skip to content' });
  listen(a, 'click', e => {
    e.preventDefault();
    const m = $$('main.view').find(x => !x.hidden); if (!m) return;
    m.tabIndex = -1; m.focus({ preventScroll: false });
  });
  document.body.prepend(a);
}

// ---------- one indicator gliding under the active tab (transform only) ----------
function navIndicator() {
  const nav = $('#viewNav'); if (!nav) return;
  nav.setAttribute('aria-label', 'Sections');
  const ind = Object.assign(document.createElement('span'), { className: 'nav-ind no-anim' });
  ind.setAttribute('aria-hidden', 'true');
  nav.append(ind);
  document.documentElement.classList.add('js-nav');
  let pending = 0, first = true;
  const place = () => {
    if (pending) return;
    pending = frame(() => {
      pending = 0;
      const a = nav.querySelector('a.on:not([hidden])');
      // read
      const x = a ? a.offsetLeft + 12 : 0, w = a ? Math.max(0, a.offsetWidth - 24) : 0;
      // write
      ind.style.setProperty('--x', `${x}px`); ind.style.setProperty('--w', String(w));
      ind.style.opacity = a ? '1' : '0';
      if (first) { first = false; frame(() => ind.classList.remove('no-anim')); }
      if (a && nav.scrollWidth > nav.clientWidth) a.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: reducedMotion() ? 'auto' : 'smooth' });
    });
  };
  const mo = new MutationObserver(place); mo.observe(nav, { subtree: true, attributes: true, attributeFilter: ['class', 'hidden'] }); live.observers.push(mo);
  const ro = new ResizeObserver(place); ro.observe(nav); live.observers.push(ro);
  document.fonts?.ready.then(place);
  place();
}

// ---------- mobile: the tab row becomes a menu sheet ----------
function mobileMenu() {
  const nav = $('#viewNav'), bar = $('.top-in'); if (!nav || !bar) return;
  const btn = Object.assign(document.createElement('button'), { type: 'button', className: 'xbtn navbtn', innerHTML: I('menu') });
  btn.setAttribute('aria-label', 'Open menu'); btn.setAttribute('aria-expanded', 'false'); btn.setAttribute('aria-controls', 'navSheet');
  bar.prepend(btn);
  const sheet = document.createElement('div');
  sheet.className = 'navsheet'; sheet.id = 'navSheet';
  sheet.innerHTML = `<div class="sheet" role="dialog" aria-modal="true" aria-label="Menu"><div class="sheet-head"><b>Menu</b><button type="button" class="xbtn" data-close aria-label="Close menu">${I('x')}</button></div><nav aria-label="Sections"></nav></div>`;
  document.body.append(sheet);
  const list = sheet.querySelector('nav');
  let lastFocus = null;
  const fill = () => {
    list.innerHTML = $$('a[data-view]', nav).filter(a => !a.hidden).map(a => {
      const em = a.querySelector('em'), badge = em && !em.hidden && em.textContent.trim() ? `<em>${esc(em.textContent.trim())}</em>` : '';
      const ic = a.querySelector('[data-i]')?.dataset.i || 'chevron';
      return `<a href="${esc(a.getAttribute('href'))}"${a.classList.contains('on') ? ' aria-current="page"' : ''}>${I(ic)}<span>${esc(a.textContent.replace(em?.textContent || '', '').trim())}</span>${badge}</a>`;
    }).join('');
  };
  const focusables = () => $$('button, a[href]', sheet).filter(x => !x.hidden);
  const open = () => {
    fill(); lastFocus = document.activeElement;
    sheet.classList.add('open'); btn.setAttribute('aria-expanded', 'true'); document.body.style.overflow = 'hidden';
    frame(() => (list.querySelector('[aria-current]') || focusables()[0])?.focus());
  };
  const close = (restore = true) => {
    if (!sheet.classList.contains('open')) return;
    sheet.classList.remove('open'); btn.setAttribute('aria-expanded', 'false'); document.body.style.overflow = '';
    if (restore) (lastFocus && lastFocus !== document.body && lastFocus.isConnected && lastFocus.offsetParent !== null ? lastFocus : btn).focus();
  };
  listen(btn, 'click', open);
  listen(sheet, 'click', e => { if (e.target === sheet || e.target.closest('[data-close]')) close(); else if (e.target.closest('nav a')) close(false); });
  listen(sheet, 'keydown', e => {
    if (e.key === 'Escape') { e.preventDefault(); close(); return; }
    if (e.key === 'Tab') { const f = focusables(), i = f.indexOf(document.activeElement); if (e.shiftKey && i <= 0) { e.preventDefault(); f.at(-1).focus(); } else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); } }
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { const f = $$('nav a', sheet), i = f.indexOf(document.activeElement); if (i >= 0) { e.preventDefault(); f[(i + (e.key === 'ArrowDown' ? 1 : -1) + f.length) % f.length].focus(); } }
  });
  const mq = matchMedia('(min-width: 761px)'); const wide = () => mq.matches && close(false);
  listen(mq, 'change', wide);
}

// ---------- arrow keys inside every tab group (Left/Right, Home/End); vertical lists use Up/Down ----------
const GROUPS = '.subtabs, .seg, .tabs, .dr-tabs, #viewNav, .set-views, .lv-dl-repos';
function tabKeys() {
  listen(document, 'keydown', e => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key) || e.altKey || e.ctrlKey || e.metaKey) return;
    const g = e.target.closest?.(GROUPS); if (!g || /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) && e.target.type !== 'checkbox') return;
    const items = $$('button:not([disabled]), a[href], input[type="checkbox"]:not([disabled])', g).filter(x => !x.hidden && x.offsetParent !== null);
    const i = items.indexOf(e.target.closest('button, a, input')); if (i < 0) return;
    e.preventDefault();
    const n = e.key === 'Home' ? 0 : e.key === 'End' ? items.length - 1 : (i + (e.key === 'ArrowRight' ? 1 : -1) + items.length) % items.length;
    items[n].focus();
  });
}

// ---------- ARIA state mirrors the visual state (.on) so screen readers hear the selection ----------
function ariaSync() {
  let queued = 0;
  const sync = () => {
    queued = 0;
    for (const g of $$('.subtabs, .dr-tabs')) {
      if (g.getAttribute('role') !== 'tablist') g.setAttribute('role', 'tablist');
      for (const b of $$('button', g)) { if (b.getAttribute('role') !== 'tab') b.setAttribute('role', 'tab'); const v = String(b.classList.contains('on')); if (b.getAttribute('aria-selected') !== v) b.setAttribute('aria-selected', v); }
    }
    for (const b of $$('.seg button, .tabs .tab')) { const v = String(b.classList.contains('on')); if (b.getAttribute('aria-pressed') !== v) b.setAttribute('aria-pressed', v); }
    for (const a of $$('#viewNav a')) { if (a.classList.contains('on')) { if (a.getAttribute('aria-current') !== 'page') a.setAttribute('aria-current', 'page'); } else if (a.hasAttribute('aria-current')) a.removeAttribute('aria-current'); }
    for (const b of $$('.act[title]:not([aria-label]), .xbtn[title]:not([aria-label]), .ibtn[title]:not([aria-label])')) b.setAttribute('aria-label', b.title);
  };
  const mo = new MutationObserver(() => { if (!queued) queued = frame(sync); });
  mo.observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['class'] });
  live.observers.push(mo);
  sync();
}

// ---------- header gains a hairline shadow once the page scrolls ----------
function headerState() {
  const top = $('.top'); if (!top) return;
  let ticking = 0, was = null;
  const read = () => { ticking = 0; const now = scrollY > 4; if (now !== was) { was = now; top.classList.toggle('scrolled', now); } };
  listen(window, 'scroll', () => { if (!ticking) ticking = frame(read); }, { passive: true });
  read();
}

// ---------- view headers ease in when they first appear (never live data) ----------
function reveal() {
  const els = $$('[data-reveal]'); if (!els.length) return;
  if (reducedMotion() || !('IntersectionObserver' in window)) { els.forEach(el => el.classList.add('in')); return; }
  document.documentElement.classList.add('js-reveal');
  const io = new IntersectionObserver(entries => {
    for (const en of entries) if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.01 });
  els.forEach(el => io.observe(el));
  live.observers.push(io);
}

// ---------- keyboard shortcuts sheet ( ? ) ----------
const KEYS = [
  [['N'], 'New app'], [['/'], 'Search apps'], [['Ctrl', 'S'], 'Save the open app or site settings'], [['Esc'], 'Close the editor, a dialog or the menu'],
  [['Shift', 'P'], 'Privacy mode: blur money and emails'], [['←', '→'], 'Move between tabs'], [['?'], 'Show these shortcuts']
];
function shortcuts() {
  const d = document.createElement('dialog');
  d.className = 'modal small'; d.id = 'keysDlg'; d.setAttribute('aria-labelledby', 'keysTitle');
  d.innerHTML = `<div class="m-in"><h3 id="keysTitle">${I('keyboard')}Keyboard shortcuts</h3><div class="keys">${KEYS.map(([k, t]) => `<div><span>${esc(t)}</span><span>${k.map(x => `<kbd>${esc(x)}</kbd>`).join('')}</span></div>`).join('')}</div><div class="m-foot"><button class="hbtn primary" type="button" data-close>Done</button></div></div>`;
  document.body.append(d);
  listen(d, 'click', e => { if (e.target === d || e.target.closest('[data-close]')) d.close(); });
  listen(document, 'keydown', e => {
    if (e.key !== '?' || typing() || e.ctrlKey || e.metaKey || e.altKey || $('dialog[open]') || ($('#editor') && !$('#editor').hidden)) return;
    if (window.HUB_PREFS?.shortcuts === false) return;
    e.preventDefault(); openKeys();
  });
}
export const openKeys = () => { const d = $('#keysDlg'); if (d && !d.open) d.showModal(); };

// ---------- footer: who, how the site is doing, where to go next ----------
function footer() {
  const f = document.createElement('footer');
  f.className = 'app-foot';
  const anchor = $('#saveBar') || $('#editor');
  anchor ? anchor.before(f) : document.body.append(f);
  const draw = () => {
    const s = S.status, prod = S.product, name = prod?.name || (isManager() ? 'Pylerium Manager' : 'Pylerium Studio Hub');
    const st = !s ? ['', 'Checking the website…'] : !s.repoOk ? ['err', isManager() ? 'No site connected yet' : 'Site folder needs attention'] : (s.changes?.length || s.workingFiles || s.ahead) ? ['pending', 'Changes waiting to publish'] : ['ok', 'Website up to date'];
    const site = S.config?.siteUrl;
    f.innerHTML = `<div><div class="af-brand"><b>${esc(name)}</b>${prod?.version ? `<small>v${esc(prod.version)}</small>` : ''}</div>
      <div class="af-status ${st[0]}" role="status"><i aria-hidden="true"></i>${esc(st[1])}</div></div>
      <nav aria-label="Footer">${site ? `<a href="${esc(site)}" target="_blank" rel="noopener">${I('globe')}Your website</a>` : ''}
        <a href="#/settings">${I('sliders')}Settings</a>${isManager() ? `<a href="#/settings/phone">${I('phone')}Phone access</a>` : ''}
        <button type="button" data-keys>${I('keyboard')}Shortcuts <kbd>?</kbd></button>
        ${prod?.website ? `<a href="${esc(prod.website)}" target="_blank" rel="noopener">${I('book')}Help</a>` : ''}</nav>`;
  };
  listen(f, 'click', e => { if (e.target.closest('[data-keys]')) openKeys(); });
  on(what => { if (what === 'status' || what === 'site') draw(); });
  draw();
}
