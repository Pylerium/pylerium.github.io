// First-run setup wizard (licence → GitHub → site → brand → launch) and the Settings view.
import { R, S, $, $$, esc, api, toast, confirmBox, rel } from './core.js';
import * as Update from './update.js';

const I = n => R.icon(n);
let ST = null, step = 0, dev = null, devTimer = 0, repos = null, launching = false, logoData = null, err = null;
const STEPS = ['Welcome', 'Licence', 'GitHub', 'Your site', 'Your brand', 'Launch'];
const CURRENCIES = ['USD', 'EUR', 'GBP', 'AUD', 'CAD', 'NZD', 'JPY', 'SEK', 'NOK', 'DKK', 'CHF', 'PLN', 'BRL', 'MXN', 'INR', 'SGD'];
const TOKEN_URL = 'https://github.com/settings/tokens/new?scopes=public_repo&description=Pylerium%20Manager';

export function init() {
  const card = $('#setupCard');
  card.addEventListener('click', onClick);
  card.addEventListener('submit', onSubmit);
  card.addEventListener('change', onChange);
  card.addEventListener('input', e => { if (e.target.name === 'name' && e.target.form?.id === 'suBrand' && !logoData && !ST.site.brand?.logo) { const l = $('.su-logo'); const svg = l?.querySelector('svg.mark'); if (svg) svg.outerHTML = R.monogram(R.initialsOf(e.target.value || 'My Studio'), 'mark'); } });
  const P = $('#settingsPanel');
  P.addEventListener('click', onClick);
  P.addEventListener('submit', onSubmit);
}
export async function load() { ST = await api('GET', '/api/setup'); licenceChrome(); return ST; }

// ---------- header pill + trial bar ----------
export function licenceChrome() {
  const L = ST?.license; if (!L) return;
  const pill = $('#licPill'), bar = $('#licBar');
  pill.textContent = L.state === 'licensed' ? 'PRO' : L.state === 'trial' ? `TRIAL · ${L.daysLeft}D` : L.state === 'expired' ? 'RENEW' : 'UNLICENSED';
  pill.className = 'hubpill' + (L.state === 'licensed' ? ' pro' : L.state === 'trial' ? '' : ' bad');
  $('#studioName').textContent = ST.site?.brand?.name ? `${ST.site.brand.name}${ST.config.siteUrl ? ' · ' + ST.config.siteUrl.replace(/^https?:\/\//, '') : ''}` : 'Your studio, on autopilot';
  const show = L.state !== 'licensed' && (L.state !== 'trial' || L.daysLeft <= 5);
  bar.hidden = !show;
  if (show) bar.innerHTML = `<div class="lic-in">${I(L.state === 'trial' ? 'clock' : 'lock')}<span>${L.state === 'trial' ? `Your free trial ends in <b>${L.daysLeft} day${L.daysLeft === 1 ? '' : 's'}</b>. Everything keeps working after you activate a licence.` : esc(L.msg || 'Activate a licence to keep publishing.')}</span><a class="hbtn primary sm" href="${esc(ST.product.buyUrl)}" target="_blank" rel="noopener">Get Pylerium Manager</a><a class="hbtn ghost sm" href="#/settings/license">Enter key</a></div>`;
  $('#nSettings').hidden = (L.state === 'licensed' || L.state === 'trial') && !ST.update;
  $('#nSettings').textContent = '!';
}

// ---------- wizard ----------
export async function open(at = 0) {
  if (!ST) await load();
  step = at === 0 ? resumeStep() : at;
  err = null; await prep();
  $('#setup').hidden = false; document.body.classList.add('in-setup');
  render();
}
// After a refresh, pick up where the customer left off instead of starting again at Welcome.
function resumeStep() {
  const L = ST.license;
  if (!ST.github.connected) return 0;
  if (L.state !== 'licensed' && L.state !== 'trial') return 1;
  if (!ST.config.repo) return 3;
  if (!ST.config.brandDone) return 4;
  return 5;
}
// Errors are shown in the card itself (toasts are easy to miss while the wizard is open).
function fail(e) {
  err = { step, msg: e.message || String(e), newUrl: e.data?.newUrl || '' };
  toast(err.msg, 'err', 10000);
  if (e.data?.step != null && e.data.step !== step) { step = e.data.step; err.step = step; }
}
const errBox = () => err && err.step === step ? `<p class="note err" role="alert"><span>${I('info')}</span><span>${esc(err.msg)}${err.newUrl ? ` <a href="${esc(err.newUrl)}" target="_blank" rel="noopener">Create the repository on GitHub</a>` : ''}</span></p>` : '';
function close() { $('#setup').hidden = true; document.body.classList.remove('in-setup'); clearTimeout(devTimer); }
const dots = () => `<div class="su-steps">${STEPS.map((s, i) => `<span class="${i < step ? 'done' : i === step ? 'on' : ''}"><i>${i < step ? I('check') : i + 1}</i>${s}</span>`).join('')}</div>`;
const nav = (next = 'Continue', o = {}) => `<div class="su-nav">${step > 0 && !o.noBack ? `<button type="button" class="hbtn ghost" data-su="back">${I('chevleft')}Back</button>` : '<span></span>'}${o.skip ? `<button type="button" class="linkbtn" data-su="skip">${esc(o.skip)}</button>` : ''}<button type="${o.submit ? 'submit' : 'button'}" class="hbtn primary" ${o.submit ? '' : 'data-su="next"'}${o.disabled ? ' disabled' : ''}>${esc(next)}${I('chevron')}</button></div>`;

function render() {
  const C = $('#setupCard');
  const body = [welcome, licence, github, site, brand, launch][step]();
  C.innerHTML = `<div class="su-top"><span class="su-mark">${R.brandMark('mark')}</span><b>Pylerium Manager</b>${step && step < 5 ? `<button type="button" class="su-x" data-su="later" title="Finish later">${I('x')}</button>` : ''}</div>${step ? dots() : ''}<div class="su-body">${errBox()}${body}</div>`;
  C.querySelector('input:not([type=checkbox]):not([type=file])')?.focus();
}
function welcome() {
  return `<div class="su-hero"><h1>Your studio site, <span class="grad-text">live in minutes.</span></h1>
    <p>Pylerium Manager builds a beautiful showcase for your apps, publishes it free on GitHub Pages, and runs the business side for you: sales, supporter codes, emails and Discord alerts.</p>
    <div class="su-feats">${[['globe', 'Your own site', 'yourname.github.io, hosted free by GitHub'], ['layers', 'App showcase', 'Cards, screenshots, release notes, videos'], ['card', 'Sales on autopilot', 'Stripe, supporter codes, automatic emails'], ['discord', 'Discord alerts', 'Every sale, release and video, instantly']]
      .map(([i, t, d]) => `<div>${I(i)}<b>${t}</b><small>${d}</small></div>`).join('')}</div>
    <div class="su-nav one"><button type="button" class="hbtn primary lg" data-su="next">Let’s build it${I('chevron')}</button></div>
    <p class="su-fine">Takes about 3 minutes. You’ll need a free GitHub account.</p></div>`;
}
function licence() {
  const L = ST.license;
  return `<h2>${I('key')}Licence</h2>
    ${L.state === 'licensed' ? `<div class="su-ok">${I('check')}<div><b>Activated</b><small>${esc(L.email || '')} · ${esc(L.plan || 'lifetime')}${L.exp ? ` · renews ${new Date(L.exp).toLocaleDateString()}` : ''}</small></div></div>${nav()}`
    : `<p>Paste the licence key from your purchase email${L.state === 'trial' ? `, or try everything free for <b>${L.daysLeft} more day${L.daysLeft === 1 ? '' : 's'}</b>` : ''}.</p>
      <form id="suLic" class="fb"><label class="fld"><span>Licence key</span><textarea name="key" rows="3" class="mono" placeholder="PM1-…" spellcheck="false"></textarea></label>
      ${L.state === 'invalid' || L.state === 'trial-over' || L.state === 'expired' || L.state === 'revoked' ? `<p class="note lock"><span>${I('info')}</span>${esc(L.msg)}</p>` : ''}
      <div class="row"><button class="hbtn primary" type="submit">${I('check')}Activate</button><a class="hbtn ghost" href="${esc(ST.product.buyUrl)}" target="_blank" rel="noopener">${I('card')}Subscribe</a></div></form>
      ${nav(L.state === 'trial' ? 'Start my free trial' : 'Continue', { disabled: L.state !== 'trial' })}`}`;
}
function github() {
  const g = ST.github;
  if (g.connected) return `<h2>${I('github')}GitHub</h2><div class="su-ok gh">${g.user.avatar ? `<img src="${esc(g.user.avatar)}" alt="">` : I('github')}<div><b>Connected as ${esc(g.user.login)}</b><small>${esc(g.user.name || '')}</small></div><button type="button" class="linkbtn" data-su="ghout">Use another account</button></div>${g.user.fineGrained && !ST.config.repo ? `<p class="note lock"><span>${I('info')}</span><span>This is a fine-grained token (github_pat_…). It can only create your site if it was made with <b>All repositories</b> access and <b>Administration</b>, <b>Contents</b> and <b>Pages</b> set to “Read and write”. If you’re not sure, choose “Use another account” and paste a classic token from the “Create a token on GitHub” button instead.</span></p>` : ''}${nav()}`;
  return `<h2>${I('github')}Connect GitHub</h2>
    <p>Your site is hosted free on <b>GitHub Pages</b>. Pylerium Manager creates the repository, turns on Pages and uploads your site. No git or command line needed.</p>
    <p class="su-fine">No GitHub account? <a href="https://github.com/signup" target="_blank" rel="noopener">Create one free</a> (1 minute), then come back.</p>
    ${ST.deviceFlow ? `<div class="su-device">${dev ? `<p>Enter this code on the GitHub page that just opened:</p><div class="su-code"><b>${esc(dev.userCode)}</b><button type="button" class="act" data-copy="${esc(dev.userCode)}" title="Copy">${I('copy')}</button></div><p class="muted"><span class="spinner"></span> Waiting for you to approve… <a href="${esc(dev.url)}" target="_blank" rel="noopener">Open GitHub again</a></p>`
      : `<button type="button" class="hbtn primary lg" data-su="device">${I('github')}Sign in with GitHub</button>`}</div><div class="su-or"><span>or use a token</span></div>` : ''}
    <ol class="su-list"><li><a class="hbtn ${ST.deviceFlow ? 'ghost' : 'primary'} sm" href="${TOKEN_URL}" target="_blank" rel="noopener">${I('external')}Create a token on GitHub</a> (the right permission is already ticked).</li><li>Scroll down, press <b>Generate token</b>, then copy it.</li><li>Paste it here:</li></ol>
    <form id="suTok" class="inrow"><input name="token" type="password" class="mono" autocomplete="off" placeholder="ghp_…" spellcheck="false"><button class="hbtn primary" type="submit">${I('check')}Connect</button></form>
    <p class="su-fine">${I('lock')} The token is stored only on this computer and is used only to publish your site.</p>
    ${nav('Continue', { disabled: true })}`;
}
function site() {
  const login = ST.github.user?.login || 'you';
  const userRepo = `${login}.github.io`;
  const have = repos?.find(r => r.name.toLowerCase() === userRepo.toLowerCase());
  const pick = ST._pick || 'user';
  return `<h2>${I('globe')}Your site</h2>
    <form id="suSite" class="fb">
    <label class="su-opt${pick === 'user' ? ' on' : ''}"><input type="radio" name="pick" value="user"${pick === 'user' ? ' checked' : ''}><div><b>${esc(login.toLowerCase())}.github.io</b><small>${have ? 'You already have this repository. Pylerium Manager adds your site to it and leaves your other files alone.' : 'Recommended. Your main site, at the shortest address. The repository is created for you.'}</small></div><span class="su-tag">Recommended</span></label>
    <label class="su-opt${pick === 'project' ? ' on' : ''}"><input type="radio" name="pick" value="project"${pick === 'project' ? ' checked' : ''}><div><b>A project site</b><small>${esc(login.toLowerCase())}.github.io/<i>name</i>. Use this if your main github.io site is something else.</small>
      ${pick === 'project' ? `<input name="repo" list="repoList" placeholder="studio" value="${esc(ST._repo || '')}" class="mono"><datalist id="repoList">${(repos || []).filter(r => !r.private).map(r => `<option value="${esc(r.name)}">`).join('')}</datalist>` : ''}</div></label>
    ${ST.config.repo ? `<p class="note"><span>${I('check')}</span>Currently publishing to <b>${esc(ST.config.repo)}</b> (${esc(ST.config.siteUrl)}).</p>` : ''}
    ${nav(ST.config.repo ? 'Use this site' : 'Create my site', { submit: true })}</form>`;
}
function brand() {
  const b = ST.site.brand || {}, c = ST.site.community || {}, h = ST.site.hero || {};
  const logo = logoData || (b.logo ? `/media/${b.logo}` : '');
  return `<h2>${I('sparkles')}Your brand</h2>
    <form id="suBrand" class="fb">
      <div class="su-brand">
        <label class="su-logo" title="Upload a logo (optional)">${logo ? `<img src="${esc(logo)}" alt="">` : R.monogram(R.initialsOf(b.name || 'My Studio'), 'mark')}<input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" data-logo hidden><span>${I('upload')}Logo</span></label>
        <div class="grow">
          <label class="fld"><span>Studio name</span><input name="name" value="${esc(b.name === 'My Studio' ? '' : b.name || '')}" placeholder="e.g. Nova Labs" required maxlength="60" data-live></label>
          <label class="fld"><span>Tagline</span><input name="tagline" value="${esc(b.tagline || '')}" placeholder="e.g. Independent software lab" maxlength="80"></label>
        </div>
      </div>
      <div class="f2"><label class="fld"><span>Headline</span><input name="title" value="${esc(h.title || '')}" placeholder="Software made with"></label><label class="fld"><span>Highlighted words</span><input name="highlight" value="${esc(h.highlight || '')}" placeholder="care."></label></div>
      <label class="fld"><span>One-line intro</span><input name="lead" value="${esc(h.lead || '')}"></label>
      <div class="f2"><label class="fld"><span>Contact email <small>shown on your site</small></span><input name="email" type="email" value="${esc(ST.config.supportEmail || '')}" placeholder="hello@…"></label>
        <label class="fld"><span>Currency</span><select name="currency">${CURRENCIES.map(x => `<option${x === (c.currency || 'USD') ? ' selected' : ''}>${x}</option>`).join('')}</select></label></div>
      <label class="fld"><span>YouTube channel <small>optional, your latest videos appear on the site</small></span><input name="youtube" value="${esc(ST.site.youtube?.channelUrl || '')}" placeholder="https://www.youtube.com/@yourchannel"></label>
      ${nav('Continue', { submit: true })}
    </form>`;
}
function launch() {
  if (launching === 'done') return `<div class="su-hero done"><div class="su-burst">${I('rocket')}</div><h1>You’re <span class="grad-text">live.</span></h1>
    <p>Your site is published at</p><a class="su-url" href="${esc(ST.config.siteUrl)}" target="_blank" rel="noopener">${esc(ST.config.siteUrl.replace(/^https:\/\//, ''))}${I('external')}</a>
    <p class="su-fine" id="suPages">${I('clock')} GitHub Pages can take a minute or two the very first time.</p>
    <div class="su-next">${[['layers', 'Add your apps', '#/apps'], ['card', 'Connect Stripe', '#/community/settings'], ['discord', 'Discord alerts', '#/alerts/setup'], ['mail', 'Automatic emails', '#/alerts/emails']].map(([i, t, h]) => `<a href="${h}" data-su="close">${I(i)}<b>${t}</b></a>`).join('')}</div>
    <div class="su-nav one"><button type="button" class="hbtn primary lg" data-su="close">Open my dashboard${I('chevron')}</button></div></div>`;
  if (launching) return `<div class="su-hero"><h2><span class="spinner"></span>Launching your site…</h2><div class="su-prog" id="suProg"><div class="on">${I('layers')}Building your pages</div><div>${I('upload')}Uploading to GitHub</div><div>${I('globe')}Turning on GitHub Pages</div></div></div>`;
  return `<h2>${I('rocket')}Ready to launch</h2>
    <div class="su-sum">
      <div>${I('globe')}<span>Site</span><b>${esc(ST.config.siteUrl || '—')}</b></div>
      <div>${I('github')}<span>Repository</span><b>${esc(ST.config.repo || '—')}</b></div>
      <div>${I('sparkles')}<span>Studio</span><b>${esc(ST.site.brand?.name || '')}</b></div>
      <div>${I('key')}<span>Licence</span><b>${ST.license.state === 'licensed' ? 'Activated' : `Free trial · ${ST.license.daysLeft} days`}</b></div>
    </div>
    <p>We’ll publish your site with a sample app you can edit afterwards. Stripe, Discord and automatic emails can be connected any time from the dashboard.</p>
    ${ST.config.repo ? nav('Build & publish my site', {}) : `<p class="note lock"><span>${I('info')}</span><span>No site has been created yet. Go back to <b>Your site</b> and create it first.</span></p>${nav('Build & publish my site', { disabled: true })}`}`;
}

// ---------- settings view ----------
export async function showSettings(sub) {
  await load();
  const L = ST.license, g = ST.github, P = $('#settingsPanel');
  P.innerHTML = `<div class="cols">
    <div class="card" id="setLicense"><div class="card-head"><h3>${I('key')}Licence</h3>${L.state === 'licensed' ? `<span class="dc-pill ok">${I('check')}Active</span>` : L.state === 'trial' ? `<span class="dc-pill warn">Trial · ${L.daysLeft} days left</span>` : `<span class="dc-pill bad">Not active</span>`}</div>
      ${L.state === 'licensed' ? `<div class="kv"><span>Licensed to</span><b>${esc(L.email)}</b><span>Plan</span><b>${esc(L.plan)}</b>${L.exp ? `<span>${L.sub && L.cancelAtPeriodEnd ? 'Ends' : 'Renews'}</span><b>${new Date(L.exp).toLocaleDateString()}${L.sub && !['active', 'trialing'].includes(L.status) ? ' · payment due' : ''}</b>` : ''}${L.sub ? `<span>Last checked</span><b>${L.checkedAt ? new Date(L.checkedAt).toLocaleString() : 'not yet'}</b>` : ''}<span>Licence id</span><b class="mono">${esc(L.id)}</b></div>
        <div class="row">${L.sub && ST.product.manageUrl ? `<a class="hbtn ghost sm" href="${esc(ST.product.manageUrl)}" target="_blank" rel="noopener">${I('card')}Manage subscription</a>` : ''}${L.sub ? `<button type="button" class="hbtn ghost sm" data-su="licrefresh">${I('refresh')}Check now</button>` : ''}<button type="button" class="hbtn ghost sm" data-su="deact">Remove licence from this computer</button></div>`
      : `<p class="sub">${esc(L.msg || 'Paste the key from your purchase email.')}</p><form id="suLic" class="fb"><textarea name="key" rows="3" class="mono" placeholder="PM1-…" spellcheck="false"></textarea><div class="row"><button class="hbtn primary sm" type="submit">${I('check')}Activate</button><a class="hbtn ghost sm" href="${esc(ST.product.buyUrl)}" target="_blank" rel="noopener">${I('card')}${L.state === 'expired' ? 'Renew' : 'Subscribe'}</a>${L.state === 'expired' && ST.product.manageUrl ? `<a class="hbtn ghost sm" href="${esc(ST.product.manageUrl)}" target="_blank" rel="noopener">Update payment</a>` : ''}${L.state === 'expired' ? `<button type="button" class="hbtn ghost sm" data-su="licrefresh">${I('refresh')}Check again</button>` : ''}</div></form>`}
    </div>
    <div class="card" id="setGithub"><div class="card-head"><h3>${I('github')}GitHub &amp; site</h3>${g.connected ? `<span class="dc-pill ok">${I('check')}Connected</span>` : `<span class="dc-pill bad">Not connected</span>`}</div>
      ${g.connected ? `<div class="su-ok gh">${g.user.avatar ? `<img src="${esc(g.user.avatar)}" alt="">` : ''}<div><b>${esc(g.user.login)}</b><small>${esc(ST.config.repo || 'No site chosen yet')}</small></div></div>` : `<p class="sub">${esc(g.error || 'Connect GitHub to publish your site.')}</p>`}
      ${ST.config.siteUrl ? `<div class="kv"><span>Website</span><b><a href="${esc(ST.config.siteUrl)}" target="_blank" rel="noopener">${esc(ST.config.siteUrl)}</a></b><span>Repository</span><b><a href="https://github.com/${esc(ST.config.repo)}" target="_blank" rel="noopener">${esc(ST.config.repo)}</a></b></div>` : ''}
      <div class="row"><button type="button" class="hbtn ${g.connected ? 'ghost' : 'primary'} sm" data-su="wiz2">${I('github')}${g.connected ? 'Change account or site' : 'Connect GitHub'}</button>${g.connected ? `<button type="button" class="hbtn ghost sm" data-su="ghout">Disconnect</button>` : ''}</div>
    </div>
    <div class="card"><h3>${I('cpu')}Pylerium Manager</h3>
      <div class="kv"><span>Version</span><b>${esc(ST.product.version)}</b><span>Support</span><b><a href="mailto:${esc(ST.product.supportEmail)}">${esc(ST.product.supportEmail)}</a></b><span>Website</span><b><a href="${esc(ST.product.website)}" target="_blank" rel="noopener">${esc(ST.product.website.replace(/^https:\/\//, ''))}</a></b></div>
      <div class="row" id="updSlot"></div>
      <div class="row"><button type="button" class="hbtn ghost sm" data-su="rerun">${I('sparkles')}Run setup again</button><button type="button" class="hbtn ghost sm" data-su="quit">${I('power')}Quit Pylerium Manager</button></div>
      <p class="muted small">Closing this tab doesn’t stop the app. It keeps watching sales and sending emails in the background until you quit.</p>
    </div>
  </div>`;
  Update.chip();
  if (sub === 'license') $('#setLicense')?.scrollIntoView({ block: 'start' });
  if (sub === 'github') $('#setGithub')?.scrollIntoView({ block: 'start' });
}

// ---------- actions ----------
async function onChange(e) {
  const t = e.target;
  if (t.name === 'pick') { ST._pick = t.value; render(); return; }
  if (t.dataset.logo !== undefined && t.files?.[0]) {
    const f = t.files[0];
    if (f.size > 3 * 1024 * 1024) return toast('Logo must be under 3 MB', 'err');
    logoData = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(f); });
    const form = $('#suBrand'); const keep = Object.fromEntries(new FormData(form));
    render(); for (const [k, v] of Object.entries(keep)) { const el = $('#suBrand')?.elements[k]; if (el && el.type !== 'file') el.value = v; }
  }
}
async function onClick(e) {
  const b = e.target.closest('[data-su],[data-copy]'); if (!b) return;
  if (b.dataset.copy) { await navigator.clipboard.writeText(b.dataset.copy); toast('Copied'); return; }
  const a = b.dataset.su;
  try {
    if (a === 'next') { if (step === 5) return doLaunch(); err = null; step++; await prep(); render(); return; }
    if (a === 'back') { err = null; step = Math.max(0, step - 1); await prep(); render(); return; }
    if (a === 'later') { if (await confirmBox('Finish setup later?', 'You can come back any time from Settings → Run setup again.', 'Finish later', false)) close(); return; }
    if (a === 'close') { close(); location.hash = b.getAttribute('href') || '#/live'; location.reload(); return; }
    if (a === 'device') { dev = await api('POST', '/api/github/device/start'); render(); pollDevice(); return; }
    if (a === 'ghout') { if (!(await confirmBox('Disconnect GitHub?', 'Publishing stops until you connect again. Your site stays online.', 'Disconnect'))) return; ST = await api('POST', '/api/github/disconnect'); dev = null; if ($('#setup').hidden) showSettings(); else render(); return; }
    if (a === 'deact') { if (!(await confirmBox('Remove the licence?', 'You can activate it again with the same key.', 'Remove'))) return; ST = await api('POST', '/api/license/deactivate'); licenceChrome(); showSettings(); return; }
    if (a === 'licrefresh') { ST = await api('POST', '/api/license/refresh'); licenceChrome(); showSettings(); toast(ST.license.state === 'licensed' ? 'Subscription is active ✓' : (ST.license.msg || 'Not active yet'), ST.license.state === 'licensed' ? 'ok' : 'err'); return; }
    if (a === 'wiz2') { await open(2); return; }
    if (a === 'rerun') { await open(1); return; }
    if (a === 'opendata') { await api('POST', '/api/open', { target: ST.home }); return; }
    if (a === 'quit') { if (!(await confirmBox('Quit Pylerium Manager?', 'Sales alerts and automatic emails stop until you open it again.', 'Quit'))) return; await api('POST', '/api/quit'); document.body.innerHTML = '<div class="bye"><h2>Pylerium Manager has stopped.</h2><p>Open it again from your desktop or Start menu.</p></div>'; return; }
  } catch (e) { if ($('#setup').hidden) toast(e.message, 'err', 9000); else { fail(e); await prep(); render(); } }
}
async function prep() { if (step === 3 && ST.github.connected && !repos) { try { repos = (await api('GET', '/api/github/repos')).repos; } catch { repos = []; } } }
function pollDevice() {
  clearTimeout(devTimer);
  if (!dev) return;
  devTimer = setTimeout(async () => {
    try {
      const r = await api('POST', '/api/github/device/poll', { deviceCode: dev.deviceCode });
      err = null; if (r.done) { ST = r; dev = null; toast(`Connected as ${ST.github.user.login} ✓`); step = 3; await prep(); render(); return; }
      if (r.slow) dev.interval += 5;
      pollDevice();
    } catch (err) { dev = null; toast(err.message, 'err'); render(); }
  }, (dev.interval || 5) * 1000);
}
async function onSubmit(e) {
  e.preventDefault();
  const f = e.target, btn = f.querySelector('button[type=submit]');
  const busy = t => { if (btn) { btn.disabled = true; btn.innerHTML = `<span class="spinner"></span>${t}`; } };
  try {
    if (f.id === 'suLic') { busy('Checking…'); ST = await api('POST', '/api/license/activate', { key: f.key.value }); err = null; licenceChrome(); toast('Licence activated. Thank you! ✓'); if ($('#setup').hidden) showSettings(); else { step = 2; render(); } return; }
    if (f.id === 'suTok') { busy('Connecting…'); err = null; ST = await api('POST', '/api/github/token', { token: f.token.value }); toast(`Connected as ${ST.github.user.login} ✓`); step = 3; await prep(); render(); return; }
    if (f.id === 'suSite') {
      const pick = f.pick.value, repo = pick === 'project' ? (f.repo?.value || '').trim() : '';
      if (pick === 'project' && !repo) return toast('Name your project site', 'err');
      ST._repo = repo;
      busy(ST.config.repo ? 'Checking…' : 'Creating your repository…');
      const r = await api('POST', '/api/setup/site', { repo: repo || undefined });
      ST = { ...r, _pick: pick, _repo: repo };
      err = null; toast(r.repo.created ? `Created ${r.repo.full} ✓` : `Using ${r.repo.full} ✓`);
      if (r.pages?.error) toast(`GitHub Pages: ${r.pages.error}`, 'err', 9000);
      step = 4; render(); return;
    }
    if (f.id === 'suBrand') {
      busy('Saving…');
      const d = Object.fromEntries(new FormData(f));
      ST = await api('POST', '/api/setup/brand', { ...d, logo: logoData || undefined });
      err = null; logoData = null; licenceChrome(); step = 5; render(); return;
    }
  } catch (e) { if ($('#setup').hidden) { toast(e.message, 'err', 10000); showSettings(); return; } fail(e); await prep(); render(); }
}
async function doLaunch() {
  launching = true; render();
  const prog = n => $$('#suProg > div').forEach((d, i) => d.className = i < n ? 'done' : i === n ? 'on' : '');
  setTimeout(() => prog(1), 1500);
  try {
    const r = await api('POST', '/api/setup/finish', { publish: true });
    ST = r; prog(2);
    launching = 'done'; render(); confetti();
    watchPages();
  } catch (e) { launching = false; fail(e); await prep(); render(); }
}
async function watchPages() {
  for (let i = 0; i < 40; i++) {
    await new Promise(r => setTimeout(r, 6000));
    try { const p = await api('GET', '/api/pages'); const el = $('#suPages'); if (!el) return; if (p.live) { el.innerHTML = `${I('check')} Your site is live. Go take a look!`; el.classList.add('ok'); return; } el.innerHTML = `<span class="spinner"></span> GitHub is building your site (${esc(p.status || 'building')})…`; } catch {}
  }
}
function confetti() {
  const c = document.createElement('div'); c.className = 'confetti';
  const colors = ['#8B5CF6', '#38BDF8', '#2DD4BF', '#F59E0B', '#FB7185', '#A3E635'];
  c.innerHTML = Array.from({ length: 90 }, (_, i) => `<i style="left:${Math.random() * 100}%;background:${colors[i % colors.length]};animation-delay:${Math.random() * .6}s;animation-duration:${2.2 + Math.random() * 1.6}s;transform:rotate(${Math.random() * 360}deg)"></i>`).join('');
  document.body.append(c); setTimeout(() => c.remove(), 4500);
}
