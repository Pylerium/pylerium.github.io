// Edit Studio's consumer layer, kept apart from the editor's own modules: follows the dashboard's theme and accent,
// gives the controls the house icons, and adds the overview scrubber, jump palette, transport keys and voice-over.
import { icon } from '/shared/render.js';
import { initJump } from './jump.js';
import { initVoice } from './voiceover.js';

const $ = id => document.getElementById(id);

// the same themes as Settings → Appearance (surfaces and main colour only)
const THEMES = {
  midnight: [['#07080E', '#0B0D16', '#0F1220', '#141829', '#1A1F33'], '#2CCFBA'], obsidian: [['#08080A', '#0E0E10', '#121214', '#18181B', '#202024'], '#A1A1AA'],
  ocean: [['#040A14', '#08101E', '#0A1424', '#0E1C30', '#152640'], '#3B82F6'], aurora: [['#040B09', '#081310', '#0A1714', '#0E201C', '#152C26'], '#10B981'],
  ember: [['#0B0605', '#150C0A', '#1B0F0C', '#261612', '#32201A'], '#F97316'], plum: [['#0A050C', '#140A18', '#1A0D1E', '#24132A', '#311C39'], '#D946EF'],
  graphite: [['#121317', '#181A1F', '#1C1E24', '#22252C', '#2C3039'], '#94A3B8']
};
function theme() {
  let p = {}; try { p = JSON.parse(localStorage.getItem('hub.prefs') || '{}'); } catch {}
  const [surfaces, main] = THEMES[p.theme] || THEMES.midnight, accent = /^#[0-9a-f]{6}$/i.test(p.accent || '') ? p.accent : main, r = document.documentElement.style;
  surfaces.forEach((c, i) => r.setProperty(`--s${i}`, c));
  const rgb = [1, 3, 5].map(i => parseInt(accent.slice(i, i + 2), 16)), lum = rgb.map(v => { v /= 255; return v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; }).reduce((s, v, i) => s + v * [.2126, .7152, .0722][i], 0);
  r.setProperty('--act', accent); r.setProperty('--act-rgb', rgb.join(',')); r.setProperty('--act-soft', `color-mix(in srgb, ${accent} 45%, white)`); r.setProperty('--act-ink', lum > .28 ? `color-mix(in srgb, ${accent} 14%, black)` : '#fff');
  if (p.motion) document.documentElement.dataset.motion = p.motion;
}

const ICONS = { save: 'save', export: 'rocket', 'keyboard-help': null, import: 'upload', 'viewer-import': 'upload', new: 'plus', refresh: 'refresh', 'library-view': 'grid', split: 'sliders', caption: 'list', 'duplicate-item': 'copy', 'delete-item': 'trash', 'add-marker': 'tag', 'timeline-add': 'plus', guides: 'grid', 'monitor-mute': 'mic', 'copy-style': 'copy', 'paste-style': 'check', 'fit-timeline': 'monitor' };
const LABELS = { import: 'Import media', 'viewer-import': 'Import media', save: 'Save edit', export: 'Export MP4', 'timeline-add': 'Add', 'add-marker': 'Marker' };
const ARROW = { undo: '<path d="M8 5 4 9l4 4"/><path d="M4 9h10a6 6 0 0 1 0 12h-2"/>', redo: '<path d="m16 5 4 4-4 4"/><path d="M20 9H10a6 6 0 0 0 0 12h2"/>', first: '<path d="M6 5v14M18 6l-8 6 8 6Z"/>', last: '<path d="M18 5v14M6 6l8 6-8 6Z"/>', back: '<path d="M15 6l-7 6 7 6M18 5v14"/>', fwd: '<path d="m9 6 7 6-7 6M6 5v14"/>' };
const own = n => `<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ARROW[n]}</svg>`;
function icons() {
  for (const [id, name] of Object.entries(ICONS)) { const el = $(id); if (!el) continue; if (id === 'keyboard-help') { el.innerHTML = icon('keyboard'); continue; } const label = LABELS[id] || el.textContent.replace(/^[^\p{L}\p{N}]+/u, '').trim(); el.innerHTML = icon(name) + (label ? `<span>${label.replace(/</g, '&lt;')}</span>` : ''); }
  for (const [id, name] of [['undo', 'undo'], ['redo', 'redo'], ['previous-edit', 'first'], ['next-edit', 'last'], ['back-frame', 'back'], ['forward-frame', 'fwd']]) { const el = $(id); if (!el) continue; el.innerHTML = own(name) + (id === 'undo' || id === 'redo' ? `<span>${id === 'undo' ? 'Undo' : 'Redo'}</span>` : ''); }
  const back = document.querySelector('.studio-back'); if (back) back.innerHTML = `${icon('chevleft')}<span>Promo Studio</span>`;
  const brand = document.querySelector('.editor-brand'); if (brand) brand.innerHTML = `<i class="editor-mark" aria-hidden="true">${icon('film')}</i>Edit Studio <span>PYLERIUM</span>`;
  const empty = document.querySelector('.empty-symbol'); if (empty) empty.innerHTML = icon('film');
  // the editor rewrites the Play button's label as it plays: mirror it to a state the stylesheet can draw an icon for
  const play = $('play'), sync = () => { const s = /pause/i.test(play.textContent) ? 'playing' : 'paused'; if (play.dataset.state !== s) play.dataset.state = s; };
  const mo = new MutationObserver(sync); mo.observe(play, { childList: true, characterData: true, subtree: true }); sync();
  addEventListener('pagehide', () => mo.disconnect(), { once: true });
}

theme();
addEventListener('storage', e => { if (e.key === 'hub.prefs') theme(); });
const ready = () => (window.pyleriumVideoEditor ? Promise.resolve() : new Promise(ok => { let n = 0; const t = setInterval(() => { if (window.pyleriumVideoEditor || ++n > 200) { clearInterval(t); ok(); } }, 50); }));
ready().then(() => { icons(); if (window.pyleriumVideoEditor) { initJump(); initVoice(); } });
