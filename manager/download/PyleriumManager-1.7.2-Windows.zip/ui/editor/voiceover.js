// Voice-over inside the Edit Studio: type a line, hear it, and drop it on the timeline at the playhead (with a
// matching caption if wanted). Speech is made on this computer by the Speak TTS engine, or the Windows voices.
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
const store = 'studio.voice';

async function call(method, path, body) {
  const r = await fetch(path, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({})); if (!r.ok) throw Error(d.error || 'The voice-over request failed.'); return d;
}
const srt = (start, length, text) => { const f = t => { const ms = Math.round(t * 1000), p = (n, w = 2) => String(n).padStart(w, '0'); return `${p(ms / 3600000 | 0)}:${p((ms / 60000 | 0) % 60)}:${p((ms / 1000 | 0) % 60)},${p(ms % 1000, 3)}`; }; const words = text.split(/\s+/), lines = []; for (let i = 0; i < words.length; i += 7) lines.push(words.slice(i, i + 7).join(' ')); let t = start; return lines.map((line, i) => { const part = length * line.length / text.length, out = `${i + 1}\n${f(t)} --> ${f(t + part)}\n${line}\n`; t += part; return out; }).join('\n'); };

export async function initVoice() {
  const library = $('library'); if (!library) return;
  const box = document.createElement('section'); box.className = 'library-tools vox'; box.setAttribute('aria-label', 'Voice-over');
  box.innerHTML = '<h3>Voice-over</h3><p>Checking voices…</p>';
  library.querySelector('#media-kind')?.before(box);
  let state;
  try { state = await call('GET', '/api/video/voice'); } catch (e) { box.innerHTML = `<h3>Voice-over</h3><p class="bad">${esc(e.message)}</p>`; return; }
  if (!state.voices?.length) { box.innerHTML = `<h3>Voice-over</h3><p>${esc(state.speak?.reason || 'No voice is available on this computer.')} Set it up in Promo → Video.</p>`; return; }
  let saved = {}; try { saved = JSON.parse(localStorage.getItem(store) || '{}'); } catch {}
  const voice = state.voices.some(v => v.id === saved.voice) ? saved.voice : state.default, groups = [...new Set(state.voices.map(v => v.group))];
  box.innerHTML = `<h3>Voice-over</h3><textarea id="vox-text" maxlength="1200" placeholder="Type what the voice should say…" aria-label="Voice-over text"></textarea>
    <select id="vox-voice" aria-label="Voice">${groups.map(g => `<optgroup label="${esc(g)}">${state.voices.filter(v => v.group === g).map(v => `<option value="${esc(v.id)}"${v.id === voice ? ' selected' : ''}>${esc(v.label)}</option>`).join('')}</optgroup>`).join('')}</select>
    <label>Pace <input id="vox-rate" type="range" min="0.7" max="1.4" step="0.05" value="${saved.rate || 1}"></label>
    <label>Add a caption too <input id="vox-caption" type="checkbox"${saved.caption ? ' checked' : ''}></label>
    <div class="actions"><button type="button" id="vox-add" class="primary">Add at playhead</button></div><p id="vox-status" role="status">Spoken on this computer${state.speak.ok ? ' by Speak TTS' : ''}. Added at the playhead as a sound layer.</p>`;
  const status = (t, bad) => { const p = $('vox-status'); p.textContent = t; p.classList.toggle('bad', !!bad); };
  $('vox-add').onclick = async () => {
    const text = $('vox-text').value.trim(), api = window.pyleriumVideoEditor, button = $('vox-add');
    if (!text) { $('vox-text').focus(); return status('Type something for the voice to say.', true); }
    localStorage.setItem(store, JSON.stringify({ voice: $('vox-voice').value, rate: +$('vox-rate').value, caption: $('vox-caption').checked }));
    button.disabled = true; status(state.speak.ok && !state.speak.warm ? 'Warming up the voice (about a minute the first time)…' : 'Speaking…');
    try {
      const at = api.time, { media } = await call('POST', '/api/video/voice', { text, voice: $('vox-voice').value, rate: +$('vox-rate').value });
      state.speak.warm = true;
      if (!api.project.clips.length) { await api.refresh(); return status('Saved to your media library. Add a video or image to the timeline, then place the voice on it.'); }
      await api.addSound(media.id);
      if ($('vox-caption').checked) {
        const file = $('caption-file'), data = new DataTransfer();
        data.items.add(new File([srt(at, media.duration, text)], 'voice.srt', { type: 'text/plain' }));
        file.files = data.files; file.dispatchEvent(new Event('change', { bubbles: true }));
      }
      status(`Added ${media.duration.toFixed(1)}s of voice at ${at.toFixed(1)}s.`);
    } catch (e) { status(e.message, true); }
    finally { button.disabled = false; }
  };
}
