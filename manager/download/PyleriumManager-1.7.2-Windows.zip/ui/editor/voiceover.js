// Voice-over inside the Edit Studio: type a line, hear it, and drop it on the timeline at the playhead (with a
// matching caption if wanted). Speech is made on this computer by the Speak TTS engine, or the Windows voices.
import { locate, duration } from './model.js';
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
const store = 'studio.voice';

async function call(method, path, body) {
  const r = await fetch(path, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({})); if (!r.ok) throw Error(d.error || 'The voice-over request failed.'); return d;
}
const srt = (start, length, text) => { const f = t => { const ms = Math.round(t * 1000), p = (n, w = 2) => String(n).padStart(w, '0'); return `${p(ms / 3600000 | 0)}:${p((ms / 60000 | 0) % 60)}:${p((ms / 1000 | 0) % 60)},${p(ms % 1000, 3)}`; }; const words = text.split(/\s+/), lines = []; for (let i = 0; i < words.length; i += 7) lines.push(words.slice(i, i + 7).join(' ')); let t = start; return lines.map((line, i) => { const part = length * line.length / text.length, out = `${i + 1}\n${f(t)} --> ${f(t + part)}\n${line}\n`; t += part; return out; }).join('\n'); };

export async function initVoice() {
  const library = $('library'); if (!library) return;
  const box = document.createElement('section'); box.className = 'library-tools vox'; box.setAttribute('aria-label', 'Voice-over');
  box.innerHTML = '<h3>Voice-over</h3><p>Checking voices…</p>';
  library.querySelector('#media-kind')?.before(box);
  let state;
  try { state = await call('GET', '/api/video/voice'); } catch (e) { box.innerHTML = `<h3>Voice-over</h3><p class="bad">${esc(e.message)}</p>`; return; }
  if (!state.voices?.length) { box.innerHTML = `<h3>Voice-over</h3><p>${esc(state.speak?.reason || 'No voice is available on this computer.')} Set it up in Promo → Video.</p>`; return; }
  let saved = {}; try { saved = JSON.parse(localStorage.getItem(store) || '{}'); } catch {}
  const voice = state.voices.some(v => v.id === saved.voice) ? saved.voice : state.default, groups = [...new Set(state.voices.map(v => v.group))];
  const writer = await call('GET', '/api/video/writer').catch(e => ({ ok: false, error: e.message, apps: [] }));
  box.innerHTML = `<h3>Voice-over</h3><textarea id="vox-text" maxlength="1200" placeholder="Type what the voice should say…" aria-label="Voice-over text"></textarea>
    <select id="vox-voice" aria-label="Voice">${groups.map(g => `<optgroup label="${esc(g)}">${state.voices.filter(v => v.group === g).map(v => `<option value="${esc(v.id)}"${v.id === voice ? ' selected' : ''}>${esc(v.label)}</option>`).join('')}</optgroup>`).join('')}</select>
    <label>Pace <input id="vox-rate" type="range" min="0.7" max="1.4" step="0.05" value="${saved.rate || 1}"></label>
    <label>Add a caption too <input id="vox-caption" type="checkbox"${saved.caption ? ' checked' : ''}></label>
    <fieldset class="vox-ai"><legend>Written by Ollama</legend>
      ${writer.ok ? `<label>About <select id="vox-app"><option value="">The app the clip is from</option>${writer.apps.map(a => `<option value="${esc(a.id)}">${esc(a.name)}</option>`).join('')}</select></label>
      <div class="actions"><button type="button" id="vox-write">Write for this clip</button><button type="button" id="vox-all">Narrate every clip</button></div>` : `<p>${esc(writer.error || 'Ollama isn’t available.')}</p>`}</fieldset>
    <div class="actions"><button type="button" id="vox-add" class="primary">Add at playhead</button></div><p id="vox-status" role="status">Spoken on this computer${state.speak.ok ? ' by Speak TTS' : ''}. Added at the playhead as a sound layer.</p>`;
  const status = (t, bad) => { const p = $('vox-status'); p.textContent = t; p.classList.toggle('bad', !!bad); };
  const controls = () => ['vox-add', 'vox-write', 'vox-all'].map($).filter(Boolean);
  const line = (clip, previous) => call('POST', '/api/video/narrate', { mediaId: clip.mediaId, appId: $('vox-app')?.value || '', seconds: duration(clip), previous, rate: +$('vox-rate').value });
  if ($('vox-write')) {
    $('vox-write').onclick = async () => {
      const api = window.pyleriumVideoEditor, at = locate(api.project, api.time);
      if (!at) return status('Put the playhead on a video or picture on the main track first.', true);
      controls().forEach(b => (b.disabled = true)); status('Looking at the clip and writing…');
      try { const r = await line(at.clip, ''); $('vox-text').value = r.say; $('vox-text').focus(); status(`${r.page?.title ? `Recognised: ${r.page.title}. ` : ''}Edit it if you like, then add it.`); }
      catch (e) { status(e.message, true); }
      controls().forEach(b => (b.disabled = false));
    };
    $('vox-all').onclick = async () => {
      const api = window.pyleriumVideoEditor, clips = api.project.clips;
      if (!clips.length) return status('Add videos or pictures to the timeline first.', true);
      if (api.project.sounds.length + clips.length > 24) return status(`An edit holds 24 sound layers, and this needs ${clips.length} more.`, true);
      if (!confirm(`Write and add a voice-over for ${clips.length} clip${clips.length > 1 ? 's' : ''}? Undo removes them again.`)) return;
      controls().forEach(b => (b.disabled = true));
      let start = 0, previous = '', added = 0, failed = 0; const was = api.time;
      for (const [i, clip] of clips.entries()) {
        const length = duration(clip);
        try {
          status(`Clip ${i + 1} of ${clips.length}: writing…`);
          const r = await line(clip, previous); previous = r.say;
          status(`Clip ${i + 1} of ${clips.length}: speaking…`);
          const { media } = await call('POST', '/api/video/voice', { text: r.say, voice: $('vox-voice').value, rate: +$('vox-rate').value });
          api.seek(start); await api.addSound(media.id); added++;
          if ($('vox-caption').checked) { const file = $('caption-file'), data = new DataTransfer(); data.items.add(new File([srt(start, media.duration, r.say)], 'voice.srt', { type: 'text/plain' })); file.files = data.files; file.dispatchEvent(new Event('change', { bubbles: true })); await new Promise(ok => setTimeout(ok, 150)); }
        } catch (e) { failed++; status(`Clip ${i + 1}: ${e.message}`, true); await new Promise(ok => setTimeout(ok, 1200)); }
        start += length;
      }
      api.seek(was); controls().forEach(b => (b.disabled = false));
      status(`Added voice-over to ${added} clip${added === 1 ? '' : 's'}${failed ? `; ${failed} couldn’t be written` : ''}.`, !added);
    };
  }
  $('vox-add').onclick = async () => {
    const text = $('vox-text').value.trim(), api = window.pyleriumVideoEditor, button = $('vox-add');
    if (!text) { $('vox-text').focus(); return status('Type something for the voice to say.', true); }
    localStorage.setItem(store, JSON.stringify({ voice: $('vox-voice').value, rate: +$('vox-rate').value, caption: $('vox-caption').checked }));
    button.disabled = true; status(state.speak.ok && !state.speak.warm ? 'Warming up the voice (about a minute the first time)…' : 'Speaking…');
    try {
      const at = api.time, { media } = await call('POST', '/api/video/voice', { text, voice: $('vox-voice').value, rate: +$('vox-rate').value });
      state.speak.warm = true;
      if (!api.project.clips.length) { await api.refresh(); return status('Saved to your media library. Add a video or image to the timeline, then place the voice on it.'); }
      await api.addSound(media.id);
      if ($('vox-caption').checked) {
        const file = $('caption-file'), data = new DataTransfer();
        data.items.add(new File([srt(at, media.duration, text)], 'voice.srt', { type: 'text/plain' }));
        file.files = data.files; file.dispatchEvent(new Event('change', { bubbles: true }));
      }
      status(`Added ${media.duration.toFixed(1)}s of voice at ${at.toFixed(1)}s.`);
    } catch (e) { status(e.message, true); }
    finally { button.disabled = false; }
  };
}
