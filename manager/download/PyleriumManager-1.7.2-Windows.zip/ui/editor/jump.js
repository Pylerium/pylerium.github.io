// Getting around the edit: an overview scrubber with a hover preview, a "jump to" palette (Ctrl+K or /) over markers,
// clips, captions, sounds and typed times, YouTube-style transport keys, and chapters from your markers.
import { duration, total } from './model.js';

const $ = id => document.getElementById(id);
const E = () => window.pyleriumVideoEditor;
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
export const stamp = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}.${String(Math.floor((s % 1) * 10))}`;
const short = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

function items(project) {
  const media = new Map((E().media || []).map(m => [m.id, m.name])), list = [];
  let at = 0;
  for (const c of project.clips) { list.push({ t: at, end: at + duration(c), kind: 'Clip', text: c.blank ? 'Gap' : media.get(c.mediaId) || 'Missing source', id: c.id }); at += duration(c); }
  for (const c of project.overlays || []) list.push({ t: c.start, kind: 'Layer', text: media.get(c.mediaId) || 'Picture layer', id: c.id });
  for (const c of project.sounds || []) list.push({ t: c.start, kind: 'Sound', text: media.get(c.mediaId) || 'Sound', id: c.id });
  for (const c of project.texts || []) list.push({ t: c.start, kind: 'Caption', text: c.text || 'Caption', id: c.id });
  for (const m of project.markers || []) list.push({ t: m.time, kind: 'Marker', text: m.label, id: m.id });
  return list.sort((a, b) => a.t - b.t);
}
export function select(id) { document.querySelector(`#timeline-content [data-id="${CSS.escape(id)}"]`)?.click(); }

// ---------- jump palette ----------
function parseTime(q, project) {
  const pct = q.match(/^(\d+(?:\.\d+)?)\s*%$/); if (pct) return total(project) * +pct[1] / 100;
  const frames = q.match(/^f\s*(\d+)$/i); if (frames) return +frames[1] / project.fps;
  const t = q.match(/^(?:(\d+):)?(?:(\d+):)?(\d+(?:\.\d+)?)\s*s?$/); if (!t) return null;
  const parts = [t[1], t[2], t[3]].filter(v => v !== undefined).map(Number);
  return parts.reduce((sum, v) => sum * 60 + v, 0);
}
export function openJump() {
  if (document.querySelector('dialog[open]')) return;
  const project = E().project, all = items(project);
  const d = document.createElement('dialog'); d.className = 'jp'; d.setAttribute('aria-label', 'Jump to');
  d.innerHTML = `<input type="text" placeholder="Jump to a time (1:23, 45s, 50%) or search clips, captions, markers" aria-label="Jump to" autocomplete="off" role="combobox" aria-expanded="true" aria-controls="jp-list"><ul id="jp-list" role="listbox"></ul>
    <footer><span><kbd>↑</kbd> <kbd>↓</kbd> choose</span><span><kbd>Enter</kbd> jump</span><span><kbd>Esc</kbd> close</span></footer>`;
  document.body.append(d); d.showModal();
  const input = d.querySelector('input'), list = d.querySelector('ul');
  let shown = [], active = 0;
  const draw = () => {
    const q = input.value.trim().toLowerCase(), t = q ? parseTime(q, project) : null;
    shown = [...(t != null ? [{ t: Math.max(0, Math.min(total(project), t)), kind: 'Time', text: `Go to ${stamp(Math.max(0, Math.min(total(project), t)))}` }] : []), ...all.filter(i => !q || `${i.kind} ${i.text}`.toLowerCase().includes(q))].slice(0, 60);
    active = Math.min(active, Math.max(0, shown.length - 1));
    list.innerHTML = shown.map((i, n) => `<li role="option" data-n="${n}" id="jp-${n}" aria-selected="${n === active}"><time>${stamp(i.t)}</time><b>${esc(i.text)}</b><small>${i.kind}</small></li>`).join('') || `<span class="none">${all.length ? 'Nothing matches.' : 'Add media to the timeline first, or type a time.'}</span>`;
    input.setAttribute('aria-activedescendant', shown.length ? `jp-${active}` : '');
    list.querySelector('[aria-selected="true"]')?.scrollIntoView({ block: 'nearest' });
  };
  const go = n => { const i = shown[n]; if (!i) return; d.close(); if (i.id && i.kind !== 'Marker') select(i.id); E().seek(i.t + (i.kind === 'Time' || i.kind === 'Marker' ? 0 : .001)); };
  input.oninput = () => { active = 0; draw(); };
  input.onkeydown = e => { if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); active = (active + (e.key === 'ArrowDown' ? 1 : -1) + shown.length) % (shown.length || 1); draw(); } else if (e.key === 'Enter') { e.preventDefault(); go(active); } };
  d.onclick = e => { if (e.target === d) return d.close(); const li = e.target.closest('li'); if (li) go(+li.dataset.n); };
  d.onclose = () => d.remove();
  draw(); input.focus();
}

// ---------- overview scrubber ----------
function overview() {
  const host = document.querySelector('#viewer .transport'); if (!host) return;
  const bar = document.createElement('div'); bar.className = 'ov'; bar.tabIndex = 0;
  bar.setAttribute('role', 'slider'); bar.setAttribute('aria-label', 'Position in the edit'); bar.setAttribute('aria-valuemin', '0');
  bar.innerHTML = '<div class="ov-track"><div class="ov-fill"></div></div><div class="ov-extra"></div><div class="ov-knob"></div><div class="ov-tip" hidden></div>';
  host.before(bar);
  const track = bar.querySelector('.ov-track'), fill = bar.querySelector('.ov-fill'), extra = bar.querySelector('.ov-extra'), knob = bar.querySelector('.ov-knob'), tip = bar.querySelector('.ov-tip');
  let project = null, length = 0, list = [], sig = '', last = -1, scrub = false, raf = 0, timer = 0;
  const rebuild = () => {
    const p = E()?.project; if (!p) return;
    const next = JSON.stringify([p.clips, p.markers, p.texts, p.overlays]); if (next === sig) return;
    sig = next; project = p; length = total(p) || 0; list = items(p);
    const pct = t => (length ? t / length * 100 : 0);
    track.querySelectorAll('i').forEach(i => i.remove());
    for (const c of list.filter(i => i.kind === 'Clip')) { const i = document.createElement('i'); i.style.cssText = `left:${pct(c.t)}%;width:${pct(c.end - c.t)}%`; track.prepend(i); }
    extra.innerHTML = list.map(i => i.kind === 'Marker' ? `<span class="ov-mark" style="left:${pct(i.t)}%"></span>` : '').join('') + (p.texts || []).map(t => `<span class="ov-cap" style="left:${pct(t.start)}%;width:${pct(t.duration)}%"></span>`).join('');
    bar.setAttribute('aria-valuemax', length.toFixed(1)); last = -1;
  };
  const tick = () => {
    raf = requestAnimationFrame(tick);
    const t = E()?.time ?? 0; if (t === last) return; last = t;
    const k = length ? Math.min(1, t / length) : 0;
    fill.style.transform = `scaleX(${k})`; knob.style.left = `${k * 100}%`;
    bar.setAttribute('aria-valuenow', t.toFixed(1)); bar.setAttribute('aria-valuetext', stamp(t));
  };
  const timeAt = e => { const r = bar.getBoundingClientRect(); return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * length; };
  bar.addEventListener('pointerdown', e => { if (!length || e.button) return; scrub = true; bar.setPointerCapture(e.pointerId); E().seek(timeAt(e)); });
  bar.addEventListener('pointermove', e => {
    if (!length) return; const t = timeAt(e);
    const near = list.filter(i => i.kind === 'Marker').find(i => Math.abs(i.t - t) < length / 100) || list.filter(i => i.kind === 'Clip').find(i => t >= i.t && t < i.end);
    tip.hidden = false; tip.style.left = `${t / length * 100}%`; tip.innerHTML = `${stamp(t)}${near ? `<small>${esc(near.text)}</small>` : ''}`;
    if (scrub) E().seek(t);
  });
  const end = () => { scrub = false; };
  bar.addEventListener('pointerup', end); bar.addEventListener('pointercancel', end); bar.addEventListener('pointerleave', () => { tip.hidden = true; });
  bar.addEventListener('keydown', e => { const t = E().time; const to = e.key === 'ArrowRight' ? t + 5 : e.key === 'ArrowLeft' ? t - 5 : e.key === 'Home' ? 0 : e.key === 'End' ? length : null; if (to == null) return; e.preventDefault(); e.stopPropagation(); E().seek(Math.max(0, Math.min(length, to))); });
  rebuild(); timer = setInterval(() => { if (!document.hidden) rebuild(); }, 600); raf = requestAnimationFrame(tick);
  addEventListener('pagehide', () => { clearInterval(timer); cancelAnimationFrame(raf); }, { once: true });
}

// ---------- transport keys ----------
function keys() {
  addEventListener('keydown', e => {
    if (!E() || document.querySelector('dialog[open]')) return;
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === 'k') { e.preventDefault(); e.stopImmediatePropagation(); return openJump(); }
    if (e.target.closest?.('input, textarea, select, .ov') || mod || e.altKey) return;
    const k = e.key.toLowerCase(), eat = () => { e.preventDefault(); e.stopImmediatePropagation(); };
    const length = () => total(E().project), go = t => { eat(); E().seek(Math.max(0, Math.min(length(), t))); };
    const playing = () => $('play').dataset.state === 'playing', rate = $('monitor-rate');
    const setRate = v => { rate.value = String(v); rate.dispatchEvent(new Event('change', { bubbles: true })); };
    if (k === '/') { eat(); return openJump(); }
    if (k === 'j') return go(E().time - (e.repeat ? 1 : 5));
    if (k === 'k') { eat(); setRate(1); if (playing()) $('play').click(); return; }
    if (k === 'l') { eat(); if (!playing()) { setRate(1); return $('play').click(); } const next = [1, 1.5, 2].find(v => v > +rate.value) || 1; return setRate(next); }
    if (e.shiftKey && (e.key === 'ArrowLeft' || e.key === 'ArrowRight')) return go(E().time + (e.key === 'ArrowLeft' ? -1 : 1));
    if (e.key === 'ArrowUp') { eat(); return $('previous-edit').click(); }
    if (e.key === 'ArrowDown') { eat(); return $('next-edit').click(); }
    if (/^[0-9]$/.test(e.key) && !e.shiftKey) return go(length() * +e.key / 10);
  }, { capture: true });
}

// ---------- chapters from markers ----------
function chapters() {
  const host = $('marker-list')?.parentElement; if (!host) return;
  const b = document.createElement('button'); b.type = 'button'; b.id = 'st-chapters'; b.textContent = 'Copy YouTube chapters';
  b.onclick = async () => {
    const marks = [...(E().project.markers || [])].sort((a, c) => a.time - c.time), say = t => { $('status').textContent = t; };
    const list = []; if (!marks.length || marks[0].time >= 1) list.push({ time: 0, label: 'Intro' });
    for (const m of marks) if (!list.length || m.time - list.at(-1).time >= 10) list.push({ time: list.length ? m.time : 0, label: m.label });
    if (list.length < 3) return say('YouTube needs at least three chapters, each 10 seconds apart. Add more markers (M).');
    try { await navigator.clipboard.writeText(list.map(c => `${short(c.time)} ${c.label}`).join('\n')); say(`Copied ${list.length} chapters.`); } catch { say('Couldn’t copy the chapters.'); }
  };
  host.append(b);
}

export function initJump() {
  overview(); keys(); chapters();
  const time = $('time'); time.setAttribute('role', 'button'); time.tabIndex = 0; time.setAttribute('aria-label', 'Jump to a time');
  time.addEventListener('click', openJump); time.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); openJump(); } });
}
