// Updates: asks before installing, shows progress while the app downloads, closes and comes back, then reloads the page.
// Server side: update.mjs.
import { R, $, esc, api, toast } from './core.js';

const I = n => R.icon(n);
const ASKED = 'update.asked';
let S = null, dlg = null, timer = 0, installing = false, recheck = 0;

const store = { get: () => { try { return localStorage.getItem(ASKED) || ''; } catch { return ''; } }, set: v => { try { localStorage.setItem(ASKED, v); } catch {} } };
const mb = n => (n ? `${Math.round(n / 1048576)} MB` : '');

export async function init() {
  await refresh();
  // the first check runs in the background as the app starts: look again shortly, then now and then
  recheck = setTimeout(async function again() { await refresh(); recheck = setTimeout(again, 3600e3); }, 12000);
  addEventListener('pagehide', () => { clearTimeout(recheck); clearTimeout(timer); }, { once: true });
}
export async function refresh() {
  if (installing) return;
  try { S = await api('GET', '/api/update'); } catch { return; }
  report(); bar(); chip();
  if (S.job && !S.job.error && S.job.version) return follow(S.job.version);
  const u = S.update;
  if (u && store.get() !== u.version && $('#setup')?.hidden !== false && !document.querySelector('dialog[open]')) { store.set(u.version); ask(); }
}
// tells you once how the last update went
function report() {
  const last = S.last; if (!last) return;
  if (last.ok && last.version === S.current) toast(`Updated to version ${last.version}`, 'ok', 8000);
  else if (!last.ok) toast(`The update didn’t finish, so version ${last.from} was put back. ${last.error || ''}`, 'err', 15000);
  else return;
  S.last = null; api('POST', '/api/update/seen', {}).catch(() => {});
}
function bar() {
  let el = $('#updBar');
  const u = S?.update;
  if (!el) { const after = $('#licBar'); if (!after) return; el = document.createElement('div'); el.id = 'updBar'; el.className = 'upd-bar'; after.after(el); el.addEventListener('click', e => { if (e.target.closest('[data-upd]')) ask(); }); }
  el.hidden = !u;
  if (u) el.innerHTML = `<div class="upd-in">${I('download')}<span><b>Version ${esc(u.version)} is ready.</b> You have ${esc(S.current)}.</span>${u.canInstall ? `<button type="button" class="hbtn primary sm" data-upd>Update</button>` : `<a class="hbtn primary sm" href="${esc(u.url)}" target="_blank" rel="noopener">Get the new version</a>`}</div>`;
}
// the same offer inside Settings → Account
export function chip() {
  const slot = document.getElementById('updSlot'); if (!slot) return;
  const u = S?.update;
  slot.innerHTML = u ? (u.canInstall ? `<button type="button" class="hbtn primary sm" data-updnow>${I('download')}Update to ${esc(u.version)}</button>` : `<a class="hbtn primary sm" href="${esc(u.url)}" target="_blank" rel="noopener">${I('download')}Get ${esc(u.version)}</a>`)
    : `<button type="button" class="hbtn ghost sm" data-updcheck>${I('refresh')}Check for updates</button>`;
  slot.onclick = async e => {
    if (e.target.closest('[data-updnow]')) return ask();
    const b = e.target.closest('[data-updcheck]'); if (!b) return;
    b.disabled = true;
    try { S = await api('POST', '/api/update/check', {}); bar(); chip(); if (S.update) ask(); else toast('You have the newest version'); }
    catch (x) { toast(x.message, 'err', 8000); b.disabled = false; }
  };
}

function dialog() {
  if (dlg) return dlg;
  dlg = document.createElement('dialog'); dlg.className = 'upd-dlg'; dlg.setAttribute('aria-labelledby', 'updTitle');
  document.body.append(dlg);
  dlg.addEventListener('cancel', e => { if (installing) e.preventDefault(); });
  dlg.addEventListener('click', e => {
    if (e.target.closest('[data-later]') || (e.target === dlg && !installing)) return dlg.close();
    if (e.target.closest('[data-go]')) start();
  });
  return dlg;
}
export function ask() {
  const u = S?.update; if (!u || installing) return;
  if (!u.canInstall) { if (u.why) toast(u.why, 'err', 10000); return window.open(u.url, '_blank', 'noopener'); }
  const d = dialog();
  d.innerHTML = `<div class="upd"><span class="upd-ico" aria-hidden="true">${I('download')}</span><h2 id="updTitle">Update to version ${esc(u.version)}?</h2>
    ${u.notes ? `<p class="upd-notes">${esc(u.notes)}</p>` : ''}
    <p class="upd-sub">Pylerium Manager downloads it${u.size ? ` (${mb(u.size)})` : ''}, closes, installs and opens again. It takes a minute or two. Your apps, settings and voice pack stay as they are.</p>
    <div class="upd-foot"><button type="button" class="hbtn ghost" data-later>Not now</button><button type="button" class="hbtn primary" data-go>${I('download')}Update now</button></div></div>`;
  if (!d.open) d.showModal();
  d.querySelector('[data-go]').focus();
}
async function start() {
  const version = S.update.version;
  try { S = await api('POST', '/api/update/install', { version }); follow(version); }
  catch (e) { dlg.close(); toast(e.message, 'err', 12000); }
}
const STEP = { downloading: 'Downloading…', unpacking: 'Checking and unpacking…', installing: 'Installing…', restarting: 'Restarting Pylerium Manager…' };
function progress(phase, part) {
  const d = dialog();
  if (!d.querySelector('.upd-meter')) d.innerHTML = `<div class="upd" aria-busy="true"><span class="upd-ico" aria-hidden="true">${I('download')}</span><h2 id="updTitle">Updating</h2><p class="upd-step" role="status" aria-live="polite"></p>
    <div class="upd-meter" role="progressbar" aria-label="Download" aria-valuemin="0" aria-valuemax="100"><i></i></div><p class="upd-sub">Keep this page open. It reloads by itself when the new version is running.</p></div>`;
  const text = STEP[phase] || phase, step = d.querySelector('.upd-step'), meter = d.querySelector('.upd-meter');
  if (step.textContent !== text) step.textContent = text;
  const known = phase === 'downloading';
  meter.classList.toggle('busy', !known);
  meter.firstElementChild.style.transform = known ? `scaleX(${Math.max(.02, part)})` : '';
  known ? meter.setAttribute('aria-valuenow', Math.round(part * 100)) : meter.removeAttribute('aria-valuenow');
  if (!d.open) d.showModal();
}
function stop(title, text) {
  installing = false;
  dialog().innerHTML = `<div class="upd"><span class="upd-ico bad" aria-hidden="true">${I('alert')}</span><h2 id="updTitle">${esc(title)}</h2><p class="upd-sub">${esc(text)}</p><div class="upd-foot"><button type="button" class="hbtn primary" data-later>Close</button></div></div>`;
  if (!dlg.open) dlg.showModal();
}
// follows the download, then waits for the app to go away and come back
function follow(version) {
  installing = true; clearTimeout(timer);
  let gone = false; const began = Date.now();
  progress('downloading', 0);
  const tick = async () => {
    try {
      if (!gone) {
        const s = await api('GET', '/api/update');
        if (s.job?.error) return stop('The update didn’t finish', `${s.job.error} Nothing was changed.`);
        if (s.current === version) return void (timer = setTimeout(() => location.reload(), 1800));
        if (s.job) progress(s.job.phase, s.job.progress);
        else if (s.last && !s.last.ok) return location.reload(); // put back: the reload explains why
      } else {
        // a restarted app has a new security token, so ask for the page itself and reload once it answers
        const r = await fetch('/', { cache: 'no-store' });
        if (r.ok) return void (timer = setTimeout(() => location.reload(), 1800)); // let the helper record the result first
      }
    } catch (e) {
      if (!gone) { gone = true; progress('restarting', 1); }
      if (e?.data) return void (timer = setTimeout(() => location.reload(), 1800)); // it answered but refused our old token: it has restarted
    }
    if (Date.now() - began > 25 * 60000) return stop('This is taking too long', 'Close Pylerium Manager and open it again. If the update didn’t finish, your previous version is still there.');
    timer = setTimeout(tick, 900);
  };
  timer = setTimeout(tick, 600);
}
