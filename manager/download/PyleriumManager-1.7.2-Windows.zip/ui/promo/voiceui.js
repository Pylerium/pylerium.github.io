// Voice-over controls shared by the Video Director: voice picker grouped by language, speaking rate, a sample button,
// one-click setup when the natural voices' Python packages are missing.
import { api, toast, confirmBox, esc } from '../core.js';
import { ST, I, sw, addJob } from './common.js';

let player = null, seq = 0;
export function stopVoice() { seq++; player?.pause(); player = null; }

export function voiceControls(v, O) {
  const groups = [...new Set(v.voices.map(x => x.group))];
  const order = g => ['English (US)', 'English (UK)'].includes(g) ? 0 : g === 'Windows voices' ? 2 : 1;
  const setup = !v.speak.ok ? `<div class="vo-setup">${I('mic')}<div><b>Natural voices ${v.speak.installable ? 'need a one-time setup' : 'aren’t available'}</b><small>${esc(v.speak.installed ? v.speak.reason : 'Natural voices come as the voice pack: unzip it into the app’s folder, then reopen this page.')}${v.windows ? ' Windows voices work meanwhile.' : ''}</small></div>${v.speak.installable ? '<button type="button" class="hbtn primary sm" data-v="voiceinstall">Set up voice-over</button>' : ''}</div>` : '';
  if (!v.voices.length) return `<div class="vo">${setup}</div>`;
  return `<div class="vo"><div class="vo-top">${sw('data-o="narration"', O.narration, 'Voice-over')}<small class="muted">${v.speak.ok ? 'Speak TTS · made on this computer' : 'Windows voices'}</small></div>${setup}
    ${O.narration ? `<div class="vo-row"><label class="fld"><span>Voice</span><select data-o="voice">${groups.sort((a, b) => order(a) - order(b) || a.localeCompare(b)).map(g => `<optgroup label="${esc(g)}">${v.voices.filter(x => x.group === g).map(x => `<option value="${esc(x.id)}"${x.id === O.voice ? ' selected' : ''}>${esc(x.label)}</option>`).join('')}</optgroup>`).join('')}</select></label>
      <label class="fld"><span>Pace <small class="num">${(+O.rate || 1).toFixed(2)}×</small></span><input type="range" data-o="rate" min="0.7" max="1.4" step="0.05" value="${O.rate || 1}"></label>
      <button type="button" class="hbtn ghost sm" data-v="voicesample">${I('playfill')}Hear it</button></div>` : ''}</div>`;
}
export async function previewVoice(text, O, button) {
  stopVoice(); const mine = seq;
  if (!String(text || '').trim()) return toast('Write a line for the voice first', 'err');
  const html = button.innerHTML; button.disabled = true;
  button.innerHTML = `<span class="spinner sm"></span>${ST.film.voice.speak.ok && !ST.film.voice.speak.warm ? 'Warming up…' : 'Speaking…'}`;
  try {
    const r = await api('POST', '/api/promo/voice/preview', { text, voice: O.voice, rate: O.rate });
    if (!O.voice?.startsWith('win:')) ST.film.voice.speak.warm = true;
    if (mine !== seq) return;
    player = new Audio(r.audio); await player.play();
  } catch (e) { toast(e.message, 'err', 9000); }
  finally { if (button.isConnected) { button.disabled = false; button.innerHTML = html; } }
}
export async function installVoice(button) {
  if (!(await confirmBox('Set up voice-over?', 'This downloads the MediaPipe, NumPy and SciPy packages into your Python (a few hundred MB, once). Speech is then generated on your computer.', 'Download and set up', false))) return;
  button.disabled = true;
  try { addJob((await api('POST', '/api/promo/voice/install')).job); toast('Setting up voice-over. This takes a few minutes.', 'info', 7000); }
  catch (e) { button.disabled = false; toast(e.message, 'err', 9000); }
}
