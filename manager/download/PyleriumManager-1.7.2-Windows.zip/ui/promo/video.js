// Video Director: choose a direction, watch it play with its soundtrack and voice-over, edit it on a real timeline,
// jump anywhere, render. The player is the film engine in a same-origin iframe, so what plays here is what gets encoded.
import { api, toast, confirmBox, esc, rel } from '../core.js';
import { ST, app, I, media, debounce, clock, sw, seg, addJob, active, copyText } from './common.js';
import { createTimeline, precise } from './timeline.js';
import { voiceControls, previewVoice, stopVoice, installVoice } from './voiceui.js';

const SHAPES = [['16:9', 'Wide'], ['9:16', 'Vertical'], ['1:1', 'Square'], ['4:5', 'Portrait']];
const RATES = [.5, .75, 1, 1.25, 1.5, 2];
const DEF = { direction: 'tour', seconds: 30, theme: 'ink', mood: 'bright', captions: false, narration: false, voice: '', rate: 1, music: .8, sfx: .8, quality: 'full', fps: 30 };
const KEYS = [['Space · K', 'Play or pause'], ['J  L', 'Back or forward 10 seconds'], ['←  →', 'Back or forward 5 seconds'], [',  .', 'One frame back or forward'], ['[  ]', 'Previous or next scene'], ['0 – 9', 'Jump to 0% – 90%'], ['Home  End', 'Start or end'],
  ['/', 'Jump to a time or scene'], ['S', 'Split the scene at the playhead'], ['M', 'Add a marker'], ['X', 'Switch the scene on or off'], ['Ctrl D', 'Duplicate scene'], ['Delete', 'Delete scene'], ['Ctrl Z  Ctrl Y', 'Undo, redo'], ['Alt ← →', 'Move the selected scene'], ['< >', 'Slower or faster'], ['R', 'Repeat the selected scene'], ['F', 'Full screen']];
let root = null, board = null, shots = [], sel = 0, aspect = '16:9', O = { ...DEF }, spec = null, total = 0, time = 0, playing = false, raf = 0, startedAt = 0, token = 0, ready = false, loadedFor = '';
let frame = null, audio = null, ro = null, region = null, tl = null, rate = 1, loop = false, past = [], future = [], committed = '', side = 'scene', keys = null, mounted = 0, pending = false;
const prefsKey = 'promo.video';
try { O = { ...DEF, ...JSON.parse(localStorage.getItem(prefsKey) || '{}') }; } catch {}
const savePrefs = () => localStorage.setItem(prefsKey, JSON.stringify(O));
const scene = () => board?.scenes[sel];
const beat = () => 60 / (board?.bpm || 100);
const needsShot = t => ['reveal', 'spotlight', 'loupe', 'split', 'glide'].includes(t);
const label = t => ST.film.sceneTypes.find(x => x.id === t)?.label || t;
const built = i => spec?.scenes.find(s => s.index === i);
const uid = () => 's' + Date.now().toString(36) + Math.floor(Math.random() * 99);
// Ollama voice-over: who writes, whether it is writing now, and which page each screenshot was recognised as
let writer = null, aiBusy = false, fresh = false;
const seen = new Map();
const SEEN_BY = { capture: 'from the capture', vision: 'seen by your model', text: 'read from the picture', name: 'from the file name' };
function showSeen() {
  const el = root?.querySelector('#vdSees'), s = scene(); if (!el || !s) return;
  const file = s.shot || s.shots?.[0] || '', p = seen.get(file);
  el.hidden = !file;
  el.textContent = !file ? '' : p === undefined ? 'Recognising this screen…' : p ? `Screen: ${p.title} · ${SEEN_BY[p.source] || ''}` : '';
  if (file && p === undefined && !seen.has(`…${file}`)) {
    seen.set(`…${file}`, true); const mine = mounted;
    api('POST', '/api/promo/pages', { files: [file] }).then(r => seen.set(file, r.pages[0] || null)).catch(() => seen.set(file, null)).finally(() => { seen.delete(`…${file}`); if (mine === mounted) showSeen(); });
  }
}
// Writes lines for the given scenes (all of them when none are named). Scenes are matched by id, so editing meanwhile is safe.
async function aiWrite(only) {
  if (aiBusy || !board) return; if (!writer?.ok) { writer = await api('GET', '/api/promo/writer').catch(() => writer); if (!writer?.ok) return toast(writer?.error || 'Ollama isn’t available.', 'err', 9000); }
  const mine = mounted, asked = board.scenes.map(s => s.id), indexes = only || board.scenes.map((s, i) => (s.off ? -1 : i)).filter(i => i >= 0);
  aiBusy = true; drawRender(); if (side === 'scene') drawSide();
  try {
    const r = await api('POST', '/api/promo/narrate', { appId: ST.appId, board, indexes, rate: O.rate });
    if (mine !== mounted) return;
    remember.flush(); let written = 0, kept = 0;
    for (const l of r.lines) {
      const s = board.scenes.find(x => x.id === asked[l.index]); if (!s) continue;
      if (l.page) seen.set(s.shot || s.shots?.[0] || '', l.page);
      if (l.fallback && only) { kept++; continue; } s.say = l.say; l.fallback ? kept++ : written++;
    }
    toast(written ? `${r.model} wrote ${written} line${written === 1 ? '' : 's'}${kept ? `; ${kept} kept the simple wording` : ''}. Undo brings the old ones back.` : 'The model didn’t give a usable line. Try again.', written ? 'ok' : 'err', 7000);
    aiBusy = false; changed({ panel: true });
  } catch (e) { if (mine === mounted) toast(e.message, 'err', 10000); }
  if (mine === mounted) { aiBusy = false; drawRender(); drawSide(); }
}

export function stop() { playing = false; cancelAnimationFrame(raf); audio?.pause(); syncButtons(); }
export function unmount() {
  stop(); stopVoice(); token++; mounted++; save.flush?.(); save.cancel(); refresh.cancel(); ro?.disconnect(); tl?.destroy(); keys?.abort(); ro = tl = keys = null; frame = audio = null; ready = false;
  if (root) root.onclick = root.oninput = root.onchange = root.onkeydown = root.onpointerdown = null; root = null;
}

export async function mount(el) {
  root = el;
  root.innerHTML = `<div class="card lv-loading"><span class="spinner"></span>Reading ${esc(app().name)}’s screenshots and writing the storyboard…</div>`;
  const mine = ++mounted, id = ST.appId;
  try {
    const film = await api('GET', '/api/promo/film');
    const [sb, an, w] = await Promise.all([api('POST', '/api/promo/storyboard', { appId: id, options: O }), api('POST', '/api/promo/analyze', { appId: id }), api('GET', '/api/promo/writer').catch(e => ({ ok: false, error: e.message }))]);
    writer = w; aiBusy = false; fresh = !sb.saved;
    if (mine !== mounted) return;
    ST.film = film; board = sb.board; board.markers ||= []; shots = an.shots; sel = 0; time = 0; loadedFor = id; past = []; future = []; committed = JSON.stringify(board);
    Object.assign(O, { direction: board.direction || O.direction, theme: board.theme, mood: board.mood });
    if (!ST.film.voice.voices.some(v => v.id === O.voice)) O.voice = ST.film.voice.default;
  } catch (e) { if (mine === mounted) root.innerHTML = `<div class="card"><div class="emptystate">${I('alert')}<h4>Couldn’t prepare the video</h4><p>${esc(e.message)}</p></div></div>`; return; }
  skeleton(); bind(); drawAll(); refresh.flush();
  if (fresh && O.narration && writer.ok && writer.auto) aiWrite();
  if (O.narration && ST.film.voice.speak.ok) api('POST', '/api/promo/voice/warm').catch(() => {});
}

function skeleton() {
  root.innerHTML = `
  <div class="vd">
    <section class="card vd-direct" aria-label="Direction" id="vdDirect"></section>
    <section class="vd-stage" aria-label="Preview" id="vdStage">
      <div class="vd-screenwrap" id="vdWrap"><div class="vd-screen" id="vdScreen"><iframe title="Video preview" src="/promo/film.html" tabindex="-1"></iframe><button type="button" class="vd-big" data-v="play" aria-label="Play preview">${I('playfill')}</button></div><div class="vd-busy" id="vdBusy" role="status"><span class="spinner"></span><span id="vdBusyText">Building preview…</span></div><div class="vd-flash" id="vdFlash" aria-hidden="true"></div></div>
      <div class="vd-transport" role="toolbar" aria-label="Playback">
        <button type="button" class="act" data-v="prev" aria-label="Previous scene ([)" title="Previous scene  [">${I('chevleft')}</button>
        <button type="button" class="hbtn primary sm" data-v="play" id="vdPlay"></button>
        <button type="button" class="act" data-v="next" aria-label="Next scene (])" title="Next scene  ]">${I('chevron')}</button>
        <output class="num" id="vdTime">0:00.0 / 0:00.0</output>
        <form class="vd-jump" id="vdJump" autocomplete="off"><label class="search">${I('search')}<input id="vdJumpIn" placeholder="Jump to 0:12 or a scene  ( / )" aria-label="Jump to a time or scene" list="vdJumpList"></label><datalist id="vdJumpList"></datalist></form>
        <span class="sp"></span>
        <button type="button" class="act" data-v="loop" id="vdLoop" aria-pressed="false" aria-label="Repeat the selected scene (R)" title="Repeat scene  R">${I('refresh')}</button>
        <select id="vdRate" aria-label="Preview speed">${RATES.map(r => `<option value="${r}"${r === rate ? ' selected' : ''}>${r}×</option>`).join('')}</select>
        <div class="seg" role="group" aria-label="Video shape" id="vdShape"></div>
        <button type="button" class="act" data-v="full" aria-label="Full screen (F)" title="Full screen  F">${I('monitor')}</button>
      </div>
      <div class="vd-edit" role="toolbar" aria-label="Edit"><button type="button" class="hbtn ghost sm" data-v="undo" title="Undo  Ctrl Z">Undo</button><button type="button" class="hbtn ghost sm" data-v="redo" title="Redo  Ctrl Y">Redo</button><i></i>
        <button type="button" class="hbtn ghost sm" data-v="split" title="Split at the playhead  S">Split</button><button type="button" class="hbtn ghost sm" data-v="dup" title="Duplicate  Ctrl D">${I('copy')}Duplicate</button><button type="button" class="hbtn ghost sm" data-v="toggle" title="Switch on or off  X">${I('eyeoff')}On / off</button><button type="button" class="hbtn ghost sm" data-v="del" title="Delete">${I('trash')}Delete</button><i></i>
        <button type="button" class="hbtn ghost sm" data-v="marker" title="Add a marker  M">${I('tag')}Marker</button><span class="sp"></span>
        <label class="vd-zoom">Zoom<input type="range" id="vdZoom" min="1" max="12" step=".25" value="1" aria-label="Timeline zoom"></label><button type="button" class="act" data-v="keys" aria-label="Keyboard shortcuts" title="Keyboard shortcuts">${I('keyboard')}</button></div>
      <div id="vdLine"></div>
    </section>
    <section class="card vd-inspect" aria-label="Inspector"><div class="seg wide" role="tablist" aria-label="Inspector view">${[['scene', 'Scene'], ['jump', 'Chapters']].map(([v, l]) => `<button type="button" role="tab" data-side="${v}">${l}</button>`).join('')}</div><div id="vdScene"></div></section>
  </div>
  <div class="vd-lower"><section class="card" id="vdRender" aria-label="Render"></section><section class="card" id="vdOut" aria-label="Finished videos"></section></div>
  <audio id="vdAudio" preload="auto"></audio>`;
  frame = root.querySelector('iframe'); audio = root.querySelector('#vdAudio');
  ro = new ResizeObserver(fit); ro.observe(root.querySelector('#vdWrap'));
  tl = createTimeline(root.querySelector('#vdLine'), {
    board: () => board, spec: () => spec, time: () => time, sel: () => sel, typeName: label, narrating: () => O.narration && (!spec || pending),
    seek: (t, scrubbing) => { if (scrubbing && playing) stop(); seek(t); syncButtons(); }, scrubEnd: () => {},
    select: (i, jump) => select(i, jump), trim: (i, beats) => { if (board.scenes[i].beats === beats) return tl.draw(); board.scenes[i].beats = beats; sel = i; changed({ panel: true }); },
    move, add, marker: (i, t) => editMarker(i, t), zoomed: z => { root.querySelector('#vdZoom').value = z; }
  });
}

function drawAll() { drawDirect(); drawShape(); tl.draw(); drawSide(); drawRender(); drawOutputs(); drawJumpList(); syncButtons(); }
function drawDirect() {
  const f = ST.film;
  root.querySelector('#vdDirect').innerHTML = `<div class="card-head"><h3>${I('film')}Direction</h3></div>
    <div class="vd-dirs" role="radiogroup" aria-label="Story">${f.directions.map(d => `<button type="button" role="radio" aria-checked="${O.direction === d.id}" class="${O.direction === d.id ? 'on' : ''}" data-dir="${d.id}"><b>${esc(d.label)}</b><small>${esc(d.blurb)}</small></button>`).join('')}</div>
    <label class="fld"><span>Length <small class="num" id="vdSecs">about ${O.seconds}s</small></span><input type="range" min="12" max="60" step="3" value="${O.seconds}" data-o="seconds"></label>
    <div class="fld"><span>Look</span><div class="vd-themes">${f.themes.map(t => `<button type="button" class="th-${t.id}${board.theme === t.id ? ' on' : ''}" data-theme="${t.id}" aria-pressed="${board.theme === t.id}"><i></i>${esc(t.label)}</button>`).join('')}</div></div>
    <div class="fld"><span>Accent</span><div class="row vd-accent"><button type="button" class="hbtn ghost sm${board.accent ? '' : ' on'}" data-v="autoaccent">From the app</button><input type="color" data-o="accent" value="${board.accent || '#34d1b4'}" aria-label="Custom accent colour"></div></div>
    <div class="fld"><span>Music</span>${seg('data-mood', f.moods.map(m => [m.id, m.label]), board.mood)}</div>
    <div class="vd-gen"><button type="button" class="hbtn primary" data-v="generate">${I('sparkles')}Write new storyboard</button><button type="button" class="hbtn ghost" data-v="another" title="Same settings, different camera choices">${I('refresh')}Another take</button></div>`;
}
function drawShape() { root.querySelector('#vdShape').innerHTML = SHAPES.map(([v, l]) => `<button type="button" data-shape="${v}" class="${aspect === v ? 'on' : ''}" title="${l} ${v}">${v}</button>`).join(''); }

// ---------- chapters: scenes and markers as a list to jump through ----------
function chapters() { return (spec?.scenes || []).map(s => ({ t: s.start, i: s.index, title: board.scenes[s.index]?.title || label(s.type), type: label(s.type), shot: board.scenes[s.index]?.shot })); }
// YouTube wants the first chapter at 0:00 and each at least 10 seconds long
function youtubeChapters() {
  const list = [];
  for (const c of chapters()) { if (!list.length) list.push({ ...c, t: 0 }); else if (c.t - list.at(-1).t >= 10 && total - c.t >= 10) list.push(c); }
  return list.map(c => `${clock(c.t)} ${c.title}`).join('\n');
}
function drawJumpList() { const d = root.querySelector('#vdJumpList'); if (d) d.innerHTML = chapters().map(c => `<option value="${esc(c.title)}">${precise(c.t)}</option>`).join('') + (board.markers || []).map(m => `<option value="${esc(m.label)}">${precise(m.t)}</option>`).join(''); }
function jump(q) {
  const s = q.trim().toLowerCase(); if (!s) return;
  const t = s.match(/^(?:(\d+):)?(\d+(?:\.\d+)?)\s*s?$/), pct = s.match(/^(\d+(?:\.\d+)?)\s*%$/);
  let to = null, name = '';
  if (t) to = (+(t[1] || 0)) * 60 + +t[2]; else if (pct) to = total * +pct[1] / 100;
  else {
    const scene_ = s.match(/^(?:scene|#)\s*(\d+)$/), list = [...(board.markers || []).map(m => ({ t: m.t, text: m.label })), ...chapters().map(c => ({ t: c.t, i: c.i, text: `${c.title} ${c.type} ${board.scenes[c.i]?.detail || ''} ${board.scenes[c.i]?.say || ''} ${(c.shot || '').split('/').pop()}` }))];
    const hit = scene_ ? chapters().find(c => c.i === +scene_[1] - 1) : list.find(x => x.text.toLowerCase().includes(s));
    if (hit) { to = hit.t + (hit.i != null ? .05 : 0); if (hit.i != null) select(hit.i, false); name = hit.text?.split(' ').slice(0, 5).join(' ') || ''; }
  }
  if (to == null) return toast(`Nothing called “${q}” in this video`, 'err');
  seek(to); syncButtons(); flash(name || precise(time));
}
const flash = text => { const f = root?.querySelector('#vdFlash'); if (!f) return; f.textContent = text; f.classList.remove('show'); void f.offsetWidth; f.classList.add('show'); };

function drawSide() {
  root.querySelectorAll('[data-side]').forEach(b => { b.classList.toggle('on', b.dataset.side === side); b.setAttribute('aria-selected', b.dataset.side === side); });
  if (side === 'scene') return drawScene();
  const list = chapters(), marks = board.markers || [];
  root.querySelector('#vdScene').innerHTML = `<ol class="vd-chapters">${list.map(c => `<li><button type="button" data-chapter="${c.i}" data-t="${c.t}" class="${c.i === sel ? 'on' : ''}">${c.shot ? `<img src="${esc(media(c.shot))}" alt="" loading="lazy">` : `<span class="ph">${I('film')}</span>`}<span><b>${esc(c.title)}</b><small>${esc(c.type)}</small></span><time class="num">${precise(c.t)}</time></button></li>`).join('')}</ol>
    ${marks.length ? `<h4 class="vd-h">Markers</h4><ol class="vd-chapters">${marks.map((m, i) => `<li><button type="button" data-t="${m.t}"><span class="ph">${I('tag')}</span><span><b>${esc(m.label)}</b></span><time class="num">${precise(m.t)}</time></button><button type="button" class="act" data-renmark="${i}" aria-label="Rename marker">${I('edit')}</button><button type="button" class="act del" data-delmark="${i}" aria-label="Delete marker">${I('trash')}</button></li>`).join('')}</ol>` : '<p class="muted small">Press M while playing to drop a marker.</p>'}
    <button type="button" class="hbtn ghost sm" data-v="chapters"${total >= 30 ? '' : ' disabled title="YouTube chapters need a video of 30 seconds or more"'}>${I('copy')}Copy YouTube chapters</button>
    <p class="muted small">Rendered MP4 files carry these scenes as chapters.</p>`;
}
function drawScene() {
  const s = scene(), box = root.querySelector('#vdScene'); if (!s) { box.innerHTML = ''; return; }
  const field = (k, l, ph = '') => `<label class="fld"><span>${l}</span><input data-s="${k}" value="${esc(s[k] || '')}" placeholder="${esc(ph)}" maxlength="160"></label>`;
  const info = shots.find(x => x.file === s.shot);
  box.innerHTML = `<div class="card-head"><h3>${I('sliders')}Scene ${sel + 1}<small class="muted num">of ${board.scenes.length}</small></h3>
      <div class="row"><button type="button" class="act" data-v="left" aria-label="Move scene earlier"${sel ? '' : ' disabled'}>${I('chevleft')}</button><button type="button" class="act" data-v="right" aria-label="Move scene later"${sel < board.scenes.length - 1 ? '' : ' disabled'}>${I('chevron')}</button></div></div>
    ${sw('data-s="on"', !s.off, 'Include in the video')}
    <label class="fld"><span>Technique</span><select data-s="type">${ST.film.sceneTypes.filter(t => !t.shot && !needsShot(t.id) || shots.length).map(t => `<option value="${t.id}"${t.id === s.type ? ' selected' : ''}>${esc(t.label)}</option>`).join('')}</select></label>
    ${['hook', 'split', 'list', 'stat', 'quote'].includes(s.type) ? field('kicker', 'Small label') : ''}
    ${field('title', 'Headline')}
    ${s.type === 'hook' || s.type === 'quote' ? field('sub', 'Supporting line') : ['list', 'stat', 'montage'].includes(s.type) ? '' : field('detail', 'Supporting line')}
    ${s.type === 'end' ? `<div class="f2">${field('button', 'Button')}${field('url', 'Link shown')}</div>` : ''}
    ${s.type === 'stat' ? `<label class="fld"><span>Number</span><input type="number" min="0" data-s="value" value="${s.value || 0}"></label>` : ''}
    ${s.type === 'list' ? `<label class="fld"><span>Items <small>one per line, up to 5</small></span><textarea rows="5" data-s="items">${esc((s.items || []).join('\n'))}</textarea></label>` : ''}
    <div class="vd-say"><small class="vd-sees" id="vdSees" role="status" hidden></small><label class="fld"><span>Voice-over and captions</span><textarea rows="3" data-s="say" placeholder="What the voice says over this scene">${esc(s.say || '')}</textarea></label>
      <div class="row"><button type="button" class="hbtn ghost sm" data-v="listen"${ST.film.voice.default ? '' : ' disabled'}>${I('playfill')}Listen</button><button type="button" class="hbtn ghost sm" data-v="rewrite" title="Write the line from this scene’s headline">${I('edit')}From headline</button><button type="button" class="hbtn ghost sm" data-v="ailine"${aiBusy || !writer?.ok ? ' disabled' : ''} title="${esc(writer?.ok ? 'Written by your own model from this screen and the app’s details' : writer?.error || '')}">${aiBusy ? '<span class="spinner sm"></span>Writing…' : `${I('ollama')}Ask Ollama`}</button><small class="muted num">${built(sel) && spec.voice.find(v => v.index === sel) ? `${(spec.voice.find(v => v.index === sel).e - spec.voice.find(v => v.index === sel).s).toFixed(1)}s spoken` : `${(s.say || '').split(/\s+/).filter(Boolean).length} words`}</small></div></div>
    <label class="fld"><span>On screen for <small class="num" id="vdDur">${(s.beats * beat()).toFixed(1)}s · ${s.beats} beats</small></span><input type="range" min="2" max="24" step="2" data-s="beats" value="${s.beats}"></label>
    ${needsShot(s.type) ? `<div class="fld"><span>Screen</span><div class="vd-shots">${shots.map(x => `<button type="button" class="${x.file === s.shot ? 'on' : ''}" data-pick="${esc(x.file)}" aria-pressed="${x.file === s.shot}"><img src="${esc(media(x.file))}" alt="${esc(x.file.split('/').pop())}" loading="lazy"></button>`).join('')}</div></div>` : ''}
    ${s.type === 'montage' ? `<div class="fld"><span>Screens in the wall</span><div class="vd-shots">${shots.map(x => `<button type="button" class="${(s.shots || []).includes(x.file) ? 'on' : ''}" data-wall="${esc(x.file)}" aria-pressed="${(s.shots || []).includes(x.file)}"><img src="${esc(media(x.file))}" alt="" loading="lazy"></button>`).join('')}</div></div>` : ''}
    ${['spotlight', 'loupe', 'split', 'glide'].includes(s.type) && info ? `<div class="fld"><span>Camera targets <small>drag on the screen to draw one</small></span>
      <div class="vd-focus" id="vdFocus"><img src="${esc(media(s.shot))}" alt="Screenshot. Drag to mark the area the camera should show." draggable="false">${(s.regions || []).map((r, i) => `<i style="left:${r.x * 100}%;top:${r.y * 100}%;width:${r.w * 100}%;height:${r.h * 100}%"><b>${i + 1}</b></i>`).join('')}</div>
      <div class="row"><button type="button" class="hbtn ghost sm" data-v="autoregion"${info.regions?.length ? '' : ' disabled'}>${I('sparkles')}Find areas</button><button type="button" class="hbtn ghost sm" data-v="clearregion"${s.regions?.length ? '' : ' disabled'}>Clear</button></div></div>` : ''}`;
  showSeen();
}
function drawRender() {
  root.querySelector('#vdRender').innerHTML = `<div class="card-head"><h3>${I('rocket')}Render</h3><small class="muted num">${total ? `${clock(total)} · ${spec.scenes.length} scenes` : ''}</small></div>
    ${voiceControls(ST.film.voice, O)}
    <div class="vd-ai"><span>${I('ollama')}<span><b>Voice-over writer</b><small>${esc(writer?.ok ? `${writer.model} · knows ${app().name} and reads each screen` : writer?.error || 'Checking Ollama…')}</small></span></span>
      ${writer?.ok ? `<button type="button" class="hbtn ghost sm" data-v="aiall"${aiBusy ? ' disabled' : ''}>${aiBusy ? '<span class="spinner sm"></span>Writing…' : `${I('sparkles')}Write all lines`}</button>` : '<a class="hbtn ghost sm" href="#/connectors/ollama">Set up</a>'}</div>
    <div class="vd-shapes" role="group" aria-label="Shapes to render">${SHAPES.map(([v, l]) => `<label><input type="checkbox" data-want="${v}"${v === aspect ? ' checked' : ''}><i style="aspect-ratio:${v.replace(':', '/')}"></i><b>${l}</b><small>${v}</small></label>`).join('')}</div>
    <div class="vd-opts">
      <div class="fld"><span>Quality</span>${seg('data-quality', [['draft', 'Draft'], ['hd', '720p'], ['full', '1080p']], O.quality)}</div>
      <div class="fld"><span>Frame rate</span>${seg('data-fps', [[30, '30'], [60, '60']], O.fps)}</div>
      <label class="fld"><span>Music volume</span><input type="range" min="0" max="1.2" step=".1" value="${O.music}" data-o="music"></label>
      <label class="fld"><span>Sound effects</span><input type="range" min="0" max="1.2" step=".1" value="${O.sfx}" data-o="sfx"></label>
    </div>
    <div class="row vd-checks">${sw('data-o="captions"', O.captions, 'Burn in captions (+ .srt)')}</div>
    <button type="button" class="hbtn primary" data-v="render"${ST.data.tools.ffmpeg && ST.data.tools.chrome ? '' : ' disabled'}>${I('rocket')}Render video</button>
    ${!ST.data.tools.ffmpeg ? `<p class="note lock">${I('info')}<span>Rendering needs FFmpeg. Windows: <code>winget install ffmpeg</code>, then restart the app.</span></p>` : ''}`;
}
export function drawOutputs() {
  if (!root?.querySelector('#vdOut')) return;
  const a = app(), v = a.videos || {}, keys_ = SHAPES.map(s => s[0]).filter(k => v[k]);
  root.querySelector('#vdOut').innerHTML = `<div class="card-head"><h3>${I('video')}Finished videos</h3><a class="hbtn ghost sm" href="/editor/?find=${encodeURIComponent(a.name)}" target="_blank" rel="noopener">${I('film')}Edit Studio</a></div>
    ${keys_.length ? `<div class="vd-outs">${keys_.map(k => { const x = v[k], url = media(x.file, x.at); return `<figure class="vd-out s${k.replace(':', 'x')}"><video src="${esc(url)}"${x.poster ? ` poster="${esc(media(x.poster, x.at))}"` : ''} controls preload="none" playsinline></video><figcaption><b>${esc(SHAPES.find(s => s[0] === k)[1])}</b><small class="num">${x.w}×${x.h} · ${Math.round(x.duration || 0)}s · ${esc(rel(new Date(x.at).toISOString()))}</small></figcaption>
      <div class="row"><a class="act" href="${esc(url)}" download="${esc(a.id)}-${k.replace(':', 'x')}.mp4" aria-label="Download video" title="Download video">${I('download')}</a>${x.srt ? `<a class="act" href="${esc(media(x.srt, x.at))}" download="${esc(a.id)}-${k.replace(':', 'x')}.srt" aria-label="Download captions" title="Captions (.srt)">${I('list')}</a>` : ''}${x.poster ? `<a class="act" href="${esc(media(x.poster, x.at))}" download="${esc(a.id)}-${k.replace(':', 'x')}.jpg" aria-label="Download thumbnail" title="Thumbnail">${I('image')}</a>` : ''}${k === '16:9' ? `<button type="button" class="act" data-use="${esc(x.file)}" aria-label="Use as the app’s video" title="Use as the app’s video on your site">${I('globe')}</button>` : ''}<button type="button" class="act del" data-delfile="${esc(x.file)}" aria-label="Delete video" title="Delete">${I('trash')}</button></div></figure>`; }).join('')}</div>`
      : `<div class="emptystate">${I('film')}<h4>No videos yet</h4><p>Press Render video. A 30-second film takes about a minute or two, and you can keep working.</p></div>`}`;
}

// ---------- preview ----------
const player = () => frame?.contentWindow;
const refresh = debounce(async () => {
  if (!root) return;
  const mine = ++token, busy = root.querySelector('#vdBusy'); busy.hidden = false; pending = true;
  root.querySelector('#vdBusyText').textContent = O.narration ? (ST.film.voice.speak.ok && !ST.film.voice.speak.warm ? 'Warming up the voice (a minute the first time)…' : 'Generating voice-over…') : 'Building preview…';
  try {
    const r = await api('POST', '/api/promo/film/preview', { appId: ST.appId, board, aspect, options: O });
    if (mine !== token || !root) return;
    for (let i = 0; i < 100 && !player()?.booted; i++) await new Promise(ok => setTimeout(ok, 60));
    if (mine !== token || !root) return;
    spec = r.spec; total = r.total; await player().load(spec);
    if (mine !== token || !root) return;
    const was = playing; stop();
    if (r.audio && audio.dataset.src !== r.audio) { audio.dataset.src = r.audio; audio.src = r.audio; audio.playbackRate = rate; }
    if (O.narration) ST.film.voice.speak.warm = true;
    const first = !ready; ready = true; pending = false; time = Math.min(time, total - .05); fit(); seek(first ? (spec.scenes[0]?.start || 0) + 1.4 : time, false);
    tl.draw(); tl.loadWave(r.audio); drawJumpList(); if (side === 'jump' || !root.querySelector('#vdScene :focus')) drawSide(); drawRenderHead();
    if (was) play();
  } catch (e) { if (mine === token) toast(e.message, 'err', 9000); }
  finally { if (mine === token && root) { busy.hidden = true; pending = false; } }
}, 450);
const drawRenderHead = () => { const s = root.querySelector('#vdRender .card-head small'); if (s) s.textContent = `${clock(total)} · ${spec.scenes.length} scenes`; };
function fit() {
  if (!root || !spec) return;
  const wrap = root.querySelector('#vdWrap'), screen = root.querySelector('#vdScreen');
  const scale = Math.min(wrap.clientWidth / spec.w, wrap.clientHeight / spec.h);
  screen.style.width = `${Math.floor(spec.w * scale)}px`; screen.style.height = `${Math.floor(spec.h * scale)}px`;
  Object.assign(frame.style, { width: `${spec.w}px`, height: `${spec.h}px`, transform: `scale(${scale})` });
}
function paint() {
  if (!ready || !root) return;
  player().render(time);
  root.querySelector('#vdTime').textContent = `${precise(time)} / ${precise(total)}`;
  tl.playhead(playing);
}
function seek(t, fromUser = true) { if (!ready) return; time = Math.max(0, Math.min(total - .001, t)); if (fromUser && audio?.src) audio.currentTime = time; if (playing) startedAt = performance.now() - time * 1000 / rate; paint(); }
function play() {
  if (!ready) return;
  if (time >= total - .1) time = 0;
  playing = true; startedAt = performance.now() - time * 1000 / rate;
  if (audio.src) { audio.currentTime = time; audio.playbackRate = rate; audio.play().catch(() => {}); }
  const tick = now => {
    if (!playing || !root) return;
    if (root.offsetParent === null) return stop(); // the tab was left
    const a = audio.src && !audio.paused && audio.readyState > 2 ? audio.currentTime : null;
    time = a ?? (now - startedAt) * rate / 1000;
    const span = loop ? built(sel) : null;
    if (span && time >= span.start + span.dur - .03) { time = span.start; audio.currentTime = time; startedAt = now - time * 1000 / rate; }
    if (time >= total) { time = total - .001; paint(); return stop(); }
    paint(); raf = requestAnimationFrame(tick);
  };
  cancelAnimationFrame(raf); raf = requestAnimationFrame(tick); syncButtons();
}
const toggle = () => (playing ? stop() : play());
function syncButtons() {
  if (!root) return;
  const b = root.querySelector('#vdPlay'); if (b) b.innerHTML = playing ? `<span class="vd-pause" aria-hidden="true"></span>Pause` : `${I('playfill')}Play`;
  root.querySelector('.vd-big')?.classList.toggle('gone', playing || time > .05);
  const u = root.querySelector('[data-v="undo"]'); if (u) { u.disabled = !past.length; root.querySelector('[data-v="redo"]').disabled = !future.length; root.querySelector('[data-v="del"]').disabled = board.scenes.length < 2; root.querySelector('#vdLoop').setAttribute('aria-pressed', loop); }
}
const step = (dir) => { if (!spec) return; const starts = spec.scenes.map(s => s.start); const t = dir > 0 ? starts.find(s => s > time + .05) : [...starts].reverse().find(s => s < time - .6); seek(t ?? (dir > 0 ? total : 0)); const i = spec.scenes.findLast(s => time >= s.start - .01)?.index; if (i != null) select(i, false); };

// ---------- edits, history ----------
const save = debounce(() => { if (board && loadedFor) api('PUT', '/api/promo/storyboard', { appId: loadedFor, board }).catch(e => toast(e.message, 'err')); }, 900);
const remember = debounce(() => { const now = JSON.stringify(board); if (now === committed) return; past.push(committed); if (past.length > 100) past.shift(); future = []; committed = now; syncButtons(); }, 350);
function changed({ line = true, panel = false } = {}) { if (line) tl.draw(); if (panel) drawSide(); remember(); save(); refresh(); syncButtons(); }
function travel(from, to) { remember.flush(); if (!from.length) return; to.push(committed); committed = from.pop(); board = JSON.parse(committed); sel = Math.min(sel, board.scenes.length - 1); drawDirect(); tl.draw(); drawSide(); save(); refresh(); syncButtons(); }
function select(i, jump_ = true) {
  sel = Math.max(0, Math.min(board.scenes.length - 1, i)); tl.draw(); drawSide();
  const s = built(sel); if (jump_ && ready && s) { stop(); seek(s.start + Math.min(s.dur * .62, 2.4)); syncButtons(); }
}
async function generate(seed) {
  stop(); const b = root.querySelector('[data-v="generate"]'); b.disabled = true;
  try {
    const r = await api('POST', '/api/promo/storyboard', { appId: ST.appId, fresh: true, options: { ...O, theme: board.theme, mood: board.mood, accent: board.accent, seed } });
    board = { ...r.board, markers: board.markers || [] }; sel = 0; time = 0; drawDirect(); changed({ panel: true });
    if (O.narration && writer?.ok && writer.auto) aiWrite();
  } catch (e) { toast(e.message, 'err'); }
  if (root) { const x = root.querySelector('[data-v="generate"]'); if (x) x.disabled = false; }
}
function move(from, to) { if (to < 0 || to >= board.scenes.length || from === to) return tl.draw(); const [s] = board.scenes.splice(from, 1); board.scenes.splice(to, 0, s); sel = to; changed({ panel: true }); }
function add() { const sh = shots[0]; board.scenes.splice(sel + 1, 0, { id: uid(), type: sh ? 'split' : 'quote', beats: 6, title: 'New scene', detail: '', say: '', shot: sh?.file || '', regions: [], items: [], shots: [] }); sel++; changed({ panel: true }); }
function duplicate() { board.scenes.splice(sel + 1, 0, { ...structuredClone(scene()), id: uid() }); sel++; changed({ panel: true }); }
function remove() { if (board.scenes.length < 2) return; board.scenes.splice(sel, 1); sel = Math.min(sel, board.scenes.length - 1); changed({ panel: true }); }
function split() {
  const s = spec?.scenes.findLast(x => time >= x.start); if (!s) return;
  const i = s.index, a = board.scenes[i], total_ = a.beats, at = Math.round((time - s.start) / beat() / 2) * 2;
  if (total_ < 4) return toast('That scene is too short to split', 'err');
  const left = Math.max(2, Math.min(total_ - 2, at || Math.round(total_ / 4) * 2)), b = { ...structuredClone(a), id: uid(), beats: total_ - left, say: '' };
  a.beats = left;
  if (a.type === 'list' && a.items.length > 1) { const k = Math.ceil(a.items.length / 2); b.items = a.items.slice(k); a.items = a.items.slice(0, k); }
  if (a.type === 'spotlight' && a.regions.length > 1) { const k = Math.ceil(a.regions.length / 2); b.regions = a.regions.slice(k); a.regions = a.regions.slice(0, k); }
  else if (a.type === 'spotlight') b.type = 'loupe';
  board.scenes.splice(i + 1, 0, b); sel = i + 1; changed({ panel: true }); flash('Split');
}
function onOff() { const s = scene(); if (!s.off && board.scenes.filter(x => !x.off).length < 2) return toast('At least one scene has to stay on', 'err'); s.off = !s.off; changed({ panel: true }); }
async function editMarker(i, t) {
  const m = i == null ? null : board.markers[i], { formBox } = await import('../core.js');
  const r = await formBox(m ? 'Rename marker' : 'Add a marker', '', [{ name: 'label', label: 'Name', value: m?.label || `Marker ${(board.markers || []).length + 1}` }], 'Save');
  if (!r || !root) return;
  if (m) m.label = r.label.trim() || m.label; else board.markers.push({ t: t ?? time, label: r.label.trim() || 'Marker' });
  board.markers.sort((a, b) => a.t - b.t); marksChanged();
}
function marksChanged() { tl.draw(); drawJumpList(); if (side === 'jump') drawSide(); remember(); save(); }
const addMarker = () => { board.markers.push({ t: time, label: `Marker ${board.markers.length + 1}` }); board.markers.sort((a, b) => a.t - b.t); marksChanged(); flash(`Marker at ${precise(time)}`); };
function setRate(r) { rate = r; if (audio) audio.playbackRate = r; if (playing) startedAt = performance.now() - time * 1000 / rate; root.querySelector('#vdRate').value = r; flash(`${r}×`); }
function fullscreen() { const el = root.querySelector('#vdStage'); document.fullscreenElement ? document.exitFullscreen() : el.requestFullscreen?.().then(() => setTimeout(fit, 80)); }
function shortcuts() {
  const d = document.createElement('dialog'); d.className = 'modal small'; d.setAttribute('aria-label', 'Video shortcuts');
  d.innerHTML = `<div class="m-in"><h3>${I('keyboard')}Video shortcuts</h3><div class="keys">${KEYS.map(([k, t]) => `<div><span>${esc(t)}</span><span><kbd>${esc(k)}</kbd></span></div>`).join('')}</div><div class="m-foot"><button type="button" class="hbtn primary">Done</button></div></div>`;
  document.body.append(d); d.showModal(); d.onclick = e => { if (e.target === d || e.target.closest('button')) d.close(); }; d.onclose = () => d.remove();
}

function bind() {
  root.onclick = async e => {
    const b = e.target.closest('button'); if (!b || !board) return;
    const d = b.dataset;
    if (d.v === 'play') return toggle();
    if (d.v === 'prev') return step(-1); if (d.v === 'next') return step(1);
    if (d.v === 'loop') { loop = !loop; syncButtons(); return flash(loop ? 'Repeating this scene' : 'Repeat off'); }
    if (d.v === 'full') return fullscreen(); if (d.v === 'keys') return shortcuts();
    if (d.v === 'undo') return travel(past, future); if (d.v === 'redo') return travel(future, past);
    if (d.v === 'split') return split(); if (d.v === 'dup') return duplicate(); if (d.v === 'del') return remove(); if (d.v === 'toggle') return onOff(); if (d.v === 'marker') return addMarker();
    if (d.side) { side = d.side; return drawSide(); }
    if (d.t != null) { if (d.chapter != null) select(+d.chapter, false); stop(); return seek(+d.t + .05); }
    if (d.renmark != null) return editMarker(+d.renmark);
    if (d.delmark != null) { board.markers.splice(+d.delmark, 1); return marksChanged(); }
    if (d.v === 'chapters') return copyText(youtubeChapters(), 'Chapters copied. Paste them into the video description.');
    if (d.v === 'listen') return previewVoice(scene().say, O, b);
    if (d.v === 'rewrite') { const s = scene(); s.say = [s.title, s.type === 'hook' ? s.sub : s.detail].filter(Boolean).map(t => t.replace(/…/g, '').replace(/[.!?]?$/, '.')).join(' '); return changed({ line: false, panel: true }); }
    if (d.v === 'voicesample') return previewVoice(`Meet ${app().name}. ${app().tagline || ''}`.slice(0, 180), O, b);
    if (d.v === 'voiceinstall') return installVoice(b);
    if (d.v === 'ailine') return aiWrite([sel]);
    if (d.v === 'aiall') { if (board.scenes.some(s => s.say) && !(await confirmBox('Rewrite every line?', 'Ollama writes the voice-over for all scenes. Undo brings your lines back.', 'Write all', false))) return; return aiWrite(); }
    if (d.dir) { O.direction = d.dir; if (d.dir === 'teaser' && O.seconds > 21) O.seconds = 15; savePrefs(); drawDirect(); return generate(board.seed); }
    if (d.theme) { board.theme = O.theme = d.theme; savePrefs(); drawDirect(); return changed({ line: false }); }
    if (d.mood) { const m = ST.film.moods.find(x => x.id === d.mood); board.mood = O.mood = m.id; board.bpm = m.bpm; savePrefs(); drawDirect(); return changed({ panel: true }); }
    if (d.shape) { aspect = d.shape; drawShape(); drawRender(); return refresh.flush(); }
    if (d.quality) { O.quality = d.quality; savePrefs(); return drawRender(); }
    if (d.fps) { O.fps = +d.fps; savePrefs(); return drawRender(); }
    if (d.pick) { const s = scene(); s.shot = d.pick; s.regions = (shots.find(x => x.file === d.pick)?.regions || []).slice(0, s.type === 'spotlight' ? 2 : 1).map(({ x, y, w, h }) => ({ x, y, w, h })); return changed({ panel: true }); }
    if (d.wall) { const s = scene(), set = new Set(s.shots || []); set.has(d.wall) ? set.delete(d.wall) : set.add(d.wall); s.shots = [...set].slice(0, 9); return changed({ panel: true }); }
    if (d.v === 'generate') { if (!(await confirmBox('Write a new storyboard?', 'Your edits to the scenes are replaced. Undo brings them back.', 'Write new', false))) return; return generate(board.seed); }
    if (d.v === 'another') return generate((board.seed || 7) + 1 + Math.floor(Math.random() * 997));
    if (d.v === 'autoaccent') { board.accent = ''; drawDirect(); return changed({ line: false }); }
    if (d.v === 'left') return move(sel, sel - 1);
    if (d.v === 'right') return move(sel, sel + 1);
    if (d.v === 'autoregion') { const s = scene(); s.regions = (shots.find(x => x.file === s.shot)?.regions || []).slice(0, s.type === 'spotlight' ? 3 : 1).map(({ x, y, w, h }) => ({ x, y, w, h })); return changed({ line: false, panel: true }); }
    if (d.v === 'clearregion') { scene().regions = []; return changed({ line: false, panel: true }); }
    if (d.v === 'render') {
      const aspects = [...root.querySelectorAll('[data-want]:checked')].map(x => x.dataset.want);
      if (!aspects.length) return toast('Tick at least one shape to render', 'err');
      save.cancel(); b.disabled = true;
      try { const r = await api('POST', '/api/promo/video', { appId: ST.appId, aspects, board, options: O }); addJob(r.job); toast('Rendering. It runs in the background.', 'info'); }
      catch (x) { toast(x.message, 'err', 9000); }
      b.disabled = false; return;
    }
    if (d.use) {
      if (!(await confirmBox('Use this as the app’s video?', 'It’s copied into the app and shows on its page after you publish.', 'Use it', false))) return;
      try { await api('POST', '/api/promo/use', { appId: ST.appId, file: d.use, as: 'video' }); toast('Set as the app’s video. Publish when you’re ready.'); } catch (x) { toast(x.message, 'err'); } return;
    }
    if (d.delfile) {
      if (!(await confirmBox('Delete this video?', 'Anything you already used it for keeps its copy.'))) return;
      try { ST.data = await api('POST', '/api/promo/file/delete', { appId: ST.appId, file: d.delfile }); drawOutputs(); } catch (x) { toast(x.message, 'err'); }
    }
  };
  root.oninput = e => {
    const t = e.target;
    if (t.id === 'vdZoom') return tl.setZoom(+t.value);
    const k = t.dataset.s;
    if (k) {
      const s = scene();
      if (k === 'type' || k === 'on') return;
      if (k === 'beats') { s.beats = +t.value; root.querySelector('#vdDur').textContent = `${(s.beats * beat()).toFixed(1)}s · ${s.beats} beats`; return changed(); }
      if (k === 'items') s.items = t.value.split('\n').map(x => x.trim()).filter(Boolean).slice(0, 5);
      else if (k === 'value') s.value = +t.value || 0;
      else s[k] = t.value;
      if (k === 'say' && O.narration) { remember(); save(); refresh.cancel(); return; } // speak the finished line, not every keystroke
      return changed({ line: k === 'title' });
    }
    if (t.dataset.o === 'seconds') { O.seconds = +t.value; root.querySelector('#vdSecs').textContent = `about ${O.seconds}s`; savePrefs(); }
    if (t.dataset.o === 'rate') { O.rate = +t.value; const out = t.closest('label').querySelector('small'); if (out) out.textContent = `${(+t.value).toFixed(2)}×`; }
  };
  root.onchange = e => {
    const t = e.target, o = t.dataset.o;
    if (t.id === 'vdRate') return setRate(+t.value);
    if (t.dataset.s === 'say') { if (O.narration) refresh(); return; }
    if (t.dataset.s === 'on') return onOff();
    if (t.dataset.s === 'type') { const s = scene(); s.type = t.value; if (needsShot(s.type) && !s.shot) s.shot = shots[0]?.file || ''; if (s.type === 'montage' && !s.shots?.length) s.shots = shots.slice(0, 6).map(x => x.file); if (s.type === 'list' && !s.items?.length) s.items = (app().features || []).slice(0, 4); if (['spotlight', 'loupe'].includes(s.type) && !s.regions?.length) s.regions = (shots.find(x => x.file === s.shot)?.regions || []).slice(0, 1).map(({ x, y, w, h }) => ({ x, y, w, h })); return changed({ panel: true }); }
    if (!o) return;
    if (o === 'accent') { board.accent = t.value; drawDirect(); return changed({ line: false }); }
    if (o === 'seconds') return generate(board.seed);
    O[o] = t.type === 'checkbox' ? t.checked : t.type === 'range' ? +t.value : t.value;
    savePrefs();
    if (o === 'narration') { drawRender(); if (O.narration && ST.film.voice.speak.ok) api('POST', '/api/promo/voice/warm').catch(() => {}); }
    refresh();
  };
  root.querySelector('#vdJump').addEventListener('submit', e => { e.preventDefault(); const i = root.querySelector('#vdJumpIn'); jump(i.value); i.select(); });
  // draw a camera target directly on the screenshot
  root.onpointerdown = e => {
    const box = e.target.closest('#vdFocus'); if (!box || e.button) return;
    e.preventDefault(); const r = box.getBoundingClientRect(), pt = ev => [Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width)), Math.max(0, Math.min(1, (ev.clientY - r.top) / r.height))];
    const [x0, y0] = pt(e), ghost = document.createElement('i'); box.append(ghost); box.setPointerCapture(e.pointerId); region = null;
    const moveFn = ev => { const [x1, y1] = pt(ev); region = { x: Math.min(x0, x1), y: Math.min(y0, y1), w: Math.abs(x1 - x0), h: Math.abs(y1 - y0) }; Object.assign(ghost.style, { left: region.x * 100 + '%', top: region.y * 100 + '%', width: region.w * 100 + '%', height: region.h * 100 + '%' }); };
    const up = () => { box.removeEventListener('pointermove', moveFn); box.removeEventListener('pointerup', up); box.removeEventListener('pointercancel', up); ghost.remove();
      if (region && region.w > .04 && region.h > .04) { const s = scene(); s.regions = s.type === 'spotlight' ? [...(s.regions || []), region].slice(-3) : [region]; changed({ line: false, panel: true }); } };
    box.addEventListener('pointermove', moveFn); box.addEventListener('pointerup', up); box.addEventListener('pointercancel', up);
  };
  // keyboard, captured ahead of the hub's own single-key shortcuts while the director is on screen
  keys = new AbortController();
  addEventListener('keydown', e => {
    if (!root || root.offsetParent === null || !board || document.querySelector('dialog[open]') || document.getElementById('editor')?.hidden === false) return;
    const el = e.target, typing = /^(TEXTAREA|SELECT)$/.test(el.tagName) || el.tagName === 'INPUT' && !['range', 'checkbox'].includes(el.type) || el.isContentEditable;
    const mod = e.ctrlKey || e.metaKey, k = e.key, eat = () => { e.preventDefault(); e.stopImmediatePropagation(); };
    if (typing) return;
    if (mod) { const c = k.toLowerCase(); if (c === 'z') { eat(); return e.shiftKey ? travel(future, past) : travel(past, future); } if (c === 'y') { eat(); return travel(future, past); } if (c === 'd') { eat(); return duplicate(); } return; }
    if (e.altKey) { if (k === 'ArrowLeft' || k === 'ArrowRight') { eat(); move(sel, sel + (k === 'ArrowLeft' ? -1 : 1)); root.querySelector('.tl-clip.on')?.focus(); } return; }
    if (el.type === 'range' && /^(Arrow|Home|End|Page)/.test(k)) return;
    if ((k === ' ' && !el.closest?.('button, a, video, summary')) || k === 'k' || k === 'K') { eat(); return toggle(); }
    if (k === 'Enter' && el.classList?.contains('tl-clip')) { eat(); return select(+el.dataset.i); }
    if (el.classList?.contains('tl-clip') && (k === 'ArrowLeft' || k === 'ArrowRight')) { eat(); select(sel + (k === 'ArrowLeft' ? -1 : 1)); return root.querySelector('.tl-clip.on')?.focus(); }
    const go = t => { eat(); seek(t); syncButtons(); };
    if (el.closest?.('[role=radiogroup], .seg, [role=tablist]') && k.startsWith('Arrow')) return;
    if (k === 'j' || k === 'J') return go(time - 10); if (k === 'l' || k === 'L') return go(time + 10);
    if (k === 'ArrowLeft') return go(time - 5); if (k === 'ArrowRight') return go(time + 5);
    if (k === ',') { stop(); return go(time - 1 / O.fps); } if (k === '.') { stop(); return go(time + 1 / O.fps); }
    if (k === 'Home') return go(0); if (k === 'End') return go(total);
    if (/^[0-9]$/.test(k)) return go(total * +k / 10);
    if (k === '[') { eat(); return step(-1); } if (k === ']') { eat(); return step(1); }
    if (k === '<') { eat(); return setRate(RATES[Math.max(0, RATES.indexOf(rate) - 1)]); } if (k === '>') { eat(); return setRate(RATES[Math.min(RATES.length - 1, RATES.indexOf(rate) + 1)]); }
    if (k === '/') { eat(); return root.querySelector('#vdJumpIn').focus(); }
    const c = k.toLowerCase();
    if (c === 's') { eat(); return split(); } if (c === 'm') { eat(); return addMarker(); } if (c === 'x') { eat(); return onOff(); }
    if (c === 'r') { eat(); loop = !loop; syncButtons(); return flash(loop ? 'Repeating this scene' : 'Repeat off'); }
    if (c === 'f') { eat(); return fullscreen(); } if (c === 'n') { eat(); return add(); }
    if (k === 'Delete') { eat(); return remove(); }
  }, { capture: true, signal: keys.signal });
  addEventListener('fullscreenchange', () => setTimeout(() => { fit(); tl?.draw(); }, 80), { signal: keys.signal });
}
export const rendering = () => ST.data.jobs.some(j => j.appId === ST.appId && j.kind === 'video' && active(j));
