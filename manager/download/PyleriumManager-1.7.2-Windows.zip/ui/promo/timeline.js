// The Video Director's timeline: a time ruler you can scrub, a playhead, scene clips you can trim, reorder and select,
// a narration track, the soundtrack's waveform and markers. It only draws and reports gestures; video.js owns the data.
import { esc } from '../core.js';
import { I, media, clock } from './common.js';

export const precise = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}.${String(Math.floor((s % 1) * 10))}`;
const STEPS = [.5, 1, 2, 5, 10, 15, 30, 60];

export function createTimeline(host, api) {
  // api: board(), spec(), time(), sel(), seek(t, scrubbing), select(i, jump), trim(i, beats), move(from, to), add(), marker(i, label), removeMarker(i)
  let zoom = 1, peaks = null, peaksFor = '', drag = null, waveJob = 0, frame = 0;
  const ac = new AbortController(), on = (t, e, f, o = {}) => t.addEventListener(e, f, { ...o, signal: ac.signal });
  host.innerHTML = `<div class="tl">
    <div class="tl-labels" aria-hidden="true"><span class="tl-r"></span><span style="height:78px">Scenes</span><span>Voice</span><span>Sound</span></div>
    <div class="tl-scroll" tabindex="-1"><div class="tl-body">
      <div class="tl-ruler" role="slider" tabindex="0" aria-label="Playhead" aria-valuemin="0"></div>
      <div class="tl-clips" role="listbox" aria-label="Scenes" aria-orientation="horizontal"></div>
      <div class="tl-voice"></div>
      <canvas class="tl-wave" height="68" aria-hidden="true"></canvas>
      <div class="tl-marks"></div><div class="tl-drop" hidden></div>
      <div class="tl-head" aria-hidden="true"><i></i></div><div class="tl-hover" aria-hidden="true" hidden><span></span></div>
    </div></div>
  </div>`;
  const $ = s => host.querySelector(s), scroll = $('.tl-scroll'), body = $('.tl-body'), ruler = $('.tl-ruler'), clips = $('.tl-clips'), voice = $('.tl-voice'), wave = $('.tl-wave'), marks = $('.tl-marks'), head = $('.tl-head'), hover = $('.tl-hover'), drop = $('.tl-drop');
  const beat = () => 60 / (api.board().bpm || 100);
  // every storyboard scene gets a slot, including ones switched off (drawn narrow and greyed)
  function layout() {
    const board = api.board(), spec = api.spec(), built = new Map((spec?.scenes || []).map(s => [s.index, s]));
    let at = 0;
    return board.scenes.map((s, i) => {
      const b = built.get(i), dur = s.off ? 0 : drag?.kind === 'trim' && drag.i === i ? drag.beats * beat() : b ? Math.max(s.beats * beat(), b.dur) : s.beats * beat();
      const slot = { i, s, start: at, dur, stretched: b && b.dur > s.beats * beat() + .05 };
      at += dur; return slot;
    });
  }
  const total = () => Math.max(1, layout().reduce((n, s) => n + s.dur, 0));
  const pps = () => Math.max(8, (scroll.clientWidth - 24) / total() * zoom);
  const x = t => 8 + t * pps();
  const at = e => { const r = body.getBoundingClientRect(), k = r.width / (body.offsetWidth || 1); return Math.max(0, Math.min(total(), ((e.clientX - r.left) / k - 8) / pps())); };

  function draw() {
    if (!host.isConnected) return;
    const L = layout(), T = total(), p = pps(), width = Math.max(scroll.clientWidth, x(T) + 56);
    body.style.width = width + 'px';
    const step = STEPS.find(s => s * p >= 62) || 60;
    let r = '';
    for (let t = 0; t <= T + .001; t += step) r += `<span style="left:${x(t)}px">${step < 1 ? precise(t) : clock(t)}</span>`;
    if (step * p >= 90) for (let t = 0; t < T; t += step / 5) r += `<i style="left:${x(t)}px"></i>`;
    ruler.innerHTML = r; ruler.setAttribute('aria-valuemax', T.toFixed(1));
    const focus = clips.contains(document.activeElement);
    let off = 0;
    clips.innerHTML = L.map(({ i, s, start, dur, stretched }) => {
      const w = s.off ? 26 : Math.max(22, dur * p - 3), left = x(start) + (s.off ? off++ * 2 : 0);
      return `<div class="tl-clip${i === api.sel() ? ' on' : ''}${s.off ? ' off' : ''}" role="option" tabindex="${i === api.sel() ? 0 : -1}" aria-selected="${i === api.sel()}" data-i="${i}" style="left:${left}px;width:${w}px" title="${esc(s.title || api.typeName(s.type))} · ${(s.beats * beat()).toFixed(1)}s${s.off ? ' · switched off' : ''}">
        ${s.shot ? `<img src="${esc(media(s.shot))}" alt="" loading="lazy" draggable="false">` : ''}<span><b>${esc(s.title || api.typeName(s.type))}</b><small>${esc(api.typeName(s.type))} · ${s.off ? 'off' : (dur).toFixed(1) + 's'}</small></span>
        ${stretched ? '<em title="Lengthened to fit the voice-over">voice</em>' : ''}${s.off ? '' : '<i class="tl-trim" data-trim="1" aria-hidden="true"></i>'}</div>`;
    }).join('') + `<button type="button" class="tl-add" data-add style="left:${x(T) + 8}px" aria-label="Add a scene after the selected one">${I('plus')}</button>`;
    if (focus) clips.querySelector('.tl-clip.on')?.focus({ preventScroll: true });
    voice.innerHTML = (api.spec()?.voice || []).map(v => `<button type="button" style="left:${x(v.s)}px;width:${Math.max(8, (v.e - v.s) * p)}px" data-seek="${v.s}" title="${esc(v.text)}"><span>${esc(v.text)}</span></button>`).join('') || `<p>${api.narrating() ? 'Generating the voice-over…' : 'Voice-over is off. Switch it on under Render.'}</p>`;
    marks.innerHTML = (api.board().markers || []).map((m, i) => `<button type="button" class="tl-mark" data-mark="${i}" style="left:${x(Math.min(m.t, T))}px" aria-label="Marker ${esc(m.label)} at ${precise(m.t)}"><span>${esc(m.label)}</span></button>`).join('');
    drawWave(); playhead();
  }
  function drawWave() {
    cancelAnimationFrame(frame);
    frame = requestAnimationFrame(() => {
      const W = Math.min(8000, body.offsetWidth), g = wave.getContext('2d');
      wave.width = W; wave.style.width = body.offsetWidth + 'px'; g.clearRect(0, 0, W, 68);
      if (!peaks) return;
      const k = W / body.offsetWidth, p = pps(), css = getComputedStyle(host).getPropertyValue('--act').trim() || '#2DD4BF';
      g.fillStyle = css; g.globalAlpha = .75;
      for (let px = Math.floor(x(0) * k); px < x(peaks.duration) * k && px < W; px += 3) {
        const t = (px / k - 8) / p, j = Math.floor(t / peaks.duration * peaks.data.length), v = peaks.data[Math.max(0, Math.min(peaks.data.length - 1, j))] || 0, h = Math.max(1.5, v * 30);
        g.fillRect(px, 34 - h, 2, h * 2);
      }
    });
  }
  async function loadWave(url) {
    if (url === peaksFor) return; peaksFor = url; const job = ++waveJob; peaks = null;
    if (!url) return drawWave();
    try {
      const data = await (await fetch(url)).arrayBuffer(), ctx = new OfflineAudioContext(1, 1, 22050), audio = await ctx.decodeAudioData(data);
      if (job !== waveJob) return;
      const ch = audio.getChannelData(0), n = 1600, size = Math.max(1, Math.floor(ch.length / n)), out = new Float32Array(n); let max = .01;
      for (let i = 0; i < n; i++) { let m = 0; for (let k = i * size; k < (i + 1) * size && k < ch.length; k += 4) m = Math.max(m, Math.abs(ch[k])); out[i] = m; max = Math.max(max, m); }
      peaks = { data: out.map(v => v / max), duration: audio.duration }; drawWave();
    } catch { /* the waveform is a nicety: the preview still plays */ }
  }
  // maps the film's clock (switched-off scenes removed) onto the timeline, which is the same thing since they have no width
  function playhead(follow = false) {
    const px = x(api.time());
    head.style.transform = `translateX(${px}px)`; head.querySelector('i').textContent = precise(api.time());
    ruler.setAttribute('aria-valuenow', api.time().toFixed(1)); ruler.setAttribute('aria-valuetext', precise(api.time()));
    const live = layout().findLast(s => !s.s.off && api.time() >= s.start - .01)?.i;
    clips.querySelectorAll('.tl-clip').forEach(c => c.classList.toggle('live', +c.dataset.i === live));
    if (follow && !drag && (px > scroll.scrollLeft + scroll.clientWidth - 40 || px < scroll.scrollLeft)) scroll.scrollLeft = Math.max(0, px - 60);
  }
  function setZoom(z, anchor) {
    const t = anchor ?? api.time(), before = x(t) - scroll.scrollLeft;
    zoom = Math.max(1, Math.min(12, z)); draw(); scroll.scrollLeft = x(t) - before;
    api.zoomed?.(zoom);
  }

  on(body, 'pointerdown', e => {
    if (e.button) return;
    const trim = e.target.closest('[data-trim]'), clip = e.target.closest('.tl-clip'), seekAt = e.target.closest('[data-seek]'), mark = e.target.closest('[data-mark]');
    if (e.target.closest('[data-add]')) return;
    if (seekAt) return api.seek(+seekAt.dataset.seek);
    if (mark) return api.seek(api.board().markers[+mark.dataset.mark].t);
    body.setPointerCapture(e.pointerId);
    if (trim) { const i = +clip.dataset.i, s = layout()[i]; drag = { kind: 'trim', i, start: s.start, beats: api.board().scenes[i].beats }; e.preventDefault(); return; }
    if (clip) { drag = { kind: 'clip', i: +clip.dataset.i, sx: e.clientX, moved: false }; return; }
    drag = { kind: 'scrub' }; api.seek(at(e), true);
  });
  on(body, 'pointermove', e => {
    const t = at(e);
    if (!drag) { hover.hidden = !e.target.closest('.tl-ruler'); if (!hover.hidden) { hover.style.transform = `translateX(${x(t)}px)`; hover.firstChild.textContent = precise(t); } return; }
    if (drag.kind === 'scrub') api.seek(t, true);
    else if (drag.kind === 'trim') { const beats = Math.max(2, Math.min(24, Math.round((t - drag.start) / beat() / 2) * 2)); if (beats !== drag.beats) { drag.beats = beats; draw(); } }
    else if (drag.kind === 'clip') {
      if (!drag.moved && Math.abs(e.clientX - drag.sx) < 6) return;
      drag.moved = true; const L = layout(); let to = L.findIndex(s => t < s.start + s.dur / 2); if (to < 0) to = L.length;
      drag.to = to; drop.hidden = false; drop.style.transform = `translateX(${x(to < L.length ? L[to].start : total()) - 2}px)`;
    }
  });
  const release = () => {
    const d = drag; drag = null; drop.hidden = true; if (!d) return;
    if (d.kind === 'trim') api.trim(d.i, d.beats);
    else if (d.kind === 'clip') { if (d.moved && d.to != null) api.move(d.i, d.to > d.i ? d.to - 1 : d.to); else api.select(d.i, true); }
    else api.scrubEnd?.();
  };
  on(body, 'pointerup', release); on(body, 'pointercancel', release);
  on(body, 'pointerleave', () => { hover.hidden = true; });
  on(body, 'click', e => { if (e.target.closest('[data-add]')) api.add(); });
  on(body, 'dblclick', e => { const m = e.target.closest('[data-mark]'); if (m) api.marker(+m.dataset.mark); else if (e.target.closest('.tl-ruler')) api.marker(null, at(e)); });
  on(scroll, 'wheel', e => { if (e.ctrlKey || e.metaKey) { e.preventDefault(); setZoom(zoom * Math.exp(-e.deltaY * .002), at(e)); } else if (!e.shiftKey && Math.abs(e.deltaY) > Math.abs(e.deltaX)) { if (scroll.scrollWidth > scroll.clientWidth + 2) { e.preventDefault(); scroll.scrollLeft += e.deltaY; } } }, { passive: false });
  const ro = new ResizeObserver(() => draw()); ro.observe(scroll);
  return { draw, playhead, loadWave, setZoom, zoom: () => zoom, destroy() { ac.abort(); ro.disconnect(); cancelAnimationFrame(frame); waveJob++; host.replaceChildren(); } };
}
