// Launch kit (ready-to-post words + one download of everything) and the Library (all media, hand-made promos from
// ../promo, and capturing real screens from a running app or website).
import { S, esc, api, toast, confirmBox, rel } from '../core.js';
import { ST, app, I, media, bytes, copyText, download } from './common.js';
import * as Capture from './capture.js';

let root = null, mode = 'copy', lib = null, folder = '', filter = 'all', seq = 0;
export function unmount() { seq++; if (root) root.onclick = root.oninput = root.onchange = null; Capture.unmount(); root = null; }
export async function mount(el, which) {
  root = el; mode = which; const mine = ++seq;
  Capture.unmount(); root.onclick = onClick; root.oninput = onInput; root.onchange = onChange;
  root.innerHTML = `<div class="card lv-loading"><span class="spinner"></span>Loading…</div>`;
  try {
    if (mode === 'copy') { const { copy } = await api('POST', '/api/promo/copy-kit', { appId: ST.appId }); if (mine === seq) drawCopy(copy); }
    else { folder = ''; await loadLib(); }
  } catch (e) { if (mine === seq) root.innerHTML = `<div class="card"><p class="bad">${esc(e.message)}</p></div>`; }
}
export async function update() { if (root && mode === 'library') { Capture.refresh(); await loadLib().catch(() => {}); } }

// ---------- words ----------
function drawCopy(list) {
  const a = app(), images = Object.keys(a.files).length, videos = Object.keys(a.videos || {}).length;
  root.innerHTML = `<section class="card lk-pack"><div><h3>${I('package')}Launch kit</h3><p class="sub">One zip with every saved image (${images}), video (${videos}), your icon, screenshots, these posts and a fact sheet.</p></div><button type="button" class="hbtn primary" data-pack>${I('download')}Download launch kit</button></section>
    <div class="lk-grid">${list.map(c => `<article class="card lk-post" data-id="${esc(c.id)}"><div class="card-head"><h3>${esc(c.channel)}</h3><small class="num lk-count${c.text.length > c.limit ? ' over' : ''}">${c.text.length} / ${c.limit}</small></div>
      <textarea rows="${Math.min(12, Math.max(2, c.text.split('\n').length + Math.floor(c.text.length / 90)))}" data-limit="${c.limit}" aria-label="${esc(c.channel)} text">${esc(c.text)}</textarea>
      <div class="row"><button type="button" class="hbtn ghost sm" data-copy>${I('copy')}Copy</button></div></article>`).join('')}</div>
    <p class="muted small">Written from this app’s own tagline, features, price and release notes. Edit before posting; edits here aren’t saved.</p>`;
}

// ---------- library ----------
async function loadLib() { const mine = seq; const r = await api('POST', '/api/promo/library', { appId: ST.appId, folder }); if (mine !== seq || !root) return; lib = r; folder = r.folder; drawLib(); }
const kind = f => (/\.(mp4|webm)$/i.test(f) ? 'video' : /\.(png|jpe?g|webp|gif|svg|ico)$/i.test(f) ? 'image' : 'file');
function tile(f, external) {
  const url = external ? '' : media(f.file, Math.round(f.at)), k = kind(f.name);
  return `<figure class="lb-tile" data-file="${esc(f.file)}" data-ext="${external ? 1 : ''}">
    <div class="lb-view">${external ? `<span class="lb-ph">${I(k === 'video' ? 'film' : k === 'image' ? 'image' : 'package')}</span>` : k === 'image' ? `<img src="${esc(url)}" alt="" loading="lazy">` : k === 'video' ? `<video src="${esc(url)}" controls preload="none"></video>` : `<span class="lb-ph">${I('package')}</span>`}${f.used ? '<em>In use</em>' : ''}</div>
    <figcaption><b title="${esc(f.name)}">${esc(f.name)}</b><small class="num">${f.w ? `${f.w}×${f.h} · ` : ''}${bytes(f.size)} · ${esc(rel(new Date(f.at).toISOString()))}</small></figcaption>
    <div class="row">${external ? `<button type="button" class="hbtn ghost sm" data-act="import">${I('plus')}Import</button>` : `<a class="act" href="${esc(url)}" download="${esc(f.name)}" aria-label="Download" title="Download">${I('download')}</a>`}
      ${k === 'image' && !/\.(svg|ico)$/i.test(f.name) ? `<button type="button" class="act" data-act="screenshot" aria-label="Add to screenshots" title="Add to screenshots">${I('layers')}</button><button type="button" class="act" data-act="cover" aria-label="Use as cover" title="Use as cover">${I('image')}</button>` : ''}
      ${k === 'video' ? `<button type="button" class="act" data-act="video" aria-label="Use as the app’s video" title="Use as the app’s video">${I('globe')}</button>` : ''}
      ${external ? '' : `<button type="button" class="act del" data-act="delete" aria-label="Delete" title="Delete"${f.used ? ' disabled' : ''}>${I('trash')}</button>`}</div></figure>`;
}
function drawLib() {
  const a = app(), own = lib.own.filter(f => filter === 'all' || kind(f.name) === filter);
  let box = root.querySelector('#lbMedia');
  if (!box) {
    root.innerHTML = '<div id="lbCapture" class="lb-slot"></div><div id="lbMedia" class="lb-slot"></div>';
    Capture.mount(root.querySelector('#lbCapture')); box = root.querySelector('#lbMedia');
  }
  box.innerHTML = `<section class="card"><div class="card-head"><h3>${I('folder')}${esc(a.name)}’s media <small class="muted num">${lib.own.length} files</small></h3><div class="seg" role="group" aria-label="Show">${[['all', 'All'], ['image', 'Images'], ['video', 'Videos']].map(([v, l]) => `<button type="button" data-filter="${v}" class="${filter === v ? 'on' : ''}">${l}</button>`).join('')}</div></div>
      ${own.length ? `<div class="lb-grid">${own.map(f => tile(f)).join('')}</div>` : `<div class="emptystate">${I('image')}<h4>Nothing here yet</h4><p>Render images or videos, capture screens, or import a hand-made promo below.</p></div>`}</section>
    ${lib.folders.length ? `<section class="card"><div class="card-head"><h3>${I('film')}Hand-made promos <small class="muted">from the promo folder</small></h3>${lib.folders.length ? `<select data-folder aria-label="Promo folder"><option value="">Choose a folder…</option>${lib.folders.map(f => `<option${f === folder ? ' selected' : ''}>${esc(f)}</option>`).join('')}</select>` : ''}</div>
      ${lib.external.length ? `<div class="lb-grid small">${lib.external.map(f => tile(f, true)).join('')}</div>` : '<p class="muted">Pick a folder to see the promos in it.</p>'}</section>` : ''}`;
}
async function onClick(e) {
  if (e.target.closest('#lbCapture')) return;
  const b = e.target.closest('button'); if (!b) return;
  try {
    if (b.dataset.copy != null) return copyText(b.closest('.lk-post').querySelector('textarea').value);
    if (b.dataset.pack != null) { b.disabled = true; const r = await api('POST', '/api/promo/pack', { appId: ST.appId }); b.disabled = false; download(media(r.file, r.at), `${ST.appId}-launch-kit.zip`); return toast(`Launch kit ready: ${r.files} files`); }
    if (b.dataset.filter) { filter = b.dataset.filter; return drawLib(); }
    const act = b.dataset.act; if (!act) return;
    const t = b.closest('.lb-tile'), external = !!t.dataset.ext, file = t.dataset.file;
    if (act === 'delete' && !(await confirmBox('Delete this file?', file.split('/').pop()))) return;
    const r = await api('POST', '/api/promo/library/file', { appId: ST.appId, file, action: act, ...(external ? { folder } : {}) });
    if (r.app) { const i = S.apps.findIndex(x => x.id === ST.appId); if (i >= 0) S.apps[i] = r.app; }
    toast({ delete: 'Deleted', import: 'Imported', screenshot: 'Added to screenshots', cover: 'Set as cover', video: 'Set as the app’s video' }[act]);
    await loadLib();
  } catch (x) { b.disabled = false; toast(x.message, 'err', 8000); }
}
function onInput(e) { const t = e.target; if (t.tagName !== 'TEXTAREA' || !t.dataset.limit) return; const c = t.closest('.lk-post').querySelector('.lk-count'); c.textContent = `${t.value.length} / ${t.dataset.limit}`; c.classList.toggle('over', t.value.length > +t.dataset.limit); }
function onChange(e) { if (e.target.closest('#lbCapture')) return; if (e.target.matches('[data-folder]')) { folder = e.target.value; loadLib().catch(x => toast(x.message, 'err')); } }
