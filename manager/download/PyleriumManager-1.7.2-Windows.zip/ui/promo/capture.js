// Library → Capture: the form for photographing a running app or website (elements, screens, full pages, original
// pictures; one page or a deep scan) and the gallery of what each scan found. Engine: promo/lib/capture.mjs.
import { S, esc, api, toast, confirmBox, rel } from '../core.js';
import { ST, app, I, media, bytes, download, addJob, active, sw } from './common.js';

const PAGE = 96;
const MODES = [['elements', 'Page elements', 'Heroes, cards, sections, tables and media, cut out one by one'], ['screens', 'Screens', 'What fits on the screen, scrolling down'], ['full', 'Full pages', 'Each page as one tall picture'], ['images', 'Original pictures', 'The image files the page uses, at full size']];
const VIEWS = [['desktop', 'Desktop'], ['laptop', 'Laptop'], ['tablet', 'Tablet'], ['phone', 'Phone']];
const KINDS = { hero: 'Heroes', screen: 'Screens', full: 'Full pages', feature: 'Features', card: 'Cards', pricing: 'Pricing', gallery: 'Galleries', panel: 'Panels', section: 'Sections', testimonial: 'Testimonials', banner: 'Banners', table: 'Tables', form: 'Forms', code: 'Code', figure: 'Figures', image: 'Pictures', graphic: 'Graphics', video: 'Video', header: 'Headers', navigation: 'Navigation', footer: 'Footers' };
const FORM_KEY = 'capture.form';

let root = null, appId = '', scans = [], scanId = '', kind = '', view = '', query = '', shown = PAGE, timer = 0, seq = 0, busy = false;
const picked = new Set();

const remembered = () => { try { return JSON.parse(localStorage.getItem(FORM_KEY)) || {}; } catch { return {}; } };
const scan = () => scans.find(s => s.id === scanId) || scans[0];
const running = () => ST.data?.jobs.some(j => j.kind === 'capture' && j.appId === appId && active(j));

export function mount(el) {
  unmount(); root = el; appId = ST.appId; scans = []; scanId = ''; kind = view = query = ''; shown = PAGE; picked.clear();
  root.innerHTML = `${formHTML()}<section class="card cp-results" id="cpResults" hidden></section>
    <dialog class="cp-light" id="cpLight" aria-label="Capture preview"></dialog>`;
  root.onclick = onClick; root.onchange = onChange; root.oninput = onInput; root.onsubmit = onSubmit;
  syncForm(); refresh();
}
export function unmount() { seq++; clearTimeout(timer); if (root) root.onclick = root.onchange = root.oninput = root.onsubmit = null; root = null; }
export async function refresh() {
  if (!root) return; const mine = ++seq; clearTimeout(timer);
  try {
    const r = await api('POST', '/api/promo/captures', { appId });
    if (mine !== seq || !root) return;
    const before = JSON.stringify(scans.map(s => [s.id, s.items.length, s.state]));
    scans = r.scans;
    if (!scans.some(s => s.id === scanId)) scanId = scans[0]?.id || '';
    if (before !== JSON.stringify(scans.map(s => [s.id, s.items.length, s.state]))) drawResults();
  } catch (e) { if (mine === seq) toast(e.message, 'err'); }
  // while a scan runs, its finds appear as it goes
  if (mine === seq && running()) timer = setTimeout(refresh, 2500);
}

// ---------- the form ----------
function formHTML() {
  const a = app(), f = remembered(), modes = f.modes || ['elements'], views = f.views || ['desktop'];
  const url = (f.urls || {})[appId] ?? (a.pageUrl && /^https?:/.test(a.pageUrl) ? a.pageUrl : '');
  const options = (name, list, value) => `<select name="${name}">${list.map(([v, l]) => `<option value="${v}"${String(v) === String(value) ? ' selected' : ''}>${l}</option>`).join('')}</select>`;
  return `<section class="card cp-cap"><div class="card-head"><h3>${I('monitor')}Capture from ${esc(a.name)}</h3></div>
    <p class="sub">Point at a local dev server, a web page or anything with an address. Nothing is added to your app until you pick it.</p>
    <form class="cp-form" novalidate>
      <label class="fld"><span>Address</span><input name="url" type="url" inputmode="url" placeholder="http://localhost:5173/" value="${esc(url)}" autocomplete="url" spellcheck="false"></label>
      <fieldset class="fld"><legend>What to capture</legend><div class="cp-modes">${MODES.map(([v, l, d]) => `<label class="cp-mode"><input type="checkbox" name="mode" value="${v}"${modes.includes(v) ? ' checked' : ''}><span><b>${l}</b><small>${d}</small></span></label>`).join('')}</div></fieldset>
      <div class="cp-row">
        <fieldset class="fld"><legend>Screen sizes</legend><div class="row">${VIEWS.map(([v, l]) => `<label class="lb-chip"><input type="checkbox" name="view" value="${v}"${views.includes(v) ? ' checked' : ''}><span>${l}</span></label>`).join('')}</div></fieldset>
        <label class="fld cp-screens"><span>Screens down the page</span>${options('screens', [1, 2, 3, 4, 5, 8].map(n => [n, n]), f.screens || 3)}</label>
        <label class="fld"><span>Wait for loading</span>${options('wait', [[1, '1 second'], [2, '2 seconds'], [4, '4 seconds'], [8, '8 seconds']], f.wait || 2)}</label>
      </div>
      <div class="cp-deep">
        ${sw('name="deep" aria-describedby="cpDeepHelp"', !!f.deep, 'Deep scan: follow links to other pages')}
        <div class="cp-deepopts">
          <label class="fld"><span>Pages</span>${options('maxPages', [[10, 'Up to 10'], [25, 'Up to 25'], [60, 'Up to 60'], [200, 'Every page (up to 200)']], f.maxPages || 25)}</label>
          <label class="fld"><span>Link depth</span>${options('depth', [[1, '1 click away'], [2, '2 clicks'], [3, '3 clicks'], [5, '5 clicks']], f.depth || 3)}</label>
        </div>
        <small id="cpDeepHelp">Stays on the same site, under the starting folder. Skips sign-out, delete, checkout and download links. Forms are never submitted.</small>
      </div>
      <div class="cp-go">${sw('name="add"', !!f.add, 'Also add the 12 best to screenshots')}<span class="sp"></span>
        <button class="hbtn primary" type="submit"${ST.data.tools.chrome ? '' : ' disabled'}>${I('image')}<span id="cpGoLabel">Capture</span></button></div>
      ${ST.data.tools.chrome ? '' : `<p class="note lock"><span>${I('alert')}</span>Capturing needs Google Chrome or Microsoft Edge on this computer.</p>`}
    </form></section>`;
}
function syncForm() {
  const f = root?.querySelector('.cp-form'); if (!f) return;
  const modes = [...f.querySelectorAll('[name=mode]:checked')].map(x => x.value);
  f.classList.toggle('deep', f.elements.deep.checked);
  f.elements.screens.closest('.fld').hidden = !modes.includes('screens');
  f.querySelector('#cpGoLabel').textContent = f.elements.deep.checked ? 'Start deep scan' : 'Capture';
}

// ---------- results ----------
function visible() {
  const q = query.trim().toLowerCase();
  return (scan()?.items || []).filter(i => (!kind || i.kind === kind) && (!view || i.view === view) && (!q || `${i.label} ${i.page}`.toLowerCase().includes(q)));
}
const pathOf = url => { try { const u = new URL(url); return (u.pathname + u.hash) || '/'; } catch { return url; } };
function drawResults() {
  const box = root?.querySelector('#cpResults'); if (!box) return;
  const s = scan(); box.hidden = !s; if (!s) return;
  const ids = new Set(s.items.map(i => i.id)); for (const id of picked) if (!ids.has(id)) picked.delete(id);
  const kinds = Object.entries(s.items.reduce((m, i) => ((m[i.kind] = (m[i.kind] || 0) + 1), m), {})).sort((a, b) => b[1] - a[1]);
  const views = [...new Set(s.items.map(i => i.view))];
  if (kind && !kinds.some(k => k[0] === kind)) kind = '';
  if (view && !views.includes(view)) view = '';
  const focus = document.activeElement?.id;
  const live = s.state === 'running' && running();
  box.innerHTML = `<div class="card-head"><h3>${I('layers')}Captured <small class="muted num">${s.items.length} from ${s.pages.length} page${s.pages.length === 1 ? '' : 's'}</small></h3>
      <div class="row">${live ? '<span class="cp-live"><span class="spinner sm"></span>Scanning…</span>' : ''}
      <select id="cpScan" aria-label="Scan">${scans.map(x => `<option value="${x.id}"${x.id === s.id ? ' selected' : ''}>${esc(new URL(x.url).host)} · ${esc(rel(new Date(x.at).toISOString()))}${x.deep ? ' · deep' : ''}</option>`).join('')}</select>
      <button type="button" class="act del" data-cp="drop" aria-label="Delete this scan" title="Delete this scan"${live ? ' disabled' : ''}>${I('trash')}</button></div></div>
    ${s.errors?.length ? `<details class="cp-errors"><summary>${s.errors.length} page${s.errors.length === 1 ? '' : 's'} couldn’t be captured</summary><ul>${s.errors.slice(0, 40).map(e => `<li><code>${esc(pathOf(e.url))}</code> ${esc(e.error)}</li>`).join('')}</ul></details>` : ''}
    ${s.left ? `<p class="muted small">${s.left} more page${s.left === 1 ? ' was' : 's were'} found beyond the page limit. Raise “Pages” to include ${s.left === 1 ? 'it' : 'them'}.</p>` : ''}
    <div class="cp-filters" role="group" aria-label="Show kind">${[['', s.items.length], ...kinds].map(([k, n]) => `<button type="button" data-kind="${k}" class="${kind === k ? 'on' : ''}" aria-pressed="${kind === k}">${k ? KINDS[k] || k : 'Everything'}<em>${n}</em></button>`).join('')}</div>
    <div class="cp-tools"><input type="search" id="cpSearch" placeholder="Search by name or page" aria-label="Search captures" value="${esc(query)}">
      ${views.length > 1 ? `<select id="cpView" aria-label="Screen size"><option value="">All sizes</option>${views.map(v => `<option value="${v}"${v === view ? ' selected' : ''}>${VIEWS.find(x => x[0] === v)?.[1] || v}</option>`).join('')}</select>` : ''}
      <button type="button" class="hbtn ghost sm" data-cp="all">${I('check')}Select all shown</button></div>
    <div id="cpGrid"></div>
    <div class="cp-bar" id="cpBar" role="toolbar" aria-label="Selected captures" hidden></div>`;
  drawGrid();
  if (focus) document.getElementById(focus)?.focus({ preventScroll: true });
}
function drawGrid() {
  const box = root?.querySelector('#cpGrid'); if (!box) return;
  const list = visible(), part = list.slice(0, shown), s = scan();
  const groups = new Map(); for (const i of part) { if (!groups.has(i.page)) groups.set(i.page, []); groups.get(i.page).push(i); }
  box.innerHTML = list.length ? [...groups].map(([url, items]) => {
    const title = s.pages.find(p => p.url === url)?.title || '';
    return `<section class="cp-page"><header><h4>${esc(title || pathOf(url))}</h4><a href="${esc(url)}" target="_blank" rel="noopener">${esc(pathOf(url))}</a><span class="sp"></span><button type="button" class="hbtn ghost sm" data-page="${esc(url)}">Select page</button></header>
      <div class="cp-grid">${items.map(tile).join('')}</div></section>`;
  }).join('') + (list.length > shown ? `<div class="row cp-more"><button type="button" class="hbtn ghost" data-cp="more">Show more (${list.length - shown} left)</button></div>` : '')
    : `<p class="empty-sm">${I('search')}Nothing matches. Clear the filters to see everything.</p>`;
  drawBar();
}
function tile(i) {
  const on = picked.has(i.id), name = `${i.label || i.kind}`;
  return `<figure class="cp-tile${on ? ' on' : ''}" data-id="${esc(i.id)}">
    <button type="button" class="cp-view" data-open aria-label="Preview ${esc(name)}"><img src="${esc(media(i.file))}" alt="" loading="lazy" decoding="async"></button>
    <label class="cp-check"><input type="checkbox" data-pick${on ? ' checked' : ''} aria-label="Select ${esc(name)}"><span aria-hidden="true">${I('check')}</span></label>
    <figcaption><b title="${esc(name)}">${esc(name)}</b><small>${esc(KINDS[i.kind]?.replace(/s$/, '') || i.kind)}${i.w ? ` · ${i.w}×${i.h}` : ''}${i.view !== 'desktop' ? ` · ${esc(i.view)}` : ''}</small></figcaption></figure>`;
}
function drawBar() {
  const bar = root?.querySelector('#cpBar'); if (!bar) return;
  bar.hidden = !picked.size;
  bar.innerHTML = `<b class="num" role="status">${picked.size} selected</b><button type="button" class="hbtn ghost sm" data-cp="clear">Clear</button><span class="sp"></span>
    <button type="button" class="hbtn primary sm" data-use="screenshot"${busy ? ' disabled' : ''}>${I('layers')}Add to screenshots</button>
    <button type="button" class="hbtn ghost sm" data-use="cover"${busy || picked.size !== 1 ? ' disabled' : ''} title="Select exactly one">${I('image')}Use as cover</button>
    <button type="button" class="hbtn ghost sm" data-cp="download">${I('download')}Download</button>
    <button type="button" class="hbtn danger sm" data-cp="delete"${busy ? ' disabled' : ''}>${I('trash')}Delete</button>`;
}
function setPicked(id, on) {
  on ? picked.add(id) : picked.delete(id);
  const t = root.querySelector(`.cp-tile[data-id="${CSS.escape(id)}"]`);
  if (t) { t.classList.toggle('on', on); t.querySelector('[data-pick]').checked = on; }
}

// ---------- preview ----------
function openLight(id) {
  const d = root.querySelector('#cpLight'), list = visible(), at = list.findIndex(i => i.id === id), i = list[at]; if (!i) return;
  d.dataset.id = id;
  d.innerHTML = `<header><div><b>${esc(i.label || i.kind)}</b><small class="num">${i.w ? `${i.w}×${i.h} · ` : ''}${bytes(i.size)} · ${esc(pathOf(i.page))}</small></div>
      <button type="button" class="act" data-close aria-label="Close">${I('x')}</button></header>
    <div class="cp-stage${i.kind === 'full' ? ' tall' : ''}"><img src="${esc(media(i.file))}" alt="${esc(i.label || i.kind)}"></div>
    <footer><button type="button" class="hbtn ghost sm" data-step="-1"${at ? '' : ' disabled'}>Previous</button><button type="button" class="hbtn ghost sm" data-step="1"${at < list.length - 1 ? '' : ' disabled'}>Next</button><span class="num muted">${at + 1} of ${list.length}</span><span class="sp"></span>
      <button type="button" class="hbtn ${picked.has(id) ? 'ghost' : 'primary'} sm" data-toggle>${I(picked.has(id) ? 'x' : 'check')}${picked.has(id) ? 'Unselect' : 'Select'}</button></footer>`;
  if (!d.open) { d.showModal(); d.onkeydown = e => { const step = e.key === 'ArrowLeft' ? -1 : e.key === 'ArrowRight' ? 1 : 0; if (step) { e.preventDefault(); move(step); } }; }
}
function move(step) { const d = root.querySelector('#cpLight'), list = visible(), next = list[list.findIndex(i => i.id === d.dataset.id) + step]; if (next) { openLight(next.id); d.querySelector(`[data-step="${step}"]:not(:disabled)`)?.focus(); } }

// ---------- actions ----------
async function onClick(e) {
  const light = root.querySelector('#cpLight');
  if (e.target === light) return light.close();
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.close != null) return light.close();
  if (b.dataset.step) return move(+b.dataset.step);
  if (b.dataset.toggle != null) { const id = light.dataset.id; setPicked(id, !picked.has(id)); drawBar(); openLight(id); return light.querySelector('[data-toggle]').focus(); }
  if (b.dataset.open != null) return openLight(b.closest('.cp-tile').dataset.id);
  if (b.dataset.kind != null) { kind = b.dataset.kind; shown = PAGE; return drawResults(); }
  if (b.dataset.page) { visible().filter(i => i.page === b.dataset.page).forEach(i => setPicked(i.id, true)); return drawBar(); }
  if (b.dataset.use) return act(async () => {
    const r = await api('POST', '/api/promo/captures/use', { appId, scan: scan().id, items: [...picked], as: b.dataset.use });
    const n = S.apps.findIndex(x => x.id === appId); if (n >= 0) S.apps[n] = r.app;
    toast(b.dataset.use === 'cover' ? 'Set as cover' : `${r.count} added to screenshots`); picked.clear(); drawGrid();
  });
  const what = b.dataset.cp; if (!what) return;
  if (what === 'more') { shown += PAGE; return drawGrid(); }
  if (what === 'all') { visible().forEach(i => setPicked(i.id, true)); return drawBar(); }
  if (what === 'clear') { [...picked].forEach(id => setPicked(id, false)); return drawBar(); }
  if (what === 'download') {
    const list = scan().items.filter(i => picked.has(i.id));
    if (list.length > 20 && !(await confirmBox(`Download ${list.length} files?`, 'Your browser may ask to allow several downloads.', 'Download', false))) return;
    for (const i of list) { download(media(i.file), `${appId}-${i.id}`); await new Promise(r => setTimeout(r, 180)); }
    return;
  }
  if (what === 'delete' || what === 'drop') {
    const whole = what === 'drop';
    if (!(await confirmBox(whole ? 'Delete this scan?' : `Delete ${picked.size} capture${picked.size === 1 ? '' : 's'}?`, 'Pictures you already added to the app are separate copies and stay.'))) return;
    return act(async () => { const r = await api('POST', '/api/promo/captures/delete', { appId, scan: scan().id, ...(whole ? {} : { items: [...picked] }) }); scans = r.scans; picked.clear(); if (!scans.some(s => s.id === scanId)) scanId = scans[0]?.id || ''; drawResults(); });
  }
}
async function act(work) {
  if (busy) return; busy = true; drawBar();
  try { await work(); } catch (e) { toast(e.message, 'err', 8000); }
  busy = false; drawBar();
}
function onChange(e) {
  const t = e.target;
  if (t.closest('.cp-form')) return syncForm();
  if (t.dataset.pick != null) { setPicked(t.closest('.cp-tile').dataset.id, t.checked); return drawBar(); }
  if (t.id === 'cpScan') { scanId = t.value; picked.clear(); shown = PAGE; return drawResults(); }
  if (t.id === 'cpView') { view = t.value; shown = PAGE; return drawGrid(); }
}
function onInput(e) { if (e.target.id === 'cpSearch') { query = e.target.value; shown = PAGE; drawGrid(); } }
async function onSubmit(e) {
  e.preventDefault(); const f = e.target, button = f.querySelector('[type=submit]');
  let url = f.elements.url.value.trim();
  if (!url) { f.elements.url.focus(); return toast('Enter the address to capture', 'err'); }
  if (!/^[a-z]+:\/\//i.test(url)) url = `${/^(localhost|127\.|192\.168\.|10\.)/i.test(url) ? 'http' : 'https'}://${url}`;
  const checked = name => [...f.querySelectorAll(`[name=${name}]:checked`)].map(x => x.value);
  const body = { modes: checked('mode'), views: checked('view'), screens: +f.elements.screens.value, wait: +f.elements.wait.value, deep: f.elements.deep.checked, maxPages: +f.elements.maxPages.value, depth: +f.elements.depth.value };
  if (!body.modes.length) return toast('Choose what to capture', 'err');
  try { const old = remembered(); localStorage.setItem(FORM_KEY, JSON.stringify({ ...body, add: f.elements.add.checked, urls: { ...old.urls, [appId]: url } })); } catch { /* storage may be off */ }
  button.disabled = true;
  try {
    const r = await api('POST', '/api/promo/capture', { appId, url, ...body, addToApp: f.elements.add.checked });
    addJob(r.job); scanId = r.scanId; picked.clear(); kind = view = query = ''; shown = PAGE;
    toast(body.deep ? 'Deep scan started. Finds appear below as it goes.' : 'Capturing…', 'info');
    clearTimeout(timer); timer = setTimeout(refresh, 2000);
  } catch (x) { toast(x.message, 'err', 8000); }
  button.disabled = false;
}
