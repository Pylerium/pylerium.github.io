// Image Studio: every store and social format from one design. The preview is promo/poster.html with the same spec the
// renderer uses, so what you see is exactly what is saved.
import { S, esc, api, toast, confirmBox, rel } from '../core.js';
import { ST, app, I, media, debounce, sw, seg, addJob, copyText } from './common.js';

const ACC = { studio: '#2DD4BF', violet: '#A78BFA', sky: '#38BDF8', rose: '#FB7185', amber: '#FBBF24', emerald: '#34D399', lime: '#A3E635', orange: '#FB923C', indigo: '#818CF8', fuchsia: '#E879F9', cyan: '#22D3EE', red: '#F87171' };
let root = null, style = {}, specs = {}, focus = 'cover', dirty = false, ro = null, io = null, seq = 0;
const picked = new Set();
const fmt = id => ST.data.formats.find(f => f.id === id);

export const isDirty = () => dirty;
export function unmount() { refresh.cancel(); seq++; ro?.disconnect(); io?.disconnect(); ro = io = null; if (root) root.onclick = root.oninput = root.onchange = null; root = null; }
export function mount(el) {
  root = el; style = structuredClone(app().style || {}); specs = {}; dirty = false; picked.clear();
  root.innerHTML = `<div class="im"><section class="card im-design" id="imDesign" aria-label="Design"></section>
    <section class="im-stage"><div class="card" id="imHero"></div></section></div><section class="card" id="imKit" aria-label="All formats"></section>`;
  ro = new ResizeObserver(() => fitAll()); ro.observe(root);
  io = new IntersectionObserver(entries => { for (const e of entries) if (e.isIntersecting) { fill(e.target); io.unobserve(e.target); } }, { rootMargin: '200px' });
  root.onclick = onClick; root.oninput = onInput; root.onchange = onInput;
  design(); hero(); kit(); refresh.flush();
}
export function update() { if (!root) return; hero(); kit(); }

const frameBox = (id, big) => `<div class="pm-frame${big ? ' big' : ''}" data-frame="${id}" style="aspect-ratio:${fmt(id).w}/${fmt(id).h}"><span class="spinner"></span></div>`;
function fill(box) {
  const id = box.dataset.frame, f = fmt(id), spec = specs[id]; if (!spec) return;
  box.innerHTML = `<iframe tabindex="-1" title="${esc(f.label)} preview" style="width:${f.w}px;height:${f.h}px" src="/promo/poster.html?r=${seq}#${encodeURIComponent(JSON.stringify(spec))}"></iframe>`;
  box.classList.remove('ready'); box.querySelector('iframe').onload = () => box.classList.add('ready');
  fit(box);
}
function fit(box) {
  const f = fmt(box.dataset.frame), slot = box.parentElement, big = box.classList.contains('big');
  const cs = getComputedStyle(slot), maxW = slot.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight), maxH = big ? Math.max(320, Math.min(innerHeight * .62, 720)) : 170;
  const s = Math.max(0, Math.min(maxW / f.w, maxH / f.h));
  box.style.width = `${Math.floor(f.w * s)}px`; box.style.height = `${Math.floor(f.h * s)}px`;
  const fr = box.querySelector('iframe'); if (fr) fr.style.transform = `scale(${s})`;
}
function fitAll() { root?.querySelectorAll('.pm-frame').forEach(fit); }
function previews() { for (const box of root.querySelectorAll('.pm-frame')) { fit(box); if (box.classList.contains('big')) fill(box); else { io.unobserve(box); io.observe(box); } } }
const refresh = debounce(async () => {
  const mine = ++seq;
  try { const r = await api('POST', '/api/promo/preview', { appId: ST.appId, style }); if (mine !== seq || !root) return; specs = r.specs; previews(); if (!root.querySelector('#imDesign :focus')) design(); }
  catch (e) { toast(e.message, 'err'); }
}, 220);

function design() {
  const a = app(), s = style, t = s.template || 'hero', sp = specs[focus] || {};
  const txt = (k, label, ph, hint = '') => `<label class="fld"><span>${esc(label)}${hint ? ` <small>${esc(hint)}</small>` : ''}</span><input data-k="${k}" value="${esc(s[k] ?? '')}" placeholder="${esc(ph)}"></label>`;
  root.querySelector('#imDesign').innerHTML = `<div class="card-head"><h3>${I('palette')}Design</h3><div class="row">${dirty ? '<span class="dc-pill warn">Unsaved</span>' : ''}<button type="button" class="act" data-im="reset" aria-label="Reset to the app’s own text and colours" title="Reset">${I('refresh')}</button><button type="button" class="hbtn primary sm" data-im="save">${I('save')}Save</button></div></div>
    <div class="fld"><span>Layout</span><div class="pm-tpls">${ST.data.templates.map(x => `<button type="button" data-set="template" data-v="${x.id}" class="${t === x.id ? 'on' : ''}" aria-pressed="${t === x.id}"><b>${esc(x.label)}</b><small>${esc(x.blurb)}</small></button>`).join('')}</div></div>
    <div class="fld"><span>Look</span>${seg('data-look', ST.data.styles, s.style || 'ink')}</div>
    <div class="fld"><span>Frame</span>${seg('data-frame-style', ST.data.frames, s.frame || 'window')}</div>
    <div class="fld"><span>Accent</span><div class="pm-sw">${ST.data.accents.map(k => `<button type="button" class="${(s.accent || a.accent || 'violet') === k ? 'on' : ''}" data-set="accent" data-v="${k}" style="--c:${ACC[k] || '#2DD4BF'}" aria-label="${k}" title="${k}"></button>`).join('')}</div></div>
    ${a.shots.length ? `<div class="fld"><span>Screenshot</span><div class="vd-shots">${a.shots.map((p, i) => `<button type="button" class="${(+s.shot || 0) === i ? 'on' : ''}" data-set="shot" data-v="${i}" aria-pressed="${(+s.shot || 0) === i}"><img src="${esc(media(p))}" alt="Screenshot ${i + 1}" loading="lazy"></button>`).join('')}</div></div>` : `<p class="note">${I('info')}<span>No screenshots yet: designs use the icon and text. Add some in the app’s Media tab, or capture them in the Library.</span></p>`}
    ${t === 'feature' && a.features.length ? `<label class="fld"><span>Feature</span><select data-k="featureIndex">${a.features.map((f, i) => `<option value="${i}"${(+s.featureIndex || 0) === i ? ' selected' : ''}>${esc(f.slice(0, 80))}</option>`).join('')}</select></label>
      <div class="f3"><label class="fld"><span>Zoom <small class="num">${s.zoom || 1.6}×</small></span><input type="range" min="1" max="3" step=".1" data-k="zoom" value="${s.zoom || 1.6}"></label><label class="fld"><span>Across</span><input type="range" min="0" max="1" step=".02" data-k="fx" value="${s.fx ?? .5}"></label><label class="fld"><span>Down</span><input type="range" min="0" max="1" step=".02" data-k="fy" value="${s.fy ?? .25}"></label></div>` : ''}
    ${txt('headline', 'Headline', String(sp.headline || ''), '*stars* highlight words')}${txt('sub', 'Supporting line', String(sp.sub ?? ''))}
    <div class="f2">${txt('kicker', 'Small label', String(sp.kicker ?? ''))}${txt('pill', 'Highlight pill', String(sp.pill ?? ''))}</div>
    <div class="f2">${txt('badge', 'Corner badge', 'e.g. Just launched')}${txt('url', 'Link text', String(sp.url ?? ''))}</div>
    <div class="im-sw">${sw('data-k="showBrand"', s.showBrand !== false, 'App icon')}${sw('data-k="texture"', s.texture !== false, 'Grid and grain')}${sw('data-k="listFeatures"', !!s.listFeatures, 'List highlights')}</div>`;
}
function hero() {
  const a = app(), f = fmt(focus), file = a.files[focus];
  root.querySelector('#imHero').innerHTML = `<div class="card-head"><h3>${I('eye')}${esc(f.label)} <small class="muted num">${f.w} × ${f.h}</small></h3>
    <div class="row">${file ? `<a class="hbtn ghost sm" href="${esc(media(file.file, file.at))}" download="${esc(a.id)}-${focus}.png">${I('download')}Download</a>` : ''}<button type="button" class="hbtn primary sm" data-render="${focus}"${ST.data.tools.chrome ? '' : ' disabled'}>${I('image')}Render this</button></div></div>
    <div class="im-big">${frameBox(focus, true)}</div><p class="muted small">${esc(f.use)}. ${file ? `Saved ${esc(rel(new Date(file.at).toISOString()))}.` : 'Not saved yet.'} The preview is exactly what’s saved.</p>`;
  if (specs[focus]) fill(root.querySelector('#imHero .pm-frame'));
}
function kit() {
  const a = app(), n = picked.size;
  root.querySelector('#imKit').innerHTML = `<div class="card-head"><h3>${I('grid')}The kit <small class="muted num">${Object.keys(a.files).length} of ${ST.data.formats.length} saved</small></h3>
    <div class="row"><button type="button" class="hbtn ghost sm" data-pickset="auto">Recommended</button><button type="button" class="hbtn ghost sm" data-pickset="all">All</button><button type="button" class="hbtn ghost sm" data-pickset="none"${n ? '' : ' disabled'}>None</button><button type="button" class="hbtn primary sm" data-renderpick${ST.data.tools.chrome ? '' : ' disabled'}>${I('rocket')}Render ${n || `${a.auto.length} recommended`}</button></div></div>
    ${[...new Set(ST.data.formats.map(f => f.group))].map(g => `<h4 class="pm-g">${esc(g)}</h4><div class="pm-kit">${ST.data.formats.filter(f => f.group === g).map(f => { const file = a.files[f.id];
    return `<div class="pm-card${f.id === focus ? ' focus' : ''}"><button type="button" class="pm-thumb" data-focus="${f.id}" aria-label="Design ${esc(f.label)}">${frameBox(f.id)}</button>
    <div class="pm-meta"><label class="pm-check"><input type="checkbox" data-pick1="${f.id}"${picked.has(f.id) ? ' checked' : ''}><b>${esc(f.label)}</b></label><small class="num">${f.w}×${f.h}${file ? ' · saved' : ''}</small></div>
    ${file ? `<div class="pm-acts"><a class="act" href="${esc(media(file.file, file.at))}" download="${esc(a.id)}-${f.id}.png" aria-label="Download" title="Download">${I('download')}</a>${f.w / f.h > 1.5 && f.w >= 1200 ? `<button type="button" class="act" data-use="cover" data-file="${esc(file.file)}" aria-label="Use as cover" title="Use as the app’s cover">${I('image')}</button>` : ''}<button type="button" class="act" data-use="${f.id === 'social' ? 'social' : 'screenshot'}" data-file="${esc(file.file)}" aria-label="${f.id === 'social' ? 'Use for link previews' : 'Add to screenshots'}" title="${f.id === 'social' ? 'Use for link previews' : 'Add to screenshots'}">${I(f.id === 'social' ? 'share' : 'plus')}</button><button type="button" class="act del" data-delfile="${esc(file.file)}" aria-label="Delete" title="Delete">${I('trash')}</button></div>` : ''}</div>`; }).join('')}</div>`).join('')}`;
  previews();
}
function setStyle(k, v) { style = { ...style, [k]: v }; if (v === '' || v == null) delete style[k]; dirty = true; refresh(); }
async function renderIds(ids) { const r = await api('POST', '/api/promo/render', { appId: ST.appId, formats: ids, style }); dirty = false; app().style = style; addJob(r.job); design(); }
async function onClick(e) {
  const b = e.target.closest('button'); if (!b) return; const d = b.dataset;
  try {
    if (d.focus) { focus = d.focus; hero(); root.querySelectorAll('.pm-card').forEach(c => c.classList.toggle('focus', c.querySelector('[data-focus]').dataset.focus === focus)); design(); return root.querySelector('#imHero').scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }
    if (d.set) { setStyle(d.set, d.set === 'shot' ? +d.v : d.v); return design(); }
    if (d.look) { setStyle('style', d.look); return design(); }
    if (d.frameStyle) { setStyle('frame', d.frameStyle); return design(); }
    if (d.im === 'save') { style = (await api('PUT', '/api/promo/app/' + ST.appId, { style })).style; dirty = false; app().style = style; design(); return toast('Design saved. Automatic kits use it too.'); }
    if (d.im === 'reset') { style = {}; dirty = true; refresh(); return design(); }
    if (d.render) return await renderIds([d.render]);
    if (d.renderpick != null) return await renderIds(picked.size ? [...picked] : app().auto);
    if (d.pickset) { picked.clear(); if (d.pickset !== 'none') (d.pickset === 'all' ? ST.data.formats.map(f => f.id) : app().auto).forEach(id => picked.add(id)); return kit(); }
    if (d.use) {
      const what = { cover: 'the app’s cover image', social: 'the image for link previews and social posts', screenshot: 'a new screenshot' }[d.use];
      if (!(await confirmBox(`Use this as ${what}?`, 'It’s copied into the app. Publish to put it live.', 'Use it', false))) return;
      const r = await api('POST', '/api/promo/use', { appId: ST.appId, file: d.file, as: d.use }); const i = S.apps.findIndex(x => x.id === ST.appId); if (i >= 0) S.apps[i] = r.app;
      return toast('Done. Publish when you’re ready.');
    }
    if (d.delfile) { if (!(await confirmBox('Delete this image?', 'Anything you already used it for keeps its copy.'))) return; ST.data = await api('POST', '/api/promo/file/delete', { appId: ST.appId, file: d.delfile }); hero(); kit(); }
  } catch (x) { toast(x.message, 'err', 9000); }
}
function onInput(e) {
  const t = e.target, k = t.dataset.k;
  if (t.dataset.pick1) { if (e.type === 'change') { t.checked ? picked.add(t.dataset.pick1) : picked.delete(t.dataset.pick1); const b = root.querySelector('[data-renderpick]'); b.innerHTML = `${I('rocket')}Render ${picked.size || `${app().auto.length} recommended`}`; root.querySelector('[data-pickset="none"]').disabled = !picked.size; } return; }
  if (!k) return;
  if (t.type === 'checkbox') return setStyle(k, t.checked);
  if (t.type === 'range') { const l = t.closest('label')?.querySelector('small'); if (l && k === 'zoom') l.textContent = t.value + '×'; return setStyle(k, +t.value); }
  if (k === 'featureIndex') return setStyle(k, +t.value);
  setStyle(k, t.value);
}
export { copyText };
