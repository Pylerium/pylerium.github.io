// Icon Studio: draw with the vector editor, or start from the IconMake generator; save designs, export SVG, PNG and ICO,
// and set the result as the app's icon.
import { S, esc, api, toast, confirmBox, rel } from '../core.js';
import { createEditor } from '../vector/editor.js';
import { toSVG, importSVG, make, solid, linear, SIZE } from '../vector/doc.js';
import * as Gen from '../vector/iconmake.js';
import { ST, app, I, debounce, copyText, download, sw } from './common.js';

let root = null, tab = 'draw', editor = null, saved = [], backdrop = 'dark', guides = false, seq = 0;
let design = null; // { id, name, doc }
let gen = { ...Gen.INITIAL };
try { gen = { ...gen, ...JSON.parse(localStorage.getItem('promo.iconmake') || '{}') }; } catch {}
const draftKey = id => `promo.icon.draft.${id}`;
const blank = () => ({ size: SIZE, objects: [] });
const starter = () => ({ size: SIZE, objects: [
  make('rect', { name: 'Background', x: 20, y: 20, w: 472, h: 472, r: 108, smooth: true, fill: linear('#1B2233', '#0B0D14', 160) }),
  make('ellipse', { name: 'Ring', x: 136, y: 136, w: 240, h: 240, fill: { type: 'none' }, stroke: solid('#2DD4BF'), sw: 36 }),
  make('ellipse', { name: 'Dot', x: 322, y: 128, w: 70, h: 70, fill: solid('#FFFFFF') })
] });
const slug = s => String(s || 'icon').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'icon';
const svgNow = () => (tab === 'generate' ? Gen.iconSvg(gen) : toSVG(design.doc));
const nameNow = () => (tab === 'generate' ? gen.name : design.name);

export function unmount() { seq++; keep.flush?.(); keep.cancel(); editor?.destroy(); editor = null; if (root) root.onclick = root.oninput = root.onchange = null; root = null; }
export async function mount(el) {
  root = el; const mine = ++seq;
  let draft = null; try { draft = JSON.parse(localStorage.getItem(draftKey(ST.appId)) || 'null'); } catch {}
  design = draft?.doc?.objects ? draft : { id: '', name: `${app().name} icon`, doc: starter() };
  try { saved = (await api('GET', '/api/promo/icons')).designs; } catch (e) { toast(e.message, 'err'); }
  if (mine !== seq) return;
  root.innerHTML = `<div class="ic">
    <div class="ic-head"><div class="subtabs" role="tablist" aria-label="Icon Studio">${[['draw', 'edit', 'Draw'], ['generate', 'sparkles', 'Generate'], ['mine', 'folder', 'My icons']].map(([k, ic, l]) => `<button type="button" role="tab" data-tab="${k}">${I(ic)}${l}</button>`).join('')}</div>
      <div class="ic-actions" id="icActions"></div></div>
    <div id="icBody"></div><div class="card ic-foot" id="icFoot"></div></div>`;
  root.onclick = onClick; root.oninput = onInput; root.onchange = onInput;
  show(tab);
}
const keep = debounce(() => { if (design) localStorage.setItem(draftKey(ST.appId), JSON.stringify(design)); }, 500);

function show(next) {
  tab = next; editor?.destroy(); editor = null;
  root.querySelector('.ic').classList.toggle('drawing', tab === 'draw');
  root.querySelectorAll('[data-tab]').forEach(b => { b.classList.toggle('on', b.dataset.tab === tab); b.setAttribute('aria-selected', b.dataset.tab === tab); });
  const body = root.querySelector('#icBody');
  if (tab === 'draw') {
    body.innerHTML = '<div class="ic-editor"></div>';
    editor = createEditor(body.firstChild, { doc: design.doc, onChange: d => { design.doc = structuredClone(d); keep(); previews(); } });
  } else if (tab === 'generate') drawGen(); else drawMine();
  actions(); foot();
}
function actions() {
  root.querySelector('#icActions').innerHTML = tab === 'mine' ? `<button type="button" class="hbtn ghost sm" data-new="blank">${I('plus')}Blank canvas</button><button type="button" class="hbtn primary sm" data-new="starter">${I('sparkles')}New from starter</button>`
    : `${tab === 'draw' ? `<input id="icName" aria-label="Icon name" maxlength="60" value="${esc(design.name)}"><button type="button" class="hbtn ghost sm" data-full>${I('monitor')}Full screen</button>` : `<button type="button" class="hbtn ghost sm" data-toeditor>${I('edit')}Edit in Draw</button>`}<button type="button" class="hbtn ghost sm" data-save>${I('save')}Save</button><button type="button" class="hbtn primary sm" data-apply>${I('check')}Use as ${esc(app().name)}’s icon</button>`;
}
function foot() {
  const el = root.querySelector('#icFoot'); el.hidden = tab === 'mine';
  if (el.hidden) return;
  el.innerHTML = `<div class="ic-previews" aria-label="Previews at real sizes">${[128, 64, 32, 16].map(n => `<figure><img data-prev width="${n}" height="${n}" alt="Preview at ${n} pixels"><figcaption class="num">${n}</figcaption></figure>`).join('')}
      <figure class="ic-light"><img data-prev width="48" height="48" alt="On a light background"><figcaption>Light</figcaption></figure>
      <figure class="ic-dock"><div><span></span><img data-prev width="48" height="48" alt="In a dock"><span></span><span></span></div><figcaption>Dock</figcaption></figure></div>
    <div class="ic-export"><b>Export</b><div class="row">${[32, 64, 128, 256, 512, 1024].map(n => `<button type="button" class="hbtn ghost sm num" data-png="${n}">PNG ${n}</button>`).join('')}</div>
      <div class="row"><button type="button" class="hbtn ghost sm" data-exp="svg">${I('download')}SVG</button><button type="button" class="hbtn ghost sm" data-exp="ico">${I('download')}Windows ICO</button><button type="button" class="hbtn ghost sm" data-exp="json">JSON</button><button type="button" class="hbtn ghost sm" data-exp="copy">${I('copy')}Copy SVG</button><button type="button" class="hbtn primary sm" data-exp="all">${I('package')}All sizes</button></div></div>`;
  previews();
}
const previews = debounce(() => { if (!root || tab === 'mine') return; const url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgNow()); root.querySelectorAll('[data-prev], [data-big]').forEach(i => (i.src = url)); }, 90);

function drawGen() {
  const pick = (k, list) => `<div class="seg wide">${list.map(([v, l]) => `<button type="button" data-g="${k}" data-v="${v}" class="${gen[k] === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  const range = (k, l, min, max, step = 1) => `<label class="ve-range"><span>${l}<output class="num">${gen[k]}</output></span><input type="range" data-gk="${k}" min="${min}" max="${max}" step="${step}" value="${gen[k]}"></label>`;
  root.querySelector('#icBody').innerHTML = `<div class="ig">
    <section class="card ig-ctl" aria-label="Generator controls">
      <label class="fld"><span>Name</span><input data-gk="name" maxlength="32" value="${esc(gen.name)}"></label>
      <div class="fld"><span>Shape</span>${pick('shape', Gen.SHAPES)}</div><div class="fld"><span>Mark</span>${pick('motif', Gen.MOTIFS)}</div>
      ${gen.motif === 'monogram' ? `<label class="fld"><span>Letters</span><input data-gk="letter" maxlength="2" value="${esc(gen.letter)}"></label>` : ''}
      <div class="fld"><span>Colours</span><div class="ig-colors">${[['bg', 'Base'], ['accent', 'Accent'], ['highlight', 'Highlight']].map(([k, l]) => `<label><input type="color" data-gk="${k}" value="${gen[k]}"><span>${l}</span></label>`).join('')}</div>
        <div class="ig-pal">${Gen.PALETTES.map((p, i) => `<button type="button" data-pal="${i}" aria-label="Palette ${i + 1}" style="--a:${p[0]};--b:${p[1]};--c:${p[2]}"><i></i><i></i><i></i></button>`).join('')}</div></div>
      ${range('scale', 'Symbol size', 52, 100)}${range('glow', 'Soft glow', 0, 80)}${range('tilt', 'Turn', -15, 15)}${range('rim', 'Outer rim', 0, 5, .5)}${gen.shape === 'squircle' ? range('radius', 'Corner radius', 4, 34) : ''}${range('gradientAngle', 'Gradient angle', 0, 360, 5)}
      <div class="row"><button type="button" class="hbtn primary sm" data-random>${I('sparkles')}Surprise me</button><button type="button" class="hbtn ghost sm" data-genreset>${I('refresh')}Reset</button></div>
    </section>
    <section class="ig-stage"><div class="card ig-preview bd-${backdrop}${guides ? ' guides' : ''}"><div class="ig-tools"><div class="seg">${[['dark', 'Dark'], ['light', 'Light'], ['alpha', 'Alpha']].map(([v, l]) => `<button type="button" data-bd="${v}" class="${backdrop === v ? 'on' : ''}">${l}</button>`).join('')}</div>${sw('data-guides', guides, 'Safe zone')}</div><div class="ig-big"><img data-big width="320" height="320" alt="Your icon"><i aria-hidden="true"></i></div></div>
      <div class="card"><div class="card-head"><h3>${I('sparkles')}Places to begin</h3></div><div class="ig-ideas">${Gen.IDEAS.map((x, i) => `<button type="button" data-idea="${i}"><img alt="" src="data:image/svg+xml;charset=utf-8,${encodeURIComponent(Gen.iconSvg({ ...Gen.INITIAL, shape: x.shape, motif: x.motif, bg: x.colors[0], accent: x.colors[1], highlight: x.colors[2], scale: 86, glow: 22 }))}"><span>${esc(x.label)}</span></button>`).join('')}</div></div></section></div>`;
  previews();
}
function drawMine() {
  root.querySelector('#icBody').innerHTML = `<section class="card"><div class="card-head"><h3>${I('folder')}Saved icons <small class="muted num">${saved.length}</small></h3></div>
    ${saved.length ? `<div class="ic-grid">${saved.map(d => `<figure><button type="button" data-open="${d.id}" aria-label="Open ${esc(d.name)}">${d.thumb ? `<img alt="" src="data:image/svg+xml;charset=utf-8,${encodeURIComponent(d.thumb)}">` : I('image')}</button><figcaption><b>${esc(d.name)}</b><small>${esc(ST.data.apps.find(a => a.id === d.appId)?.name || 'No app')} · ${esc(rel(new Date(d.at).toISOString()))}</small></figcaption><button type="button" class="act del" data-remove="${d.id}" aria-label="Delete ${esc(d.name)}">${I('trash')}</button></figure>`).join('')}</div>` : `<div class="emptystate">${I('edit')}<h4>No saved icons yet</h4><p>Draw or generate one, then press Save.</p></div>`}
    <p class="muted small">Importing: drop an .svg file onto the Draw canvas, or use Import SVG in its toolbar.</p></section>`;
}

// ---------- export ----------
async function png(svg, size) {
  const url = URL.createObjectURL(new Blob([svg.replace(/width="\d+" height="\d+"/, `width="${size}" height="${size}"`)], { type: 'image/svg+xml;charset=utf-8' }));
  try { const img = new Image(); img.src = url; await img.decode(); const c = document.createElement('canvas'); c.width = c.height = size; c.getContext('2d').drawImage(img, 0, 0, size, size); return await new Promise((ok, fail) => c.toBlob(b => (b ? ok(b) : fail(new Error('The PNG couldn’t be drawn.'))), 'image/png')); }
  finally { URL.revokeObjectURL(url); }
}
async function ico(svg) {
  const sizes = [16, 24, 32, 48, 64, 128, 256], blobs = []; for (const s of sizes) blobs.push(await png(svg, s));
  const head = new Uint8Array(6 + sizes.length * 16), v = new DataView(head.buffer); v.setUint16(2, 1, true); v.setUint16(4, sizes.length, true);
  let offset = head.length; blobs.forEach((b, i) => { const p = 6 + i * 16; head[p] = head[p + 1] = sizes[i] === 256 ? 0 : sizes[i]; v.setUint16(p + 4, 1, true); v.setUint16(p + 6, 32, true); v.setUint32(p + 8, b.size, true); v.setUint32(p + 12, offset, true); offset += b.size; });
  return new Blob([head, ...blobs], { type: 'image/x-icon' });
}
function saveBlob(blob, name) { const url = URL.createObjectURL(blob); download(url, name); setTimeout(() => URL.revokeObjectURL(url), 2000); }
async function exportAs(kind) {
  const svg = svgNow(), file = slug(nameNow()), full = '<?xml version="1.0" encoding="UTF-8"?>\n' + svg;
  if (!/<(path|rect|circle|text|ellipse)/.test(svg)) return toast('Draw something first', 'err');
  if (kind === 'svg' || kind === 'all') saveBlob(new Blob([full], { type: 'image/svg+xml' }), `${file}.svg`);
  if (kind === 'all') for (const n of [1024, 512, 256, 128, 64, 32]) { saveBlob(await png(svg, n), `${file}-${n}.png`); await new Promise(r => setTimeout(r, 160)); }
  if (kind === 'ico' || kind === 'all') saveBlob(await ico(svg), `${file}.ico`);
  if (kind === 'json') saveBlob(new Blob([JSON.stringify(tab === 'generate' ? { generator: gen } : design, null, 2)], { type: 'application/json' }), `${file}.json`);
  if (kind === 'copy') return copyText(full, 'SVG copied');
  toast('Exported');
}

async function onClick(e) {
  const b = e.target.closest('button'); if (!b || b.closest('.ve')) return; const d = b.dataset;
  try {
    if (d.tab) return show(d.tab);
    if (d.g) { gen[d.g] = d.v; localStorage.setItem('promo.iconmake', JSON.stringify(gen)); return drawGen(); }
    if (d.pal != null) { [gen.bg, gen.accent, gen.highlight] = Gen.PALETTES[+d.pal]; localStorage.setItem('promo.iconmake', JSON.stringify(gen)); return drawGen(); }
    if (d.idea != null) { const x = Gen.IDEAS[+d.idea]; Object.assign(gen, { shape: x.shape, motif: x.motif, bg: x.colors[0], accent: x.colors[1], highlight: x.colors[2], scale: 86, glow: 22, tilt: 0, rim: 1.5 }); drawGen(); return toast(`${x.label} applied`); }
    if (d.random != null) { const r = a => a[Math.floor(Math.random() * a.length)], p = r(Gen.PALETTES); Object.assign(gen, { shape: r(Gen.SHAPES)[0], motif: r(Gen.MOTIFS)[0], bg: p[0], accent: p[1], highlight: p[2], scale: 68 + Math.floor(Math.random() * 32), glow: 18 + Math.floor(Math.random() * 60), tilt: Math.floor(Math.random() * 25) - 12, rim: Math.round(Math.random() * 10) / 2 }); if (gen.motif === 'monogram') gen.letter = app().name.charAt(0).toUpperCase(); return drawGen(); }
    if (d.genreset != null) { gen = { ...Gen.INITIAL, name: `${app().name} icon` }; return drawGen(); }
    if (d.bd) { backdrop = d.bd; return drawGen(); }
    if (d.toeditor != null) {
      if (design.doc.objects.length && !(await confirmBox('Replace the drawing?', 'The generated icon opens in Draw as editable layers, replacing the current canvas. Save first if you want to keep it.', 'Replace', false))) return;
      design = { id: '', name: gen.name, doc: { size: SIZE, objects: importSVG(Gen.iconSvg(gen), SIZE) } }; keep(); return show('draw');
    }
    if (d.png) { const svg = svgNow(); saveBlob(await png(svg, +d.png), `${slug(nameNow())}-${d.png}.png`); return; }
    if (d.exp) return await exportAs(d.exp);
    if (d.full != null) { const box = root.querySelector('#icBody'); return document.fullscreenElement ? document.exitFullscreen() : box.requestFullscreen(); }
    if (d.save != null) {
      const doc = tab === 'generate' ? { size: SIZE, objects: importSVG(Gen.iconSvg(gen), SIZE) } : design.doc;
      const r = await api('PUT', '/api/promo/icons', { design: { id: tab === 'generate' ? '' : design.id, name: nameNow(), appId: ST.appId, doc, thumb: svgNow() } });
      saved = r.designs; if (tab === 'draw') { design.id = r.design.id; keep(); } return toast('Saved to My icons');
    }
    if (d.apply != null) {
      if (tab === 'draw' && !design.doc.objects.length) return toast('Draw something first', 'err');
      if (!(await confirmBox(`Use this as ${app().name}’s icon?`, 'The app’s cards, pages, videos and promo images will use it. Publish to put it live.', 'Use it', false))) return;
      const r = await api('POST', '/api/promo/icons/apply', { appId: ST.appId, svg: svgNow() });
      const i = S.apps.findIndex(x => x.id === ST.appId); if (i >= 0) S.apps[i] = r.app; app().iconImage = r.file;
      root.dispatchEvent(new CustomEvent('promo:appchanged', { bubbles: true })); return toast('Icon set. Publish when you’re ready.');
    }
    if (d.open) { const x = saved.find(y => y.id === d.open); design = { id: x.id, name: x.name, doc: structuredClone(x.doc) }; if (!design.doc.objects) throw new Error('That design couldn’t be opened.'); keep(); return show('draw'); }
    if (d.remove) { if (!(await confirmBox('Delete this saved icon?', 'Apps already using it keep their copy.'))) return; saved = (await api('POST', '/api/promo/icons/delete', { id: d.remove })).designs; return drawMine(); }
    if (d.new) { if (design.doc.objects.length && !design.id && !(await confirmBox('Start a new drawing?', 'The current canvas hasn’t been saved.', 'Start new', false))) return; design = { id: '', name: `${app().name} icon`, doc: d.new === 'blank' ? blank() : starter() }; keep(); return show('draw'); }
  } catch (x) { toast(x.message, 'err', 8000); }
}
function onInput(e) {
  const t = e.target; if (t.closest('.ve')) return;
  if (t.id === 'icName') { design.name = t.value; return keep(); }
  if (t.dataset.guides != null) { guides = t.checked; return root.querySelector('.ig-preview').classList.toggle('guides', guides); }
  const k = t.dataset.gk; if (!k) return;
  gen[k] = t.type === 'range' ? +t.value : t.value; localStorage.setItem('promo.iconmake', JSON.stringify(gen));
  const out = t.closest('label')?.querySelector('output'); if (out) out.textContent = gen[k];
  previews();
}
