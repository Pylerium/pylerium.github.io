// State and helpers shared by the Promo Studio sections.
import { R, esc, api, toast, MEDIA } from '../core.js';

export const I = n => R.icon(n);
export const media = (p, v) => (p ? R.media(p, MEDIA) + (v ? `?v=${v}` : '') : '');
export const ST = { data: null, appId: '', section: 'video', film: null };
export const app = () => ST.data?.apps.find(a => a.id === ST.appId);
export const active = j => ['queued', 'running'].includes(j.state);
export const debounce = (fn, ms) => { let t = 0; const d = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; d.cancel = () => clearTimeout(t); d.flush = (...a) => { clearTimeout(t); return fn(...a); }; return d; };
export const clock = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
export const bytes = n => (n > 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);
export async function copyText(text, what = 'Copied') {
  try { await navigator.clipboard.writeText(text); toast(what); } catch { toast('Couldn’t copy. Select the text and copy it instead.', 'err'); }
}
export function download(url, name) { const a = Object.assign(document.createElement('a'), { href: url, download: name }); document.body.append(a); a.click(); a.remove(); }
export const sw = (attr, on, label) => `<label class="switch sm"><input type="checkbox" ${attr}${on ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">${esc(label)}</span></label>`;
export const seg = (attr, options, value) => `<div class="seg wide" role="group">${options.map(([v, l]) => `<button type="button" ${attr}="${esc(v)}" class="${String(value) === String(v) ? 'on' : ''}">${esc(l)}</button>`).join('')}</div>`;

// ---------- background jobs: one poller for the whole studio ----------
const listeners = new Set(); let timer = 0;
export const onJobs = fn => { listeners.add(fn); return () => listeners.delete(fn); };
export function addJob(job) { ST.data.jobs = [job, ...ST.data.jobs.filter(j => j.id !== job.id)]; drawJobs(); watch(); }
export function watch() {
  clearTimeout(timer);
  if (!ST.data?.jobs.some(active)) return;
  timer = setTimeout(async () => {
    const before = ST.data.jobs.filter(active).map(j => j.id);
    try { ST.data.jobs = (await api('GET', '/api/promo/jobs')).jobs; } catch { /* the hub may be busy: try again */ }
    const done = ST.data.jobs.filter(j => before.includes(j.id) && !active(j));
    for (const j of done) toast(j.state === 'complete' ? `${j.label}: ready` : j.state === 'failed' ? `${j.label}: ${j.error}` : `${j.label}: cancelled`, j.state === 'complete' ? 'ok' : 'err', 7000);
    drawJobs();
    if (done.length) for (const fn of listeners) fn(done);
    watch();
  }, 900);
}
export function drawJobs() {
  const box = document.getElementById('pmJobs'); if (!box) return;
  const run = (ST.data?.jobs || []).filter(active);
  box.hidden = !run.length;
  box.innerHTML = run.map(j => `<div class="ps-job"><span class="spinner sm"></span><div><b>${esc(j.label)}</b>${j.note ? `<small class="ps-note">${esc(j.note)}</small>` : ''}<div class="ps-bar"><i style="transform:scaleX(${Math.max(.02, j.progress)})"></i></div></div><small class="num">${j.state === 'queued' ? 'Waiting' : Math.round(j.progress * 100) + '%'}</small><button type="button" class="act" data-cancel="${esc(j.id)}" aria-label="Cancel ${esc(j.label)}">${I('x')}</button></div>`).join('');
}
