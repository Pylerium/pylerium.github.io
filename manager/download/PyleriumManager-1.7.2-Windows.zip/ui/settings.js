// Settings: how this dashboard looks and behaves on your computer (data/prefs.json, cached in localStorage so it applies
// before the first paint). Appearance · Dashboard · Donations & sales · Region · Data & backups (+ Account in Pylerium Manager).
// Nothing here changes your public website: that lives in Site settings, Community, Promo and Connectors.
import { R, S, $, $$, esc, api, toast, confirmBox, rel } from './core.js';
import * as Phone from './phone.js';

const I = n => R.icon(n);
const LS = 'hub.prefs';
let P = null, D = null, tab = 'appearance', account = null, B = null, lastSeen = 0, watch = null;

// ---------- themes: surfaces + three accents. The dashboard's colours are rewritten from these at runtime ----------
export const THEMES = {
  midnight: { label: 'Midnight', note: 'The original: deep navy, violet and teal', s: [[20, 24, 41], [11, 13, 22], [5, 6, 11], [13, 15, 26]], bg: '#07080E', a: ['#8B5CF6', '#38BDF8', '#2DD4BF'] },
  obsidian: { label: 'Obsidian', note: 'Neutral black, quiet and focused', s: [[24, 24, 27], [14, 14, 16], [7, 7, 8], [17, 17, 19]], bg: '#08080A', a: ['#A1A1AA', '#60A5FA', '#34D399'] },
  ocean: { label: 'Deep ocean', note: 'Inky blue with cyan highlights', s: [[14, 28, 48], [8, 16, 30], [4, 9, 17], [10, 20, 36]], bg: '#040A14', a: ['#3B82F6', '#22D3EE', '#38BDF8'] },
  aurora: { label: 'Aurora', note: 'Forest dark with emerald light', s: [[14, 32, 28], [8, 19, 16], [4, 10, 9], [10, 23, 20]], bg: '#040B09', a: ['#10B981', '#2DD4BF', '#A3E635'] },
  ember: { label: 'Ember', note: 'Warm charcoal, orange and gold', s: [[38, 22, 18], [21, 12, 10], [11, 6, 5], [27, 15, 12]], bg: '#0B0605', a: ['#F97316', '#FBBF24', '#FB7185'] },
  plum: { label: 'Plum', note: 'Dark berry with pink and lilac', s: [[36, 19, 42], [20, 10, 24], [10, 5, 12], [26, 13, 30]], bg: '#0A050C', a: ['#D946EF', '#A78BFA', '#F472B6'] },
  graphite: { label: 'Graphite', note: 'Soft grey, low contrast for long sessions', s: [[34, 37, 44], [24, 26, 31], [16, 17, 21], [28, 30, 36]], bg: '#121317', a: ['#94A3B8', '#7DD3FC', '#5EEAD4'] }
};
const ACCENTS = { '': 'Theme', '#8B5CF6': 'Violet', '#3B82F6': 'Blue', '#06B6D4': 'Cyan', '#14B8A6': 'Teal', '#10B981': 'Emerald', '#84CC16': 'Lime', '#F59E0B': 'Amber', '#F97316': 'Orange', '#F43F5E': 'Rose', '#EC4899': 'Pink', '#D946EF': 'Fuchsia', '#64748B': 'Slate' };
const FONTS = { inter: ['Inter', '"Inter", "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif'], system: ['System', 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif'], rounded: ['Rounded', '"Nunito", "Varela Round", "Segoe UI", system-ui, sans-serif'], serif: ['Serif', '"Source Serif Pro", Georgia, "Times New Roman", serif'], mono: ['Technical', '"JetBrains Mono", "Cascadia Code", Consolas, monospace'] };
const VIEWS = [['live', 'Live', 'activity'], ['apps', 'Apps', 'layers'], ['media', 'Videos & embeds', 'youtube'], ['community', 'Community', 'crown'], ['store', 'Store', 'tag'], ['promo', 'Promo', 'sparkles'], ['connectors', 'Connectors', 'plug'], ['site', 'Site settings', 'sliders']];
const TERMS = { donation: ['Donations', 'donation'], caffeine: ['Caffeine', 'caffeine'], coffee: ['Coffees', 'coffee'], tip: ['Tips', 'tip'], support: ['Support', 'support'] };
const ICONS = [['can', 'Energy drink'], ['coffee', 'Coffee'], ['heart', 'Heart'], ['star', 'Star'], ['gift', 'Gift'], ['rocket', 'Rocket'], ['crown', 'Crown']];
const LOCALES = [['', 'Same as this computer'], ['en-US', 'English (United States)'], ['en-GB', 'English (United Kingdom)'], ['en-AU', 'English (Australia)'], ['en-CA', 'English (Canada)'], ['de-DE', 'Deutsch'], ['fr-FR', 'Français'], ['es-ES', 'Español'], ['it-IT', 'Italiano'], ['nl-NL', 'Nederlands'], ['pt-BR', 'Português (Brasil)'], ['ja-JP', '日本語'], ['zh-CN', '中文 (简体)']];

// ---------- colour helpers ----------
const hexRgb = h => { const n = parseInt(String(h).slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
const rgbHex = c => '#' + c.map(v => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('').toUpperCase();
const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
// a family: base, light (+text on dark), lighter (soft text), dark (orbs)
const family = hex => { const c = hexRgb(hex); return { base: c, light: mix(c, [255, 255, 255], .28), lighter: mix(c, [255, 255, 255], .55), dark: mix(c, [0, 0, 0], .18) }; };

// The stylesheet is rewritten with the theme's colours: every violet, sky and teal tone, and every dark surface, maps to its
// counterpart in the chosen palette, so all screens (including ones added later) follow the theme with no per-screen CSS.
let cssSrc = null;
async function themeCss(p) {
  const t = THEMES[p.theme] || THEMES.midnight;
  const a = p.accent ? [p.accent, ...t.a.slice(1)] : t.a;
  if (p.theme === 'midnight' && !p.accent) return '';
  cssSrc ??= Promise.all(['/shared/showcase.css', '/ui/hub.css', '/ui/design.css'].map(u => fetch(u).then(r => r.text()))).then(x => x.join('\n'));
  let css = await cssSrc;
  const [pv, sv, tv] = a.map(family), M = THEMES.midnight;
  const rgb = c => c.map(Math.round).join(',');
  // design.css action slot (#2CCFBA): the chosen accent, else the theme's main colour; text on it is dark or white by luminance
  const act = hexRgb(p.accent || (p.theme === 'midnight' ? '#2CCFBA' : t.a[0]));
  const lum = act.map(v => { v /= 255; return v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; }).reduce((s, v, i) => s + v * [.2126, .7152, .0722][i], 0);
  const pairs = [
    [/#2CCFBA/gi, rgbHex(act)], [/44,\s*207,\s*186/g, rgb(act)], [/#A7F3E6/gi, rgbHex(mix(act, [255, 255, 255], .6))], [/#03211D/gi, lum > .28 ? rgbHex(mix(act, [0, 0, 0], .86)) : '#FFFFFF'],
    // accents (violet → primary, sky → secondary, teal → tertiary)
    [/#8B5CF6/gi, rgbHex(pv.base)], [/#A78BFA/gi, rgbHex(pv.light)], [/#C4B5FD/gi, rgbHex(pv.lighter)], [/#7C3AED/gi, rgbHex(pv.dark)], [/#818CF8/gi, rgbHex(pv.light)],
    [/139,\s*92,\s*246/g, rgb(pv.base)], [/167,\s*139,\s*250/g, rgb(pv.light)], [/124,\s*58,\s*237/g, rgb(pv.dark)],
    [/#38BDF8/gi, rgbHex(sv.base)], [/#7DD3FC/gi, rgbHex(sv.light)], [/#A5B4FC/gi, rgbHex(sv.lighter)], [/56,\s*189,\s*248/g, rgb(sv.base)],
    [/#2DD4BF/gi, rgbHex(tv.base)], [/#5EEAD4/gi, rgbHex(tv.light)], [/#99F6E4/gi, rgbHex(tv.lighter)], [/#14B8A6/gi, rgbHex(tv.dark)], [/45,\s*212,\s*191/g, rgb(tv.base)], [/20,\s*184,\s*166/g, rgb(tv.dark)],
    // surfaces
    ...M.s.map((c, i) => [new RegExp(c.join(',\\s*'), 'g'), t.s[i].join(',')]),
    [/#07080E/gi, t.bg], [/#0B0D16/gi, rgbHex(t.s[1])], [/#0F1220/gi, rgbHex(mix(t.s[1], t.s[0], .5))], [/#141829/gi, rgbHex(t.s[0])], [/#1A1F33/gi, rgbHex(mix(t.s[0], [255, 255, 255], .04))], [/#181C30/gi, rgbHex(mix(t.s[0], [255, 255, 255], .02))], [/#10131F/gi, rgbHex(t.s[3])], [/#0E1120/gi, rgbHex(t.s[3])]
  ];
  if (p.theme === 'midnight') pairs.splice(-(M.s.length + 8)); // accent only: keep the original surfaces
  for (const [re, v] of pairs) css = css.replace(re, v);
  return css;
}

// ---------- applying prefs (also used at start-up, from the cached copy) ----------
let localePatched = false;
export async function apply(p) {
  P = p; window.HUB_PREFS = p;
  try { localStorage.setItem(LS, JSON.stringify(p)); } catch {}
  const h = document.documentElement;
  h.style.setProperty('--font', (FONTS[p.font] || FONTS.inter)[1]);
  const z = p.scale && p.scale !== 100 ? p.scale / 100 : 1;
  document.body.style.zoom = z === 1 ? '' : z;
  h.style.setProperty('--z', String(z)); // hub.css divides viewport units by this so zoomed panels still fit the window
  h.dataset.motion = p.motion; h.dataset.gridlines = p.gridlines ? 'on' : 'off'; h.dataset.privacy = p.money?.privacy ? 'on' : 'off';
  h.style.setProperty('--glow', String((p.glow ?? 100) / 100));
  h.dataset.toast = p.toast || 'bottom-right';
  window.__toastScale = (p.toastMs || 3200) / 3200;
  for (const a of $$('#viewNav a')) a.hidden = (p.hidden || []).includes(a.dataset.view);
  let st = $('#themeCss'); if (!st) { st = document.createElement('style'); st.id = 'themeCss'; document.head.append(st); }
  st.textContent = await themeCss(p);
  if (!localePatched) patchLocale();
  privacyScan();
  startWatch();
}
// dates and numbers everywhere use the chosen format (calls that pass their own locale are untouched)
function patchLocale() {
  localePatched = true;
  const wrap = (proto, name) => { const orig = proto[name]; proto[name] = function (loc, opts) { const pr = window.HUB_PREFS || {}; if (loc === undefined && pr.locale) loc = pr.locale; if (pr.hour12 !== 'auto' && /Date|^toLocaleString$|Time/.test(name) && this instanceof Date) opts = { ...(opts || {}), ...((!opts || (!opts.timeStyle && !opts.dateStyle)) ? { hour12: pr.hour12 === '12' } : {}) }; return orig.call(this, loc, opts); }; };
  for (const n of ['toLocaleString', 'toLocaleDateString', 'toLocaleTimeString']) wrap(Date.prototype, n);
  wrap(Number.prototype, 'toLocaleString');
}
// privacy mode: money amounts and email addresses are blurred wherever they appear (hover to peek)
const MONEY = /((?:[A-Z]{1,3})?[$€£¥₹]\s?\d[\d,.\s]*\d|\d[\d,.]*\s?(?:AUD|USD|EUR|GBP|CAD|NZD))/g, EMAIL = /[\w.+-]+@[\w-]+\.[\w.-]+/g;
let obs = null;
function privacyScan() {
  const on = P?.money?.privacy;
  if (!on) { obs?.disconnect(); obs = null; return; }
  const walk = root => {
    const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: n => (n.parentElement && !n.parentElement.closest('script,style,textarea,input,.priv,#prefsPanel,#settingsPanel') && (MONEY.test(n.data) || EMAIL.test(n.data)) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT) });
    const list = []; while (tw.nextNode()) list.push(tw.currentNode);
    for (const n of list) { MONEY.lastIndex = EMAIL.lastIndex = 0; const span = document.createElement('span'); span.innerHTML = n.data.replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[c]).replace(MONEY, '<span class="priv">$1</span>').replace(EMAIL, m => `<span class="priv">${m}</span>`); n.replaceWith(...span.childNodes); }
  };
  walk(document.body);
  if (!obs) { obs = new MutationObserver(ms => { for (const m of ms) for (const n of m.addedNodes) if (n.nodeType === 1) walk(n); }); obs.observe(document.body, { childList: true, subtree: true }); }
}

// ---------- celebrating new sales and donations in the dashboard ----------
function startWatch() {
  clearInterval(watch);
  const m = P?.money || {};
  if (m.celebrate === 'off' && m.sound === 'off' && !m.notify) return;
  lastSeen = +localStorage.getItem('hub.lastSale') || Math.floor(Date.now() / 1000);
  const tick = async () => {
    let L; try { L = await api('GET', '/api/live'); } catch { return; }
    const fresh = (L.sales || []).filter(x => x.created > lastSeen && !(x.refunded >= x.amount)).sort((a, b) => a.created - b.created);
    if (!fresh.length) return;
    lastSeen = Math.max(...fresh.map(x => x.created)); localStorage.setItem('hub.lastSale', String(lastSeen));
    for (const x of fresh.slice(-3)) if ((x.amount || 0) / 100 >= (+m.minAmount || 0)) celebrate(x);
  };
  watch = setInterval(tick, 30000); setTimeout(tick, 4000);
}
const money = (amt, cur) => { try { return new Intl.NumberFormat(P?.locale || undefined, { style: 'currency', currency: String(cur || 'AUD').toUpperCase() }).format((amt || 0) / 100); } catch { return `${((amt || 0) / 100).toFixed(2)} ${cur}`; } };
export function celebrate(x, test = false) {
  const m = P?.money || {}, donation = x.donation ?? /caffeine|donat|tip|coffee|support/i.test(x.product || '');
  const t = (TERMS[m.term] || TERMS.donation)[1];
  const who = P?.money?.privacy ? 'Someone' : (x.name || 'Someone'), amt = P?.money?.privacy ? '' : money(x.amount, x.currency);
  const title = donation ? `New ${t}${amt ? `: ${amt}` : ''}` : `New sale${amt ? `: ${amt}` : ''}`;
  const body = donation ? `${who} sent a ${t}. Thank you!` : `${who} bought ${x.product || 'something'}.`;
  if (m.sound !== 'off') chime(m.sound, (m.volume ?? 60) / 100);
  if (m.notify && 'Notification' in window && Notification.permission === 'granted' && (document.hidden || test)) new Notification(title, { body, icon: '/ui/icon-256.png', silent: true });
  if (m.celebrate === 'off') return;
  const box = document.createElement('div'); box.className = `cel cel-${m.celebrate}`;
  box.innerHTML = `<div class="cel-card"><span class="cel-ico">${I(donation ? m.icon || 'can' : 'card')}</span><div><b>${esc(title)}</b><small>${esc(body)}${x.livemode === false && !test ? ' (test mode)' : ''}</small></div><button type="button" class="act" aria-label="Close">${I('x')}</button></div>`;
  if (m.celebrate === 'confetti' && P?.motion !== 'reduced') {
    const cols = ['--violet', '--sky', '--teal'].map(v => getComputedStyle(document.documentElement).getPropertyValue(v).trim() || '#A78BFA').concat('#FBBF24', '#FB7185');
    for (let i = 0; i < 70; i++) { const c = document.createElement('i'); c.style.cssText = `left:${Math.random() * 100}%;background:${cols[i % cols.length]};animation-delay:${Math.random() * .4}s;animation-duration:${1.8 + Math.random() * 1.4}s;--dx:${(Math.random() - .5) * 220}px;--r:${Math.random() * 720}deg`; box.append(c); }
  }
  document.body.append(box);
  box.querySelector('button').onclick = () => box.remove();
  setTimeout(() => box.classList.add('out'), 6500); setTimeout(() => box.remove(), 7200);
}
// small synthesized sounds (no audio files)
function chime(kind, vol) {
  try {
    const ac = new (window.AudioContext || window.webkitAudioContext)(), now = ac.currentTime, g = ac.createGain(); g.connect(ac.destination); g.gain.value = .0001;
    const notes = kind === 'cash' ? [[1318.5, 0], [1760, .07], [2637, .14]] : kind === 'soft' ? [[523.25, 0], [659.25, .16]] : [[880, 0], [1174.66, .12], [1567.98, .24]];
    for (const [f, d] of notes) { const o = ac.createOscillator(), og = ac.createGain(); o.type = kind === 'cash' ? 'triangle' : 'sine'; o.frequency.value = f; o.connect(og); og.connect(ac.destination); og.gain.setValueAtTime(.0001, now + d); og.gain.exponentialRampToValueAtTime(.25 * vol, now + d + .02); og.gain.exponentialRampToValueAtTime(.0001, now + d + (kind === 'soft' ? .9 : .5)); o.start(now + d); o.stop(now + d + 1); }
    setTimeout(() => ac.close(), 1600);
  } catch {}
}

// ---------- start-up ----------
export function boot() {
  let cached = null; try { cached = JSON.parse(localStorage.getItem(LS) || 'null'); } catch {}
  if (cached) apply(cached);
  // keyboard shortcuts off: single-key shortcuts outside text fields are swallowed before the dashboard sees them
  addEventListener('keydown', e => {
    if (e.key === 'P' && e.shiftKey && !e.ctrlKey && !e.altKey && !isEditable(e.target)) { e.preventDefault(); e.stopImmediatePropagation(); savePrefs({ money: { ...P.money, privacy: !P.money.privacy } }).then(() => toast(P.money.privacy ? 'Privacy mode on: money and emails are blurred' : 'Privacy mode off', 'info')); return; }
    if (P && P.shortcuts === false && !e.ctrlKey && !e.metaKey && !e.altKey && e.key.length === 1 && !isEditable(e.target)) e.stopImmediatePropagation();
  }, true);
  api('GET', '/api/prefs').then(r => { D = r.defaults; apply(r.prefs); }).catch(() => {});
}
const isEditable = t => t && (t.isContentEditable || /^(input|textarea|select)$/i.test(t.tagName));

// ---------- the page ----------
export function init(opts = {}) {
  account = opts.account || null;
  const root = $('#prefsPanel');
  $('#setTabs')?.addEventListener('click', e => { const b = e.target.closest('[data-set]'); if (b) location.hash = '#/settings/' + b.dataset.set; });
  root.addEventListener('click', onClick); root.addEventListener('input', onInput); root.addEventListener('change', onInput);
}
export async function show(sub) {
  const TABS = ['account', 'appearance', 'dashboard', 'money', 'region', 'phone', 'data'];
  let accSub;
  if (sub && !TABS.includes(sub) && account) { accSub = sub; sub = 'account'; } // e.g. #/settings/github or /license from other screens
  tab = TABS.includes(sub) ? sub : (account ? 'account' : 'appearance');
  if (tab === 'account' && !account) tab = 'appearance';
  $$('#setTabs [data-set]').forEach(b => b.classList.toggle('on', b.dataset.set === tab));
  const accEl = $('#settingsPanel');
  if (accEl) accEl.hidden = tab !== 'account';
  $('#prefsPanel').hidden = tab === 'account';
  if (tab === 'account') return account(accSub);
  if (tab === 'phone') return Phone.show($('#prefsPanel')); // Settings → Phone access (phone.js)
  if (!P || !D) { const r = await api('GET', '/api/prefs'); D = r.defaults; await apply(r.prefs); }
  if (tab === 'data') B = await api('GET', '/api/backups').catch(() => null);
  render();
}
const sw = (k, on, label, hint = '') => `<label class="switch"><input type="checkbox" data-p="${k}"${on ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">${esc(label)}${hint ? `<small>${esc(hint)}</small>` : ''}</span></label>`;
const seg = (k, v, opts) => `<div class="seg wide">${opts.map(([val, l]) => `<button type="button" data-ps="${k}" data-v="${esc(val)}" class="${String(v) === String(val) ? 'on' : ''}">${esc(l)}</button>`).join('')}</div>`;
const sel = (k, v, opts) => `<select data-p="${k}">${opts.map(([val, l]) => `<option value="${esc(val)}"${String(v) === String(val) ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
const card = (icon, title, body, sub = '') => `<div class="card set-card"><h3>${I(icon)}${esc(title)}</h3>${sub ? `<p class="sub">${sub}</p>` : ''}${body}</div>`;

function render() {
  const root = $('#prefsPanel'), p = P, m = p.money || {};
  if (tab === 'appearance') root.innerHTML = `<div class="set-grid">
    ${card('palette', 'Theme', `<div class="set-themes">${Object.entries(THEMES).map(([k, t]) => `<button type="button" class="set-theme${p.theme === k ? ' on' : ''}" data-ps="theme" data-v="${k}" style="--b:${t.bg};--s:rgb(${t.s[0].join(',')});--a1:${t.a[0]};--a2:${t.a[1]};--a3:${t.a[2]}"><span class="st-sw"><i></i><i></i><i></i></span><b>${esc(t.label)}</b><small>${esc(t.note)}</small></button>`).join('')}</div>`, 'Recolours the whole dashboard: backgrounds, cards, buttons, highlights and charts.')}
    ${card('sparkle', 'Accent colour', `<div class="set-acc">${Object.entries(ACCENTS).map(([hex, l]) => `<button type="button" class="${(p.accent || '') === hex ? 'on' : ''}" data-ps="accent" data-v="${hex}" title="${esc(l)}" style="--c:${hex || (THEMES[p.theme] || THEMES.midnight).a[0]}">${hex ? '' : I('refresh')}</button>`).join('')}<label class="set-custom" title="Any colour"><input type="color" data-p="accent" value="${esc(p.accent || (THEMES[p.theme] || THEMES.midnight).a[0])}"><span>Custom</span></label></div>`, 'The main highlight colour: primary buttons, selected items and focus rings. “Theme” uses the theme’s own.')}
    ${card('edit', 'Text & size', `<div class="fld"><span>Font</span>${seg('font', p.font, Object.entries(FONTS).map(([k, [l]]) => [k, l]))}</div>
      <label class="fld"><span>Interface size <small>${p.scale}%</small></span><input type="range" min="80" max="125" step="5" data-p="scale" value="${p.scale}"></label>
      <div class="row">${[90, 100, 110].map(v => `<button type="button" class="hbtn ghost sm" data-ps="scale" data-v="${v}">${v === 90 ? 'Compact' : v === 100 ? 'Default' : 'Large'}</button>`).join('')}</div>`)}
    ${card('layers', 'Background & motion', `<label class="fld"><span>Glow <small>${p.glow}%</small></span><input type="range" min="0" max="160" step="10" data-p="glow" value="${p.glow}"></label>
      ${sw('gridlines', p.gridlines, 'Faint grid behind the dashboard')}
      <div class="fld"><span>Motion</span>${seg('motion', p.motion, [['full', 'Full'], ['reduced', 'Reduced']])}<small class="muted">Reduced turns off animations and transitions, and confetti.</small></div>`)}
    <div class="card set-card set-preview">${previewMock()}</div>
  </div>`;
  if (tab === 'dashboard') root.innerHTML = `<div class="set-grid">
    ${card('home', 'Start page', `<div class="set-views">${VIEWS.filter(([k]) => !(p.hidden || []).includes(k)).map(([k, l, ic]) => `<button type="button" class="${p.start === k ? 'on' : ''}" data-ps="start" data-v="${k}">${I(ic)}${esc(l)}</button>`).join('')}</div>`, 'Where the dashboard opens.')}
    ${card('eye', 'Tabs', `<div class="set-tabs">${VIEWS.map(([k, l, ic]) => `<label class="switch"><input type="checkbox" data-hide="${k}"${(p.hidden || []).includes(k) ? '' : ' checked'}${k === p.start ? ' disabled' : ''}><span class="track"><i></i></span><span class="sw-lbl">${I(ic)} ${esc(l)}${k === p.start ? '<small>start page</small>' : ''}</span></label>`).join('')}</div>`, 'Hide tabs you don’t use. They keep working in the background, and links to them still open them.')}
    ${card('bell', 'Notifications', `<div class="fld"><span>Where</span>${seg('toast', p.toast, [['bottom-right', 'Bottom right'], ['bottom-left', 'Bottom left'], ['top-right', 'Top right'], ['bottom-center', 'Bottom centre']])}</div>
      <div class="fld"><span>How long</span>${seg('toastMs', p.toastMs, [[2200, 'Short'], [3200, 'Normal'], [5500, 'Long'], [9000, 'Very long']])}</div>
      <button type="button" class="hbtn ghost sm" data-test="toast">${I('bell')}Show an example</button>`)}
    ${card('key', 'Keyboard', `${sw('shortcuts', p.shortcuts !== false, 'Single-key shortcuts', 'N new app · / search · Shift+P privacy mode (always on)')}`)}
  </div>`;
  if (tab === 'money') root.innerHTML = `<div class="set-grid">
    ${card('sparkles', 'When money comes in', `<div class="fld"><span>Celebrate it</span>${seg('money.celebrate', m.celebrate, [['confetti', 'Confetti'], ['glow', 'Glowing card'], ['quiet', 'Quiet card'], ['off', 'Off']])}</div>
      <div class="fld"><span>Sound</span>${seg('money.sound', m.sound, [['chime', 'Chime'], ['cash', 'Till'], ['soft', 'Soft'], ['off', 'Off']])}</div>
      ${m.sound !== 'off' ? `<label class="fld"><span>Volume <small>${m.volume}%</small></span><input type="range" min="5" max="100" step="5" data-p="money.volume" value="${m.volume}"></label>` : ''}
      ${sw('money.notify', m.notify, 'Desktop notification when the dashboard is in the background', 'Your browser asks for permission once')}
      <label class="fld"><span>Only for amounts from</span><input type="number" min="0" step="1" data-p="money.minAmount" value="${m.minAmount || 0}"></label>
      <div class="row"><button type="button" class="hbtn primary sm" data-test="sale">${I('card')}Try a sale</button><button type="button" class="hbtn ghost sm" data-test="donation">${I(m.icon || 'can')}Try a ${esc((TERMS[m.term] || TERMS.donation)[1])}</button></div>`, 'Shown wherever you are in the dashboard, within 30 seconds of the payment reaching Stripe.')}
    ${card('heart', 'Donation style', `<div class="fld"><span>Call them</span>${seg('money.term', m.term, Object.entries(TERMS).map(([k, [l]]) => [k, l]))}</div>
      <div class="fld"><span>Icon</span><div class="set-icons">${ICONS.map(([k, l]) => `<button type="button" class="${m.icon === k ? 'on' : ''}" data-ps="money.icon" data-v="${k}" title="${esc(l)}">${I(k)}</button>`).join('')}</div></div>
      <div class="set-celprev"><span class="cel-ico">${I(m.icon || 'can')}</span><div><b>New ${esc((TERMS[m.term] || TERMS.donation)[1])}: ${esc(money(500, 'AUD'))}</b><small>Alex sent a ${esc((TERMS[m.term] || TERMS.donation)[1])}. Thank you!</small></div></div>`, 'How donations look in the dashboard’s alerts. Your website’s button is set in Community.')}
    ${card('eyeoff', 'Privacy mode', `${sw('money.privacy', m.privacy, 'Blur money and email addresses everywhere in the dashboard', 'Hover over a blurred value to peek. Toggle any time with Shift+P')}`, 'For streaming, screen-sharing and recording tutorials.')}
  </div>`;
  if (tab === 'region') {
    const now = new Date(), loc = p.locale || undefined;
    root.innerHTML = `<div class="set-grid">
    ${card('globe', 'Dates & numbers', `<label class="fld"><span>Format</span>${sel('locale', p.locale, LOCALES)}</label>
      <div class="fld"><span>Clock</span>${seg('hour12', p.hour12, [['auto', 'Automatic'], ['12', '12-hour'], ['24', '24-hour']])}</div>
      <div class="kv"><span>Date</span><b>${esc(now.toLocaleDateString(loc, { dateStyle: 'full' }))}</b><span>Time</span><b>${esc(now.toLocaleTimeString(loc, p.hour12 === 'auto' ? {} : { hour12: p.hour12 === '12' }))}</b><span>Number</span><b>${esc((1234567.89).toLocaleString(loc))}</b><span>Money</span><b>${esc(money(1999, 'AUD'))}</b></div>`, 'Used for every date, time and number in the dashboard. Emails and your website keep their own formats.')}
  </div>`;
  }
  if (tab === 'data') {
    const b = B || {};
    root.innerHTML = `<div class="set-grid">
    ${card('folder', 'Where your data lives', `<div class="st-url"><code>${esc(b.dataDir || '')}</code><button type="button" class="act" data-act="open" title="Open the folder">${I('folder')}</button><button type="button" class="act" data-copy="${esc(b.dataDir || '')}" title="Copy">${I('copy')}</button></div>
      <div class="set-files">${(b.files || []).map(f => `<span><b>${esc(f.file)}</b><small>${size(f.size)} · ${esc(rel(new Date(f.at).toISOString()))}</small></span>`).join('')}</div>`)}
    ${card('download', 'Full backup', `<p class="sub">One file with your apps, website settings, supporters, connectors, perks and preferences. Keep it somewhere safe; restore it here or on a new computer.</p>
      ${sw('secrets', false, 'Include keys and passwords', 'Only if you store the file somewhere private')}
      <div class="row"><button type="button" class="hbtn primary sm" data-act="bundle">${I('download')}Download backup</button><label class="hbtn ghost sm set-file">${I('upload')}Restore from a file<input type="file" accept=".json,application/json" data-restore hidden></label></div>`)}
    ${card('refresh', 'Automatic copies', `<p class="sub">Every time something is saved, the previous version of that file is kept. ${b.count ? `${b.count} copies (${size(b.size)}), the newest ${esc(rel(new Date(b.latest).toISOString()))}.` : 'None yet.'}</p>
      <label class="fld"><span>Keep per file <small>${p.keepBackups}</small></span><input type="range" min="5" max="100" step="5" data-p="keepBackups" value="${p.keepBackups}"></label>
      ${(b.recent || []).length ? `<div class="set-files">${b.recent.slice(0, 6).map(x => `<span><b>${esc(x.of)}</b><small>${size(x.size)} · ${esc(rel(new Date(x.at).toISOString()))}</small></span>`).join('')}</div>` : ''}`)}
    ${card('sliders', 'Reset', `<p class="sub">Put every setting on this page back to how it came. Your apps, website and accounts aren’t touched.</p><button type="button" class="hbtn ghost sm danger" data-act="reset">${I('refresh')}Reset dashboard settings</button>`)}
  </div>`;
  }
}
const size = n => (n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB');
function previewMock() {
  return `<h3>${I('eye')}Preview</h3><div class="set-mock"><div class="sm-nav"><b>Dashboard</b><span class="on">Live</span><span>Apps</span><span>Store</span></div>
    <div class="sm-body"><div class="sm-tile"><small>REVENUE</small><b>${esc(money(48250, 'AUD'))}</b></div><div class="sm-tile"><small>SUPPORTERS</small><b>128</b></div>
    <div class="sm-row"><button type="button" class="hbtn primary sm" tabindex="-1">${I('rocket')}Publish</button><button type="button" class="hbtn ghost sm" tabindex="-1">Preview</button><label class="switch"><input type="checkbox" checked tabindex="-1"><span class="track"><i></i></span></label></div>
    <div class="seg"><button type="button" class="on" tabindex="-1">Selected</button><button type="button" tabindex="-1">Other</button></div><span class="dc-pill violet">${I('sparkle')}Highlight</span></div></div>`;
}

// ---------- events ----------
const setPath = (o, path, v) => { const ks = path.split('.'); const out = structuredClone(o); let x = out; for (const k of ks.slice(0, -1)) x = x[k] ||= {}; x[ks.at(-1)] = v; return out; };
let saveTimer = null;
async function savePrefs(patch, { quiet = true } = {}) {
  const next = { ...P, ...patch, money: { ...P.money, ...(patch.money || {}) } };
  await apply(next);
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => api('PUT', '/api/prefs', { prefs: next }).then(r => { if (!quiet) toast('Saved'); P = r.prefs; }).catch(e => toast(e.message, 'err')), 350);
}
async function setKey(path, v) {
  const next = setPath(P, path, v);
  if (path === 'money.notify' && v && 'Notification' in window && Notification.permission !== 'granted') {
    const r = await Notification.requestPermission(); if (r !== 'granted') { toast('The browser blocked notifications. Allow them in the site settings of your browser.', 'err', 8000); render(); return; }
  }
  await savePrefs(next);
  if (['theme', 'accent', 'font', 'motion', 'money.celebrate', 'money.sound', 'money.term', 'money.icon', 'locale', 'hour12', 'start', 'toast', 'toastMs'].includes(path) || path.startsWith('scale')) render();
}
async function onClick(e) {
  const b = e.target.closest('button, [data-copy]'); if (!b) return;
  try {
    if (b.dataset.copy) { await navigator.clipboard.writeText(b.dataset.copy); toast('Copied'); return; }
    if (b.dataset.ps) { const k = b.dataset.ps, raw = b.dataset.v; await setKey(k, ['scale', 'toastMs'].includes(k) ? +raw : raw); return; }
    if (b.dataset.test === 'toast') { toast('This is how notifications look.', 'info', 3200); return; }
    if (b.dataset.test === 'sale') { celebrate({ name: 'Alex Example', product: S.apps?.find(a => a.published)?.name || 'Your app', amount: 1999, currency: 'aud', donation: false, livemode: true }, true); return; }
    if (b.dataset.test === 'donation') { celebrate({ name: 'Alex Example', product: 'Donation', amount: 500, currency: 'aud', donation: true, livemode: true }, true); return; }
    if (b.dataset.act === 'open') { await api('POST', '/api/open', { target: B.dataDir }); return; }
    if (b.dataset.act === 'bundle') {
      const secrets = $('#prefsPanel [data-p="secrets"]')?.checked;
      const data = await api('GET', '/api/backups/bundle' + (secrets ? '?secrets=1' : ''));
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
      a.download = `backup-${new Date().toISOString().slice(0, 10)}${secrets ? '-with-keys' : ''}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      toast(`Backup downloaded (${Object.keys(data.files).length} files)`); return;
    }
    if (b.dataset.act === 'reset') { if (!(await confirmBox('Reset dashboard settings?', 'Theme, start page, tabs, notifications, donation style and formats go back to the defaults.', 'Reset'))) return; const r = await api('POST', '/api/prefs/reset'); await apply(r.prefs); render(); toast('Dashboard settings reset'); return; }
  } catch (x) { toast(x.message, 'err', 8000); }
}
async function onInput(e) {
  const t = e.target;
  if (t.dataset.restore !== undefined && e.type === 'change') return restore(t);
  if (t.dataset.hide && e.type === 'change') { const hidden = new Set(P.hidden || []); t.checked ? hidden.delete(t.dataset.hide) : hidden.add(t.dataset.hide); await savePrefs({ hidden: [...hidden] }); render(); return; }
  const k = t.dataset.p; if (!k || k === 'secrets') return;
  let v = t.type === 'checkbox' ? t.checked : t.type === 'range' || t.type === 'number' ? +t.value : t.value;
  if (t.type === 'range') { const lbl = t.closest('label')?.querySelector('small'); if (lbl) lbl.textContent = v + (k === 'keepBackups' ? '' : '%'); if (e.type === 'input' && k !== 'scale' && k !== 'glow') return; }
  if (k === 'scale' && e.type === 'input') return; // apply on release, so the slider doesn't jump under the pointer
  await setKey(k, v);
}
async function restore(input) {
  const f = input.files?.[0]; input.value = ''; if (!f) return;
  try {
    const bundle = JSON.parse(await f.text());
    const n = Object.keys(bundle.files || {}).length;
    if (!(await confirmBox('Restore this backup?', `${n} files from ${bundle.created ? new Date(bundle.created).toLocaleString() : 'the backup'} replace the current ones. The current versions are kept as automatic copies first.${bundle.secrets ? ' It includes keys and passwords.' : ''}`, 'Restore'))) return;
    const r = await api('POST', '/api/backups/restore', { bundle });
    toast(`Restored ${r.restored.length} files. Reloading…`, 'ok', 3000);
    setTimeout(() => location.reload(), 1500);
  } catch (x) { toast(x.message || 'That file couldn’t be read.', 'err', 8000); }
}
