// Settings → Phone access: switch phone/tablet access on or off, show the pairing code and addresses, and manage
// paired devices. Talks to /api/lan (lan.mjs). Polls every 5 s only while this tab is on screen, and stops its timer the
// moment you leave it, so nothing runs in the background.
import { R, $, esc, api, toast, confirmBox, rel } from './core.js';

const I = n => R.icon(n);
let st = null, root = null, timer = 0, bound = false, busy = false;

const onScreen = () => !!root && root.isConnected && !root.hidden && location.hash.startsWith('#/settings/phone') && document.visibilityState === 'visible';
function stop() { clearInterval(timer); timer = 0; }
function poll() {
  stop();
  timer = setInterval(async () => {
    if (!onScreen()) return stop();
    try { const next = await api('GET', '/api/lan'); if (JSON.stringify(next) !== JSON.stringify(st)) { st = next; render(); } } catch { /* keep the last view */ }
  }, 5000);
}

export async function show(el) {
  root = el;
  if (!bound) { root.addEventListener('click', onClick); root.addEventListener('change', onChange); document.addEventListener('visibilitychange', () => { if (onScreen() && !timer) poll(); }); bound = true; }
  root.innerHTML = `<div class="card lv-loading"><span class="spinner"></span>Checking phone access…</div>`;
  try { st = await api('GET', '/api/lan'); } catch (e) { root.innerHTML = `<div class="card"><p class="bad">${esc(e.message)}</p></div>`; return; }
  render(); poll();
}

function render() {
  if (!root || !st) return;
  const on = st.enabled, live = on && st.listening;
  const digits = (st.code || '').split('');
  root.innerHTML = `<div class="ph-grid">
    <section class="card ph-main" aria-labelledby="phTitle">
      <div class="ph-head">
        <span class="ph-ico" aria-hidden="true">${I('phone')}</span>
        <div><h3 id="phTitle">Phone access</h3><p class="sub">Use Pylerium Manager from a phone or tablet on the same Wi-Fi. Every device pairs once with a code, and only devices on your own network can connect.</p></div>
        <label class="switch big ph-switch"><input type="checkbox" data-ph="toggle"${on ? ' checked' : ''}${busy ? ' disabled' : ''}><span class="track"><i></i></span><span class="sw-lbl">${on ? 'On' : 'Off'}</span></label>
      </div>
      ${!on ? `<div class="ph-off">${I('lock')}<span>Off. Pylerium Manager only answers this computer.</span></div>` : st.error ? `<div class="ph-err" role="alert">${I('alert')}<span>${esc(st.error)}</span><button type="button" class="hbtn ghost sm" data-ph="retry">${I('refresh')}Try again</button></div>` : ''}
      ${live ? `<ol class="ph-steps">
        <li><b>Open this address on your phone</b>
          <div class="ph-links">${st.links.map(u => `<div class="ph-link"><code>${esc(u)}</code><button type="button" class="act" data-ph-copy="${esc(u)}" aria-label="Copy ${esc(u)}" title="Copy">${I('copy')}</button></div>`).join('')}</div></li>
        <li><b>Enter this pairing code</b>
          <div class="ph-code" aria-label="Pairing code ${digits.join(' ')}" role="img">${digits.map(d => `<span>${esc(d)}</span>`).join('')}</div>
          <div class="row"><button type="button" class="hbtn ghost sm" data-ph-copy="${esc(st.code)}">${I('copy')}Copy code</button><button type="button" class="hbtn ghost sm" data-ph="rotate">${I('refresh')}New code</button></div>
          <small class="muted">A new code doesn’t sign out devices that are already paired.</small></li>
      </ol>
      <p class="ph-note">${I('info')}<span>The first time, Windows may ask whether Pylerium Manager can use private networks. Choose <b>Allow</b>.</span></p>` : ''}
    </section>
    <section class="card ph-devices" aria-labelledby="phDevTitle">
      <div class="card-head"><h3 id="phDevTitle">${I('wifi')}Paired devices</h3>${st.devices.length ? `<button type="button" class="hbtn ghost sm" data-ph="signout">${I('signout')}Sign out all</button>` : ''}</div>
      ${st.devices.length ? `<ul class="ph-dev-list">${st.devices.map(d => `<li><span class="ph-dev-ico" aria-hidden="true">${I('phone')}</span><div><b>${esc(d.device)}</b><small>${esc(d.ip)} · paired ${esc(rel(d.at))}</small></div><time class="muted" datetime="${esc(d.expires)}">until ${esc(new Date(d.expires).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }))}</time></li>`).join('')}</ul>`
        : `<div class="emptystate">${I('phone')}<h4>No devices yet</h4><p>${on ? 'Paired phones and tablets show up here. They stay signed in for 12 hours.' : 'Switch on phone access to pair a device.'}</p></div>`}
      <small class="muted ph-foot">Restarting Pylerium Manager signs every device out and makes a new code.</small>
    </section>
  </div>`;
}

async function act(fn, done) {
  if (busy) return; busy = true;
  try { st = await fn(); render(); if (done) toast(done); }
  catch (e) { toast(e.message, 'err'); }
  finally { busy = false; render(); }
}
function onChange(e) {
  const t = e.target.closest('[data-ph="toggle"]'); if (!t) return;
  const want = t.checked;
  act(() => api('PUT', '/api/lan', { enabled: want }), want ? 'Phone access is on' : 'Phone access is off');
}
async function onClick(e) {
  const c = e.target.closest('[data-ph-copy]');
  if (c) { try { await navigator.clipboard.writeText(c.dataset.phCopy); toast('Copied'); } catch { toast('Couldn’t copy. Select the text instead.', 'err'); } return; }
  const b = e.target.closest('[data-ph]'); if (!b) return;
  const k = b.dataset.ph;
  if (k === 'rotate') return act(() => api('POST', '/api/lan/rotate'), 'New pairing code ready');
  if (k === 'retry') return act(() => api('PUT', '/api/lan', { enabled: true }));
  if (k === 'signout') {
    if (!(await confirmBox('Sign out every device?', 'Paired phones and tablets will need the pairing code again.', 'Sign out all'))) return;
    return act(() => api('POST', '/api/lan/signout'), 'All devices signed out');
  }
}
