// Store → Email list: ask for an email before a download. Sets up the small Cloudflare service, picks which apps ask,
// and shows (searches, exports, deletes) the emails it collected. Server side: gate.mjs.
import { R, S, MEDIA, $, esc, api, toast, confirmBox, rel, emit, refreshStatus } from './core.js';

const I = n => R.icon(n);
const CF_TOKEN_URL = 'https://dash.cloudflare.com/profile/api-tokens';
const PAGE = 100;

let G = null, error = '', loading = false;
let leads = null, leadsError = '', leadsLoading = false;
let busy = '';                                       // 'cf' | 'deploy' | 'test' | 'settings'
let token = '';                                      // survives re-renders while typing
const saving = new Set();                            // app ids whose switch is being saved
const filter = { q: '', app: '', updates: false, shown: PAGE };

export function init() {
  const panel = $('#leadsPanel');
  panel.addEventListener('click', onClick);
  panel.addEventListener('change', onChange);
  panel.addEventListener('submit', onSubmit);
  panel.addEventListener('input', e => {
    if (e.target.id === 'ldQ') { filter.q = e.target.value; filter.shown = PAGE; renderRows(); }
    if (e.target.id === 'ldToken') token = e.target.value;
  });
}
export async function show() {
  if (loading) return; loading = true; error = '';
  if (!G) render();
  try { G = await api('GET', '/api/gate'); } catch (e) { error = e.message; }
  loading = false; render();
  if (G?.worker) loadLeads();
}
async function loadLeads() {
  if (leadsLoading) return; leadsLoading = true; leadsError = ''; renderList();
  try { leads = (await api('GET', '/api/gate/leads')).leads || []; } catch (e) { leadsError = e.message; }
  leadsLoading = false; renderList();
}

// ---------- render ----------
function render() {
  const panel = $('#leadsPanel');
  if (!G) {
    panel.innerHTML = error
      ? `<div class="card"><p class="note lock"><span>${I('alert')}</span>${esc(error)}</p><div class="row"><button type="button" class="hbtn ghost sm" data-ld="reload">${I('refresh')}Try again</button></div></div>`
      : `<div class="card lv-loading"><span class="spinner"></span>Loading the email list…</div>`;
    return;
  }
  const focus = document.activeElement?.closest?.('#leadsPanel') ? document.activeElement.id : '';
  panel.innerHTML = `<div class="st-grid">
    <div class="st-main">${G.worker ? '' : setupCard()}${appsCard()}${G.worker ? '<section class="card ld-list" id="ldList"></section>' : ''}</div>
    <div class="st-side">${G.worker ? serviceCard() : ''}${wordsCard()}${howCard()}</div>
  </div>`;
  renderList();
  if (focus) document.getElementById(focus)?.focus({ preventScroll: true });
}
function setupCard() {
  const connected = G.cloudflare.connected;
  const step = (n, done, title, body, on) => `<div class="pd-step${done ? ' done' : ''}${on ? ' on' : ''}"><span class="pd-num">${done ? I('check') : n}</span><div class="pd-sbody"><div class="pd-shead"><b>${title}</b></div>${on ? body : ''}</div></div>`;
  return `<section class="card"><h3>${I('mail')}Set up email-to-download</h3>
    <p class="sub">Two steps, once. Emails are collected by a small service in your own free Cloudflare account.</p>
    <div class="pd-steps">
      ${step(1, connected, connected ? `Cloudflare connected${G.cloudflare.accountName ? `: ${esc(G.cloudflare.accountName)}` : ''}` : 'Connect Cloudflare', `
        <ol class="pd-list"><li>No account yet? <a href="https://dash.cloudflare.com/sign-up/workers" target="_blank" rel="noopener">Sign up free</a> and confirm your email address.</li>
          <li><a class="hbtn ghost sm" href="${CF_TOKEN_URL}" target="_blank" rel="noopener">${I('external')}Open Cloudflare API tokens</a> Press <b>Create Token</b>, then <b>Use template</b> next to <b>Edit Cloudflare Workers</b>.</li>
          <li>Pick your account under <b>Account Resources</b>, create the token, and paste it here.</li></ol>
        <form class="inrow" data-ld-form="cf"><input id="ldToken" name="token" type="password" class="mono" autocomplete="off" spellcheck="false" placeholder="Cloudflare API token" aria-label="Cloudflare API token" value="${esc(token)}" required>
          <button type="submit" class="hbtn primary"${busy ? ' disabled' : ''}>${busy === 'cf' ? '<span class="spinner"></span>Connecting…' : `${I('check')}Connect`}</button></form>`, !connected)}
      ${step(2, false, 'Start the email service', `<p class="sub">Puts the service live at a free <code>workers.dev</code> address.</p>
        <div class="row"><button type="button" class="hbtn primary" data-ld="deploy"${busy ? ' disabled' : ''}>${busy === 'deploy' ? '<span class="spinner"></span>Setting up… this can take a minute' : `${I('rocket')}Start the service`}</button></div>`, connected)}
    </div></section>`;
}
function appsCard() {
  const on = G.apps.filter(a => a.gate).length;
  const rows = G.apps.map(a => {
    const note = !a.target ? 'No download link yet. Add the main button link in Apps.'
      : a.gate && !a.repoPrivate && /github\.com/i.test(a.target) ? 'The GitHub page is still public to anyone who finds it. A private repository or a direct file keeps it behind the email.'
      : a.gate && !G.worker ? 'Stays open until the email service is started.'
      : a.published ? hostOf(a.target) : `Draft · ${hostOf(a.target)}`;
    const warn = a.gate && (!G.worker || (!a.repoPrivate && /github\.com/i.test(a.target)));
    return `<li class="ld-app${a.gate ? ' on' : ''}">
      <span class="ld-ico">${a.iconImage ? `<img src="${esc(R.media(a.iconImage, MEDIA))}" alt="">` : I(a.glyph || 'package')}</span>
      <span class="ld-name"><b>${esc(a.name)}</b><small class="${warn ? 'warn' : ''}" id="ldNote-${esc(a.id)}">${esc(note)}</small></span>
      <label class="switch"><input type="checkbox" id="ldApp-${esc(a.id)}" data-ld-app="${esc(a.id)}"${a.gate ? ' checked' : ''}${(!a.target && !a.gate) || saving.has(a.id) ? ' disabled' : ''} aria-describedby="ldNote-${esc(a.id)}"><span class="track"><i></i></span><span class="vh">Ask for an email before downloading ${esc(a.name)}</span></label></li>`;
  }).join('');
  return `<section class="card"><div class="card-head"><h3>${I('lock')}Which apps ask for an email</h3><span class="ld-count">${on} of ${G.apps.length} on</span></div>
    <p class="sub">Visitors enter an email before that app’s download starts. Publish your site after changing this.</p>
    ${G.apps.length ? `<ul class="ld-apps">${rows}</ul>` : `<p class="empty-sm">${I('package')}Add an app first, then choose it here.</p>`}</section>`;
}
function serviceCard() {
  const w = G.worker, old = w.version !== G.latestVersion;
  return `<section class="card"><h3>${I('shield')}Email service</h3>
    <p class="ld-url"><a href="${esc(w.url)}/health" target="_blank" rel="noopener">${esc(w.url.replace(/^https?:\/\//, ''))}</a></p>
    ${old ? `<p class="note lock"><span>${I('alert')}</span>A newer version of the service is ready. Press Update service.</p>` : G.pending ? `<p class="note lock"><span>${I('alert')}</span>Your latest download links haven’t reached the service. Press Check connection.</p>` : `<p class="note"><span>${I('check')}</span>Download links are up to date.</p>`}
    <div class="row"><button type="button" class="hbtn ghost sm" data-ld="test"${busy ? ' disabled' : ''}>${busy === 'test' ? '<span class="spinner"></span>Checking…' : `${I('refresh')}Check connection`}</button>
      <button type="button" class="hbtn ${old ? 'primary' : 'ghost'} sm" data-ld="deploy"${busy ? ' disabled' : ''}>${busy === 'deploy' ? '<span class="spinner"></span>Updating…' : `${I('upload')}Update service`}</button></div></section>`;
}
function wordsCard() {
  return `<form class="card" data-ld-form="words"><h3>${I('edit')}What visitors read</h3>
    <label class="fld"><span>Privacy line <small>under the email box</small></span><textarea id="ldNoteText" name="note" rows="3" maxlength="300">${esc(G.note)}</textarea></label>
    <label class="fld"><span>Updates checkbox <small>leave empty to hide it</small></span><input id="ldUpdates" name="updatesText" maxlength="100" value="${esc(G.updatesText)}"></label>
    <div class="row"><button type="submit" class="hbtn ghost sm"${busy ? ' disabled' : ''}>${I('check')}Save wording</button></div></form>`;
}
function howCard() {
  return `<section class="card"><h3>${I('info')}How it works</h3>
    <ul class="ld-how"><li>The download address of a gated app is left off your public website.</li><li>A visitor enters an email and gets a link that works for 30 minutes.</li><li>Addresses are not verified, so someone can type one that isn’t theirs.</li><li>Only email people about news if they ticked the updates box, and delete anyone who asks.</li></ul></section>`;
}
const hostOf = url => { try { return new URL(url).host.replace(/^www\./, ''); } catch { return url; } };
const appName = id => G.apps.find(a => a.id === id)?.name || id;
function matching() {
  const q = filter.q.trim().toLowerCase();
  return (leads || []).filter(l => (!filter.app || l.app === filter.app) && (!filter.updates || l.updates) && (!q || l.email.includes(q)));
}
function renderList() {
  const box = $('#ldList'); if (!box || !G) return;
  const people = new Set((leads || []).map(l => l.email)).size;
  const optedIn = new Set((leads || []).filter(l => l.updates).map(l => l.email)).size;
  const week = (leads || []).filter(l => Date.now() - new Date(l.first) < 7 * 864e5).length;
  const ids = [...new Set((leads || []).map(l => l.app))];
  const head = `<div class="card-head"><h3>${I('inbox')}Collected emails</h3><button type="button" class="hbtn ghost sm" data-ld="leads"${leadsLoading ? ' disabled' : ''}>${leadsLoading ? '<span class="spinner"></span>Loading…' : `${I('refresh')}Refresh`}</button></div>`;
  if (leadsError) { box.innerHTML = `${head}<p class="note lock"><span>${I('alert')}</span>${esc(leadsError)}</p>`; return; }
  if (!leads) { box.innerHTML = `${head}<p class="empty-sm"><span class="spinner"></span>Fetching from your email service…</p>`; return; }
  if (!leads.length) { box.innerHTML = `${head}<p class="empty-sm">${I('mail')}No emails yet. They appear here after someone downloads from your published site.</p>`; return; }
  const hadFocus = document.activeElement?.id;
  box.innerHTML = `${head}
    <dl class="ld-stats"><div><dt>People</dt><dd>${people}</dd></div><div><dt>Want updates</dt><dd>${optedIn}</dd></div><div><dt>New this week</dt><dd>${week}</dd></div></dl>
    <div class="ld-tools"><input type="search" id="ldQ" placeholder="Search emails" aria-label="Search emails" value="${esc(filter.q)}">
      <select id="ldFilterApp" aria-label="Filter by app"><option value="">All apps</option>${ids.map(id => `<option value="${esc(id)}"${filter.app === id ? ' selected' : ''}>${esc(appName(id))}</option>`).join('')}</select>
      <label class="switch"><input type="checkbox" id="ldOnly"${filter.updates ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Wants updates</span></label>
      <span class="sp"></span>
      <button type="button" class="hbtn ghost sm" data-ld="copy">${I('copy')}Copy emails</button><button type="button" class="hbtn ghost sm" data-ld="csv">${I('download')}Export CSV</button></div>
    <div class="ld-rows" id="ldRows" aria-live="polite"></div>`;
  renderRows();
  if (hadFocus) document.getElementById(hadFocus)?.focus({ preventScroll: true });
}
function renderRows() {
  const box = $('#ldRows'); if (!box) return;
  const list = matching();
  if (!list.length) { box.innerHTML = `<p class="empty-sm">${I('search')}Nothing matches that search.</p>`; return; }
  box.innerHTML = `<table class="ld-table"><thead><tr><th scope="col">Email</th><th scope="col">App</th><th scope="col">Updates</th><th scope="col">Downloads</th><th scope="col">Last</th><th scope="col"><span class="vh">Actions</span></th></tr></thead><tbody>${list.slice(0, filter.shown).map(l => `<tr>
    <td class="ld-mail" title="${esc(l.email)}">${esc(l.email)}</td><td>${esc(appName(l.app))}</td><td>${l.updates ? `<span class="ld-yes">${I('check')}Yes</span>` : '<span class="ld-no">No</span>'}</td><td>${Number(l.count) || 1}</td><td><time datetime="${esc(l.last)}" title="${esc(new Date(l.last).toLocaleString())}">${esc(rel(l.last))}</time></td>
    <td><button type="button" class="act del" data-ld-del="${esc(l.email)}" data-app="${esc(l.app)}" title="Delete" aria-label="Delete ${esc(l.email)}">${I('trash')}</button></td></tr>`).join('')}</tbody></table>
    ${list.length > filter.shown ? `<div class="row"><button type="button" class="hbtn ghost sm" data-ld="more">Show more (${list.length - filter.shown} left)</button></div>` : ''}`;
}

// ---------- actions ----------
// A cell starting with = + - @ would run as a formula in a spreadsheet; the apostrophe keeps it as text.
const cell = v => { let s = String(v ?? ''); if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; return `"${s.replace(/"/g, '""')}"`; };
function exportCSV() {
  const rows = [['Email', 'App', 'Wants updates', 'Downloads', 'First', 'Last', 'Country'], ...matching().map(l => [l.email, appName(l.app), l.updates ? 'yes' : 'no', l.count, l.first, l.last, l.country])];
  const a = document.createElement('a'), url = URL.createObjectURL(new Blob(['﻿' + rows.map(r => r.map(cell).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' }));
  a.href = url; a.download = `email-list-${new Date().toISOString().slice(0, 10)}.csv`; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast(`${matching().length} rows exported`);
}
async function run(name, work) {
  if (busy) return; busy = name; render();
  try { await work(); } catch (e) { toast(e.message, 'err', 9000); }
  busy = ''; render();
}
async function onClick(e) {
  const del = e.target.closest('[data-ld-del]');
  if (del) {
    const { ldDel: email, app } = del.dataset;
    const everywhere = (leads || []).filter(l => l.email === email).length > 1;
    if (!(await confirmBox('Delete this email?', everywhere ? `${email} is removed from every app’s list. This can’t be undone.` : `${email} is removed from your list. This can’t be undone.`))) return;
    try { leads = (await api('POST', '/api/gate/leads/delete', everywhere ? { email } : { email, app })).leads || []; toast('Deleted. The list can take a minute to catch up.'); leads = leads.filter(l => l.email !== email); renderList(); }
    catch (x) { toast(x.message, 'err', 8000); }
    return;
  }
  const action = e.target.closest('[data-ld]')?.dataset.ld; if (!action) return;
  if (action === 'reload') return show();
  if (action === 'leads') return loadLeads();
  if (action === 'more') { filter.shown += PAGE; return renderRows(); }
  if (action === 'csv') return exportCSV();
  if (action === 'copy') {
    const emails = [...new Set(matching().map(l => l.email))];
    try { await navigator.clipboard.writeText(emails.join(', ')); toast(`${emails.length} email${emails.length === 1 ? '' : 's'} copied`); } catch { toast('Couldn’t copy. Use Export CSV instead.', 'err'); }
    return;
  }
  if (action === 'deploy') return run('deploy', async () => {
    const r = await api('POST', '/api/gate/deploy', {}); G = r;
    if (r.result.error) toast(`The service is set up but not answering yet: ${r.result.error}`, 'info', 12000);
    else toast(r.result.publishNeeded ? 'Email service is running. Publish your site to switch it on.' : 'Email service updated', 'ok', 6000);
    refreshStatus(); if (!r.result.error) loadLeads();
  });
  if (action === 'test') return run('test', async () => { G = await api('POST', '/api/gate/test', {}); toast('The email service is working'); loadLeads(); });
}
async function onChange(e) {
  const t = e.target;
  if (t.id === 'ldFilterApp') { filter.app = t.value; filter.shown = PAGE; return renderRows(); }
  if (t.id === 'ldOnly') { filter.updates = t.checked; filter.shown = PAGE; return renderRows(); }
  const id = t.dataset.ldApp; if (!id || saving.has(id)) return;
  const on = t.checked; saving.add(id); t.disabled = true;
  try {
    const r = await api('PUT', '/api/gate/app', { id, on }); G = r;
    const app = S.apps.find(a => a.id === id); if (app) { if (on) app.emailGate = true; else delete app.emailGate; }
    if (r.warning) toast(`Saved, but the email service couldn’t be updated: ${r.warning}`, 'err', 10000);
    else toast(on ? `${appName(id)} now asks for an email. Publish to apply.` : `${appName(id)} downloads are open again. Publish to apply.`, 'ok', 5000);
    emit('apps'); refreshStatus();
  } catch (x) { toast(x.message, 'err', 8000); }
  saving.delete(id); render(); document.getElementById(`ldApp-${id}`)?.focus({ preventScroll: true });
}
async function onSubmit(e) {
  e.preventDefault();
  const form = e.target, kind = form.dataset.ldForm;
  if (kind === 'cf') { const value = form.elements.token.value.trim(); if (!value) return; return run('cf', async () => { G = await api('PUT', '/api/gate/cloudflare', { token: value }); token = ''; toast('Cloudflare connected'); }); }
  if (kind === 'words') {
    const body = { note: form.elements.note.value, updatesText: form.elements.updatesText.value };
    return run('settings', async () => { Object.assign(G, body); G = await api('PUT', '/api/gate/settings', body); toast('Wording saved. Publish to apply.'); refreshStatus(); });
  }
}
