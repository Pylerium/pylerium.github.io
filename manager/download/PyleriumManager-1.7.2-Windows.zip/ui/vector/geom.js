// Vector geometry for Icon Studio: shapes as cubic paths, SVG path data in and out, affine transforms, boolean
// operations (union, subtract, intersect, exclude) and curve refitting. Pure functions, no DOM.
// A path is a list of subpaths { closed, pts: [{ x, y, ix, iy, ox, oy }] } with handles in absolute coordinates.

export const round = n => Math.round(n * 100) / 100;
export const pt = (x, y, ix = x, iy = y, ox = x, oy = y) => ({ x, y, ix, iy, ox, oy });
const K = .5522847498;

// ---------- affine matrices [a b c d e f] ----------
export const ID = [1, 0, 0, 1, 0, 0];
export const mul = (m, n) => [m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1], m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3], m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]];
export const apply = (m, x, y) => [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]];
export const translate = (x, y) => [1, 0, 0, 1, x, y];
export const scale = (x, y = x) => [x, 0, 0, y, 0, 0];
export const rotate = (deg, cx = 0, cy = 0) => { const r = deg * Math.PI / 180, c = Math.cos(r), s = Math.sin(r); return [c, s, -s, c, cx - c * cx + s * cy, cy - s * cx - c * cy]; };
export const rotPoint = (x, y, deg, cx, cy) => (deg ? apply(rotate(deg, cx, cy), x, y) : [x, y]);
export const transformSubs = (subs, m) => subs.map(s => ({ closed: s.closed, pts: s.pts.map(p => { const [x, y] = apply(m, p.x, p.y), [ix, iy] = apply(m, p.ix, p.iy), [ox, oy] = apply(m, p.ox, p.oy); return { x, y, ix, iy, ox, oy }; }) }));

// ---------- primitives → paths ----------
export function shapeSubs(o) {
  const { x, y, w, h } = o;
  if (o.type === 'path') return o.subs;
  if (o.type === 'ellipse') {
    const rx = w / 2, ry = h / 2, cx = x + rx, cy = y + ry, kx = rx * K, ky = ry * K;
    return [{ closed: true, pts: [pt(cx, y, cx - kx, y, cx + kx, y), pt(x + w, cy, x + w, cy - ky, x + w, cy + ky), pt(cx, y + h, cx + kx, y + h, cx - kx, y + h), pt(x, cy, x, cy + ky, x, cy - ky)] }];
  }
  if (o.type === 'polygon' || o.type === 'star') {
    const n = Math.max(3, Math.min(60, o.sides || 5)), star = o.type === 'star', total = star ? n * 2 : n, cx = x + w / 2, cy = y + h / 2;
    const raw = Array.from({ length: total }, (_, i) => { const a = -Math.PI / 2 + i / total * Math.PI * 2, r = star && i % 2 ? (o.inner ?? .45) : 1; return [Math.cos(a) * r, Math.sin(a) * r]; });
    // stretch so the drawing fills its box exactly
    const xs = raw.map(p => p[0]), ys = raw.map(p => p[1]), mx = Math.min(...xs), my = Math.min(...ys), sw = Math.max(...xs) - mx, sh = Math.max(...ys) - my;
    const pts = raw.map(([px, py]) => [x + (px - mx) / sw * w, y + (py - my) / sh * h]);
    void cx; void cy;
    return [{ closed: true, pts: o.r > 0 ? roundCorners(pts, o.r) : pts.map(([a, b]) => pt(a, b)) }];
  }
  const r = Math.max(0, Math.min(o.r || 0, w / 2, h / 2));
  if (o.type === 'rect' && r > 0) {
    // smooth ("squircle") corners pull the handles further toward the corner
    const k = o.smooth ? .82 : K, e = o.smooth ? Math.min(r * 1.28, w / 2, h / 2) : r;
    const c = (ax, ay, cx, cy, bx, by) => [pt(ax, ay, ax, ay, ax + (cx - ax) * k, ay + (cy - ay) * k), pt(bx, by, bx + (cx - bx) * k, by + (cy - by) * k, bx, by)];
    return [{ closed: true, pts: [...c(x + w - e, y, x + w, y, x + w, y + e), ...c(x + w, y + h - e, x + w, y + h, x + w - e, y + h), ...c(x + e, y + h, x, y + h, x, y + h - e), ...c(x, y + e, x, y, x + e, y)] }];
  }
  return [{ closed: true, pts: [pt(x, y), pt(x + w, y), pt(x + w, y + h), pt(x, y + h)] }];
}
function roundCorners(pts, radius) {
  const out = [], n = pts.length;
  for (let i = 0; i < n; i++) {
    const [px, py] = pts[(i + n - 1) % n], [cx, cy] = pts[i], [nx, ny] = pts[(i + 1) % n];
    const a = Math.hypot(px - cx, py - cy), b = Math.hypot(nx - cx, ny - cy), d = Math.min(radius, a / 2, b / 2);
    const ax = cx + (px - cx) / a * d, ay = cy + (py - cy) / a * d, bx = cx + (nx - cx) / b * d, by = cy + (ny - cy) / b * d;
    out.push(pt(ax, ay, ax, ay, ax + (cx - ax) * K, ay + (cy - ay) * K), pt(bx, by, bx + (cx - bx) * K, by + (cy - by) * K, bx, by));
  }
  return out;
}

export function subsToD(subs) {
  let d = '';
  for (const s of subs) {
    if (!s.pts.length) continue;
    d += `M${round(s.pts[0].x)} ${round(s.pts[0].y)}`;
    const n = s.pts.length, last = s.closed ? n : n - 1;
    for (let i = 1; i <= last; i++) {
      const a = s.pts[i - 1], b = s.pts[i % n];
      const line = Math.abs(a.ox - a.x) < .01 && Math.abs(a.oy - a.y) < .01 && Math.abs(b.ix - b.x) < .01 && Math.abs(b.iy - b.y) < .01;
      if (line) { if (!(s.closed && i === n)) d += `L${round(b.x)} ${round(b.y)}`; }
      else d += `C${round(a.ox)} ${round(a.oy)} ${round(b.ix)} ${round(b.iy)} ${round(b.x)} ${round(b.y)}`;
    }
    if (s.closed) d += 'Z';
  }
  return d;
}

// ---------- SVG path data → subpaths (every command, arcs included) ----------
export function parseD(d) {
  const tok = String(d || '').match(/[a-zA-Z]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?/g) || [];
  const subs = []; let i = 0, cmd = '', x = 0, y = 0, sx = 0, sy = 0, cur = null, lastC = null, lastQ = null;
  const num = () => +tok[i++];
  const flag = () => { const t = tok[i]; if (t.length > 1 && /^[01]/.test(t)) { tok[i] = t.slice(1); return +t[0]; } return num(); };
  const start = () => { cur = { closed: false, pts: [pt(x, y)] }; subs.push(cur); };
  const lineTo = (nx, ny) => { if (!cur) start(); cur.pts.push(pt(nx, ny)); x = nx; y = ny; };
  const cubic = (x1, y1, x2, y2, nx, ny) => { if (!cur) start(); const a = cur.pts.at(-1); a.ox = x1; a.oy = y1; cur.pts.push(pt(nx, ny, x2, y2)); x = nx; y = ny; };
  while (i < tok.length) {
    if (/[a-zA-Z]/.test(tok[i])) cmd = tok[i++]; else if (!cmd) break;
    const rel = cmd === cmd.toLowerCase(), C = cmd.toUpperCase(), bx = rel ? x : 0, by = rel ? y : 0;
    if (C === 'Z') { if (cur) { const f = cur.pts[0], l = cur.pts.at(-1); if (cur.pts.length > 1 && Math.hypot(f.x - l.x, f.y - l.y) < .05) { f.ix = l.ix; f.iy = l.iy; cur.pts.pop(); } cur.closed = true; } x = sx; y = sy; cur = null; lastC = lastQ = null; cmd = ''; continue; }
    if (Number.isNaN(+tok[i])) break;
    if (C === 'M') { x = bx + num(); y = by + num(); sx = x; sy = y; start(); cmd = rel ? 'l' : 'L'; lastC = lastQ = null; continue; }
    if (C === 'L') { lineTo(bx + num(), by + num()); lastC = lastQ = null; }
    else if (C === 'H') { lineTo(bx + num(), y); lastC = lastQ = null; }
    else if (C === 'V') { lineTo(x, by + num()); lastC = lastQ = null; }
    else if (C === 'C' || C === 'S') { let x1, y1; if (C === 'C') { x1 = bx + num(); y1 = by + num(); } else { x1 = lastC ? 2 * x - lastC[0] : x; y1 = lastC ? 2 * y - lastC[1] : y; } const x2 = bx + num(), y2 = by + num(), nx = bx + num(), ny = by + num(); cubic(x1, y1, x2, y2, nx, ny); lastC = [x2, y2]; lastQ = null; }
    else if (C === 'Q' || C === 'T') { let qx, qy; if (C === 'Q') { qx = bx + num(); qy = by + num(); } else { qx = lastQ ? 2 * x - lastQ[0] : x; qy = lastQ ? 2 * y - lastQ[1] : y; } const nx = bx + num(), ny = by + num(); cubic(x + 2 / 3 * (qx - x), y + 2 / 3 * (qy - y), nx + 2 / 3 * (qx - nx), ny + 2 / 3 * (qy - ny), nx, ny); lastQ = [qx, qy]; lastC = null; }
    else if (C === 'A') { const rx = num(), ry = num(), rot = num(), large = flag(), sweep = flag(), nx = bx + num(), ny = by + num(); arc(x, y, rx, ry, rot, large, sweep, nx, ny).forEach(c => cubic(...c)); if (x !== nx || y !== ny) lineTo(nx, ny); lastC = lastQ = null; }
    else break;
  }
  return subs.filter(s => s.pts.length > 1);
}
function arc(x0, y0, rx, ry, deg, large, sweep, x, y) {
  if (!rx || !ry || (x0 === x && y0 === y)) return [[x0, y0, x, y, x, y]];
  const phi = deg * Math.PI / 180, cos = Math.cos(phi), sin = Math.sin(phi), dx = (x0 - x) / 2, dy = (y0 - y) / 2;
  const px = cos * dx + sin * dy, py = -sin * dx + cos * dy; rx = Math.abs(rx); ry = Math.abs(ry);
  const l = px * px / (rx * rx) + py * py / (ry * ry); if (l > 1) { rx *= Math.sqrt(l); ry *= Math.sqrt(l); }
  const f = (large === sweep ? -1 : 1) * Math.sqrt(Math.max(0, (rx * rx * ry * ry - rx * rx * py * py - ry * ry * px * px) / (rx * rx * py * py + ry * ry * px * px)));
  const cxp = f * rx * py / ry, cyp = -f * ry * px / rx, cx = cos * cxp - sin * cyp + (x0 + x) / 2, cy = sin * cxp + cos * cyp + (y0 + y) / 2;
  const t1 = Math.atan2((py - cyp) / ry, (px - cxp) / rx); let dt = Math.atan2((-py - cyp) / ry, (-px - cxp) / rx) - t1;
  if (!sweep && dt > 0) dt -= Math.PI * 2; if (sweep && dt < 0) dt += Math.PI * 2;
  const n = Math.max(1, Math.ceil(Math.abs(dt) / (Math.PI / 2) - 1e-6)), step = dt / n, k = 4 / 3 * Math.tan(step / 4), out = [];
  const P = t => [cx + rx * Math.cos(t) * cos - ry * Math.sin(t) * sin, cy + rx * Math.cos(t) * sin + ry * Math.sin(t) * cos];
  const D = t => [-rx * Math.sin(t) * cos - ry * Math.cos(t) * sin, -rx * Math.sin(t) * sin + ry * Math.cos(t) * cos];
  for (let i = 0; i < n; i++) { const a = t1 + i * step, b = a + step, p = P(a), q = P(b), da = D(a), db = D(b); out.push([p[0] + k * da[0], p[1] + k * da[1], q[0] - k * db[0], q[1] - k * db[1], q[0], q[1]]); }
  return out;
}

// ---------- sampling ----------
export const bez = (a, b, t) => { const u = 1 - t, k0 = u * u * u, k1 = 3 * u * u * t, k2 = 3 * u * t * t, k3 = t * t * t; return [k0 * a.x + k1 * a.ox + k2 * b.ix + k3 * b.x, k0 * a.y + k1 * a.oy + k2 * b.iy + k3 * b.y]; };
export function flatten(subs, detail = 1.4) {
  return subs.map(s => {
    const out = [], n = s.pts.length, last = s.closed ? n : n - 1;
    for (let i = 0; i < last; i++) {
      const a = s.pts[i], b = s.pts[(i + 1) % n];
      const straight = a.ox === a.x && a.oy === a.y && b.ix === b.x && b.iy === b.y;
      const len = Math.hypot(a.ox - a.x, a.oy - a.y) + Math.hypot(b.ix - a.ox, b.iy - a.oy) + Math.hypot(b.x - b.ix, b.y - b.iy);
      const steps = straight ? 1 : Math.max(6, Math.min(80, Math.ceil(len / detail)));
      for (let k = 0; k < steps; k++) out.push(bez(a, b, k / steps));
    }
    if (!s.closed && n) out.push([s.pts[n - 1].x, s.pts[n - 1].y]);
    return out;
  });
}
export function boundsOf(subs) {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const ring of flatten(subs, 3)) for (const [x, y] of ring) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
  return x0 === Infinity ? { x: 0, y: 0, w: 0, h: 0 } : { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}

// ---------- boolean operations ----------
const area = r => r.reduce((s, p, i) => { const q = r[(i + 1) % r.length]; return s + p[0] * q[1] - q[0] * p[1]; }, 0) / 2;
function inside(rings, x, y) { // even-odd
  let on = false;
  for (const r of rings) for (let i = 0, j = r.length - 1; i < r.length; j = i++) { const [xi, yi] = r[i], [xj, yj] = r[j]; if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) on = !on; }
  return on;
}
// outlines run one way, holes the other, so pieces can be stitched back into rings
function orient(rings) { return rings.map(r => { const depth = rings.filter(o => o !== r && inside([o], r[0][0] + 1e-5, r[0][1] + 1.3e-5)).length; const want = depth % 2 ? -1 : 1; return Math.sign(area(r)) === want ? r : [...r].reverse(); }); }
function pieces(from, against, keepInside, reverse) {
  const out = [];
  for (const ring of from) for (let i = 0; i < ring.length; i++) {
    const a = ring[i], b = ring[(i + 1) % ring.length], cuts = [0, 1], dx = b[0] - a[0], dy = b[1] - a[1];
    for (const o of against) for (let j = 0; j < o.length; j++) {
      const c = o[j], d = o[(j + 1) % o.length], ex = d[0] - c[0], ey = d[1] - c[1], den = dx * ey - dy * ex;
      if (Math.abs(den) < 1e-12) continue;
      const t = ((c[0] - a[0]) * ey - (c[1] - a[1]) * ex) / den, u = ((c[0] - a[0]) * dy - (c[1] - a[1]) * dx) / den;
      if (t > 1e-9 && t < 1 - 1e-9 && u >= -1e-9 && u <= 1 + 1e-9) cuts.push(t);
    }
    cuts.sort((p, q) => p - q);
    for (let k = 0; k + 1 < cuts.length; k++) {
      if (cuts[k + 1] - cuts[k] < 1e-9) continue;
      const p = [a[0] + dx * cuts[k], a[1] + dy * cuts[k]], q = [a[0] + dx * cuts[k + 1], a[1] + dy * cuts[k + 1]];
      if (inside(against, (p[0] + q[0]) / 2, (p[1] + q[1]) / 2) === keepInside) out.push(reverse ? [q, p] : [p, q]);
    }
  }
  return out;
}
function stitch(edges) {
  const cell = 0.05, key = (x, y) => `${Math.round(x / cell)},${Math.round(y / cell)}`, from = new Map();
  edges.forEach((e, i) => { const k = key(...e[0]); (from.get(k) || from.set(k, []).get(k)).push(i); });
  const used = new Uint8Array(edges.length), rings = [];
  const nextFrom = ([x, y]) => {
    let best = -1, dist = .2;
    const cx = Math.round(x / cell), cy = Math.round(y / cell);
    for (let dx = -3; dx <= 3; dx++) for (let dy = -3; dy <= 3; dy++) for (const i of from.get(`${cx + dx},${cy + dy}`) || []) { if (used[i]) continue; const d = Math.hypot(edges[i][0][0] - x, edges[i][0][1] - y); if (d < dist) { dist = d; best = i; } }
    return best;
  };
  for (let s = 0; s < edges.length; s++) {
    if (used[s]) continue;
    const ring = []; let i = s;
    while (i >= 0 && !used[i]) { used[i] = 1; ring.push(edges[i][0]); const end = edges[i][1]; if (ring.length > 2 && Math.hypot(end[0] - ring[0][0], end[1] - ring[0][1]) < .2) break; i = nextFrom(end); }
    if (ring.length > 2 && Math.abs(area(ring)) > .5) rings.push(ring);
  }
  return rings;
}
export function booleanOp(subsA, subsB, op) {
  const A = orient(flatten(subsA.filter(s => s.closed || s.pts.length > 2), 1).filter(r => r.length > 2));
  // a hair of offset keeps shapes that share an edge from being ambiguous
  const B = orient(flatten(subsB.filter(s => s.closed || s.pts.length > 2), 1).filter(r => r.length > 2).map(r => r.map(([x, y]) => [x + .00731, y + .00519])));
  if (!A.length || !B.length) return subsA;
  if (op === 'exclude') return [...booleanOp(subsA, subsB, 'subtract'), ...booleanOp(subsB, subsA, 'subtract')];
  const edges = op === 'union' ? [...pieces(A, B, false), ...pieces(B, A, false)] : op === 'intersect' ? [...pieces(A, B, true), ...pieces(B, A, true)] : [...pieces(A, B, false), ...pieces(B, A, true, true)];
  return stitch(edges).map(fitRing);
}
// dense polygon → few smooth anchors: simplify, keep real corners sharp, give the rest tangent handles
export function simplify(points, tol) {
  if (points.length < 3) return points;
  const keep = new Uint8Array(points.length); keep[0] = keep[points.length - 1] = 1;
  const stack = [[0, points.length - 1]];
  while (stack.length) {
    const [a, b] = stack.pop(), [ax, ay] = points[a], [bx, by] = points[b], len = Math.hypot(bx - ax, by - ay) || 1e-9;
    let far = -1, d = tol;
    for (let i = a + 1; i < b; i++) { const dist = Math.abs((bx - ax) * (ay - points[i][1]) - (ax - points[i][0]) * (by - ay)) / len; if (dist > d) { d = dist; far = i; } }
    if (far > 0) { keep[far] = 1; stack.push([a, far], [far, b]); }
  }
  return points.filter((_, i) => keep[i]);
}
export function smoothPts(points, closed, cornerDeg = 32) {
  const n = points.length;
  return points.map(([x, y], i) => {
    if (!closed && (i === 0 || i === n - 1)) return pt(x, y);
    const [px, py] = points[(i + n - 1) % n], [qx, qy] = points[(i + 1) % n];
    const v1x = x - px, v1y = y - py, v2x = qx - x, v2y = qy - y, l1 = Math.hypot(v1x, v1y), l2 = Math.hypot(v2x, v2y);
    const turn = Math.acos(Math.max(-1, Math.min(1, (v1x * v2x + v1y * v2y) / (l1 * l2 || 1)))) * 180 / Math.PI;
    if (turn > cornerDeg) return pt(x, y);
    let tx = v1x / (l1 || 1) + v2x / (l2 || 1), ty = v1y / (l1 || 1) + v2y / (l2 || 1); const t = Math.hypot(tx, ty) || 1; tx /= t; ty /= t;
    return pt(x, y, x - tx * l1 / 3, y - ty * l1 / 3, x + tx * l2 / 3, y + ty * l2 / 3);
  });
}
export function fitRing(ring) {
  let far = 0; for (let i = 1; i < ring.length; i++) if (Math.hypot(ring[i][0] - ring[0][0], ring[i][1] - ring[0][1]) > Math.hypot(ring[far][0] - ring[0][0], ring[far][1] - ring[0][1])) far = i;
  const simple = [...simplify(ring.slice(0, far + 1), .32), ...simplify([...ring.slice(far), ring[0]], .32).slice(1, -1)];
  return { closed: true, pts: smoothPts(simple, true, 26) };
}
