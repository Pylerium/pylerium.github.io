// IconMake's generator (from iconmake-src/app.js), kept as pure functions: pick a shape, a mark and colours, get an SVG.
// Icon Studio can send any result into the vector editor as editable layers.
export const PALETTES = [
  ['#10131F','#988AFF','#75E4D4'], ['#101A21','#6FE0C6','#E9C889'],
  ['#201420','#F18DB1','#FFC77C'], ['#101A2B','#68B6FF','#9D8BFF'],
  ['#191714','#E4B85C','#A5D0C0'], ['#171725','#D4A3FF','#81D7F1'],
  ['#1C1516','#FF8A67','#E8D6B6'], ['#111A19','#A4DF87','#71DFCF'],
  ['#181622','#FFA7CA','#B8A6FF'], ['#111620','#81A5FF','#E5C1FF'],
  ['#1A1711','#E8A958','#7ED9BD'], ['#10131B','#E8E8F4','#A8A0FF'],
];
export const IDEAS = [
  {label:'Afterglow',shape:'squircle',motif:'dialogue',colors:PALETTES[0]},
  {label:'Fresh air',shape:'circle',motif:'wave',colors:PALETTES[1]},
  {label:'Daydream',shape:'rounded',motif:'orbit',colors:PALETTES[5]},
  {label:'Little spark',shape:'shield',motif:'spark',colors:PALETTES[6]},
  {label:'Signal',shape:'squircle',motif:'wave',colors:PALETTES[3]},
  {label:'Orbit line',shape:'circle',motif:'orbit',colors:PALETTES[9]},
  {label:'Night mark',shape:'rounded',motif:'monogram',colors:PALETTES[11]},
  {label:'Solar flare',shape:'shield',motif:'spark',colors:PALETTES[10]},
  {label:'Soft signal',shape:'squircle',motif:'pulse',colors:PALETTES[7]},
  {label:'Field note',shape:'rounded',motif:'grid',colors:PALETTES[4]},
  {label:'North star',shape:'circle',motif:'crown',colors:PALETTES[8]},
  {label:'Current',shape:'squircle',motif:'bolt',colors:PALETTES[2]},
];
function clamp(n,min,max){return Math.max(min,Math.min(max,n));}
function hexRgb(hex){const n=parseInt(hex.slice(1),16);return [(n>>16)&255,(n>>8)&255,n&255];}
function mixHex(hex,other,amount){const a=hexRgb(hex),b=hexRgb(other);return '#'+a.map((v,i)=>Math.round(v*(1-amount)+b[i]*amount).toString(16).padStart(2,'0')).join('');}
function slug(text){return (text||'icon').normalize('NFKD').replace(/[^a-zA-Z0-9]+/g,'-').replace(/^-|-$/g,'').toLowerCase()||'icon';}
function shapeMarkup(shape,fill,stroke='none',sw=0,radius=34){
  if(shape==='circle')return `<circle cx="64" cy="64" r="60" fill="${fill}" stroke="${stroke}" stroke-width="${sw}"/>`;
  if(shape==='shield')return `<path d="M64 4 116 22 108 78 64 124 20 78 12 22 64 4Z" fill="${fill}" stroke="${stroke}" stroke-width="${sw}" stroke-linejoin="round"/>`;
  const rx=shape==='rounded'?22:(Number(radius)||34);
  return `<rect x="4" y="4" width="120" height="120" rx="${rx}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}"/>`;
}
function motifMarkup(motif,p){
  const accent=p.accent, light=p.highlight, dark=mixHex(p.bg,'#000000',.34), pale=mixHex(accent,'#FFFFFF',.7);
  if(motif==='dialogue')return `
    <g>
      <path d="M42 24h40c11.6 0 21 9.4 21 21v14c0 11.6-9.4 21-21 21H53L35 94l4.3-12.8A20.8 20.8 0 0 1 21 60V45c0-11.6 9.4-21 21-21Z" fill="url(#bubble)" stroke="${accent}" stroke-opacity=".82" stroke-width="2.4" stroke-linejoin="round"/>
      <circle cx="44" cy="51" r="4" fill="${pale}"/>
      <circle cx="59" cy="51" r="4" fill="${mixHex(accent,'#FFFFFF',.42)}"/>
      <circle cx="74" cy="51" r="4" fill="${accent}"/>
      <path d="M77 68h13c7.2 0 13 5.8 13 13v8c0 7.2-5.8 13-13 13h-8l-10 8 2-9.2A12.8 12.8 0 0 1 64 88V81c0-7.2 5.8-13 13-13Z" fill="url(#highlight)" fill-opacity=".92" stroke="${light}" stroke-opacity=".78" stroke-width="1.6" stroke-linejoin="round"/>
      <path d="M78 82v6M86 78v14M94 81v8" stroke="${dark}" stroke-width="3" stroke-linecap="round"/>
    </g>`;
  if(motif==='wave')return `
    <g>
      <rect x="20" y="31" width="88" height="66" rx="22" fill="url(#bubble)" stroke="url(#signature)" stroke-width="3"/>
      <g stroke-linecap="round">
        <path d="M38 55v18M49 43v42M62 34v60M75 46v36M88 51v26M99 59v10" stroke="${accent}" stroke-width="6"/>
        <path d="M62 34v60" stroke="url(#highlight)" stroke-width="8"/>
      </g>
      <circle cx="99" cy="31" r="6" fill="${light}" stroke="${p.bg}" stroke-width="2"/>
    </g>`;
  if(motif==='orbit')return `
    <g>
      <circle cx="64" cy="64" r="31" fill="url(#bubble)" stroke="${accent}" stroke-width="2.5"/>
      <ellipse cx="64" cy="64" rx="51" ry="21" transform="rotate(-32 64 64)" fill="none" stroke="url(#signature)" stroke-width="4"/>
      <ellipse cx="64" cy="64" rx="51" ry="21" transform="rotate(34 64 64)" fill="none" stroke="${mixHex(accent,'#FFFFFF',.28)}" stroke-width="2" stroke-opacity=".8"/>
      <circle cx="64" cy="64" r="11" fill="url(#highlight)" stroke="#FFFFFF" stroke-opacity=".35" stroke-width="1.5"/>
      <circle cx="35" cy="42" r="6" fill="${light}" stroke="${p.bg}" stroke-width="2"/>
      <circle cx="96" cy="82" r="5" fill="${accent}" stroke="${p.bg}" stroke-width="2"/>
    </g>`;
  if(motif==='monogram')return `
    <g>
      <rect x="19" y="19" width="90" height="90" rx="28" fill="url(#bubble)" stroke="url(#signature)" stroke-width="3"/>
      <path d="M32 94V34h20c16 0 27 8 27 21 0 15-12 23-28 23H43v16H32Zm11-27h8c10 0 16-4 16-12 0-7-6-11-16-11h-8v23Z" fill="${light}" opacity=".17"/>
      <text x="64" y="79" text-anchor="middle" font-family="Segoe UI,Inter,sans-serif" font-size="52" font-weight="800" letter-spacing="-4" fill="url(#highlight)">${escapeXml((p.letter||'P').slice(0,2).toUpperCase())}</text>
      <circle cx="98" cy="30" r="5" fill="${light}"/>
    </g>`;
  if(motif==='pulse')return `
    <g>
      <circle cx="64" cy="64" r="38" fill="url(#bubble)" stroke="${accent}" stroke-width="2.5"/>
      <path d="M27 64h16l8-20 16 40 10-24 8 4h16" fill="none" stroke="url(#signature)" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
      <circle cx="64" cy="64" r="5" fill="${light}"/>
    </g>`;
  if(motif==='grid')return `
    <g>
      <rect x="27" y="27" width="74" height="74" rx="18" fill="url(#bubble)" stroke="${accent}" stroke-width="2.5"/>
      <g fill="${light}">
        <rect x="41" y="41" width="13" height="13" rx="4"/><rect x="74" y="41" width="13" height="13" rx="4"/>
        <rect x="41" y="74" width="13" height="13" rx="4"/><rect x="74" y="74" width="13" height="13" rx="4"/>
      </g>
      <circle cx="64" cy="64" r="6" fill="${accent}"/>
    </g>`;
  if(motif==='crown')return `
    <g>
      <path d="M30 43l17 15 17-30 17 30 17-15-8 45H38Z" fill="url(#bubble)" stroke="url(#signature)" stroke-width="3" stroke-linejoin="round"/>
      <path d="M40 74h48" stroke="${light}" stroke-width="5" stroke-linecap="round"/>
      <circle cx="64" cy="28" r="5" fill="${light}"/>
    </g>`;
  if(motif==='bolt')return `
    <g>
      <path d="M72 18 36 70h25l-8 40 39-58H67Z" fill="url(#highlight)" stroke="#FFFFFF" stroke-opacity=".38" stroke-width="2" stroke-linejoin="round"/>
      <path d="M72 18 61 56h21Z" fill="${accent}" fill-opacity=".55"/>
    </g>`;
  return `
    <g stroke-linejoin="round">
      <path d="M64 18 76 48 108 36 88 62 114 78 82 82 78 114 64 88 50 114 46 82 14 78 40 62 20 36 52 48Z" fill="url(#bubble)" stroke="url(#signature)" stroke-width="2.5"/>
      <path d="M64 18 64 88 50 114 46 82 14 78 40 62Z" fill="${accent}" fill-opacity=".12"/>
      <circle cx="64" cy="65" r="14" fill="url(#highlight)" stroke="#FFFFFF" stroke-opacity=".42" stroke-width="2"/>
      <circle cx="64" cy="65" r="5" fill="${p.bg}" fill-opacity=".72"/>
      <circle cx="101" cy="29" r="5" fill="${light}" stroke="${p.bg}" stroke-width="2"/>
    </g>`;
}
function escapeXml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));}
export function iconSvg(p){
  const dark=mixHex(p.bg,'#000000',.25), glow=(Number(p.glow)||0)/100, scale=(Number(p.scale)||74)/100;
  const glowAlpha=(.06+glow*.28).toFixed(3);
  const angle=Number(p.gradientAngle)||135;
  const rad=(angle-90)*Math.PI/180;
  const cx=(64+Math.cos(rad)*64).toFixed(1), cy=(64+Math.sin(rad)*64).toFixed(1);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 128 128" fill="none">
  <defs>
    <linearGradient id="surface" x1="13" y1="7" x2="116" y2="123" gradientUnits="userSpaceOnUse"><stop stop-color="${p.bg}"/><stop offset="1" stop-color="${dark}"/></linearGradient>
    <linearGradient id="signature" x1="${128-cx}" y1="${128-cy}" x2="${cx}" y2="${cy}" gradientUnits="userSpaceOnUse"><stop stop-color="${p.accent}"/><stop offset=".48" stop-color="${mixHex(p.accent,p.highlight,.55)}"/><stop offset="1" stop-color="${p.highlight}"/></linearGradient>
    <linearGradient id="bubble" x1="25" y1="23" x2="106" y2="102" gradientUnits="userSpaceOnUse"><stop stop-color="${mixHex(p.bg,p.accent,.26)}"/><stop offset="1" stop-color="${mixHex(p.bg,p.accent,.12)}"/></linearGradient>
    <linearGradient id="highlight" x1="64" y1="64" x2="111" y2="108" gradientUnits="userSpaceOnUse"><stop stop-color="${mixHex(p.highlight,'#FFFFFF',.24)}"/><stop offset="1" stop-color="${p.highlight}"/></linearGradient>
    <radialGradient id="halo"><stop stop-color="${p.accent}" stop-opacity="${glowAlpha}"/><stop offset="1" stop-color="${p.accent}" stop-opacity="0"/></radialGradient>
  </defs>
  ${shapeMarkup(p.shape,'url(#surface)','none',0,p.radius)}
  ${shapeMarkup(p.shape,'none','url(#signature)',p.rim,p.radius)}
  ${shapeMarkup(p.shape,'url(#halo)','none',0,p.radius)}
  <circle cx="64" cy="64" r="58" fill="url(#halo)"/>
  <g transform="translate(64 64) rotate(${Number(p.tilt)||0}) scale(${scale}) translate(-64 -64)">${motifMarkup(p.motif,p)}</g>
  
  </svg>`;
}
export const SHAPES = [['squircle','Soft'],['rounded','Rounded'],['circle','Circle'],['shield','Shield']];
export const MOTIFS = [['dialogue','Dialogue'],['wave','Wave'],['orbit','Orbit'],['monogram','Letter'],['spark','Spark'],['pulse','Pulse'],['grid','Grid'],['crown','Crown'],['bolt','Bolt']];
export const INITIAL = { shape: 'squircle', motif: 'dialogue', bg: '#0a0e18', accent: '#a9a2ff', highlight: '#68dccc', scale: 100, glow: 35, tilt: 0, rim: 1.5, radius: 34, gradientAngle: 135, letter: 'P', name: 'My icon' };
