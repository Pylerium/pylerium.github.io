// The Icon Studio document: objects (bottom first), their bounds, SVG export and SVG import.
// { size: 512, objects: [ { id, type, name, x, y, w, h, rot, fill, stroke, sw, opacity, blend, shadow, … } ] }
import { ID, mul, translate, scale, rotate, shapeSubs, subsToD, parseD, transformSubs, boundsOf, rotPoint, pt, round } from './geom.js';

export const SIZE = 512;
export const uid = () => 'o' + Math.random().toString(36).slice(2, 9);
export const solid = (color, a = 1) => ({ type: 'solid', color, a });
export const none = () => ({ type: 'none' });
export const linear = (c1, c2, angle = 135) => ({ type: 'linear', angle, stops: [{ o: 0, color: c1, a: 1 }, { o: 1, color: c2, a: 1 }] });
export const make = (type, props = {}) => ({ id: uid(), type, name: NAMES[type] || 'Shape', x: 0, y: 0, w: 100, h: 100, rot: 0, fill: solid('#2DD4BF'), stroke: none(), sw: 8, cap: 'round', join: 'round', dash: 0, opacity: 1, blend: 'normal', shadow: null, visible: true, locked: false, ...props });
const NAMES = { rect: 'Rectangle', ellipse: 'Ellipse', polygon: 'Polygon', star: 'Star', path: 'Path', text: 'Text', group: 'Group' };

export const walk = (list, fn) => { for (const o of list) { fn(o); if (o.type === 'group') walk(o.children, fn); } };

let measurer = null;
export function measureText(o) {
  measurer ||= document.createElement('canvas').getContext('2d');
  measurer.font = `${o.weight || 700} ${o.size || 160}px ${o.font || 'Segoe UI, system-ui, sans-serif'}`;
  const lines = String(o.text || ' ').split('\n');
  o.w = Math.max(4, ...lines.map(l => measurer.measureText(l).width + (o.tracking || 0) * Math.max(0, l.length - 1)));
  o.h = (o.size || 160) * 1.16 * lines.length;
}
// bounds before the object's own rotation
export function box(o) {
  if (o.type === 'path') return boundsOf(o.subs);
  if (o.type === 'group') { const b = o.children.map(worldBox); if (!b.length) return { x: 0, y: 0, w: 0, h: 0 }; const x = Math.min(...b.map(r => r.x)), y = Math.min(...b.map(r => r.y)); return { x, y, w: Math.max(...b.map(r => r.x + r.w)) - x, h: Math.max(...b.map(r => r.y + r.h)) - y }; }
  return { x: o.x, y: o.y, w: o.w, h: o.h };
}
export function worldBox(o) {
  if (o.type !== 'group' && o.rot && o.type !== 'text') return boundsOf(transformSubs(shapeSubs(o), rotate(o.rot, ...centre(o))));
  const b = box(o); if (!o.rot || o.type === 'group') return b;
  const c = centre(o), p = [[b.x, b.y], [b.x + b.w, b.y], [b.x + b.w, b.y + b.h], [b.x, b.y + b.h]].map(([x, y]) => rotPoint(x, y, o.rot, ...c));
  const xs = p.map(q => q[0]), ys = p.map(q => q[1]); return { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) };
}
export const centre = o => { const b = box(o); return [b.x + b.w / 2, b.y + b.h / 2]; };

export function moveBy(o, dx, dy) {
  if (o.type === 'group') return o.children.forEach(c => moveBy(c, dx, dy));
  if (o.type === 'path') { o.subs = transformSubs(o.subs, translate(dx, dy)); return; }
  o.x += dx; o.y += dy;
}
// resize so that box `from` maps onto box `to` (used for handle drags, typed sizes and group scaling)
export function resize(o, from, to) {
  const sx = from.w ? to.w / from.w : 1, sy = from.h ? to.h / from.h : 1;
  const map = (x, y) => [to.x + (x - from.x) * sx, to.y + (y - from.y) * sy];
  if (o.type === 'group') return o.children.forEach(c => resize(c, from, to));
  if (o.type === 'path') { o.subs = transformSubs(o.subs, mul(translate(to.x, to.y), mul(scale(sx || .001, sy || .001), translate(-from.x, -from.y)))); o.sw *= 1; return; }
  const [x, y] = map(o.x, o.y), [x2, y2] = map(o.x + o.w, o.y + o.h);
  o.x = Math.min(x, x2); o.y = Math.min(y, y2); o.w = Math.max(1, Math.abs(x2 - x)); o.h = Math.max(1, Math.abs(y2 - y));
  if (o.r) o.r *= Math.min(Math.abs(sx), Math.abs(sy));
  if (o.type === 'text') { o.size *= Math.abs(sy); o.tracking = (o.tracking || 0) * Math.abs(sx); measureText(o); }
}
// any object → editable path (rotation baked in)
export function toPath(o) {
  if (o.type === 'group' || o.type === 'text') return o;
  const subs = structuredClone(shapeSubs(o)), path = { ...o, type: 'path', subs: o.rot ? transformSubs(subs, rotate(o.rot, ...centre(o))) : subs, rot: 0, name: o.name };
  delete path.r; delete path.sides; delete path.inner; delete path.smooth; return path;
}
export function flip(o, horizontal, about) {
  if (o.type === 'group') return o.children.forEach(c => flip(c, horizontal, about));
  const [cx, cy] = about;
  if (o.type === 'text') { const [ox, oy] = centre(o); moveBy(o, horizontal ? 2 * (cx - ox) : 0, horizontal ? 0 : 2 * (cy - oy)); o.rot = -o.rot; return; }
  const p = toPath(o); p.subs = transformSubs(p.subs, mul(translate(cx, cy), mul(scale(horizontal ? -1 : 1, horizontal ? 1 : -1), translate(-cx, -cy))));
  Object.assign(o, p);
}
export function spin(o, deg, about) {
  if (o.type === 'group') return o.children.forEach(c => spin(c, deg, about));
  const [cx, cy] = centre(o), [nx, ny] = rotPoint(cx, cy, deg, ...about);
  moveBy(o, nx - cx, ny - cy); o.rot = ((o.rot + deg) % 360 + 360) % 360;
}

// ---------- export ----------
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[c]);
const hex = c => (/^#[0-9a-f]{6}$/i.test(c) ? c : '#000000');
function paint(p, id, defs) {
  if (!p || p.type === 'none') return ['none', 1];
  if (p.type === 'solid') return [hex(p.color), p.a ?? 1];
  const stops = [...p.stops].sort((a, b) => a.o - b.o).map(s => `<stop offset="${round(s.o)}" stop-color="${hex(s.color)}"${(s.a ?? 1) < 1 ? ` stop-opacity="${round(s.a)}"` : ''}/>`).join('');
  if (p.type === 'radial') defs.push(`<radialGradient id="${id}" cx="${p.cx ?? .5}" cy="${p.cy ?? .5}" r="${p.r ?? .6}">${stops}</radialGradient>`);
  else { const a = (p.angle - 90) * Math.PI / 180, dx = Math.cos(a) / 2, dy = Math.sin(a) / 2; defs.push(`<linearGradient id="${id}" x1="${round(.5 - dx)}" y1="${round(.5 - dy)}" x2="${round(.5 + dx)}" y2="${round(.5 + dy)}">${stops}</linearGradient>`); }
  return [`url(#${id})`, 1];
}
export function markup(o, defs, prefix = '', ids = false) {
  if (!o.visible) return '';
  const data = ids ? ` data-id="${o.id}"` : '';
  const style = o.blend && o.blend !== 'normal' ? ` style="mix-blend-mode:${o.blend}"` : '';
  let filter = '';
  if (o.shadow?.on) { const s = o.shadow, id = `${prefix}sh${o.id}`; defs.push(`<filter id="${id}" x="-60%" y="-60%" width="220%" height="220%"><feDropShadow dx="${round(s.dx)}" dy="${round(s.dy)}" stdDeviation="${round(s.blur / 2)}" flood-color="${hex(s.color)}" flood-opacity="${round(s.a)}"/></filter>`); filter = ` filter="url(#${id})"`; }
  const op = o.opacity < 1 ? ` opacity="${round(o.opacity)}"` : '';
  if (o.type === 'group') return `<g${data}${op}${filter}${style}>${o.children.map(c => markup(c, defs, prefix)).join('')}</g>`;
  const [fill, fa] = paint(o.fill, `${prefix}f${o.id}`, defs), [stroke, sa] = paint(o.stroke, `${prefix}s${o.id}`, defs);
  const attrs = `fill="${fill}"${fa < 1 ? ` fill-opacity="${round(fa)}"` : ''}${stroke !== 'none' && o.sw > 0 ? ` stroke="${stroke}" stroke-width="${round(o.sw)}" stroke-linecap="${o.cap}" stroke-linejoin="${o.join}"${sa < 1 ? ` stroke-opacity="${round(sa)}"` : ''}${o.dash ? ` stroke-dasharray="${round(o.dash)} ${round(o.dash * 1.6)}"` : ''}` : ''}`;
  const turn = o.rot ? ` transform="rotate(${round(o.rot)} ${centre(o).map(round).join(' ')})"` : '';
  if (o.type === 'text') {
    const lines = String(o.text || '').split('\n');
    return `<text${data}${turn}${op}${filter}${style} ${attrs} font-family="${esc(o.font || 'Segoe UI, system-ui, sans-serif')}" font-size="${round(o.size)}" font-weight="${o.weight || 700}"${o.tracking ? ` letter-spacing="${round(o.tracking)}"` : ''} xml:space="preserve">${lines.map((l, i) => `<tspan x="${round(o.x)}" y="${round(o.y + o.size * (.94 + i * 1.16))}">${esc(l)}</tspan>`).join('')}</text>`;
  }
  const rule = o.type === 'path' && o.subs.length > 1 ? ' fill-rule="evenodd"' : '';
  return `<path${data}${turn}${op}${filter}${style} d="${subsToD(shapeSubs(o))}" ${attrs}${rule}/>`;
}
export function toSVG(doc, { size = doc.size || SIZE, prefix = '' } = {}) {
  const defs = [], body = doc.objects.map(o => markup(o, defs, prefix)).join('');
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${doc.size || SIZE} ${doc.size || SIZE}">${defs.length ? `<defs>${defs.join('')}</defs>` : ''}${body}</svg>`;
}

// ---------- import ----------
function matrixOf(str) {
  let m = ID;
  for (const [, fn, args] of String(str || '').matchAll(/(\w+)\s*\(([^)]*)\)/g)) {
    const a = args.split(/[\s,]+/).filter(Boolean).map(Number);
    if (fn === 'translate') m = mul(m, translate(a[0], a[1] || 0));
    else if (fn === 'scale') m = mul(m, scale(a[0], a[1] ?? a[0]));
    else if (fn === 'rotate') m = mul(m, rotate(a[0], a[1] || 0, a[2] || 0));
    else if (fn === 'matrix') m = mul(m, a);
    else if (fn === 'skewX') m = mul(m, [1, 0, Math.tan(a[0] * Math.PI / 180), 1, 0, 0]);
    else if (fn === 'skewY') m = mul(m, [1, Math.tan(a[0] * Math.PI / 180), 0, 1, 0, 0]);
  }
  return m;
}
const colorCtx = () => (colorCtx.c ||= document.createElement('canvas').getContext('2d'));
function colorOf(v) {
  if (!v || v === 'none' || v === 'transparent') return null;
  const c = colorCtx(); c.fillStyle = '#000'; c.fillStyle = v === 'currentColor' ? '#e8eaf0' : v; const out = c.fillStyle;
  if (out.startsWith('#')) return { color: out, a: 1 };
  const m = out.match(/[\d.]+/g); return m ? { color: '#' + m.slice(0, 3).map(n => (+n).toString(16).padStart(2, '0')).join(''), a: +m[3] } : null;
}
export function importSVG(text, target = SIZE) {
  const xml = new DOMParser().parseFromString(String(text), 'image/svg+xml'), svg = xml.documentElement;
  if (svg.nodeName !== 'svg' || xml.querySelector('parsererror')) throw new Error('That file isn’t a readable SVG.');
  const vb = (svg.getAttribute('viewBox') || `0 0 ${parseFloat(svg.getAttribute('width')) || target} ${parseFloat(svg.getAttribute('height')) || target}`).split(/[\s,]+/).map(Number);
  const k = target / Math.max(vb[2], vb[3]), root = mul(translate((target - vb[2] * k) / 2, (target - vb[3] * k) / 2), mul(scale(k), translate(-vb[0], -vb[1])));
  const byId = id => xml.querySelector(`[id="${CSS.escape(id)}"]`);
  const styleOf = (el, inherit) => {
    const s = { ...inherit };
    for (const p of ['fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'fill-opacity', 'stroke-opacity', 'font-size', 'font-weight', 'font-family', 'letter-spacing']) { const v = el.style?.getPropertyValue(p) || el.getAttribute(p); if (v) s[p] = v.trim(); }
    return s;
  };
  const paintOf = (v, alpha) => {
    const ref = String(v || '').match(/url\(["']?#([^"')]+)/);
    if (ref) {
      let g = byId(ref[1]); if (!g) return none();
      const href = g.getAttribute('href') || g.getAttribute('xlink:href'); const stopsFrom = g.querySelector('stop') ? g : href ? byId(href.slice(1)) : g;
      const stops = [...(stopsFrom?.querySelectorAll('stop') || [])].map(st => { const c = colorOf(st.style.stopColor || st.getAttribute('stop-color') || '#000') || { color: '#000000', a: 1 }; const o = st.getAttribute('offset') || '0'; return { o: o.endsWith('%') ? parseFloat(o) / 100 : +o, color: c.color, a: +(st.style.stopOpacity || st.getAttribute('stop-opacity') || c.a) * alpha }; });
      if (!stops.length) return none();
      if (g.nodeName === 'radialGradient') return { type: 'radial', stops };
      const n = a => parseFloat(g.getAttribute(a) ?? (a === 'x2' ? 1 : 0));
      return { type: 'linear', stops, angle: Math.round(Math.atan2(n('y2') - n('y1'), n('x2') - n('x1')) * 180 / Math.PI + 90) };
    }
    const c = colorOf(v); return c ? solid(c.color, c.a * alpha) : none();
  };
  const out = [];
  const visit = (el, m, inherit, opacity) => {
    const tag = el.nodeName.replace(/^svg:/, ''); if (['defs', 'clipPath', 'mask', 'style', 'title', 'desc', 'metadata', 'filter', 'linearGradient', 'radialGradient', 'script', 'foreignObject'].includes(tag)) return;
    const mine = mul(m, matrixOf(el.getAttribute('transform'))), s = styleOf(el, inherit), op = opacity * (+(el.getAttribute('opacity') || el.style?.opacity || 1));
    if (tag === 'g' || tag === 'svg') return [...el.children].forEach(c => visit(c, mine, s, op));
    const a = n => parseFloat(el.getAttribute(n)) || 0;
    const base = { fill: paintOf(s.fill ?? '#000000', +(s['fill-opacity'] ?? 1)), stroke: paintOf(s.stroke, +(s['stroke-opacity'] ?? 1)), sw: parseFloat(s['stroke-width'] ?? 1) * Math.sqrt(Math.abs(mine[0] * mine[3] - mine[1] * mine[2])), cap: s['stroke-linecap'] || 'butt', join: s['stroke-linejoin'] || 'miter', opacity: op };
    if (tag === 'text') {
      const size = parseFloat(s['font-size'] || 16) * Math.sqrt(Math.abs(mine[0] * mine[3] - mine[1] * mine[2]));
      const o = make('text', { ...base, text: el.textContent.trim(), size, weight: s['font-weight'] || 400, font: s['font-family'] || undefined, tracking: parseFloat(s['letter-spacing'] || 0) }); measureText(o);
      const [x, y] = [mine[0] * a('x') + mine[2] * a('y') + mine[4], mine[1] * a('x') + mine[3] * a('y') + mine[5]];
      o.x = x - (el.getAttribute('text-anchor') === 'middle' ? o.w / 2 : el.getAttribute('text-anchor') === 'end' ? o.w : 0); o.y = y - size * .94; out.push(o); return;
    }
    let subs = null;
    if (tag === 'path') subs = parseD(el.getAttribute('d'));
    else if (tag === 'rect') { let rx = a('rx') || a('ry'); subs = shapeSubs({ type: 'rect', x: a('x'), y: a('y'), w: a('width'), h: a('height'), r: rx }); }
    else if (tag === 'circle' || tag === 'ellipse') { const rx = a('r') || a('rx'), ry = a('r') || a('ry'); subs = shapeSubs({ type: 'ellipse', x: a('cx') - rx, y: a('cy') - ry, w: rx * 2, h: ry * 2 }); }
    else if (tag === 'line') subs = [{ closed: false, pts: [pt(a('x1'), a('y1')), pt(a('x2'), a('y2'))] }];
    else if (tag === 'polygon' || tag === 'polyline') { const n = (el.getAttribute('points') || '').split(/[\s,]+/).filter(Boolean).map(Number), pts = []; for (let i = 0; i + 1 < n.length; i += 2) pts.push(pt(n[i], n[i + 1])); subs = [{ closed: tag === 'polygon', pts }]; }
    if (!subs?.length || (base.fill.type === 'none' && base.stroke.type === 'none')) return;
    out.push(make('path', { ...base, name: el.id || tag.charAt(0).toUpperCase() + tag.slice(1), subs: transformSubs(subs, mine) }));
  };
  [...svg.children].forEach(c => visit(c, root, styleOf(svg, {}), 1));
  if (!out.length) throw new Error('No shapes were found in that SVG.');
  return out.slice(0, 600);
}
