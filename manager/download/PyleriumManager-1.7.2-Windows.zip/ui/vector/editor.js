// The vector editor: tools, selection and transforms, node and pen editing, snapping, layers, properties and history.
// createEditor(host, { doc, onChange }) → { doc(), load(doc), add(objects), undo, redo, destroy() }
import { shapeSubs, subsToD, booleanOp, simplify, smoothPts, pt, rotPoint, bez, round } from './geom.js';
import { make, uid, solid, none, linear, box, worldBox, centre, moveBy, resize, toPath, flip, spin, markup, measureText, importSVG, SIZE } from './doc.js';
import { T } from './toolicons.js';

const TOOLS = [['select', 'Select', 'V'], ['node', 'Edit points', 'A'], ['pen', 'Pen', 'P'], ['pencil', 'Pencil', 'N'], null, ['rect', 'Rectangle', 'M'], ['ellipse', 'Ellipse', 'L'], ['polygon', 'Polygon', 'Y'], ['star', 'Star', 'S'], ['line', 'Line', 'U'], ['text', 'Text', 'T'], null, ['eyedropper', 'Pick colour', 'I'], ['hand', 'Pan', 'H']];
const BLENDS = ['normal', 'multiply', 'screen', 'overlay', 'darken', 'lighten', 'color-dodge', 'color-burn', 'soft-light', 'hard-light', 'difference'];
const SWATCHES = ['#FFFFFF', '#E8EAF0', '#14161C', '#07080E', '#2DD4BF', '#38BDF8', '#818CF8', '#A78BFA', '#E879F9', '#FB7185', '#FB923C', '#FBBF24', '#A3E635', '#34D399'];
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

export function createEditor(host, { doc, onChange }) {
  let D = structuredClone(doc || { size: SIZE, objects: [] });
  let tool = 'select', sel = [], nodeSel = null, view = { z: 1, x: 0, y: 0 }, history = [], future = [], clip = [], pen = null, drag = null, space = false, guides = [];
  const opt = { grid: false, snap: true, keyline: true, outline: false };
  const current = { fill: solid('#2DD4BF'), stroke: none(), sw: 10 };
  const ac = new AbortController(), on = (t, ev, fn, o = {}) => t.addEventListener(ev, fn, { ...o, signal: ac.signal });
  let raf = 0, ro = null;

  host.innerHTML = `<div class="ve">
    <div class="ve-top" role="toolbar" aria-label="Commands"></div>
    <div class="ve-tools" role="toolbar" aria-label="Tools" aria-orientation="vertical">${TOOLS.map(t => (t ? `<button type="button" data-tool="${t[0]}" aria-label="${t[1]} (${t[2]})" title="${t[1]}  ${t[2]}">${T[t[0]]}</button>` : '<i></i>')).join('')}</div>
    <div class="ve-stage" tabindex="0" aria-label="Drawing canvas"><svg class="ve-svg" xmlns="http://www.w3.org/2000/svg"><g class="ve-world"><g class="ve-back"></g><defs class="ve-defs"></defs><g class="ve-art"></g><g class="ve-lines"></g></g><g class="ve-over"></g></svg><div class="ve-status num"></div></div>
    <aside class="ve-side"><section class="ve-props" aria-label="Properties"></section><section class="ve-layers" aria-label="Layers"></section></aside>
    <input type="file" accept=".svg,image/svg+xml" hidden></div>`;
  const $ = s => host.querySelector(s);
  const stage = $('.ve-stage'), svg = $('.ve-svg'), world = $('.ve-world'), art = $('.ve-art'), defsEl = $('.ve-defs'), over = $('.ve-over'), back = $('.ve-back'), lines = $('.ve-lines'), file = $('input[type=file]');

  // ---------- model helpers ----------
  const byId = id => D.objects.find(o => o.id === id);
  const selected = () => sel.map(byId).filter(Boolean);
  const union = list => { const b = list.map(worldBox); if (!b.length) return null; const x = Math.min(...b.map(r => r.x)), y = Math.min(...b.map(r => r.y)); return { x, y, w: Math.max(...b.map(r => r.x + r.w)) - x, h: Math.max(...b.map(r => r.y + r.h)) - y }; };
  const snapshot = () => JSON.stringify(D.objects);
  let committed = snapshot();
  function commit() { const now = snapshot(); if (now === committed) return; history.push(committed); if (history.length > 200) history.shift(); future = []; committed = now; onChange?.(D); drawTop(); }
  function restore(json) { D.objects = JSON.parse(json); committed = json; sel = sel.filter(byId); nodeSel = null; pen = null; onChange?.(D); draw(); }
  const undo = () => { if (pen) { pen = null; return draw(); } if (history.length) { future.push(committed); restore(history.pop()); } };
  const redo = () => { if (future.length) { history.push(committed); restore(future.pop()); } };
  function pick(ids, extend = false) { sel = extend ? [...new Set([...sel, ...ids])] : ids; if (!ids.length && !extend) sel = []; nodeSel = null; draw(); }

  // ---------- view ----------
  const toDoc = e => { const r = svg.getBoundingClientRect(), k = r.width / (svg.clientWidth || r.width || 1); return [((e.clientX - r.left) / k - view.x) / view.z, ((e.clientY - r.top) / k - view.y) / view.z]; };
  const toScreen = (x, y) => [x * view.z + view.x, y * view.z + view.y];
  function fitView() { const w = stage.clientWidth, h = stage.clientHeight; if (!w) return; view.z = Math.max(.1, Math.min((w - 64) / D.size, (h - 64) / D.size)); view.x = (w - D.size * view.z) / 2; view.y = (h - D.size * view.z) / 2; draw(); }
  function zoomAt(f, sx = stage.clientWidth / 2, sy = stage.clientHeight / 2) { const z = Math.max(.1, Math.min(24, view.z * f)), k = z / view.z; view.x = sx - (sx - view.x) * k; view.y = sy - (sy - view.y) * k; view.z = z; draw(); }

  // ---------- snapping ----------
  function snapPoint(x, y, skip = []) {
    guides = []; if (!opt.snap) return [x, y];
    const tol = 7 / view.z, xs = [0, D.size / 2, D.size], ys = [0, D.size / 2, D.size];
    for (const o of D.objects) if (o.visible && !skip.includes(o.id)) { const b = worldBox(o); xs.push(b.x, b.x + b.w / 2, b.x + b.w); ys.push(b.y, b.y + b.h / 2, b.y + b.h); }
    const near = (v, list) => { let best = null, d = tol; for (const c of list) if (Math.abs(c - v) < d) { d = Math.abs(c - v); best = c; } return best; };
    let nx = near(x, xs), ny = near(y, ys);
    if (nx != null) guides.push(['v', nx]); else nx = opt.grid ? Math.round(x / 16) * 16 : Math.round(x * 2) / 2;
    if (ny != null) guides.push(['h', ny]); else ny = opt.grid ? Math.round(y / 16) * 16 : Math.round(y * 2) / 2;
    return [nx, ny];
  }
  function snapMove(b, dx, dy, skip) {
    guides = []; if (!opt.snap) return [dx, dy];
    let out = [dx, dy];
    for (const [axis, i, offs] of [['v', 0, [0, b.w / 2, b.w]], ['h', 1, [0, b.h / 2, b.h]]]) {
      const start = i ? b.y : b.x; let best = null, d = 7 / view.z;
      const targets = [0, D.size / 2, D.size]; for (const o of D.objects) if (o.visible && !skip.includes(o.id)) { const r = worldBox(o); targets.push(...(i ? [r.y, r.y + r.h / 2, r.y + r.h] : [r.x, r.x + r.w / 2, r.x + r.w])); }
      for (const off of offs) for (const t of targets) { const gap = t - (start + off + out[i]); if (Math.abs(gap) < d) { d = Math.abs(gap); best = [gap, t]; } }
      if (best) { out[i] += best[0]; guides.push([axis, best[1]]); }
      else if (opt.grid) out[i] = Math.round((start + out[i]) / 16) * 16 - start;
    }
    return out;
  }

  // ---------- drawing ----------
  const handleDefs = b => [['nw', 0, 0], ['n', .5, 0], ['ne', 1, 0], ['e', 1, .5], ['se', 1, 1], ['s', .5, 1], ['sw', 0, 1], ['w', 0, .5]].map(([id, u, v]) => ({ id, u, v, x: b.x + b.w * u, y: b.y + b.h * v }));
  // the frame of a single object turns with it; several objects share an upright frame
  const frameOf = () => { const l = selected(); if (!l.length) return null; if (l.length === 1 && l[0].type !== 'group') return { box: box(l[0]), rot: l[0].rot, c: centre(l[0]) }; const b = union(l); return { box: b, rot: 0, c: [b.x + b.w / 2, b.y + b.h / 2] }; };
  function draw() { cancelAnimationFrame(raf); raf = requestAnimationFrame(render); }
  function render() {
    world.setAttribute('transform', `translate(${view.x} ${view.y}) scale(${view.z})`);
    const s = D.size, px = 1 / view.z;
    back.innerHTML = `<rect class="ve-board" width="${s}" height="${s}"/><rect width="${s}" height="${s}" fill="url(#veCheck)"/>`;
    const defs = [`<pattern id="veCheck" width="32" height="32" patternUnits="userSpaceOnUse"><path d="M0 0h16v16H0zM16 16h16v16H16z" fill="rgba(255,255,255,.035)"/></pattern>`];
    art.innerHTML = D.objects.map(o => markup(o, defs, 've-', true)).join('');
    art.classList.toggle('outline', opt.outline);
    defsEl.innerHTML = defs.join('');
    let l = `<rect width="${s}" height="${s}" fill="none" class="ve-edge" stroke-width="${px}"/>`;
    if (opt.grid) { let d = ''; for (let v = 16; v < s; v += 16) d += `M${v} 0V${s}M0 ${v}H${s}`; l += `<path d="${d}" class="ve-grid" stroke-width="${px * .5}"/>`; }
    if (opt.keyline) { const m = s * .1; l += `<g class="ve-key" stroke-width="${px}" fill="none"><rect x="${s * .04}" y="${s * .04}" width="${s * .92}" height="${s * .92}" rx="${s * .22}"/><circle cx="${s / 2}" cy="${s / 2}" r="${s / 2 - m}"/><rect x="${s * .18}" y="${s * .18}" width="${s * .64}" height="${s * .64}"/><path d="M${s / 2} 0V${s}M0 ${s / 2}H${s}M0 0 ${s} ${s}M${s} 0 0 ${s}"/></g>`; }
    lines.innerHTML = l;
    drawOver(); drawTop(); if (!drag) { drawProps(); drawLayers(); }
    $('.ve-status').textContent = `${Math.round(view.z * 100)}%  ·  ${s}×${s}${sel.length ? `  ·  ${sel.length} selected` : ''}`;
    host.querySelectorAll('[data-tool]').forEach(b => { b.classList.toggle('on', b.dataset.tool === tool); b.setAttribute('aria-pressed', b.dataset.tool === tool); });
    stage.dataset.tool = space ? 'hand' : tool;
  }
  function drawOver() {
    let h = '';
    for (const [a, v] of guides) { const [x, y] = toScreen(v, v); h += a === 'v' ? `<path class="ve-guide" d="M${x} 0V${stage.clientHeight}"/>` : `<path class="ve-guide" d="M0 ${y}H${stage.clientWidth}"/>`; }
    const l = selected();
    if (tool === 'node' && l.length === 1 && l[0].type === 'path') {
      const o = l[0], c = centre(o), S = (x, y) => toScreen(...rotPoint(x, y, o.rot, ...c));
      h += `<path class="ve-outline" d="${subsToD(o.subs.map(sub => ({ closed: sub.closed, pts: sub.pts.map(p => { const [x, y] = S(p.x, p.y), [ix, iy] = S(p.ix, p.iy), [ox, oy] = S(p.ox, p.oy); return { x, y, ix, iy, ox, oy }; }) })))}"/>`;
      o.subs.forEach((sub, si) => sub.pts.forEach((p, pi) => {
        const [x, y] = S(p.x, p.y), picked = nodeSel && nodeSel[0] === si && nodeSel[1] === pi;
        if (picked) for (const k of ['i', 'o']) { const [hx, hy] = S(p[k + 'x'], p[k + 'y']); if (Math.hypot(hx - x, hy - y) > 1) h += `<path class="ve-lever" d="M${x} ${y}L${hx} ${hy}"/><circle class="ve-knob" cx="${hx}" cy="${hy}" r="4" data-h="${k}" data-s="${si}" data-p="${pi}"/>`; }
        h += `<rect class="ve-anchor${picked ? ' on' : ''}" x="${x - 4}" y="${y - 4}" width="8" height="8" rx="1.5" data-s="${si}" data-p="${pi}"/>`;
      }));
    } else if (l.length && !pen) {
      const f = frameOf(), b = f.box, C = (x, y) => toScreen(...rotPoint(x, y, f.rot, ...f.c));
      const q = [C(b.x, b.y), C(b.x + b.w, b.y), C(b.x + b.w, b.y + b.h), C(b.x, b.y + b.h)];
      h += `<path class="ve-frame" d="M${q.map(p => p.join(' ')).join('L')}Z"/>`;
      if (tool === 'select' && !l.some(o => o.locked)) {
        const top = C(b.x + b.w / 2, b.y), spinAt = C(b.x + b.w / 2, b.y - 24 / view.z);
        h += `<path class="ve-lever" d="M${top.join(' ')}L${spinAt.join(' ')}"/><circle class="ve-knob spin" cx="${spinAt[0]}" cy="${spinAt[1]}" r="5" data-spin="1"/>`;
        for (const k of handleDefs(b)) { const [x, y] = C(k.x, k.y); h += `<rect class="ve-handle" x="${x - 4.5}" y="${y - 4.5}" width="9" height="9" rx="2" data-handle="${k.id}"/>`; }
      }
    }
    if (pen) {
      const subs = [{ closed: false, pts: pen.pts.map(p => ({ ...p })) }];
      if (pen.hover && !drag) subs[0].pts.push(pt(...pen.hover));
      h += `<path class="ve-outline" d="${subsToD(subs.map(s => ({ closed: false, pts: s.pts.map(p => { const [x, y] = toScreen(p.x, p.y), [ix, iy] = toScreen(p.ix, p.iy), [ox, oy] = toScreen(p.ox, p.oy); return { x, y, ix, iy, ox, oy }; }) })))}"/>`;
      pen.pts.forEach((p, i) => { const [x, y] = toScreen(p.x, p.y); if (i === pen.pts.length - 1) { const [ox, oy] = toScreen(p.ox, p.oy), [ix, iy] = toScreen(p.ix, p.iy); h += `<path class="ve-lever" d="M${ix} ${iy}L${ox} ${oy}"/><circle class="ve-knob" cx="${ox}" cy="${oy}" r="3.5"/><circle class="ve-knob" cx="${ix}" cy="${iy}" r="3.5"/>`; } h += `<rect class="ve-anchor${i === 0 ? ' first' : ''}" x="${x - 4}" y="${y - 4}" width="8" height="8" rx="1.5"/>`; });
    }
    if (drag?.kind === 'marquee') { const [x0, y0] = toScreen(...drag.from), [x1, y1] = toScreen(...drag.to); h += `<rect class="ve-marquee" x="${Math.min(x0, x1)}" y="${Math.min(y0, y1)}" width="${Math.abs(x1 - x0)}" height="${Math.abs(y1 - y0)}"/>`; }
    if (drag?.kind === 'pencil') h += `<path class="ve-outline" d="M${drag.pts.map(p => toScreen(...p).join(' ')).join('L')}"/>`;
    over.innerHTML = h;
  }
  function drawTop() {
    const n = sel.length, g = selected().some(o => o.type === 'group');
    const b = (cmd, icon, label, dis = false, pressed) => `<button type="button" data-cmd="${cmd}" aria-label="${label}" title="${label}"${dis ? ' disabled' : ''}${pressed !== undefined ? ` aria-pressed="${pressed}" class="${pressed ? 'on' : ''}"` : ''}>${T[icon]}</button>`;
    const html = `<div>${b('undo', 'undo', 'Undo (Ctrl+Z)', !history.length && !pen)}${b('redo', 'redo', 'Redo (Ctrl+Y)', !future.length)}</div>
      <div>${b('union', 'union', 'Unite shapes', n < 2)}${b('subtract', 'subtract', 'Subtract the shapes above from the bottom one', n < 2)}${b('intersect', 'intersect', 'Keep only the overlap', n < 2)}${b('exclude', 'exclude', 'Remove the overlap', n < 2)}</div>
      <div>${['alignL', 'alignC', 'alignR', 'alignT', 'alignM', 'alignB'].map((a, i) => b(a, a, ['Align left', 'Centre across', 'Align right', 'Align top', 'Centre down', 'Align bottom'][i], !n)).join('')}${b('distH', 'distH', 'Space evenly across', n < 3)}${b('distV', 'distV', 'Space evenly down', n < 3)}</div>
      <div>${b('flipH', 'flipH', 'Flip horizontally', !n)}${b('flipV', 'flipV', 'Flip vertically', !n)}${b('group', 'group', 'Group (Ctrl+G)', n < 2)}${b('ungroup', 'ungroup', 'Ungroup (Ctrl+Shift+G)', !g)}${b('up', 'up', 'Bring forward (])', !n)}${b('down', 'down', 'Send back ([)', !n)}</div>
      <span class="sp"></span>
      <div>${b('grid', 'grid', 'Grid', false, opt.grid)}${b('snap', 'snap', 'Snapping', false, opt.snap)}${b('keyline', 'keyline', 'Icon keylines', false, opt.keyline)}${b('outline', 'outline', 'Outline view', false, opt.outline)}${b('fit', 'fit', 'Fit to window (0)')}</div>
      <button type="button" class="hbtn ghost sm" data-cmd="import">Import SVG</button>`;
    const top = $('.ve-top'); if (top._h !== html) { const focus = top.contains(document.activeElement) ? document.activeElement.dataset.cmd : ''; top.innerHTML = top._h = html; if (focus) top.querySelector(`[data-cmd="${focus}"]`)?.focus(); }
  }

  // ---------- properties ----------
  const numField = (k, label, v, step = 1, min = '', max = '') => `<label class="ve-num"><span>${label}</span><input type="number" data-prop="${k}" value="${round(v)}" step="${step}"${min !== '' ? ` min="${min}"` : ''}${max !== '' ? ` max="${max}"` : ''}></label>`;
  const rangeField = (k, label, v, min, max, step) => `<label class="ve-range"><span>${label}<output class="num">${round(v)}</output></span><input type="range" data-prop="${k}" value="${v}" min="${min}" max="${max}" step="${step}"></label>`;
  function paintField(key, label, p) {
    const type = p?.type || 'none';
    let body = '';
    if (type === 'solid') body = `<div class="ve-color"><input type="color" data-paint="${key}.color" value="${p.color}" aria-label="${label} colour"><input type="text" data-paint="${key}.color" value="${p.color}" maxlength="7" aria-label="${label} hex"><input type="number" data-paint="${key}.a" value="${Math.round((p.a ?? 1) * 100)}" min="0" max="100" aria-label="${label} opacity"><span>%</span></div><div class="ve-swatches">${SWATCHES.map(c => `<button type="button" data-swatch="${key}" data-c="${c}" style="--c:${c}" aria-label="${c}"></button>`).join('')}</div>`;
    if (type === 'linear' || type === 'radial') body = `<div class="ve-gbar" style="background:linear-gradient(90deg,${[...p.stops].sort((a, b) => a.o - b.o).map(s => `${s.color} ${s.o * 100}%`).join(',')})"></div>${p.stops.map((s, i) => `<div class="ve-color"><input type="color" data-stop="${key}.${i}.color" value="${s.color}" aria-label="Stop ${i + 1} colour"><input type="range" data-stop="${key}.${i}.o" value="${s.o}" min="0" max="1" step=".01" aria-label="Stop ${i + 1} position"><input type="number" data-stop="${key}.${i}.a" value="${Math.round((s.a ?? 1) * 100)}" min="0" max="100" aria-label="Stop ${i + 1} opacity"><button type="button" class="act" data-delstop="${key}.${i}" aria-label="Remove stop"${p.stops.length <= 2 ? ' disabled' : ''}>×</button></div>`).join('')}<button type="button" class="hbtn ghost sm" data-addstop="${key}">Add stop</button>${type === 'linear' ? rangeField(`${key}.angle`, 'Angle', p.angle, 0, 360, 1) : ''}`;
    return `<fieldset class="ve-paint"><legend>${label}</legend><div class="seg wide">${[['none', 'None'], ['solid', 'Solid'], ['linear', 'Linear'], ['radial', 'Radial']].map(([v, l]) => `<button type="button" data-ptype="${key}" data-v="${v}" class="${type === v ? 'on' : ''}">${l}</button>`).join('')}</div>${body}</fieldset>`;
  }
  function drawProps() {
    const box_ = $('.ve-props'); if (box_.contains(document.activeElement) && /number|text|range|color/.test(document.activeElement.type) && !box_._force) return;
    box_._force = false;
    const l = selected(), o = l[0], src = o ? (o.type === 'group' ? o.children[0] : o) : current;
    if (!o) { box_.innerHTML = `<h4>New shapes</h4>${paintField('fill', 'Fill', current.fill)}${paintField('stroke', 'Stroke', current.stroke)}${current.stroke.type !== 'none' ? rangeField('sw', 'Stroke width', current.sw, 0, 80, 1) : ''}<p class="muted small">Pick a tool and drag on the canvas. Hold Shift to keep proportions, Alt to draw from the centre.</p>`; return; }
    const b = l.length === 1 ? box(o) : union(l);
    box_.innerHTML = `<h4>${l.length > 1 ? `${l.length} objects` : esc(o.name)}</h4>
      <div class="ve-geom">${numField('x', 'X', b.x)}${numField('y', 'Y', b.y)}${numField('w', 'W', b.w, 1, 1)}${numField('h', 'H', b.h, 1, 1)}${l.length === 1 && o.type !== 'group' ? numField('rot', 'Angle', o.rot) : ''}
      ${o.type === 'rect' || o.type === 'polygon' || o.type === 'star' ? numField('r', 'Corner', o.r || 0, 1, 0) : ''}${o.type === 'polygon' || o.type === 'star' ? numField('sides', o.type === 'star' ? 'Points' : 'Sides', o.sides, 1, 3, 60) : ''}</div>
      ${o.type === 'rect' ? `<label class="switch sm"><input type="checkbox" data-prop="smooth"${o.smooth ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Smooth (squircle) corners</span></label>` : ''}
      ${o.type === 'star' ? rangeField('inner', 'Point depth', o.inner ?? .45, .1, .95, .01) : ''}
      ${o.type === 'text' ? `<label class="ve-range"><span>Text</span><textarea data-prop="text" rows="2">${esc(o.text)}</textarea></label><div class="ve-geom">${numField('size', 'Size', o.size, 1, 4)}${numField('tracking', 'Spacing', o.tracking || 0)}<label class="ve-num"><span>Weight</span><select data-prop="weight">${[300, 400, 600, 700, 800, 900].map(w => `<option${+o.weight === w ? ' selected' : ''}>${w}</option>`).join('')}</select></label><label class="ve-num wide"><span>Font</span><select data-prop="font">${[['Segoe UI, system-ui, sans-serif', 'Segoe'], ['Georgia, serif', 'Georgia'], ['Consolas, monospace', 'Mono'], ['Arial Black, sans-serif', 'Black'], ['Trebuchet MS, sans-serif', 'Trebuchet']].map(([v, n]) => `<option value="${v}"${o.font === v ? ' selected' : ''}>${n}</option>`).join('')}</select></label></div>` : ''}
      ${paintField('fill', 'Fill', src.fill)}${paintField('stroke', 'Stroke', src.stroke)}
      ${src.stroke.type !== 'none' ? `${rangeField('sw', 'Stroke width', src.sw, 0, 80, .5)}${rangeField('dash', 'Dashes', src.dash || 0, 0, 80, 1)}<div class="ve-geom"><label class="ve-num wide"><span>Ends</span><select data-prop="cap">${['round', 'butt', 'square'].map(v => `<option${src.cap === v ? ' selected' : ''}>${v}</option>`).join('')}</select></label><label class="ve-num wide"><span>Corners</span><select data-prop="join">${['round', 'miter', 'bevel'].map(v => `<option${src.join === v ? ' selected' : ''}>${v}</option>`).join('')}</select></label></div>` : ''}
      ${rangeField('opacity', 'Opacity', o.opacity, 0, 1, .01)}
      <label class="ve-num wide"><span>Blend</span><select data-prop="blend">${BLENDS.map(v => `<option${o.blend === v ? ' selected' : ''}>${v}</option>`).join('')}</select></label>
      <label class="switch sm"><input type="checkbox" data-prop="shadow"${o.shadow?.on ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Drop shadow</span></label>
      ${o.shadow?.on ? `<div class="ve-color"><input type="color" data-shadow="color" value="${o.shadow.color}" aria-label="Shadow colour"></div>${rangeField('shadow.dx', 'Offset X', o.shadow.dx, -60, 60, 1)}${rangeField('shadow.dy', 'Offset Y', o.shadow.dy, -60, 60, 1)}${rangeField('shadow.blur', 'Blur', o.shadow.blur, 0, 80, 1)}${rangeField('shadow.a', 'Strength', o.shadow.a, 0, 1, .01)}` : ''}
      ${tool === 'node' && o.type === 'path' ? `<div class="row"><button type="button" class="hbtn ghost sm" data-cmd="smooth"${nodeSel ? '' : ' disabled'}>Smooth point</button><button type="button" class="hbtn ghost sm" data-cmd="corner"${nodeSel ? '' : ' disabled'}>Corner point</button><button type="button" class="hbtn ghost sm" data-cmd="open">${o.subs[nodeSel?.[0] || 0]?.closed ? 'Open path' : 'Close path'}</button></div>` : ''}
      ${o.type !== 'path' && o.type !== 'group' && o.type !== 'text' ? '<button type="button" class="hbtn ghost sm" data-cmd="topath">Convert to editable path</button>' : ''}`;
  }
  function drawLayers() {
    const el = $('.ve-layers'); if (el.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') return;
    el.innerHTML = `<h4>Layers <small class="num">${D.objects.length}</small></h4><ul role="listbox" aria-multiselectable="true">${[...D.objects].reverse().map(o => {
      const defs = [], b = worldBox(o), pad = Math.max(b.w, b.h) * .08 + 1;
      return `<li role="option" aria-selected="${sel.includes(o.id)}" class="${sel.includes(o.id) ? 'on' : ''}" draggable="true" data-layer="${o.id}" tabindex="0"><svg viewBox="${b.x - pad} ${b.y - pad} ${b.w + pad * 2} ${b.h + pad * 2}" aria-hidden="true">${(() => { const m = markup({ ...o, visible: true }, defs, 'th-'); return `<defs>${defs.join('')}</defs>${m}`; })()}</svg><input value="${esc(o.name)}" data-name="${o.id}" aria-label="Layer name" readonly>
        <button type="button" class="act" data-vis="${o.id}" aria-label="${o.visible ? 'Hide' : 'Show'} layer" aria-pressed="${!o.visible}">${o.visible ? '●' : '○'}</button><button type="button" class="act" data-lock="${o.id}" aria-label="${o.locked ? 'Unlock' : 'Lock'} layer" aria-pressed="${o.locked}">${o.locked ? T.lock : T.unlock}</button></li>`; }).join('')}</ul>${D.objects.length ? '' : '<p class="muted small">Nothing drawn yet.</p>'}`;
  }

  // ---------- commands ----------
  function order(dir, end = false) {
    const ids = new Set(sel), list = D.objects;
    if (end) D.objects = dir > 0 ? [...list.filter(o => !ids.has(o.id)), ...list.filter(o => ids.has(o.id))] : [...list.filter(o => ids.has(o.id)), ...list.filter(o => !ids.has(o.id))];
    else { const idx = list.map((o, i) => i); if (dir > 0) idx.reverse(); for (const i of idx) { const j = i + dir; if (ids.has(list[i].id) && list[j] && !ids.has(list[j].id)) [list[i], list[j]] = [list[j], list[i]]; } }
  }
  function remove() { if (tool === 'node' && nodeSel) { const o = selected()[0], [s, p] = nodeSel; o.subs[s].pts.splice(p, 1); if (o.subs[s].pts.length < 2) o.subs.splice(s, 1); if (!o.subs.length) { D.objects = D.objects.filter(x => x !== o); sel = []; } nodeSel = null; } else { D.objects = D.objects.filter(o => !sel.includes(o.id) || o.locked); sel = []; } commit(); draw(); }
  const reid = o => { o.id = uid(); o.children?.forEach(reid); return o; };
  function paste(list, offset = 16) { const added = list.map(o => { const c = reid(structuredClone(o)); moveBy(c, offset, offset); return c; }); D.objects.push(...added); sel = added.map(o => o.id); commit(); draw(); }
  function command(cmd) {
    const l = selected(), b = union(l);
    if (cmd === 'undo') return undo(); if (cmd === 'redo') return redo();
    if (cmd in opt) { opt[cmd] = !opt[cmd]; return draw(); }
    if (cmd === 'fit') return fitView();
    if (cmd === 'import') return file.click();
    if (['union', 'subtract', 'intersect', 'exclude'].includes(cmd)) {
      const shapes = D.objects.filter(o => sel.includes(o.id)); if (shapes.some(o => o.type === 'text' || o.type === 'group')) return flash('Shape operations work on shapes and paths. Ungroup first; text stays as text.');
      let subs = toPath(shapes[0]).subs; for (const o of shapes.slice(1)) subs = booleanOp(subs, toPath(o).subs, cmd);
      if (!subs.length) return flash('Those shapes don’t overlap that way.');
      const result = { ...toPath(shapes[0]), id: uid(), name: cmd.charAt(0).toUpperCase() + cmd.slice(1), subs };
      const at = D.objects.indexOf(shapes[0]); D.objects = D.objects.filter(o => !sel.includes(o.id)); D.objects.splice(Math.min(at, D.objects.length), 0, result); sel = [result.id];
    }
    else if (cmd.startsWith('align')) { const ref = l.length > 1 ? b : { x: 0, y: 0, w: D.size, h: D.size }, k = cmd.slice(5); for (const o of l) { const r = worldBox(o); moveBy(o, k === 'L' ? ref.x - r.x : k === 'C' ? ref.x + ref.w / 2 - r.x - r.w / 2 : k === 'R' ? ref.x + ref.w - r.x - r.w : 0, k === 'T' ? ref.y - r.y : k === 'M' ? ref.y + ref.h / 2 - r.y - r.h / 2 : k === 'B' ? ref.y + ref.h - r.y - r.h : 0); } }
    else if (cmd === 'distH' || cmd === 'distV') { const x = cmd === 'distH', s = [...l].sort((p, q) => (x ? worldBox(p).x - worldBox(q).x : worldBox(p).y - worldBox(q).y)), total = s.reduce((n, o) => n + (x ? worldBox(o).w : worldBox(o).h), 0), gap = ((x ? b.w : b.h) - total) / (s.length - 1); let at = x ? b.x : b.y; for (const o of s) { const r = worldBox(o); moveBy(o, x ? at - r.x : 0, x ? 0 : at - r.y); at += (x ? r.w : r.h) + gap; } }
    else if (cmd === 'flipH' || cmd === 'flipV') { for (const o of l) flip(o, cmd === 'flipH', [b.x + b.w / 2, b.y + b.h / 2]); }
    else if (cmd === 'group') { const items = D.objects.filter(o => sel.includes(o.id)), at = D.objects.indexOf(items.at(-1)) - items.length + 1, g = make('group', { children: items }); D.objects = D.objects.filter(o => !sel.includes(o.id)); D.objects.splice(Math.max(0, at), 0, g); sel = [g.id]; }
    else if (cmd === 'ungroup') { const next = []; for (const o of l.filter(o => o.type === 'group')) { const i = D.objects.indexOf(o); o.children.forEach(c => (c.opacity *= o.opacity)); D.objects.splice(i, 1, ...o.children); next.push(...o.children.map(c => c.id)); } sel = next.length ? next : sel; }
    else if (cmd === 'up') order(1); else if (cmd === 'down') order(-1);
    else if (cmd === 'topath') { const i = D.objects.indexOf(l[0]); D.objects[i] = toPath(l[0]); tool = 'node'; }
    else if (['smooth', 'corner'].includes(cmd) && nodeSel) { const o = l[0], sub = o.subs[nodeSel[0]], p = sub.pts[nodeSel[1]]; if (cmd === 'corner') Object.assign(p, pt(p.x, p.y)); else { const n = sub.pts.length, prev = sub.pts[(nodeSel[1] + n - 1) % n], next = sub.pts[(nodeSel[1] + 1) % n]; Object.assign(p, smoothPts([[prev.x, prev.y], [p.x, p.y], [next.x, next.y]], false, 181)[1]); } }
    else if (cmd === 'open') { const s = l[0].subs[nodeSel?.[0] || 0]; s.closed = !s.closed; }
    commit(); $('.ve-props')._force = true; draw();
  }
  function flash(msg) { const s = $('.ve-status'); s.textContent = msg; s.classList.add('warn'); setTimeout(() => { s.classList.remove('warn'); draw(); }, 3200); }

  // ---------- pen ----------
  function finishPen(closed) { if (pen && pen.pts.length > 1) { const o = make('path', { subs: [{ closed, pts: pen.pts }], fill: closed ? structuredClone(current.fill) : none(), stroke: closed ? structuredClone(current.stroke) : current.stroke.type === 'none' ? solid(current.fill.color || '#FFFFFF') : structuredClone(current.stroke), sw: current.sw }); D.objects.push(o); sel = [o.id]; commit(); } pen = null; draw(); }

  // ---------- pointer ----------
  on(stage, 'pointerdown', e => {
    stage.focus({ preventScroll: true });
    const target = e.target, [x, y] = toDoc(e);
    stage.setPointerCapture(e.pointerId);
    if (e.button === 1 || tool === 'hand' || space) { drag = { kind: 'pan', sx: e.clientX, sy: e.clientY, view: { ...view } }; return; }
    if (e.button !== 0) return;
    if (tool === 'eyedropper') { const id = target.closest('[data-id]')?.dataset.id, o = byId(id); if (!o) return; const src = o.type === 'group' ? o.children[0] : o, p = structuredClone(src.fill.type !== 'none' ? src.fill : src.stroke); current.fill = p; for (const s of selected()) if (s.id !== id) setProp(s, 'fill', structuredClone(p)); tool = 'select'; commit(); return draw(); }
    if (tool === 'pen') {
      const [px, py] = snapPoint(x, y);
      if (pen && pen.pts.length > 2) { const [fx, fy] = toScreen(pen.pts[0].x, pen.pts[0].y), [cx, cy] = toScreen(px, py); if (Math.hypot(fx - cx, fy - cy) < 10) { drag = { kind: 'penclose', p: pen.pts[0] }; return; } }
      pen ||= { pts: [] }; const p = pt(px, py); pen.pts.push(p); drag = { kind: 'penpull', p }; return draw();
    }
    if (tool === 'pencil') { drag = { kind: 'pencil', pts: [[x, y]] }; return; }
    if (tool === 'text') { const o = make('text', { text: 'Aa', size: Math.round(D.size * .3), weight: 800, font: 'Segoe UI, system-ui, sans-serif', x, y, fill: structuredClone(current.fill), name: 'Text' }); measureText(o); o.x -= o.w / 2; o.y -= o.h / 2; D.objects.push(o); sel = [o.id]; tool = 'select'; commit(); draw(); requestAnimationFrame(() => requestAnimationFrame(() => $('.ve-props textarea')?.select())); return; }
    if (['rect', 'ellipse', 'polygon', 'star', 'line'].includes(tool)) {
      const [px, py] = snapPoint(x, y);
      const props = { x: px, y: py, w: 1, h: 1, fill: structuredClone(current.fill), stroke: structuredClone(current.stroke), sw: current.sw, ...(tool === 'polygon' ? { sides: 6, r: 0 } : tool === 'star' ? { sides: 5, inner: .45, r: 0 } : tool === 'rect' ? { r: 0 } : {}) };
      const o = tool === 'line' ? make('path', { ...props, name: 'Line', fill: none(), stroke: current.stroke.type === 'none' ? solid(current.fill.color || '#FFFFFF') : structuredClone(current.stroke), subs: [{ closed: false, pts: [pt(px, py), pt(px, py)] }] }) : make(tool, props);
      D.objects.push(o); sel = [o.id]; drag = { kind: 'create', o, from: [px, py] }; return draw();
    }
    if (tool === 'node') {
      const o = selected()[0], knob = target.closest('[data-h]'), anchor = target.closest('.ve-anchor[data-s]');
      if (knob) { drag = { kind: 'knob', o, s: +knob.dataset.s, p: +knob.dataset.p, h: knob.dataset.h, alt: e.altKey }; return; }
      if (anchor) { nodeSel = [+anchor.dataset.s, +anchor.dataset.p]; drag = { kind: 'anchor', o, s: nodeSel[0], p: nodeSel[1], pull: e.altKey }; $('.ve-props')._force = true; return draw(); }
      const hit = byId(target.closest('[data-id]')?.dataset.id);
      if (hit && !hit.locked) { if (hit.type !== 'text' && hit.type !== 'group' && hit.type !== 'path') { const i = D.objects.indexOf(hit); D.objects[i] = toPath(hit); commit(); } sel = [hit.id]; nodeSel = null; $('.ve-props')._force = true; return draw(); }
      sel = []; nodeSel = null; return draw();
    }
    // select tool
    const spinH = target.closest('[data-spin]'), handle = target.closest('[data-handle]');
    if (spinH) { const f = frameOf(); drag = { kind: 'spin', c: f.c, start: Math.atan2(y - f.c[1], x - f.c[0]), base: structuredClone(selected()), rot: f.rot }; return; }
    if (handle) { const f = frameOf(); drag = { kind: 'size', id: handle.dataset.handle, frame: f, base: structuredClone(selected()) }; return; }
    const hit = byId(target.closest('[data-id]')?.dataset.id);
    if (hit && !hit.locked) {
      if (e.shiftKey) { sel = sel.includes(hit.id) ? sel.filter(i => i !== hit.id) : [...sel, hit.id]; $('.ve-props')._force = true; return draw(); }
      if (!sel.includes(hit.id)) { sel = [hit.id]; $('.ve-props')._force = true; }
      drag = { kind: 'move', from: [x, y], base: structuredClone(selected()), box: union(selected()), alt: e.altKey, moved: false };
      return draw();
    }
    drag = { kind: 'marquee', from: [x, y], to: [x, y], keep: e.shiftKey ? [...sel] : [] }; if (!e.shiftKey) sel = []; $('.ve-props')._force = true; draw();
  });
  const replace = list => { for (const o of list) { const i = D.objects.findIndex(x => x.id === o.id); if (i >= 0) D.objects[i] = o; } };
  on(stage, 'pointermove', e => {
    let [x, y] = toDoc(e);
    if (!drag) { if (pen) { pen.hover = snapPoint(x, y); drawOver(); } return; }
    const d = drag;
    if (d.kind === 'pan') { const r = svg.getBoundingClientRect(), k = r.width / (svg.clientWidth || 1); view.x = d.view.x + (e.clientX - d.sx) / k; view.y = d.view.y + (e.clientY - d.sy) / k; }
    else if (d.kind === 'marquee') { d.to = [x, y]; const a = { x: Math.min(d.from[0], x), y: Math.min(d.from[1], y), w: Math.abs(x - d.from[0]), h: Math.abs(y - d.from[1]) }; sel = [...new Set([...d.keep, ...D.objects.filter(o => { if (o.locked || !o.visible) return false; const b = worldBox(o); return b.x < a.x + a.w && b.x + b.w > a.x && b.y < a.y + a.h && b.y + b.h > a.y; }).map(o => o.id)])]; }
    else if (d.kind === 'move') {
      let dx = x - d.from[0], dy = y - d.from[1];
      if (!d.moved && Math.hypot(dx, dy) * view.z < 3) return;
      if (!d.moved && d.alt) { const copies = d.base.map(o => reid(structuredClone(o))); D.objects.push(...copies); sel = copies.map(o => o.id); d.base = structuredClone(copies); }
      d.moved = true;
      if (e.shiftKey) Math.abs(dx) > Math.abs(dy) ? (dy = 0) : (dx = 0);
      [dx, dy] = snapMove(d.box, dx, dy, sel);
      const next = structuredClone(d.base); next.forEach(o => moveBy(o, dx, dy)); replace(next);
    }
    else if (d.kind === 'size') {
      const f = d.frame, b = f.box, [lx, ly] = rotPoint(...(f.rot ? [x, y] : snapPoint(x, y, sel)), -f.rot, ...f.c);
      let x0 = b.x, y0 = b.y, x1 = b.x + b.w, y1 = b.y + b.h;
      if (d.id.includes('w')) x0 = Math.min(lx, x1 - 1); if (d.id.includes('e')) x1 = Math.max(lx, x0 + 1); if (d.id.includes('n')) y0 = Math.min(ly, y1 - 1); if (d.id.includes('s')) y1 = Math.max(ly, y0 + 1);
      const corner = d.id.length === 2;
      if (e.shiftKey && corner && b.w && b.h) { const k = Math.max((x1 - x0) / b.w, (y1 - y0) / b.h); if (d.id.includes('w')) x0 = x1 - b.w * k; else x1 = x0 + b.w * k; if (d.id.includes('n')) y0 = y1 - b.h * k; else y1 = y0 + b.h * k; }
      if (e.altKey) { const cx = b.x + b.w / 2, cy = b.y + b.h / 2, hw = Math.max(Math.abs(d.id.includes('w') ? cx - x0 : x1 - cx), .5), hh = Math.max(Math.abs(d.id.includes('n') ? cy - y0 : y1 - cy), .5); if (/[ew]/.test(d.id)) { x0 = cx - hw; x1 = cx + hw; } if (/[ns]/.test(d.id)) { y0 = cy - hh; y1 = cy + hh; } }
      const to = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
      const next = structuredClone(d.base); next.forEach(o => resize(o, b, to));
      // a rotated object keeps its opposite edge still: shift by how its centre moved
      if (f.rot && next.length === 1) { const nc = [to.x + to.w / 2, to.y + to.h / 2], [rx, ry] = rotPoint(...nc, f.rot, ...f.c); moveBy(next[0], rx - nc[0], ry - nc[1]); }
      replace(next);
    }
    else if (d.kind === 'spin') { let deg = (Math.atan2(y - d.c[1], x - d.c[0]) - d.start) * 180 / Math.PI; if (e.shiftKey) deg = Math.round((d.rot + deg) / 15) * 15 - d.rot; else deg = Math.round(deg * 2) / 2; const next = structuredClone(d.base); next.forEach(o => spin(o, deg, d.c)); replace(next); }
    else if (d.kind === 'create') {
      let [px, py] = snapPoint(x, y, [d.o.id]); const [fx, fy] = d.from;
      if (d.o.type === 'path') { if (e.shiftKey) { const a = Math.round(Math.atan2(py - fy, px - fx) / (Math.PI / 4)) * (Math.PI / 4), l = Math.hypot(px - fx, py - fy); px = fx + Math.cos(a) * l; py = fy + Math.sin(a) * l; } d.o.subs[0].pts[1] = pt(px, py); }
      else { let w = px - fx, h = py - fy; if (e.shiftKey) { const m = Math.max(Math.abs(w), Math.abs(h)); w = Math.sign(w || 1) * m; h = Math.sign(h || 1) * m; } if (e.altKey) Object.assign(d.o, { x: fx - Math.abs(w), y: fy - Math.abs(h), w: Math.abs(w) * 2 || 1, h: Math.abs(h) * 2 || 1 }); else Object.assign(d.o, { x: Math.min(fx, fx + w), y: Math.min(fy, fy + h), w: Math.abs(w) || 1, h: Math.abs(h) || 1 }); }
    }
    else if (d.kind === 'penpull') { const p = d.p; Object.assign(p, { ox: x, oy: y, ix: 2 * p.x - x, iy: 2 * p.y - y }); }
    else if (d.kind === 'pencil') { const l = d.pts.at(-1); if (Math.hypot(x - l[0], y - l[1]) * view.z > 2) d.pts.push([x, y]); return drawOver(); }
    else if (d.kind === 'anchor') { const p = d.o.subs[d.s].pts[d.p]; [x, y] = rotPoint(x, y, -d.o.rot, ...centre(d.o)); if (d.pull) Object.assign(p, { ox: x, oy: y, ix: 2 * p.x - x, iy: 2 * p.y - y }); else { const [nx, ny] = snapPoint(x, y, [d.o.id]), dx = nx - p.x, dy = ny - p.y; Object.assign(p, { x: nx, y: ny, ix: p.ix + dx, iy: p.iy + dy, ox: p.ox + dx, oy: p.oy + dy }); } }
    else if (d.kind === 'knob') { const p = d.o.subs[d.s].pts[d.p], k = d.h, other = k === 'i' ? 'o' : 'i'; [x, y] = rotPoint(x, y, -d.o.rot, ...centre(d.o)); const len = Math.hypot(p[other + 'x'] - p.x, p[other + 'y'] - p.y), a = Math.atan2(y - p.y, x - p.x); p[k + 'x'] = x; p[k + 'y'] = y; if (!d.alt && !e.altKey && len > .5) { p[other + 'x'] = p.x - Math.cos(a) * len; p[other + 'y'] = p.y - Math.sin(a) * len; } }
    draw();
  });
  const release = () => {
    const d = drag; if (!d) return; drag = null; guides = [];
    if (d.kind === 'create') { const b = worldBox(d.o); if (Math.max(b.w, b.h) < 4) { if (d.o.type === 'path') D.objects = D.objects.filter(o => o !== d.o); else Object.assign(d.o, { x: d.from[0] - D.size * .2, y: d.from[1] - D.size * .2, w: D.size * .4, h: D.size * .4 }); } tool = 'select'; }
    if (d.kind === 'penclose') finishPen(true);
    if (d.kind === 'pencil' && d.pts.length > 3) { const closed = Math.hypot(d.pts[0][0] - d.pts.at(-1)[0], d.pts[0][1] - d.pts.at(-1)[1]) * view.z < 14; const simple = simplify(d.pts, 2.2 / view.z); if (closed) simple.pop(); if (simple.length > 1) { const o = make('path', { name: 'Drawing', subs: [{ closed, pts: smoothPts(simple, closed, 62) }], fill: closed ? structuredClone(current.fill) : none(), stroke: closed ? structuredClone(current.stroke) : current.stroke.type === 'none' ? solid(current.fill.color || '#FFFFFF') : structuredClone(current.stroke), sw: current.sw }); D.objects.push(o); sel = [o.id]; } }
    if (d.kind !== 'penpull') commit();
    $('.ve-props')._force = true; draw();
  };
  on(stage, 'pointerup', release); on(stage, 'pointercancel', release);
  on(stage, 'dblclick', e => {
    if (pen) { pen.pts.pop(); return finishPen(false); }
    const o = selected()[0];
    if (tool === 'node' && o?.type === 'path') { // double-click the outline to add a point exactly there
      const [x, y] = rotPoint(...toDoc(e), -o.rot, ...centre(o)); let best = null;
      o.subs.forEach((s, si) => { const n = s.pts.length, last = s.closed ? n : n - 1; for (let i = 0; i < last; i++) for (let k = 1; k < 40; k++) { const t = k / 40, [bx, by] = bez(s.pts[i], s.pts[(i + 1) % n], t), d = Math.hypot(bx - x, by - y); if (!best || d < best.d) best = { d, si, i, t }; } });
      if (best && best.d * view.z < 10) { const s = o.subs[best.si], a = s.pts[best.i], b = s.pts[(best.i + 1) % s.pts.length], t = best.t, L = (p, q) => [p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t];
        const p0 = [a.x, a.y], p1 = [a.ox, a.oy], p2 = [b.ix, b.iy], p3 = [b.x, b.y], m1 = L(p0, p1), m2 = L(p1, p2), m3 = L(p2, p3), n1 = L(m1, m2), n2 = L(m2, m3), c = L(n1, n2);
        const straight = a.ox === a.x && a.oy === a.y && b.ix === b.x && b.iy === b.y;
        if (!straight) { [a.ox, a.oy] = m1; [b.ix, b.iy] = m3; }
        s.pts.splice(best.i + 1, 0, straight ? pt(...c) : pt(c[0], c[1], n1[0], n1[1], n2[0], n2[1])); nodeSel = [best.si, best.i + 1]; commit(); draw(); }
      return;
    }
    const hit = byId(e.target.closest('[data-id]')?.dataset.id); if (tool === 'select' && hit && !hit.locked && hit.type !== 'group' && hit.type !== 'text') { command('topath'); }
    else if (hit?.type === 'text') $('.ve-props textarea')?.select();
  });
  on(stage, 'wheel', e => { e.preventDefault(); const r = svg.getBoundingClientRect(), k = r.width / (svg.clientWidth || 1); if (e.ctrlKey || e.metaKey || !e.shiftKey && Math.abs(e.deltaY) >= 50 && !e.deltaX) zoomAt(Math.exp(-e.deltaY * .0016), (e.clientX - r.left) / k, (e.clientY - r.top) / k); else { view.x -= e.shiftKey ? e.deltaY : e.deltaX; view.y -= e.shiftKey ? 0 : e.deltaY; draw(); } }, { passive: false });

  // ---------- panels ----------
  function setProp(o, k, v) { if (o.type === 'group') { if (['opacity', 'blend', 'shadow'].includes(k)) o[k] = v; else o.children.forEach(c => setProp(c, k, structuredClone(v))); } else o[k] = v; }
  const targets = () => (selected().length ? selected() : [current]);
  const paintOfSel = key => { const o = targets()[0]; return (o.type === 'group' ? o.children[0] : o)[key]; };
  function editPaint(key, fn) { for (const o of targets()) { const apply = x => { if (x.type === 'group') return x.children.forEach(apply); const p = structuredClone(x[key]); x[key] = fn(p) || p; }; apply(o); } if (sel.length) current[key] = structuredClone(paintOfSel(key)); }
  const side = $('.ve-side');
  on(side, 'input', e => {
    const t = e.target, l = selected(), o = l[0];
    if (t.dataset.name) return;
    if (t.dataset.paint) { const [key, prop] = t.dataset.paint.split('.'); if (prop === 'color' && !/^#[0-9a-f]{6}$/i.test(t.value)) return; editPaint(key, p => { p[prop] = prop === 'a' ? Math.max(0, Math.min(100, +t.value)) / 100 : t.value; }); }
    else if (t.dataset.stop) { const [key, i, prop] = t.dataset.stop.split('.'); editPaint(key, p => { if (p.stops?.[+i]) p.stops[+i][prop] = prop === 'color' ? t.value : prop === 'a' ? +t.value / 100 : +t.value; }); }
    else if (t.dataset.shadow) { for (const x of l) if (x.shadow) x.shadow.color = t.value; }
    else if (t.dataset.prop) {
      const k = t.dataset.prop, v = t.type === 'checkbox' ? t.checked : t.type === 'number' || t.type === 'range' ? +t.value : t.value;
      if (t.type === 'number' && t.value === '') return;
      const out = t.closest('label')?.querySelector('output'); if (out) out.textContent = round(+v);
      if (k.includes('.')) { const [a, b] = k.split('.'); if (b === 'angle') editPaint(a, p => { p.angle = v; }); else for (const x of l) if (x.shadow) x.shadow[b] = v; }
      else if (['x', 'y', 'w', 'h'].includes(k) && o) { const b = l.length === 1 ? box(o) : union(l); if (k === 'x' || k === 'y') l.forEach(x => moveBy(x, k === 'x' ? v - b.x : 0, k === 'y' ? v - b.y : 0)); else if (v >= 1) { const to = { ...b, [k]: v }; l.forEach(x => resize(x, b, to)); } }
      else if (k === 'shadow') l.forEach(x => (x.shadow = v ? { on: true, dx: 0, dy: 12, blur: 24, color: '#000000', a: .45 } : null));
      else { targets().forEach(x => setProp(x, k, k === 'weight' ? +v : k === 'sides' ? Math.max(3, Math.min(60, Math.round(v))) : v)); if (['sw', 'dash', 'cap', 'join'].includes(k)) current[k] = v; if (o?.type === 'text') measureText(o); }
    } else return;
    cancelAnimationFrame(raf); raf = requestAnimationFrame(() => { const keep = document.activeElement; drag = { kind: 'prop' }; render(); drag = null; keep?.focus?.({ preventScroll: true }); });
  });
  on(side, 'change', e => { if (e.target.dataset.name) { const o = byId(e.target.dataset.name); if (o) o.name = e.target.value.trim() || o.name; e.target.readOnly = true; } commit(); if (e.target.type === 'checkbox' || e.target.tagName === 'SELECT' || e.target.type === 'color') { $('.ve-props')._force = true; draw(); } });
  on(side, 'click', e => {
    const b = e.target.closest('button'), li = e.target.closest('[data-layer]');
    if (b?.dataset.cmd) return command(b.dataset.cmd);
    if (b?.dataset.ptype) { const key = b.dataset.ptype, type = b.dataset.v; editPaint(key, p => { const base = p.color || p.stops?.[0]?.color || '#2DD4BF'; if (type === 'none') return none(); if (type === 'solid') return solid(base); const g = p.stops ? { ...p, type } : linear(base, '#818CF8'); g.type = type; return g; }); if (!sel.length) current[key] = paintOfSel(key); }
    else if (b?.dataset.swatch) editPaint(b.dataset.swatch, p => { p.color = b.dataset.c; });
    else if (b?.dataset.addstop) editPaint(b.dataset.addstop, p => { p.stops.push({ o: .5, color: '#FFFFFF', a: 1 }); });
    else if (b?.dataset.delstop) { const [key, i] = b.dataset.delstop.split('.'); editPaint(key, p => { if (p.stops.length > 2) p.stops.splice(+i, 1); }); }
    else if (b?.dataset.vis) { const o = byId(b.dataset.vis); o.visible = !o.visible; }
    else if (b?.dataset.lock) { const o = byId(b.dataset.lock); o.locked = !o.locked; }
    else if (li && !(e.target.tagName === 'INPUT' && !e.target.readOnly)) { const id = li.dataset.layer; sel = e.shiftKey || e.ctrlKey ? (sel.includes(id) ? sel.filter(i => i !== id) : [...sel, id]) : [id]; nodeSel = null; $('.ve-props')._force = true; return draw(); }
    else return;
    commit(); $('.ve-props')._force = true; draw();
  });
  on(side, 'dblclick', e => { if (e.target.dataset.name) { e.target.readOnly = false; e.target.select(); } });
  let layerDrag = null;
  on(side, 'dragstart', e => { const li = e.target.closest?.('[data-layer]'); if (li) { layerDrag = li.dataset.layer; e.dataTransfer.setData('text/plain', 'layer'); } });
  on(side, 'dragover', e => { if (layerDrag && e.target.closest('[data-layer]')) e.preventDefault(); });
  on(side, 'drop', e => { const li = e.target.closest('[data-layer]'); if (!layerDrag || !li || li.dataset.layer === layerDrag) return; e.preventDefault(); const moving = byId(layerDrag), to = D.objects.indexOf(byId(li.dataset.layer)); D.objects.splice(D.objects.indexOf(moving), 1); D.objects.splice(to, 0, moving); layerDrag = null; commit(); draw(); });
  on($('.ve-top'), 'click', e => { const b = e.target.closest('[data-cmd]'); if (b) command(b.dataset.cmd); });
  on($('.ve-tools'), 'click', e => { const b = e.target.closest('[data-tool]'); if (!b) return; setTool(b.dataset.tool); });
  function setTool(t) { if (pen && t !== 'pen') finishPen(false); tool = t; nodeSel = null; if (t === 'node' && sel.length === 1) { const o = selected()[0]; if (!['path', 'text', 'group'].includes(o.type)) { D.objects[D.objects.indexOf(o)] = toPath(o); commit(); } } $('.ve-props')._force = true; draw(); }
  on(file, 'change', async () => { const f = file.files[0]; file.value = ''; if (!f) return; try { add(importSVG(await f.text(), D.size)); } catch (x) { flash(x.message); } });
  on(stage, 'dragover', e => { if (e.dataTransfer.types.includes('Files')) e.preventDefault(); });
  on(stage, 'drop', async e => { const f = [...e.dataTransfer.files].find(x => /\.svg$/i.test(x.name)); if (!f) return; e.preventDefault(); try { add(importSVG(await f.text(), D.size)); } catch (x) { flash(x.message); } });
  function add(list) { const items = Array.isArray(list) ? list : [list]; D.objects.push(...items); sel = items.map(o => o.id); tool = 'select'; commit(); $('.ve-props')._force = true; draw(); }

  // ---------- keyboard (captured before the hub's own shortcuts while the editor is on screen) ----------
  on(window, 'keydown', e => {
    if (!host.isConnected || host.offsetParent === null || document.querySelector('dialog[open]')) return;
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) && !e.target.readOnly;
    if (typing) { if (e.key === 'Enter' && e.target.dataset?.name) e.target.blur(); return; }
    const k = e.key.toLowerCase(), mod = e.ctrlKey || e.metaKey, eat = () => { e.preventDefault(); e.stopImmediatePropagation(); };
    if (mod) {
      if (k === 'z') { eat(); return e.shiftKey ? redo() : undo(); }
      if (k === 'y') { eat(); return redo(); }
      if (k === 'a') { eat(); return pick(D.objects.filter(o => !o.locked && o.visible).map(o => o.id)); }
      if (k === 'c' || k === 'x') { if (!sel.length) return; eat(); clip = structuredClone(selected()); if (k === 'x') remove(); return; }
      if (k === 'v') { if (!clip.length) return; eat(); return paste(clip); }
      if (k === 'd') { eat(); if (sel.length) paste(selected()); return; }
      if (k === 'g') { eat(); if (e.shiftKey) command('ungroup'); else if (sel.length > 1) command('group'); return; }
      return;
    }
    if (e.altKey) return;
    if (k === ' ') { eat(); if (!space) { space = true; draw(); } return; }
    if (k === 'enter' && pen) { eat(); return finishPen(false); }
    if (k === 'escape') { if (pen) { eat(); return finishPen(false); } if (sel.length) { eat(); return pick([]); } return; }
    if (k === 'delete' || k === 'backspace') { eat(); if (sel.length) remove(); return; }
    if (e.key.startsWith('Arrow') && sel.length && !e.target.closest('.ve-tools, .seg')) { eat(); const n = e.shiftKey ? 10 : 1, dx = k === 'arrowleft' ? -n : k === 'arrowright' ? n : 0, dy = k === 'arrowup' ? -n : k === 'arrowdown' ? n : 0; if (tool === 'node' && nodeSel) { const p = selected()[0].subs[nodeSel[0]].pts[nodeSel[1]]; for (const q of ['', 'i', 'o']) { p[q + 'x'] += dx; p[q + 'y'] += dy; } } else selected().forEach(o => !o.locked && moveBy(o, dx, dy)); commit(); $('.ve-props')._force = true; return draw(); }
    if (k === '[' || k === ']') { eat(); order(k === ']' ? 1 : -1, e.shiftKey); commit(); return draw(); }
    if (k === '0') { eat(); return fitView(); }
    if (k === '+' || k === '=') { eat(); return zoomAt(1.25); }
    if (k === '-') { eat(); return zoomAt(.8); }
    const t = TOOLS.find(x => x && x[2].toLowerCase() === k); if (t) { eat(); setTool(t[0]); } else if (k === 'n' || k === '?') return;
  }, { capture: true });
  on(window, 'keyup', e => { if (e.key === ' ' && space) { space = false; draw(); } });

  let sized = false;
  ro = new ResizeObserver(() => { if (!stage.clientWidth) return; if (!sized) { sized = true; fitView(); } else draw(); }); ro.observe(stage);
  draw();
  return {
    doc: () => D, add, undo, redo,
    load(next) { D = structuredClone(next); history = []; future = []; sel = []; pen = null; committed = snapshot(); onChange?.(D); fitView(); },
    destroy() { ac.abort(); ro.disconnect(); cancelAnimationFrame(raf); host.replaceChildren(); }
  };
}
