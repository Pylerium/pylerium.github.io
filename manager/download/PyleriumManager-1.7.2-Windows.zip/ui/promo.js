// Promo Studio: one place to make everything that launches an app. This is the shell (app picker, sections, jobs,
// settings, and the editor strip); each section lives in ui/promo/*.js and mounts into the stage.
import { $, esc, api, toast, confirmBox } from './core.js';
import { ST, app, I, media, active, onJobs, addJob, watch, drawJobs, sw } from './promo/common.js';
import * as Video from './promo/video.js';
import * as Images from './promo/images.js';
import * as Icons from './promo/icons.js';
import * as Launch from './promo/launch.js';

const SECTIONS = [['video', 'film', 'Video', 'Directed promo films'], ['images', 'image', 'Images', 'Every store and social size'], ['icons', 'edit', 'Icon Studio', 'Draw and export icons'], ['copy', 'megaphone', 'Launch kit', 'Posts and one download'], ['library', 'folder', 'Library', 'Media and screen capture']];
let mounted = null, loadSeq = 0, query = '';

export function init() {
  if (!document.querySelector('link[data-promo]')) { const l = Object.assign(document.createElement('link'), { rel: 'stylesheet', href: '/ui/promo/promo.css' }); l.dataset.promo = '1'; document.head.append(l); }
  const root = $('#promoPanel');
  root.className = 'ps';
  root.addEventListener('click', onClick);
  root.addEventListener('input', e => { if (e.target.id === 'psFind') { query = e.target.value.toLowerCase(); drawApps(); } });
  root.addEventListener('promo:appchanged', () => drawApps());
  onJobs(async done => { if (!ST.data || !mounted) return; await reload(); if (done.some(j => j.kind === 'voice')) { ST.film = null; if (mounted === Video) { unmount(); return open(); } } if (done.some(j => j.appId === ST.appId)) { if (mounted === Video) Video.drawOutputs(); else if (mounted === Images) Images.update(); else if (mounted === Launch) Launch.update(); } drawApps(); });
  // leaving the tab stops playback; the page itself stays as it was
  addEventListener('hashchange', () => { if (!location.hash.startsWith('#/promo')) Video.stop(); });
}
export async function show(sub) {
  // #/promo/<app id or section>
  const section = SECTIONS.find(s => s[0] === sub)?.[0];
  const wanted = section ? '' : sub;
  const mine = ++loadSeq;
  const first = !ST.data;
  if (!(await reload()) || mine !== loadSeq) return;
  if (wanted && ST.data.apps.some(a => a.id === wanted) && wanted !== ST.appId) { ST.appId = wanted; unmount(); }
  if (section && section !== ST.section) { ST.section = section; unmount(); }
  if (!ST.data.apps.find(a => a.id === ST.appId)) ST.appId = (ST.data.apps.find(a => a.published && a.shots.length) || ST.data.apps[0])?.id || '';
  if (first || !$('#psStage')) skeleton();
  drawApps(); drawJobs(); watch();
  if (!mounted && app()) open();
}
async function reload() {
  try { ST.data = await api('GET', '/api/promo'); return true; }
  catch (e) { toast(e.message, 'err'); if (!ST.data) $('#promoPanel').innerHTML = `<div class="card"><div class="emptystate">${I('alert')}<h4>Promo Studio couldn’t load</h4><p>${esc(e.message)}. Restart the app if you’ve just updated it.</p></div></div>`; return false; }
}
function unmount() { mounted?.unmount(); mounted = null; }
function skeleton() {
  const t = ST.data.tools, tool = (l, ok, tip) => `<span class="pm-tool ${ok ? 'ok' : 'bad'}" title="${esc(tip)}">${I(ok ? 'check' : 'alert')}${l}</span>`;
  $('#promoPanel').innerHTML = !ST.data.apps.length ? `<div class="card"><div class="emptystate">${I('image')}<h4>Add an app first</h4><p>Promo Studio makes videos, images and icons from your apps.</p></div></div>` : `
    <div class="ps-bar-top"><label class="search ps-find">${I('search')}<input id="psFind" type="search" placeholder="Find an app" autocomplete="off" aria-label="Find an app"></label><div class="ps-apps" id="psApps" role="listbox" aria-label="App"></div></div>
    <div class="ps-nav"><nav class="ps-sections" aria-label="Promo Studio sections">${SECTIONS.map(([k, ic, l, d]) => `<button type="button" data-section="${k}">${I(ic)}<span><b>${l}</b><small>${d}</small></span></button>`).join('')}</nav>
      <div class="ps-tools">${tool('Chrome', t.chrome, t.chrome ? 'Used to draw images and video frames' : 'Install Google Chrome or Microsoft Edge')}${tool('FFmpeg', t.ffmpeg, t.ffmpeg ? 'Used to encode videos' : 'Install FFmpeg: winget install ffmpeg')}<a class="hbtn ghost sm" href="/editor/" target="_blank" rel="noopener">${I('film')}Edit Studio</a><button type="button" class="hbtn ghost sm" data-settings>${I('sliders')}Settings</button></div></div>
    <div id="psStage"></div><div class="ps-jobs" id="pmJobs" role="status" aria-live="polite" hidden></div>`;
}
function drawApps() {
  const box = $('#psApps'); if (!box) return;
  const list = ST.data.apps.filter(a => !query || `${a.name} ${a.tagline || ''}`.toLowerCase().includes(query));
  box.innerHTML = list.map(a => { const busy = ST.data.jobs.some(j => j.appId === a.id && active(j)), n = Object.keys(a.files).length, v = Object.keys(a.videos || {}).length;
    return `<button type="button" role="option" aria-selected="${a.id === ST.appId}" class="ps-app${a.id === ST.appId ? ' on' : ''}" data-app="${esc(a.id)}" title="${esc(a.tagline || a.name)}"><span class="ps-ico">${a.iconImage ? `<img src="${esc(media(a.iconImage))}" alt="">` : I(a.glyph || 'package')}</span><span><b>${esc(a.name)}</b><small class="num">${busy ? 'Working…' : n || v ? [v && `${v} video${v > 1 ? 's' : ''}`, n && `${n} image${n > 1 ? 's' : ''}`].filter(Boolean).join(' · ') : a.shots.length ? `${a.shots.length} screens` : 'Needs screens'}</small></span></button>`; }).join('') || '<p class="muted">No app matches.</p>';
}
function open() {
  const stage = $('#psStage'); if (!stage || !app()) return;
  document.querySelectorAll('#promoPanel [data-section]').forEach(b => { const on = b.dataset.section === ST.section; b.classList.toggle('on', on); on ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current'); });
  stage.replaceChildren(); const box = document.createElement('div'); box.className = 'ps-stage'; stage.append(box);
  if (ST.section === 'video') { mounted = Video; Video.mount(box); }
  else if (ST.section === 'images') { mounted = Images; Images.mount(box); }
  else if (ST.section === 'icons') { mounted = Icons; Icons.mount(box); }
  else { mounted = Launch; Launch.mount(box, ST.section); }
}
async function canLeave() { return mounted !== Images || !Images.isDirty() || confirmBox('Leave without saving the design?', 'Your image design changes aren’t saved.', 'Leave', false); }
async function onClick(e) {
  const b = e.target.closest('button'); if (!b) return;
  try {
    if (b.dataset.app && b.dataset.app !== ST.appId) { if (!(await canLeave())) return; unmount(); ST.appId = b.dataset.app; history.replaceState(null, '', '#/promo/' + ST.appId); drawApps(); return open(); }
    if (b.dataset.section && b.dataset.section !== ST.section) { if (!(await canLeave())) return; unmount(); ST.section = b.dataset.section; await reload(); drawApps(); return open(); }
    if (b.dataset.cancel) { await api('POST', `/api/promo/jobs/${b.dataset.cancel}/cancel`); return toast('Cancelling…', 'info'); }
    if (b.dataset.settings != null) return settings();
  } catch (x) { toast(x.message, 'err', 8000); }
}
function settings() {
  const s = ST.data.settings, d = document.createElement('dialog');
  d.className = 'modal'; d.setAttribute('aria-label', 'Promo settings');
  d.innerHTML = `<form class="m-in pm-set" method="dialog"><h3>${I('sliders')}Promo settings</h3>
    ${sw('name="auto"', s.auto, 'Make an image kit when I add screenshots or a cover')}${sw('name="autoVideo"', s.autoVideo, '…and direct promo videos too (wide and vertical)')}${sw('name="useSocial"', s.useSocial, 'Use the Link preview image for link previews and social posts')}
    <div class="fld"><span>Every app’s kit includes <small>plus store formats for its kind</small></span><div class="pm-fmts">${ST.data.formats.map(f => `<label><input type="checkbox" name="fmt" value="${f.id}"${(s.formats || ST.data.autoBase).includes(f.id) ? ' checked' : ''}>${esc(f.label)}</label>`).join('')}</div></div>
    <label class="fld"><span>FFmpeg path <small>only if it isn’t on PATH</small></span><input name="ff" value="${esc(s.ffmpegPath || '')}" placeholder="C:\\ffmpeg\\bin\\ffmpeg.exe"></label>
    <div class="m-foot"><button type="button" class="hbtn ghost" data-x>Cancel</button><button type="submit" class="hbtn primary">${I('save')}Save</button></div></form>`;
  document.body.append(d); d.showModal();
  d.addEventListener('close', () => d.remove());
  d.addEventListener('click', e => { if (e.target === d || e.target.closest('[data-x]')) d.close(); });
  d.querySelector('form').addEventListener('submit', async e => {
    const f = e.target;
    try { await api('PUT', '/api/promo/settings', { auto: f.auto.checked, autoVideo: f.autoVideo.checked, useSocial: f.useSocial.checked, formats: [...f.querySelectorAll('[name=fmt]:checked')].map(i => i.value), ffmpegPath: f.ff.value }); toast('Saved'); await reload(); unmount(); skeleton(); drawApps(); open(); }
    catch (x) { toast(x.message, 'err'); }
  });
}

// ---------- the strip in the app editor's Media tab ----------
// Shows this app's promo kit, live progress after uploads, and one-click "use as cover / add as screenshot".
let stripTimer = 0;
export async function editorStrip(d, onUse) {
  clearTimeout(stripTimer);
  const box = $('#promoStrip'); if (!box) return;
  if (!d?.id) { box.innerHTML = `<p class="muted small">${I('sparkles')}Save the app, then add screenshots: a promo kit is made for it automatically.</p>`; return; }
  let o; try { o = await api('GET', '/api/promo'); } catch { box.innerHTML = ''; return; }
  const a = o.apps.find(x => x.id === d.id), job = o.jobs.find(j => j.appId === d.id && active(j)), files = Object.entries(a?.files || {});
  box.innerHTML = `<div class="pm-strip"><div class="row"><b>${I('sparkles')}Promo kit</b><small class="muted">${job ? `<span class="spinner sm"></span> ${esc(job.label)} · ${Math.round(job.progress * 100)}%` : files.length ? `${files.length} images made from these screenshots` : o.settings.auto ? 'Made automatically when you add screenshots' : 'Automatic kits are off (Promo → Settings)'}</small><span class="sp"></span><a class="hbtn ghost sm" href="#/promo/${esc(d.id)}" data-goto="promo:${esc(d.id)}">${I('film')}Open Promo Studio</a></div>
    ${files.length ? `<div class="pm-strip-row">${files.slice(0, 8).map(([id, f]) => `<figure><img src="${esc(media(f.file, f.at))}" alt="" loading="lazy"><figcaption>${esc(o.formats.find(x => x.id === id)?.label || id)}</figcaption><button type="button" class="hbtn ghost sm" data-pmuse="${id === 'cover' ? 'cover' : 'screenshot'}" data-file="${esc(f.file)}">${id === 'cover' ? 'Use as cover' : 'Add as screenshot'}</button></figure>`).join('')}</div>` : ''}</div>`;
  box.onclick = async e => {
    const b = e.target.closest('[data-pmuse]'); if (!b) return;
    try { const r = await api('POST', '/api/promo/copy', { appId: d.id, file: b.dataset.file }); onUse(b.dataset.pmuse, r.path); toast(b.dataset.pmuse === 'cover' ? 'Cover set. Save the app to keep it.' : 'Added to screenshots. Save the app to keep it.'); } catch (x) { toast(x.message, 'err'); }
  };
  if (job) stripTimer = setTimeout(() => { if (!$('#editor').hidden) editorStrip(d, onUse); }, 1500);
}
export { addJob };
