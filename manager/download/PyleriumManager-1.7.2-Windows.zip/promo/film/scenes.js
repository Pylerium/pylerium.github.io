// Scene types. Each builder lays out its elements once and returns frame(t): a pure function of time, so the preview,
// scrubbing and the frame-by-frame renderer always agree. Only transforms and opacity change per frame.
import { clamp, lerp, out, inout, spring, h, esc, words, wordsFrame, rise, Screen, camLerp, camFor } from './kit.js';

const text = (cls, s, style = '') => (s ? `<div class="${cls}" style="${style}">${esc(s)}</div>` : '');
const CURSOR = '<svg class="cursor" viewBox="0 0 24 24"><path d="M5 3.5 19 12l-6.2 1.3L9.6 19.5Z" fill="#fff" stroke="#14161C" stroke-width="1.4" stroke-linejoin="round"/></svg>';

function hook(el, s, c) {
  const { U, W, H, tall } = c;
  const box = h('div', 'abs', `left:${tall ? 8 * U : 11 * U}px;right:${tall ? 8 * U : 11 * U}px;top:50%`);
  const len = (s.title || '').length, size = (tall ? 11.5 : 11) * (len > 44 ? .72 : len > 28 ? .85 : 1);
  box.innerHTML = `${text('kicker', s.kicker)}<div class="h1" style="margin-top:${2.6 * U}px;font-size:${size * U}px;max-width:${tall ? 100 : 84}%">${words(s.title)}</div><div class="rule" style="margin-top:${3.4 * U}px"></div>${text('body', s.sub, `margin-top:${2.6 * U}px;max-width:${tall ? 100 : 60}%`)}`;
  el.append(box);
  const [kick, title, rule, sub] = [box.querySelector('.kicker'), box.querySelector('.h1'), box.querySelector('.rule'), box.querySelector('.body')];
  return t => {
    box.style.transform = `translateY(calc(-50% + ${-t * .35 * U}px))`;
    if (kick) rise(kick, t, .05, U);
    wordsFrame(title, t, .16, .075);
    rule.style.transform = `scaleX(${out(clamp((t - .55) / .8))})`;
    if (sub) rise(sub, t, .75, U);
  };
}

function reveal(el, s, c) {
  const { U, W, H, tall, square } = c;
  const area = tall ? { x: 4 * U, y: H * .34, w: W - 8 * U, h: H * .5 } : { x: W * (square ? .08 : .16), y: H * .27, w: W * (square ? .84 : .68), h: H * .66 };
  const screen = Screen(c, s, area, { fit: !tall });
  const fill = tall ? clamp(screen.vh / screen.ih, 1, 1.55) : 1;
  const head = h('div', 'abs', tall ? `left:${7 * U}px;right:${7 * U}px;top:${H * .13}px;text-align:center` : `left:0;right:0;top:${H * .065}px;text-align:center`);
  head.innerHTML = `<div style="display:flex;justify-content:center;align-items:center;gap:${2 * U}px">${c.logo(tall ? 10 : 8)}<div class="h2" style="font-size:${(tall ? 7.6 : 6.6) * U}px">${words(s.title)}</div></div>${text('body', s.detail, `margin:${1.4 * U}px auto 0;max-width:${tall ? 92 : 62}%`)}`;
  const sheen = h('i', 'sheen'); screen.view.append(sheen);
  el.append(head, screen.el);
  const title = head.querySelector('.h2'), sub = head.querySelector('.body'), mark = head.querySelector('.logo');
  return (t, d) => {
    const p = spring(t - .12, 5.2);
    screen.el.style.transform = `perspective(${180 * U}px) translateY(${(1 - p) * 38 * U - t * .25 * U}px) rotateX(${(1 - p) * 26 + 1.2}deg) scale(${.9 + .1 * p + t / d * .018})`;
    screen.el.style.opacity = clamp(t / .3);
    const k = inout(clamp(t / d));
    screen.cam({ cx: tall ? .46 + .08 * k : .5, cy: tall ? .5 : screen.top, z: fill * (1 + .035 * k) });
    const m = spring(t - .25, 7); mark.style.transform = `scale(${.4 + .6 * m})`; mark.style.opacity = clamp((t - .25) / .25);
    wordsFrame(title, t, .34, .07); if (sub) rise(sub, t, .7, U);
    sheen.style.transform = `translateX(${lerp(-130, 560, inout(clamp((t - 1) / 1.3)))}%) skewX(-12deg)`;
  };
}

// establishing view → travel to each area of interest with a highlight and a pointer → pull back
function spotlight(el, s, c) {
  const { U, W, H, tall, square } = c;
  const area = tall ? { x: 4 * U, y: H * .16, w: W - 8 * U, h: H * .54 } : { x: W * .055, y: H * .085, w: W * .89, h: H * .83 };
  const screen = Screen(c, s, area, { fit: !tall });
  const focus = h('div', 'focus'), cursor = h('div', '', ''); cursor.innerHTML = CURSOR; const pointer = cursor.firstChild, ripple = h('i', 'ripple');
  screen.view.append(focus, ripple, pointer);
  const card = h('div', 'card', tall ? `left:${6 * U}px;right:${6 * U}px;top:${H * .735}px` : `left:${W * .035}px;bottom:${H * .06}px;max-width:${square ? 70 : 52}%`);
  card.innerHTML = `<div class="tick"></div>${text('h2', s.title)}${text('body', s.detail)}`;
  el.append(screen.el); if (s.title) el.append(card);
  const regs = (s.regions?.length ? s.regions : [{ x: .22, y: .2, w: .56, h: .5 }]);
  const wide = { cx: .5, cy: tall ? .5 : screen.top, z: tall ? clamp(screen.vh / screen.ih, 1, 1.45) : 1 };
  return (t, d) => {
    const first = s.cues?.[0] ?? 1, seg = (d - first - .55) / regs.length;
    const cams = [wide, ...regs.map(r => { const k = camFor(screen, r, tall ? 1.06 : 1.2); return { ...k, z: Math.max(k.z, wide.z) }; })];
    // which leg of the journey are we on?
    let cam = wide, active = -1, arrive = 0;
    for (let i = 0; i < regs.length; i++) {
      const at = (s.cues?.[i] ?? first + i * seg) - .5; if (t < at) break;
      arrive = inout(clamp((t - at) / .95)); active = i; cam = camLerp(cams[i], cams[i + 1], arrive);
    }
    const back = inout(clamp((t - (d - .55)) / .55)); if (back > 0) cam = camLerp(cam, wide, back * .7);
    screen.cam(cam);
    const enter = spring(t, 6);
    screen.el.style.transform = `perspective(${180 * U}px) translateY(${(1 - enter) * 7 * U}px) rotateX(${(1 - enter) * 8}deg) scale(${.95 + .05 * enter})`;
    if (active >= 0) {
      const r = regs[active], prev = regs[Math.max(0, active - 1)], k = active ? arrive : 1;
      const box = { x: lerp(prev.x, r.x, k), y: lerp(prev.y, r.y, k), w: lerp(prev.w, r.w, k), h: lerp(prev.h, r.h, k) };
      const q = screen.rect(box);
      focus.style.cssText = `width:${q.w}px;height:${q.h}px;transform:translate(${q.x}px,${q.y}px);opacity:${(active ? 1 : out(arrive)) * (1 - back)}`;
      const aim = screen.rect(r), px = aim.x + aim.w * .62, py = aim.y + aim.h * .6;
      const from = active ? screen.rect(prev) : { x: screen.vw * .9, y: screen.vh * 1.05, w: 0, h: 0 };
      const m = out(clamp((arrive - .1) / .9)), x = lerp(from.x + from.w * .62, px, m), y = lerp(from.y + from.h * .6, py, m);
      const cue = s.cues?.[active] ?? first + active * seg, since = t - cue - .35, press = since > 0 && since < .22 ? 1 - Math.sin(since / .22 * Math.PI) * .18 : 1;
      pointer.style.transform = `translate(${x}px,${y}px) scale(${press})`; pointer.style.opacity = clamp(arrive * 3) * (1 - back);
      ripple.style.transform = `translate(${x}px,${y}px) scale(${.25 + clamp(since / .6) * 1.1})`; ripple.style.opacity = since > 0 && since < .6 ? (1 - since / .6) * .9 : 0;
    } else { focus.style.opacity = 0; pointer.style.opacity = 0; ripple.style.opacity = 0; }
    if (s.title) { const p = spring(t - .45, 6.5); card.style.transform = `translateY(${(1 - p) * 9 * U}px)`; card.style.opacity = clamp((t - .45) / .3); }
  };
}

// the whole screen stays in view; a lens lifts one area out and enlarges it, wired to where it came from
function loupe(el, s, c) {
  const { U, W, H, tall, square } = c;
  const area = tall ? { x: 5 * U, y: H * .22, w: W - 10 * U, h: H * .3 } : { x: W * .045, y: H * .13, w: W * (square ? .74 : .64), h: H * .72 };
  const screen = Screen(c, s, area, { fit: true });
  const r = s.regions?.[0] || { x: .3, y: .25, w: .4, h: .34 };
  const ra = clamp((r.w * screen.iw) / Math.max(1, r.h * screen.ih), .8, 2.4);
  const lw = tall ? W - 14 * U : W * (square ? .5 : .42), lh = Math.min(lw / ra, H * (tall ? .24 : .52));
  const lx = tall ? 7 * U : W - lw - W * .04, ly = tall ? H * .565 : H * (r.y > .45 ? .12 : .34);
  const lens = h('div', 'loupe', `left:${lx}px;top:${ly}px;width:${lw}px;height:${lh}px`);
  const inner = h('div', 'world'); const img = h('img'); img.src = s.shotUrl; inner.append(img); lens.append(inner);
  const z = Math.min(lw / (r.w * screen.iw), lh / (r.h * screen.ih)) * .96;
  inner.style.width = screen.iw * z + 'px'; inner.style.height = screen.ih * z + 'px';
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('class', 'wires'); svg.setAttribute('width', W); svg.setAttribute('height', H);
  svg.innerHTML = `<rect rx="${U}"/><path pathLength="1"/><path pathLength="1"/>`;
  const card = h('div', 'abs', tall ? `left:${7 * U}px;right:${7 * U}px;top:${H * .825}px;text-align:center` : `left:${lx}px;width:${lw}px;top:${Math.min(H * .76, ly + lh + 3.4 * U)}px`);
  const cardCls = tall ? '' : 'card';
  card.innerHTML = `<div class="${cardCls}" style="position:static">${text('h2', s.title, `font-size:${(tall ? 5.4 : 3.8) * U}px`)}${text('body', s.detail, `margin-top:${U}px`)}</div>`;
  el.append(screen.el, svg, lens, card);
  const [box, w1, w2] = svg.children;
  return (t, d) => {
    const enter = spring(t, 6);
    screen.cam({ cx: .5, cy: screen.top, z: 1 });
    const driftX = -t / d * U * 1.2;
    screen.el.style.transform = `translate(${driftX}px, ${(1 - enter) * 6 * U}px) scale(${.96 + .04 * enter})`;
    const q = screen.rect(r), bx = screen.vx + q.x + driftX, by = screen.vy + q.y;
    const on = out(clamp((t - .75) / .45));
    box.setAttribute('x', bx - (1 - on) * 3 * U); box.setAttribute('y', by - (1 - on) * 3 * U); box.setAttribute('width', q.w + (1 - on) * 6 * U); box.setAttribute('height', q.h + (1 - on) * 6 * U); box.style.opacity = on;
    const p = spring(t - 1.05, 6.2), cx = bx + q.w / 2, cy = by + q.h / 2;
    lens.style.transform = `translate(${(1 - p) * (cx - (lx + lw / 2))}px, ${(1 - p) * (cy - (ly + lh / 2))}px) scale(${lerp(q.w / lw, 1, p)})`;
    lens.style.opacity = clamp((t - 1.05) / .22);
    const pan = inout(clamp((t - 1.6) / Math.max(1, d - 1.8)));
    inner.style.transform = `translate(${lw / 2 - (r.x + r.w * (.46 + .08 * pan)) * screen.iw * z}px, ${lh / 2 - (r.y + r.h * .5) * screen.ih * z}px)`;
    const draw = out(clamp((t - 1.15) / .6));
    const ends = tall ? [[bx, by + q.h, lx, ly], [bx + q.w, by + q.h, lx + lw, ly]] : [[bx + q.w, by, lx, ly], [bx + q.w, by + q.h, lx, ly + lh]];
    [w1, w2].forEach((w, i) => { const [x1, y1, x2, y2] = ends[i]; w.setAttribute('d', `M${x1} ${y1}L${x2} ${y2}`); w.style.strokeDasharray = 1; w.style.strokeDashoffset = 1 - draw; w.style.opacity = draw ? .85 : 0; });
    rise(card, t, 1.35, U);
  };
}

function split(el, s, c) {
  const { U, W, H, tall, square, index } = c;
  const flip = index % 2 === 1 && !tall;
  const area = tall ? { x: 6 * U, y: H * .42, w: W - 12 * U, h: H * .44 }
    : { x: flip ? -W * .02 : W * (square ? .42 : .43), y: H * (square ? .2 : .14), w: W * (square ? .6 : .59), h: H * (square ? .62 : .72) };
  const screen = Screen(c, s, area, { fit: true });
  const copy = h('div', 'abs', tall ? `left:${8 * U}px;right:${8 * U}px;top:${H * .13}px`
    : `${flip ? `right:${W * .05}px` : `left:${W * .06}px`};top:50%;width:${W * (square ? .34 : .31)}px`);
  copy.innerHTML = `${text('kicker', s.kicker || c.name)}<div class="h2" style="margin-top:${2.2 * U}px;font-size:${(tall ? 7.6 : square ? 5.2 : 6.2) * U}px">${words(s.title)}</div><div class="rule" style="margin-top:${2.8 * U}px;width:${9 * U}px"></div>${text('body', s.detail, `margin-top:${2.4 * U}px`)}`;
  el.append(screen.el, copy);
  const [kick, title, rule, body] = [copy.querySelector('.kicker'), copy.querySelector('.h2'), copy.querySelector('.rule'), copy.querySelector('.body')];
  const target = s.regions?.[0];
  return (t, d) => {
    if (!tall) copy.style.transform = 'translateY(-50%)';
    if (kick) rise(kick, t, .1, U); wordsFrame(title, t, .22, .07); rule.style.transform = `scaleX(${out(clamp((t - .6) / .6))})`; if (body) rise(body, t, .75, U);
    const p = spring(t - .08, 4.8), turn = tall ? 0 : (flip ? 1 : -1) * lerp(24, 9, p) + (flip ? -1 : 1) * t / d * 3;
    screen.el.style.transformOrigin = flip ? '100% 50%' : '0% 50%';
    screen.el.style.transform = `perspective(${150 * U}px) translate(${(1 - p) * (flip ? -30 : 30) * U}px, ${tall ? (1 - p) * 24 * U : 0}px) rotateY(${turn}deg) ${tall ? `rotateX(${lerp(18, 3, p)}deg)` : ''}`;
    screen.el.style.opacity = clamp(t / .28);
    const goal = target ? camFor(screen, target, 1.9) : { cx: .5, cy: screen.top, z: 1.08 };
    screen.cam(camLerp({ cx: .5, cy: screen.top, z: 1 }, { ...goal, z: Math.min(goal.z, 1.45) }, inout(clamp((t - 1) / Math.max(1, d - 1.35)))));
  };
}

// a steady travel across a tall or very wide screen, at a constant, readable magnification
function glide(el, s, c) {
  const { U, W, H, tall, square } = c;
  const area = tall ? { x: 5 * U, y: H * .22, w: W - 10 * U, h: H * .56 } : { x: W * .07, y: H * .09, w: W * .86, h: H * .74 };
  const screen = Screen(c, s, area, {});
  const label = h('div', 'card', `left:50%;${tall ? `top:${H * .805}px;width:${W * .86}px` : `bottom:${H * .045}px;max-width:${square ? 88 : 66}%`};text-align:center`);
  label.innerHTML = `${text('h2', s.title, `font-size:${(tall ? 5 : 3.6) * U}px`)}${text('body', s.detail)}`;
  el.append(screen.el); if (s.title) el.append(label);
  const aspect = screen.iw / screen.ih, boxA = screen.vw / screen.vh, cover = Math.max(1, aspect / boxA === 0 ? 1 : (screen.vh / screen.ih));
  const z = Math.min(2.1, Math.max(cover, aspect > boxA ? screen.vh / screen.ih : 1.14));
  const vertical = screen.ih * z > screen.vh * 1.12 && screen.iw * z <= screen.vw * 1.2;
  const a = vertical ? { cx: .5, cy: 0, z } : { cx: 0, cy: s.regions?.[0] ? s.regions[0].y + s.regions[0].h / 2 : .4, z };
  const b = vertical ? { cx: .5, cy: 1, z } : { cx: 1, cy: s.regions?.[0] ? s.regions[0].y + s.regions[0].h / 2 : .45, z };
  return (t, d) => {
    const enter = spring(t, 5.6);
    screen.el.style.transform = `translateY(${(1 - enter) * 9 * U}px) scale(${.95 + .05 * enter})`;
    screen.cam(camLerp(a, b, inout(clamp((t - .45) / Math.max(1, d - .8)))));
    if (s.title) { const p = spring(t - .4, 6.5); label.style.transform = `translate(-50%, ${(1 - p) * 8 * U}px)`; label.style.opacity = clamp((t - .4) / .3); }
  };
}

function montage(el, s, c) {
  const { U, W, H, tall } = c;
  const urls = s.shotUrls?.length ? s.shotUrls : [s.shotUrl].filter(Boolean);
  const cols = tall ? 2 : 3, gap = 2.4 * U, cw = W * 1.24 / cols, ch = cw / 1.6;
  const wall = h('div', 'abs', `left:${-W * .12}px;top:${-H * .2}px;width:${W * 1.24}px;height:${H * 1.4}px`);
  const columns = Array.from({ length: cols }, (_, i) => {
    const col = h('div', 'abs', `left:${i * (cw + gap)}px;top:0;width:${cw}px`);
    const need = Math.ceil(H * 1.4 / (ch + gap)) + 3;
    for (let k = 0; k < need; k++) { const tile = h('div', 'tile', `left:0;top:${k * (ch + gap)}px;width:${cw}px;height:${ch}px`); const img = h('img'); img.src = urls[(i * 2 + k) % urls.length]; tile.append(img); col.append(tile); }
    wall.append(col); return col;
  });
  const scrim = h('div', 'scrim');
  const title = h('div', 'abs', `left:${8 * U}px;right:${8 * U}px;top:50%;text-align:center`);
  title.innerHTML = `<div class="h1" style="font-size:${(tall ? 11 : 9.6) * U}px">${words(s.title)}</div>`;
  el.append(wall, scrim, title);
  return (t, d) => {
    const p = spring(t, 3.4);
    wall.style.transform = `perspective(${170 * U}px) rotateX(${lerp(36, 22, p)}deg) rotateZ(${-9 + t * .45}deg) scale(${lerp(1.28, 1.04, p)})`;
    columns.forEach((col, i) => { const dir = i % 2 ? 1 : -1; col.style.transform = `translateY(${dir * (t * 5.2 * U) - (dir > 0 ? ch * 2 : 0) - i * 6 * U}px)`; });
    scrim.style.opacity = clamp((t - .35) / .5);
    title.style.transform = 'translateY(-50%)'; wordsFrame(title.firstChild, t, .55, .09);
  };
}

function list(el, s, c) {
  const { U, W, H, tall, square } = c, stack = tall || square;
  const head = h('div', 'abs', stack ? `left:${8 * U}px;right:${8 * U}px;top:${H * .12}px` : `left:${W * .08}px;top:50%;width:${W * .34}px`);
  head.innerHTML = `${text('kicker', s.kicker || c.name)}<div class="h2" style="margin-top:${2.2 * U}px;font-size:${(tall ? 8 : 7) * U}px">${words(s.title)}</div><div class="rule" style="margin-top:${3 * U}px"></div>`;
  const items = h('div', 'abs', stack ? `left:${8 * U}px;right:${8 * U}px;top:${H * (tall ? .4 : .4)}px` : `left:${W * .5}px;right:${W * .08}px;top:50%`);
  items.innerHTML = (s.items || []).map(i => `<div class="item"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="12"/><path d="m6.8 12.4 3.5 3.5 7-7.4" pathLength="1"/></svg><span>${esc(i)}</span></div>`).join('');
  el.append(head, items);
  const rows = [...items.children];
  return t => {
    if (!stack) { head.style.transform = 'translateY(-50%)'; items.style.transform = 'translateY(-50%)'; }
    rise(head.querySelector('.kicker') || head, t, .05, U); wordsFrame(head.querySelector('.h2'), t, .14, .08);
    head.querySelector('.rule').style.transform = `scaleX(${out(clamp((t - .55) / .7))})`;
    rows.forEach((row, i) => {
      const at = s.cues?.[i] ?? .6 + i * .5, p = spring(t - at, 7.5);
      row.style.transform = `translateX(${(1 - p) * 9 * U}px)`; row.style.opacity = clamp((t - at) / .25);
      const tick = row.querySelector('path'); tick.style.strokeDasharray = 1; tick.style.strokeDashoffset = 1 - out(clamp((t - at - .15) / .4));
    });
  };
}

function stat(el, s, c) {
  const { U, tall } = c;
  const box = h('div', 'abs', 'left:0;right:0;top:50%;text-align:center');
  box.innerHTML = `${text('kicker', s.kicker || c.name)}<div class="big" style="margin-top:${3 * U}px">0</div><div class="h2" style="margin-top:${3 * U}px;padding:0 ${8 * U}px">${words(s.title)}</div>`;
  el.append(box);
  const big = box.querySelector('.big'), fmt = new Intl.NumberFormat('en');
  return (t, d) => {
    box.style.transform = 'translateY(-50%)';
    rise(box.querySelector('.kicker') || box, t, .05, U);
    const k = out(clamp((t - .25) / Math.min(2, d * .62))), v = Math.round((s.value || 0) * k);
    const shown = fmt.format(v); if (big.textContent !== shown) big.textContent = shown;
    big.style.fontSize = (tall ? 20 : 24) * U * Math.min(1, 7 / fmt.format(s.value || 0).length) + 'px';
    big.style.transform = `scale(${.86 + .14 * spring(t - .2, 5)})`; big.style.opacity = clamp((t - .15) / .3);
    wordsFrame(box.querySelector('.h2'), t, .8, .07);
  };
}

function quote(el, s, c) {
  const { U, tall } = c;
  const box = h('div', 'abs', `left:${tall ? 9 * U : 14 * U}px;right:${tall ? 9 * U : 14 * U}px;top:50%`);
  const len = (s.title || '').length;
  box.innerHTML = `${text('kicker', s.kicker)}<div class="h2" style="margin-top:${3 * U}px;font-size:${(len > 80 ? 5.6 : len > 45 ? 7 : 8.6) * U}px;line-height:1.14">${words(s.title)}</div><div class="rule" style="margin-top:${3.6 * U}px;width:${10 * U}px"></div>${text('body', s.sub || s.detail, `margin-top:${2.4 * U}px`)}`;
  el.append(box);
  return (t, d) => {
    box.style.transform = `translateY(calc(-50% + ${-t * .3 * U}px))`;
    const k = box.querySelector('.kicker'); if (k) rise(k, t, .05, U);
    wordsFrame(box.querySelector('.h2'), t, .2, Math.min(.09, (d * .4) / Math.max(1, (s.title || '').split(' ').length)));
    box.querySelector('.rule').style.transform = `scaleX(${out(clamp((t - 1) / .7))})`;
    const b = box.querySelector('.body'); if (b) rise(b, t, 1.2, U);
  };
}

function end(el, s, c) {
  const { U, W, H, tall } = c;
  const box = h('div', 'abs', `left:${7 * U}px;right:${7 * U}px;top:50%;display:flex;flex-direction:column;align-items:center;text-align:center`);
  box.innerHTML = `${c.logo(tall ? 22 : 17)}<div class="h1" style="margin-top:${4 * U}px;font-size:${(tall ? 9.6 : 8.4) * U}px">${words(s.title)}</div>${text('body', s.detail, `margin-top:${2 * U}px;max-width:${tall ? 100 : 58}%`)}<div style="margin-top:${4.4 * U}px"><span class="button">${esc(s.button || 'Learn more')}</span></div>${text('url', s.url, `margin-top:${3 * U}px`)}`;
  const cursor = h('div', '', 'position:absolute;left:0;top:0'); cursor.innerHTML = CURSOR;
  el.append(box, cursor);
  const q = k => box.querySelector(k), pointer = cursor.firstChild;
  let spot = null;
  return t => {
    box.style.transform = 'translateY(-50%)';
    const m = spring(t - .08, 6); const mark = q('.logo'); mark.style.transform = `scale(${.3 + .7 * m}) rotate(${(1 - m) * -14}deg)`; mark.style.opacity = clamp((t - .08) / .25);
    wordsFrame(q('.h1'), t, .3, .08); if (q('.body')) rise(q('.body'), t, .7, U);
    const btn = q('.button'), p = spring(t - .95, 7), cue = s.cues?.[0] ?? 2.2, since = t - cue;
    if (!spot && btn.offsetWidth) { let x = btn.offsetLeft, y = btn.offsetTop, n = btn.offsetParent; while (n && n !== box) { x += n.offsetLeft; y += n.offsetTop; n = n.offsetParent; } spot = { x: box.offsetLeft + x + btn.offsetWidth * .86, y: H / 2 - box.offsetHeight / 2 + y + btn.offsetHeight * .68 }; }
    btn.style.display = 'inline-block'; btn.style.transform = `scale(${(.7 + .3 * p) * (since > 0 && since < .26 ? 1 - Math.sin(since / .26 * Math.PI) * .08 : 1)})`; btn.style.opacity = clamp((t - .95) / .25);
    if (spot) { const k = inout(clamp((t - (cue - 1)) / .95)); pointer.style.transform = `translate(${lerp(W * .86, spot.x, k)}px, ${lerp(H * .96, spot.y, k)}px) scale(${since > 0 && since < .2 ? .84 : 1})`; pointer.style.opacity = clamp((t - (cue - 1)) / .25); }
    if (q('.url')) rise(q('.url'), t, 1.3, U);
  };
}

export const SCENES = { hook, reveal, spotlight, loupe, split, glide, montage, list, stat, quote, end };
