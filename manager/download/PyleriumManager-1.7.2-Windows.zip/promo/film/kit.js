// Motion and layout helpers shared by the scenes. All easing is analytic (a function of time), so any frame can be drawn
// on its own, in any order.
export const clamp = (x, a = 0, b = 1) => (x < a ? a : x > b ? b : x);
export const lerp = (a, b, t) => a + (b - a) * t;
export const out = t => 1 - Math.pow(1 - clamp(t), 4);
export const inout = t => { t = clamp(t); return t < .5 ? 8 * t * t * t * t : 1 - Math.pow(-2 * t + 2, 4) / 2; };
// under-damped spring from 0 to 1: a touch of overshoot, then settles
export const spring = (t, w = 6) => (t <= 0 ? 0 : 1 - Math.exp(-w * .86 * t) * (Math.cos(w * .6 * t) + 1.43 * Math.sin(w * .6 * t)));
export const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
export function h(tag, cls, css) { const e = document.createElement(tag); if (cls) e.className = cls; if (css) e.style.cssText = css; return e; }
// headline split into masked words for the kinetic rise
export const words = s => String(s || '').split(/\s+/).filter(Boolean).map(w => `<span class="word"><span>${esc(w)}</span></span>`).join(' ');
export function wordsFrame(el, t, delay, stagger) {
  const spans = el._w || (el._w = [...el.querySelectorAll('.word > span')]);
  for (let i = 0; i < spans.length; i++) { const p = spring(t - delay - i * stagger, 7); spans[i].style.transform = `translateY(${(1 - p) * 112}%) rotate(${(1 - p) * 4}deg)`; }
}
export function rise(el, t, delay, U) { const p = out((t - delay) / .6); el.style.opacity = p; el.style.transform = `translateY(${(1 - p) * 2.6 * U}px)`; }

// An app window showing one screenshot through a camera {cx, cy, z}: z = 1 shows the screen's full width (or all of it
// when `fit`), cx/cy are the point of the image held at the centre. The camera never shows past the image's edges.
export function Screen(c, scene, area, { fit = false } = {}) {
  const { U } = c, bar = 3.1 * U, aspect = scene.shotAspect || 1.6;
  let vw = area.w, vh = area.h - bar;
  if (fit) { if (vw / aspect < vh) vh = Math.max(vh * .42, vw / aspect); else if (aspect >= .95) vw = Math.max(vw * .5, vh * aspect); }
  const x = area.x + (area.w - vw) / 2, y = area.y + (area.h - bar - vh) / 2;
  const el = h('div', 'win', `left:${x}px;top:${y}px;width:${vw}px`);
  el.innerHTML = `<div class="bar"><i></i><i></i><i></i><span>${esc(c.name)}</span></div>`;
  const view = h('div', 'view', `height:${vh}px`), world = h('div', 'world'), img = h('img');
  img.src = scene.shotUrl || ''; world.append(img); view.append(world); el.append(view);
  const iw = vw, ih = vw / aspect;
  world.style.width = iw + 'px'; world.style.height = ih + 'px';
  let state = { z: 1, tx: 0, ty: 0 };
  const api = {
    el, view, vw, vh, iw, ih, vx: x, vy: y + bar,
    top: Math.min(.5, vh / 2 / ih),
    cam({ cx, cy, z }) {
      const sw = iw * z, sh = ih * z;
      const tx = sw <= vw ? (vw - sw) / 2 : clamp(vw / 2 - cx * sw, vw - sw, 0);
      const ty = sh <= vh ? (vh - sh) / 2 : clamp(vh / 2 - cy * sh, vh - sh, 0);
      state = { z, tx, ty };
      world.style.transform = `translate(${tx}px, ${ty}px) scale(${z})`;
    },
    rect(r) { return { x: state.tx + r.x * iw * state.z, y: state.ty + r.y * ih * state.z, w: r.w * iw * state.z, h: r.h * ih * state.z }; },
    maxZoom: Math.max(1.15, Math.min(2.6, ((scene.shotW || 1600) / vw) * 1.5))
  };
  api.cam({ cx: .5, cy: api.top, z: 1 });
  return api;
}
// the camera that frames an area of interest with breathing room, limited so the screenshot never turns to mush
export function camFor(screen, r, room = 1.3) {
  const z = clamp(Math.min(screen.vw / (r.w * screen.iw * room), screen.vh / (r.h * screen.ih * room)), 1, screen.maxZoom);
  return { cx: r.x + r.w / 2, cy: r.y + r.h / 2, z };
}
// travel between cameras: zoom in log space, centre eased by how far the zoom has got, which keeps the path straight
export function camLerp(a, b, t) {
  const z = Math.exp(lerp(Math.log(a.z), Math.log(b.z), t));
  const k = Math.abs(1 / b.z - 1 / a.z) < 1e-4 ? t : (1 / z - 1 / a.z) / (1 / b.z - 1 / a.z);
  const m = lerp(t, k, .65);
  return { cx: lerp(a.cx, b.cx, m), cy: lerp(a.cy, b.cy, m), z };
}
