// The film player: builds every scene of a timeline once, then render(t) draws any instant of it.
// Used identically by the Promo Studio preview (same-origin iframe) and the headless renderer.
//   window.load(spec) → Promise   window.render(seconds)   window.TOTAL
// spec: { w, h, theme, accent, onAccent, name, icon, bug, captions: [{s,e,text}], scenes: [{ type, start, dur, cues, … }] }
import { clamp, inout, out, h, esc } from './kit.js';
import { SCENES } from './scenes.js';

const stage = document.getElementById('stage');
const OVER = .46; // length of a transition between two scenes
let scenes = [], spec = null, bug = null, captions = null, wipe = null, bg = null, U = 10, W = 1920, H = 1080;

// transitions alternate so consecutive cuts never repeat; the end card always gets the accent wipe
const KINDS = ['push', 'wipe', 'zoom', 'lift'];
const kindFor = (i, type) => (type === 'end' ? 'wipe' : type === 'montage' ? 'zoom' : KINDS[(i + (spec.seed || 0)) % KINDS.length]);

async function load(next) {
  spec = next; W = spec.w; H = spec.h; U = Math.min(W, H) / 100;
  stage.className = `t-${spec.theme || 'ink'}${H > W * 1.15 ? ' tall' : ''}`;
  stage.style.cssText = `width:${W}px;height:${H}px;--u:${U}px;--accent:${spec.accent};--on-accent:${spec.onAccent}`;
  stage.replaceChildren();
  bg = h('div', 'bg'); bg.innerHTML = '<i class="light"></i><i class="dots"></i>'; stage.append(bg);
  const tall = H > W * 1.15, square = !tall && W < H * 1.25;
  const logo = size => `<div class="logo" style="width:${size * U}px;height:${size * U}px;font-size:${size * .5 * U}px;flex:none">${spec.icon ? `<img src="${esc(spec.icon)}" alt="">` : esc((spec.name || '?').trim().charAt(0))}</div>`;
  scenes = spec.scenes.map((s, index) => {
    const el = h('div', 'scene'); el.style.zIndex = index + 1; stage.append(el);
    const build = SCENES[s.type] || SCENES.quote;
    const ctx = { U, W, H, tall, square, index, name: spec.name, logo };
    return { ...s, el, build: () => build(el, s, ctx), frame: null, kind: index ? kindFor(index, s.type) : 'lift' };
  });
  // build with scenes laid out (hidden, not display:none) so measurements work
  for (const s of scenes) s.frame = s.build();
  bug = h('div', 'bug', `left:${3.4 * U}px;${tall ? `top:${H * .055}px` : `top:${2.8 * U}px`}`);
  bug.innerHTML = `${logo(3.8)}<span>${esc(spec.name)}</span>`; stage.append(bug);
  wipe = h('div', 'wipe', `width:${W}px;height:${H}px`); stage.append(wipe);
  captions = h('div', 'captions', `bottom:${tall ? H * .095 : H * .028}px`); stage.append(captions);
  window.TOTAL = scenes.reduce((m, s) => Math.max(m, s.start + s.dur), 0);
  await Promise.all([...stage.querySelectorAll('img')].map(i => i.decode().catch(() => {})));
  await document.fonts.ready;
  render(0);
  return true;
}

function render(t) {
  if (!spec) return;
  bg.style.transform = `translate(${Math.sin(t / 11) * 2.4 * U}px, ${-((t * .55 * U) % (4 * U))}px)`;
  let wipeAt = -1;
  scenes.forEach((s, i) => {
    const next = scenes[i + 1];
    const from = i ? s.start - OVER / 2 : 0, to = next ? next.start + OVER / 2 : s.start + s.dur + 1;
    const visible = t >= from && t < to;
    s.el.style.visibility = visible ? 'visible' : 'hidden';
    if (!visible) return;
    s.frame(Math.max(0, t - s.start + (i ? OVER * .28 : 0)), s.dur);
    // entering
    const p = i ? clamp((t - from) / OVER) : 1, e = inout(p);
    // leaving (the next scene draws on top)
    const q = next ? clamp((t - (next.start - OVER / 2)) / OVER) : 0, x = inout(q);
    let transform = '', opacity = 1, clip = '';
    if (p < 1) {
      if (s.kind === 'push') { transform = `translateX(${(1 - e) * 100}%)`; }
      else if (s.kind === 'zoom') { transform = `scale(${1.22 - .22 * e})`; opacity = clamp(p * 1.5); }
      else if (s.kind === 'lift') { transform = `translateY(${(1 - e) * 16}%) scale(${.97 + .03 * e})`; opacity = clamp(p * 1.4); }
      else { opacity = p >= .5 ? 1 : 0; }
      if (s.kind === 'push' || s.kind === 'zoom' || s.kind === 'lift') clip = 'var(--bg)';
      if (s.kind === 'wipe') wipeAt = p;
    }
    if (q > 0 && next) {
      if (next.kind === 'push') transform = `translateX(${-x * 34}%)`;
      else if (next.kind === 'zoom') { transform = `scale(${1 - .1 * x})`; opacity = 1 - x; }
      else if (next.kind === 'lift') { transform = `translateY(${-x * 8}%) scale(${1 - .04 * x})`; opacity = 1 - out(q * 1.3); }
      else opacity = q >= .5 ? 0 : 1;
    }
    s.el.style.transform = transform; s.el.style.opacity = opacity;
    // an opaque backing while sliding over the previous scene, so the two never muddle together
    s.el.style.background = clip && p < 1 && s.kind !== 'lift' ? 'var(--bg)' : '';
  });
  if (wipeAt >= 0) {
    const p = wipeAt, a = inout(clamp(p * 2)), b = inout(clamp(p * 2 - 1));
    wipe.style.visibility = 'visible';
    wipe.style.clipPath = `polygon(${b * 124 - 24}% 0, ${a * 124}% 0, ${a * 124 - 24}% 100%, ${b * 124 - 48}% 100%)`;
  } else wipe.style.visibility = 'hidden';
  const current = scenes.findLast(s => t >= s.start) || scenes[0];
  const showBug = spec.bug !== false && current && !['hook', 'end', 'reveal', 'montage', 'spotlight', 'glide'].includes(current.type);
  bug.style.opacity = showBug ? clamp(Math.min((t - current.start - .25) / .3, (current.start + current.dur - .2 - t) / .3)) : 0;
  const line = (spec.captions || []).find(c => t >= c.s && t < c.e);
  if (line && captions.textContent !== line.text) captions.textContent = line.text;
  captions.style.opacity = line ? clamp(Math.min((t - line.s) / .12, (line.e - t) / .12)) : 0;
}

window.render = render;
window.load = load;
window.ready = window.SPEC ? load(window.SPEC) : Promise.resolve(false);
window.booted = true;
