PYLERIUM MANAGER
Your studio site, live in minutes.
=================================

Pylerium Manager builds a showcase website for your apps, publishes it free on
GitHub Pages (yourname.github.io), and runs the business side for you: Stripe
sales, supporter codes, automatic emails and Discord alerts. Promo Studio then
makes the launch material: videos with voice-over, store and social images,
your app icons and ready-to-post words.


START IT
--------
Windows:  Unzip this folder somewhere you keep apps (for example Documents),
          then double-click "Pylerium Manager.cmd". This package includes its
          own runtime; no separate install or download is needed.

macOS:    For a source package, double-click "Pylerium Manager.command". If macOS says it can't be
          opened, right-click it, choose Open, then Open again.

Linux:    For a source package, run launcher/start.sh

Pylerium Manager opens in your web browser. It runs on your own computer
(nothing is uploaded except your website to your own GitHub account). Phone
access is off unless you switch it on.


THE SETUP (about 3 minutes)
---------------------------
1. Licence      Paste the key from your purchase email, or start the free trial.
2. GitHub       Sign in, or create a token (the button opens the right page with
                the right permission already ticked) and paste it.
                No GitHub account? Make one free at github.com/signup.
3. Your site    Pylerium Manager creates yourname.github.io and turns on
                GitHub Pages for you.
4. Your brand   Name, tagline, logo, contact email and currency.
5. Launch       Your site is built and published. GitHub takes a minute or two
                to put it online the first time.

Then add your apps in the Apps tab and press Publish whenever you change
something.


WHAT'S IN IT
------------
Live            Revenue, payments, what needs you, system status, and download
                counts from your GitHub releases (choose which repositories).

Apps            Your catalog, with a Markdown editor, "Sync from GitHub",
                drag-to-reorder, a switch for the Source button on each card,
                and an optional public release repository for download counts.

Videos & embeds Your YouTube uploads and Shorts, plus custom embeds.

Community       Supporters, perks and app submissions.
  - Caffeine & perks:  connect Stripe for sales and supporter codes

Store           Everything you sell, in one tab:
  Apps for sale        Sell an app. Its files stay in a private GitHub
                       repository and buyers download them right after paying
                       (uses a free Cloudflare account, set up for you). Pick an
                       app or choose "+ New app...". Apps on your site with no
                       way to download are flagged. Versions, notes and prices
                       stay in sync by themselves.
  Products & prices    Every price and checkout; Stripe is updated for you.
  Email list           Ask for an email before a free download, per app. The
                       download address stays off your public site; emails are
                       collected in your own free Cloudflare account, where you
                       can search, export (CSV) and delete them.
  Licences             Buyers of a licensed app get a key with their download.
                       Get a ready-made key check for Python, JavaScript, C# or
                       C/C++; it only accepts keys for that app, and the app
                       remembers the key.
  Tax                  Stripe Tax adds the right GST/VAT at checkout; sales per
                       country, warnings before you need to register, and CSV
                       reports.

Promo           Promo Studio (see below).

Connectors      Discord alerts and posts, automatic emails, social posting,
                GitHub, Stripe, store uploads and more.

Site settings   Text and announcement, sections, categories, social links and
                the mobile menu.

Settings        Account, appearance and interface size, dashboard layout,
                celebrations, region, Phone access, data and backups.

Press ? anywhere to see keyboard shortcuts.


PROMO STUDIO
------------
Pick an app, then:

Video       A promo film is written from the app's own words and screenshots.
            Five story types (product tour, teaser, deep dive, what's new,
            problem and answer), five looks, original music made to the beat,
            optional voice-over and captions. Render wide, vertical, square or
            portrait.
            Edit it on the timeline: drag the playhead, drag a clip's edge to
            change its length, drag clips to reorder, split, duplicate, switch
            scenes on and off, add markers, undo and redo. Jump anywhere by
            typing a time or a scene name ( / ). YouTube-style keys: J K L,
            arrows, comma and full stop for single frames, 0-9. Copy YouTube
            chapters; MP4 files carry chapters too.

Images      14 store and social formats from one design.

Icon Studio Draw your own icons (pen, shapes, point editing, unite and
            subtract, layers, gradients, shadows, SVG import) or start from the
            generator. Export SVG, PNG and Windows ICO, or set it as the app's
            icon.

Launch kit  Ready-to-post text for each network, and one zip with everything.

Library     All your media, plus capture from any web address: single page
            elements (heroes, cards, sections, tables, media), screens, full
            pages and the original pictures, at desktop, laptop, tablet and
            phone sizes. Deep scan follows links through the whole site (up to
            200 pages). Pick what you like and add it to the app's screenshots.

Edit Studio A full video editor: layers, trimming, captions, motion, sound,
            voice-over at the playhead, an overview scrubber, "jump to"
            (Ctrl+K) and J K L playback.

What it needs:
  - Google Chrome or Microsoft Edge: images, videos and screen capture.
  - FFmpeg: rendering video (Windows: winget install ffmpeg, then restart).


VOICE-OVER
----------
The voices built into Windows work straight away. For natural voices, add the
voice pack (a separate download): unzip it so the "voice" folder sits next to
"Pylerium Manager.exe", then restart. Speech is generated on your computer;
nothing is sent anywhere. The first line takes up to a minute while the voice
loads.

Written by Ollama (optional): with Ollama running, your own model can write the
lines. It knows the app the same way the social automation does, and it is told
what each screen shows (from your page captures, a vision model if you have one,
or the words in the picture). In Promo Studio press "Write all lines" or "Ask
Ollama" on a scene; in Edit Studio press "Write for this clip" or "Narrate every
clip". Read the lines before you publish: small models can word things oddly.


EMAIL-TO-DOWNLOAD
-----------------
Store -> Email list: connect Cloudflare (the "Edit Cloudflare Workers" token),
start the service, switch it on for the apps you choose, then Publish. Good to
know: addresses are not verified; a public GitHub release page stays reachable
by anyone who knows it (use a private repository or a direct file); and links
published before you switched it on may remain in your site's history. Only send
news to people who ticked the updates box.


UPDATES
-------
When a new version is ready, Pylerium Manager asks. Press "Update now" and it
downloads the release, checks it was signed by Pylerium, closes, installs and
opens again. Your apps, settings and voice pack stay as they are, and if the new
version can't start, the old one is put back. You can also check any time in
Settings -> Account. (Windows download; the macOS and Linux source packages link
to the website instead.)


USE IT FROM YOUR PHONE
----------------------
Settings -> Phone access. Switch it on, open the address shown on a phone on the
same Wi-Fi, and enter the six-digit pairing code. Only devices on your own
network can connect. Windows may ask to allow private networks the first time.


YOUR DATA
---------
Everything you create is kept in your user profile, not in this folder:
  Windows:  %APPDATA%\Pylerium Manager
  macOS:    ~/Library/Application Support/Pylerium Manager
  Linux:    ~/.config/pylerium-manager
So you can update Pylerium Manager by replacing this folder with a new version.
(If you added the voice pack beside the app, copy its "voice" folder across, or
keep it in the data folder above instead.)

Keys you enter (GitHub token, Stripe key, Discord webhooks, Gmail app password)
are stored only in that folder, on your computer.


KEEPING IT RUNNING
------------------
Closing the browser tab doesn't stop Pylerium Manager: it keeps checking for
sales and sending emails in the background. To stop it: Settings -> Account ->
Quit. To start it automatically with Windows: Connectors -> Discord -> Setup ->
"Start the hub quietly when Windows starts".


HELP
----
Email danqhu3@gmail.com
https://pylerium.github.io/manager/
