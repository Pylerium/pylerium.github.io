// Email-to-download: the small service the app deploys to your Cloudflare account.
//
// The public site never contains the download address of a gated app. A visitor enters an email, this worker stores it
// and answers with a short-lived link that redirects to the file. The addresses and the collected emails live in your own
// Cloudflare KV namespace; only your app (with the admin key) can list or delete them.
//
// Bindings: LEADS (KV namespace), ADMIN_KEY (secret). Settings: SITE_URL, STORE_NAME.
// Deployed and updated by the app (Store → Email list). Editing it here by hand is not needed.

const VERSION = '1.0.0';
const LINK_MINUTES = 30;
const PER_HOUR = 20; // sign-ups from one network address
const EMAIL = /^[^\s@<>()",;:\\]{1,64}@[^\s@<>()",;:\\]+\.[A-Za-z]{2,24}$/;

class Fail extends Error { constructor(status, message) { super(message); this.status = status; } }

export default {
  async fetch(req, env) {
    const url = new URL(req.url), path = url.pathname;
    if (req.method === 'OPTIONS') return cors(new Response(null, { status: 204 }));
    try {
      if (!env.LEADS) throw new Fail(503, 'This download service isn’t set up yet.');
      if (path === '/' || path === '/health') return json({ ok: true, service: 'email-gate', version: VERSION, ...(isAdmin(env, req) ? { gates: Object.keys(await gates(env)) } : {}) });
      if (path === '/unlock' && req.method === 'POST') return json(await unlock(env, req, url));
      if (path === '/get' && req.method === 'GET') return await get(env, url);
      if (path.startsWith('/admin/')) {
        if (!isAdmin(env, req)) throw new Fail(401, 'Not allowed.');
        if (path === '/admin/gates' && req.method === 'PUT') return json(await setGates(env, await body(req, 200000)));
        if (path === '/admin/leads' && req.method === 'GET') return json(await leads(env));
        if (path === '/admin/delete' && req.method === 'POST') return json(await remove(env, await body(req, 4000)));
      }
      return json({ error: 'Not found' }, 404);
    } catch (e) {
      return json({ error: e instanceof Fail ? e.message : 'Something went wrong. Please try again in a minute.' }, e instanceof Fail ? e.status : 500);
    }
  }
};

async function body(req, limit) {
  const text = await req.text();
  if (text.length > limit) throw new Fail(413, 'That request is too large.');
  try { return JSON.parse(text || '{}'); } catch { throw new Fail(400, 'That request couldn’t be read.'); }
}
function isAdmin(env, req) {
  const a = req.headers.get('x-admin-key') || '', b = env.ADMIN_KEY || '';
  if (!b || a.length !== b.length) return false;
  let diff = 0; for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
const gates = async env => (await env.LEADS.get('gates', 'json')) || {};

// ---------- a visitor asks for a download ----------
async function unlock(env, req, url) {
  const b = await body(req, 4000);
  if (b.website) throw new Fail(400, 'That request couldn’t be accepted.'); // a hidden field only bots fill in
  const app = String(b.app || ''), email = String(b.email || '').trim().toLowerCase();
  const gate = (await gates(env))[app];
  if (!gate) throw new Fail(404, 'This download isn’t available right now.');
  if (!EMAIL.test(email) || email.length > 254) throw new Fail(400, 'Enter a valid email address.');
  const ip = req.headers.get('cf-connecting-ip') || 'local', rk = `rate:${ip}`, used = +(await env.LEADS.get(rk)) || 0;
  if (used >= PER_HOUR) throw new Fail(429, 'Too many requests from this network. Please try again later.');
  await env.LEADS.put(rk, String(used + 1), { expirationTtl: 3600 });
  const key = `lead:${app}:${email}`, now = new Date().toISOString();
  const old = await env.LEADS.get(key, 'json');
  const record = { app, email, first: old?.first || now, last: now, count: (old?.count || 0) + 1, updates: !!(b.updates || old?.updates), country: req.cf?.country || old?.country || '' };
  await env.LEADS.put(key, JSON.stringify(record), { metadata: record });
  const expires = Math.floor(Date.now() / 1000) + LINK_MINUTES * 60;
  const payload = `${app}.${expires}`;
  return { ok: true, name: gate.name || app, url: `${url.origin}/get?a=${encodeURIComponent(app)}&e=${expires}&s=${await sign(env, payload)}`, minutes: LINK_MINUTES };
}
async function get(env, url) {
  const app = url.searchParams.get('a') || '', expires = +url.searchParams.get('e') || 0, sig = url.searchParams.get('s') || '';
  if (sig !== await sign(env, `${app}.${expires}`)) throw new Fail(403, 'This download link isn’t valid. Ask for a new one on the website.');
  if (Date.now() / 1000 > expires) throw new Fail(410, 'This download link has expired. Ask for a new one on the website.');
  const gate = (await gates(env))[app];
  if (!gate?.url) throw new Fail(404, 'This download isn’t available right now.');
  return new Response(null, { status: 302, headers: { Location: gate.url, 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' } });
}
async function sign(env, text) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(env.ADMIN_KEY || ''), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const mac = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(text));
  return [...new Uint8Array(mac)].slice(0, 24).map(x => x.toString(16).padStart(2, '0')).join('');
}

// ---------- admin ----------
async function setGates(env, b) {
  const clean = {};
  for (const [id, g] of Object.entries(b.gates || {})) if (/^[\w-]{1,60}$/.test(id) && /^https?:\/\//.test(g?.url || '')) clean[id] = { url: String(g.url).slice(0, 1000), name: String(g.name || id).slice(0, 120) };
  await env.LEADS.put('gates', JSON.stringify(clean));
  return { ok: true, gates: Object.keys(clean) };
}
async function leads(env) {
  const list = []; let cursor;
  for (let page = 0; page < 50; page++) {
    const r = await env.LEADS.list({ prefix: 'lead:', cursor, limit: 1000 });
    for (const k of r.keys) if (k.metadata) list.push(k.metadata);
    if (r.list_complete) break; cursor = r.cursor;
  }
  return { ok: true, leads: list.sort((a, b) => String(b.last).localeCompare(String(a.last))) };
}
async function remove(env, b) {
  const email = String(b.email || '').trim().toLowerCase(); if (!email) throw new Fail(400, 'Which email?');
  let removed = 0, cursor;
  for (let page = 0; page < 50; page++) {
    const r = await env.LEADS.list({ prefix: b.app ? `lead:${b.app}:` : 'lead:', cursor, limit: 1000 });
    for (const k of r.keys) if (k.name.endsWith(`:${email}`)) { await env.LEADS.delete(k.name); removed++; }
    if (r.list_complete) break; cursor = r.cursor;
  }
  return { ok: true, removed };
}

function cors(r) {
  r.headers.set('Access-Control-Allow-Origin', '*');
  r.headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  r.headers.set('Access-Control-Allow-Headers', 'content-type');
  r.headers.set('Access-Control-Max-Age', '86400');
  return r;
}
const json = (v, status = 200) => cors(new Response(JSON.stringify(v), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } }));
