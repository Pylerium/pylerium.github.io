PYLERIUM MANAGER
Your studio site, live in minutes.
=================================

Pylerium Manager builds a showcase website for your apps, publishes it free on
GitHub Pages (yourname.github.io), and runs the business side for you: Stripe
sales, supporter codes, automatic emails and Discord alerts.


START IT
--------
Windows:  Unzip this folder somewhere you keep apps (for example Documents),
          then double-click "Pylerium Manager.cmd". This package includes its
          own runtime; no separate install or download is needed.

macOS:    For a source package, double-click "Pylerium Manager.command". If macOS says it can't be
          opened, right-click it, choose Open, then Open again.

Linux:    For a source package, run launcher/start.sh

Pylerium Manager opens in your web browser. It only runs on your own computer
(nothing is uploaded except your website to your own GitHub account).


THE SETUP (about 3 minutes)
---------------------------
1. Licence      Paste the key from your purchase email, or start the free trial.
2. GitHub       Sign in, or create a token (the button opens the right page with
                the right permission already ticked) and paste it.
                No GitHub account? Make one free at github.com/signup.
3. Your site    Pylerium Manager creates yourname.github.io and turns on
                GitHub Pages for you.
4. Your brand   Name, tagline, logo, contact email and currency.
5. Launch       Your site is built and published. GitHub takes a minute or two
                to put it online the first time.

Then add your apps in the Apps tab and press Publish whenever you change
something. Optional extras live in their own tabs:
  - Community → Caffeine & perks:  connect Stripe for sales and supporter codes
  - Discord:   alerts for every sale, release and video, plus automatic emails
  - Store:     everything you sell, in one tab:
      Apps for sale        Sell an app. Its files stay in a private GitHub
                           repository and buyers download them right after
                           paying (uses a free Cloudflare account, set up for
                           you). Pick an app or choose "+ New app...". Apps on
                           your site with no way to download are flagged.
                           Versions, notes and prices stay in sync by themselves.
      Products & prices    Every price and checkout; Stripe is updated for you.
      Licences             Buyers of a licensed app get a key with their
                           download. Get a ready-made key check for Python,
                           JavaScript, C# or C/C++; it only accepts keys for
                           that app, and the app remembers the key.
      Tax                  Stripe Tax adds the right GST/VAT at checkout; sales
                           per country, warnings before you need to register,
                           and CSV reports.


YOUR DATA
---------
Everything you create is kept in your user profile, not in this folder:
  Windows:  %APPDATA%\Pylerium Manager
  macOS:    ~/Library/Application Support/Pylerium Manager
  Linux:    ~/.config/pylerium-manager
So you can update Pylerium Manager by replacing this folder with a new version.

Keys you enter (GitHub token, Stripe key, Discord webhooks, Gmail app password)
are stored only in that folder, on your computer.


KEEPING IT RUNNING
------------------
Closing the browser tab doesn't stop Pylerium Manager: it keeps checking for
sales and sending emails in the background. To stop it: Settings → Quit.
To start it automatically with Windows: Discord → Setup → "Start the hub
quietly when Windows starts".


HELP
----
Email danqhu3@gmail.com
https://pylerium.github.io/manager/
