@echo off
rem Pylerium Manager. Starts the app (no separate runtime needed) and opens it in your browser.
set "PM_HUB=%~dp0"
start "" "%~dp0Pylerium Manager.exe"
timeout /t 2 /nobreak >nul
start "" http://localhost:4380/
