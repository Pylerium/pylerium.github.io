// Perks: rewards supporters unlock (downloads, early access, discount codes, Discord roles, licence keys, secret messages…).
// Ways to unlock a perk: total support, buying selected apps, buying the perk itself (its own Stripe link),
// lucky drops when someone downloads selected apps, or being given it by hand.
//
// The site is static, so every holder's rewards are published encrypted with a key derived from their personal
// supporter code (PBKDF2 + AES-256-GCM). Only someone with the code can open them; the page source shows nothing useful.
import { createHash, createHmac, createCipheriv, pbkdf2Sync, randomBytes } from 'node:crypto';

export const PERK_TYPES = ['submit', 'download', 'early', 'discount', 'discord', 'secret', 'key', 'wall', 'credits', 'vote', 'beta', 'support', 'shoutout', 'source', 'assets', 'custom'];
const ITER = 120000;
const sha = s => createHash('sha256').update(s).digest('hex');
const norm = c => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const str = (v, n = 500) => (typeof v === 'string' ? v.trim().slice(0, n) : '');
const num = v => (Number.isFinite(+v) && +v > 0 ? +v : 0);
const isUrl = u => /^https?:\/\/\S+$/i.test(String(u || ''));
const slug = s => String(s || '').toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '').trim().replace(/[\s_]+/g, '-').replace(/-+/g, '-').slice(0, 40) || 'perk';
const now = () => new Date().toISOString();

export function createPerks(ctx) {
  // ---------- storage ----------
  const blank = () => ({ perks: [], grants: {}, claims: [], drops: {} });
  const load = () => ({ ...blank(), ...ctx.readJson('perks.json', {}) });
  const save = d => ctx.writeJson('perks.json', d);

  function clean(p, prev = {}) {
    const type = PERK_TYPES.includes(p.type) ? p.type : 'custom';
    const r = p.reward || {}, u = p.unlock || {}, l = p.limits || {};
    const keys = (Array.isArray(r.keys) ? r.keys : String(r.keys || '').split('\n')).map(k => String(k).trim()).filter(Boolean).slice(0, 5000);
    const drops = (Array.isArray(u.drops) ? u.drops : []).map(d => ({ appId: str(d.appId, 60), chance: Math.min(100, Math.max(0.01, +d.chance || 5)) })).filter(d => d.appId);
    const buy = u.buy && (u.buy.url || u.buy.price) ? { price: num(u.buy.price), url: isUrl(u.buy.url) ? u.buy.url : '', linkId: str(u.buy.linkId, 80), productId: str(u.buy.productId, 80), label: str(u.buy.label, 40) } : null;
    return {
      id: prev.id || str(p.id, 48) || `${slug(p.name)}-${randomBytes(2).toString('hex')}`,
      name: str(p.name, 60) || 'Untitled perk', tagline: str(p.tagline, 160), icon: str(p.icon, 30) || 'gift', accent: str(p.accent, 20) || 'violet',
      type, enabled: p.enabled !== false, show: ['public', 'secret'].includes(p.show) ? p.show : 'public',
      reward: { url: isUrl(r.url) ? r.url.trim() : '', label: str(r.label, 40), text: str(r.text, 4000), code: str(r.code, 200), keys, appId: str(r.appId, 60), instructions: str(r.instructions, 1000) },
      unlock: {
        total: num(u.total), apps: (Array.isArray(u.apps) ? u.apps : []).map(x => str(x, 60)).filter(Boolean), appsAll: !!u.appsAll,
        products: (Array.isArray(u.products) ? u.products : []).map(String).filter(x => /^(prod|plink)_\w+$/.test(x)),
        buy, drops, dropMode: u.dropMode === 'instant' ? 'instant' : 'claim', dropDaily: Math.min(1000, Math.round(num(u.dropDaily))), dropStock: Math.round(num(u.dropStock))
      },
      limits: { stock: Math.round(num(l.stock)), days: Math.round(num(l.days)), endsAt: /^\d{4}-\d{2}-\d{2}$/.test(l.endsAt || '') ? l.endsAt : '', keepOnRefund: !!l.keepOnRefund },
      order: Number.isFinite(+p.order) ? +p.order : prev.order ?? 999, createdAt: prev.createdAt || now(), updatedAt: now()
    };
  }

  // ---------- holders ----------
  const holders = (d, perkId) => Object.entries(d.grants).filter(([, g]) => g[perkId] && !g[perkId].revoked).map(([sid]) => sid);
  const ended = p => p.limits.endsAt && p.limits.endsAt < now().slice(0, 10);
  const expired = (p, g) => p.limits.days && Date.now() - new Date(g.at) > p.limits.days * 864e5;
  const active = (p, g) => g && !g.revoked && !expired(p, g);
  const stockLeft = (d, p) => (p.limits.stock ? Math.max(0, p.limits.stock - holders(d, p.id).length) : null);
  const keysLeft = (d, p) => (p.type === 'key' ? p.reward.keys.length - Object.values(d.grants).filter(g => g[p.id]?.key).length : null);

  // Give a perk to a supporter. Makes sure they have a code (a "perks only" code doesn't unlock app submissions).
  function grantTo(d, sid, perkId, via = 'manual', note = '') {
    const p = d.perks.find(x => x.id === perkId); if (!p) throw new Error('Perk not found');
    const sups = ctx.loadSupporters(); const s = sups.find(x => x.id === sid); if (!s) throw new Error('Supporter not found');
    const g = (d.grants[sid] ||= {});
    if (active(p, g[perkId])) return { already: true, supporter: s };
    if (via !== 'manual') { if (!p.enabled) return { skipped: 'Perk is switched off' }; if (ended(p)) return { skipped: 'Perk has ended' }; }
    const left = stockLeft(d, p); if (left === 0) throw new Error(`${p.name} is out of stock (${p.limits.stock} given).`);
    let key = g[perkId]?.key || '';
    if (p.type === 'key' && !key) {
      const used = new Set(Object.values(d.grants).map(x => x[perkId]?.key).filter(Boolean));
      key = p.reward.keys.find(k => !used.has(k)) || '';
      if (!key) throw new Error(`${p.name} has no unused keys left. Add more keys to the perk.`);
    }
    g[perkId] = { at: now(), via, note: str(note, 200), ...(key ? { key } : {}) };
    let sup = s, newCode = false;
    if (!s.code || s.revoked) { sup = ctx.issueCode(sid, { perkOnly: true }); newCode = true; }
    return { granted: true, supporter: sup, newCode, perk: p };
  }
  function findOrAddSupporter(name, email) {
    const e = String(email || '').trim().toLowerCase(), n = String(name || '').trim();
    if (!e && !n) throw new Error('Pick a supporter or enter a name and email.');
    if (e && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) throw new Error('That email doesn’t look right.');
    const list = ctx.loadSupporters();
    let s = e ? list.find(x => (x.email || '').toLowerCase() === e) : null;
    if (!s) { s = { id: 'sp-' + randomBytes(5).toString('hex'), name: n, email: e, type: 'perk', total: 0, wall: false, wallName: '', notes: 'Added from Perks', source: 'perks', firstAt: now() }; list.push(s); ctx.saveSupporters(list); }
    return s;
  }

  // ---------- automatic rules ----------
  // Which perks a supporter has earned right now (support total, apps bought, the perk's own price).
  async function earned(d, s, linkApps) {
    const out = new Set();
    if (!s?.email) return out;
    const buys = ctx.purchases(s.email);
    const apps = new Set(); const links = new Set(), prods = new Set();
    for (const b of buys) { if (b.link) links.add(b.link); for (const p of b.products || []) prods.add(p); for (const a of linkApps.get(b.link) || []) apps.add(a); for (const p of b.products || []) for (const a of linkApps.get(p) || []) apps.add(a); }
    const total = Math.max(ctx.qualTotal(s.email), s.source === 'manual' || s.type === 'manual' ? +s.total || 0 : 0);
    for (const p of d.perks) {
      const u = p.unlock;
      if (u.total && total >= u.total) out.add(p.id);
      if (u.apps.length && (u.appsAll ? u.apps.every(a => apps.has(a)) : u.apps.some(a => apps.has(a)))) out.add(p.id);
      if (u.products.some(x => links.has(x) || prods.has(x))) out.add(p.id);
      if (u.buy && ((u.buy.linkId && links.has(u.buy.linkId)) || (u.buy.productId && prods.has(u.buy.productId)))) out.add(p.id);
    }
    return out;
  }
  // Grant what's newly earned; take back automatic perks after a refund or dispute (unless the perk keeps them).
  async function sync(onlyEmail) {
    const d = load(); if (!d.perks.length) return { granted: [], revoked: [] };
    const linkApps = await ctx.linkApps().catch(() => new Map());
    const granted = [], revoked = [];
    for (const s of ctx.loadSupporters()) {
      if (onlyEmail && (s.email || '').toLowerCase() !== onlyEmail.toLowerCase()) continue;
      const e = await earned(d, s, linkApps), g = d.grants[s.id] || {};
      for (const id of e) {
        if (g[id] && (g[id].revoked === 'manual' || active(d.perks.find(p => p.id === id), g[id]) || g[id].via !== 'manual' && expired(d.perks.find(p => p.id === id), g[id]))) continue;
        try { const r = grantTo(d, s.id, id, 'auto'); if (r.granted) granted.push({ supporter: r.supporter, perk: r.perk, newCode: r.newCode }); } catch {}
      }
      for (const [id, x] of Object.entries(d.grants[s.id] || {})) {
        const p = d.perks.find(q => q.id === id);
        if (p && x.via === 'auto' && !x.revoked && !e.has(id) && !p.limits.keepOnRefund) { x.revoked = 'refund'; x.revokedAt = now(); revoked.push({ supporter: s, perk: p }); }
      }
    }
    save(d);
    return { granted, revoked };
  }

  // ---------- lucky-drop claims ----------
  // Winners email a claim from the site; you paste it here and approve it (stock and daily caps are checked).
  function parseClaim(text) {
    const m = String(text || '').match(/PERK-CLAIM:([A-Za-z0-9+/=_-]+)/);
    if (!m) return null;
    try { const j = JSON.parse(Buffer.from(m[1].replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')); return j?.perk ? j : null; } catch { return null; }
  }
  function addClaim(text, from = {}) {
    const c = parseClaim(text); if (!c) throw new Error('Couldn’t find a perk claim in that text. Paste the whole email.');
    const d = load();
    const key = 'cl-' + sha(`${c.perk}:${c.t}:${c.at}`).slice(0, 10);
    if (!d.claims.some(x => x.key === key)) {
      const p = d.perks.find(x => x.id === c.perk);
      d.claims.unshift({ key, perkId: c.perk, perkName: p?.name || c.perk, appId: str(c.app, 60), name: str(from.name || c.name, 80), email: str(from.email || c.email, 120).toLowerCase(), token: str(c.t, 40), wonAt: str(c.at, 40), at: now(), status: 'pending' });
      d.claims = d.claims.slice(0, 500); save(d);
    }
    return d.claims;
  }
  function decideClaim(key, approve, edits = {}) {
    const d = load(); const c = d.claims.find(x => x.key === key); if (!c) throw new Error('Claim not found');
    if (!approve) { c.status = 'rejected'; c.decidedAt = now(); save(d); return { claim: c }; }
    const p = d.perks.find(x => x.id === c.perkId); if (!p) throw new Error('That perk no longer exists.');
    if (p.unlock.dropStock && (d.drops[p.id]?.won || 0) >= p.unlock.dropStock) throw new Error(`All ${p.unlock.dropStock} lucky drops of ${p.name} have been claimed.`);
    if (d.claims.some(x => x.status === 'approved' && x.token === c.token)) throw new Error('This claim token was already used.');
    const s = findOrAddSupporter(edits.name || c.name, edits.email || c.email);
    const r = grantTo(d, s.id, p.id, 'drop', `Lucky drop${c.appId ? ` from ${c.appId}` : ''}`);
    c.status = 'approved'; c.decidedAt = now(); c.supporterId = s.id;
    d.drops[p.id] = { won: (d.drops[p.id]?.won || 0) + 1 };
    save(d);
    return { claim: c, ...r };
  }

  // ---------- what the site gets ----------
  const keyCache = new Map();
  const deriveKey = (code, salt) => { const k = `${salt}:${code}`; if (!keyCache.has(k)) keyCache.set(k, pbkdf2Sync(norm(code), `${salt}:perks`, ITER, 32, 'sha256')); return keyCache.get(k); };
  // AES-256-GCM, IV derived from the content (so identical content gives an identical build), tag appended like WebCrypto.
  function seal(key, obj) {
    const pt = Buffer.from(JSON.stringify(obj), 'utf8');
    const iv = createHmac('sha256', key).update(pt).digest().subarray(0, 12);
    const c = createCipheriv('aes-256-gcm', key, iv); const ct = Buffer.concat([c.update(pt), c.final(), c.getAuthTag()]);
    return { iv: iv.toString('base64'), ct: ct.toString('base64') };
  }
  const payload = (p, g, apps) => {
    const r = p.reward, app = r.appId ? apps.find(a => a.id === r.appId) : null;
    return { id: p.id, name: p.name, icon: p.icon, accent: p.accent, type: p.type, url: r.url, label: r.label, text: r.text, code: r.code, key: g.key || '', instructions: r.instructions,
      app: app ? app.name : '', until: p.limits.days ? new Date(new Date(g.at).getTime() + p.limits.days * 864e5).toISOString().slice(0, 10) : '', at: g.at.slice(0, 10) };
  };
  function publicData(site, supporters, apps) {
    const d = load(), salt = site.community?.salt || '';
    const live = d.perks.filter(p => p.enabled);
    if (!live.length || !salt) return null;
    const pub = apps.filter(a => a.published);
    const name = id => pub.find(a => a.id === id)?.name;
    const list = live.filter(p => p.show === 'public' && !ended(p)).sort((a, b) => a.order - b.order).map(p => {
      const u = p.unlock, how = [];
      if (u.total) how.push({ k: 'total', amount: u.total });
      if (u.buy?.url) how.push({ k: 'buy', url: u.buy.url, price: u.buy.price, label: u.buy.label });
      const ap = u.apps.map(id => ({ id, name: name(id) })).filter(a => a.name);
      if (ap.length) how.push({ k: 'apps', all: u.appsAll && ap.length > 1, apps: ap });
      const dr = u.drops.map(x => ({ id: x.appId, name: name(x.appId), chance: x.chance })).filter(a => a.name);
      if (dr.length) how.push({ k: 'drop', apps: dr });
      if (!how.length) how.push({ k: 'gift' });
      const left = stockLeft(d, p), dl = u.dropStock ? Math.max(0, u.dropStock - (d.drops[p.id]?.won || 0)) : null;
      return { id: p.id, name: p.name, tagline: p.tagline, icon: p.icon, accent: p.accent, type: p.type, how, left, dropsLeft: dl, endsAt: p.limits.endsAt, days: p.limits.days, holders: holders(d, p.id).length };
    });
    // Drops: which apps can drop which perk. "instant" drops carry their reward, lightly scrambled (fine for small rewards).
    const drops = {};
    for (const p of live) {
      if (ended(p) || (p.unlock.dropStock && (d.drops[p.id]?.won || 0) >= p.unlock.dropStock)) continue;
      for (const x of p.unlock.drops) {
        if (!name(x.appId)) continue;
        const e = { perk: p.id, name: p.name, icon: p.icon, accent: p.accent, tagline: p.tagline, chance: x.chance, mode: p.unlock.dropMode, daily: p.unlock.dropDaily || 0 };
        if (p.unlock.dropMode === 'instant' && p.type !== 'key') e.box = seal(createHash('sha256').update(`${salt}:drop:${p.id}`).digest(), payload(p, { at: p.updatedAt || p.createdAt }, apps));
        (drops[x.appId] ||= []).push(e);
      }
    }
    // Vault: one sealed box per code holder with all their active perks.
    const vault = {}, marks = [];
    for (const s of supporters) {
      if (!s.code || s.revoked || !s.codeHash) continue;
      const g = d.grants[s.id] || {};
      const mine = live.filter(p => active(p, g[p.id])).map(p => payload(p, g[p.id], apps));
      if (!mine.length) continue;
      vault[s.codeHash] = seal(deriveKey(s.code, salt), { name: String(s.wallName || s.name || '').split(/\s+/)[0] || '', perks: mine });
      for (const p of mine) marks.push(mark(s.codeHash, p.id));
    }
    return { list, drops, vault, marks: marks.sort(), salt, iter: ITER, claimEmail: ctx.supportEmail() || '', prefix: site.community?.codePrefix || 'CAFE', submit: !!site.community?.submissionsEnabled };
  }
  // A short marker per grant: when it appears on the live site, the grant's email can go out.
  const mark = (codeHash, perkId) => sha(`${codeHash}:${perkId}`).slice(0, 20);
  // Supporters whose code should open the app-submission form: everyone except "perks only" codes, unless a perk unlocks submissions.
  function submitAllowed(s) {
    if (s.codeFor !== 'perks') return true;
    const d = load(), g = d.grants[s.id] || {};
    return d.perks.some(p => p.type === 'submit' && p.enabled && active(p, g[p.id]));
  }

  // ---------- views for the hub ----------
  function state() {
    const d = load(), sups = ctx.loadSupporters(), apps = ctx.loadApps();
    return {
      perks: [...d.perks].sort((a, b) => a.order - b.order).map(p => ({ ...p, holders: holders(d, p.id).length, left: stockLeft(d, p), keysLeft: keysLeft(d, p), dropsWon: d.drops[p.id]?.won || 0, ended: !!ended(p) })),
      grants: Object.fromEntries(Object.entries(d.grants).map(([sid, g]) => [sid, Object.fromEntries(Object.entries(g).map(([pid, x]) => [pid, { at: x.at, via: x.via, note: x.note, revoked: x.revoked || false, hasKey: !!x.key, expired: (() => { const p = d.perks.find(q => q.id === pid); return p ? !!expired(p, x) : false; })() }]))])),
      claims: d.claims,
      supporters: sups.map(s => ({ id: s.id, name: s.name, email: s.email, total: s.total || 0, code: !!s.code && !s.revoked, type: s.type })),
      apps: apps.map(a => ({ id: a.id, name: a.name, published: !!a.published, paid: /buy\.stripe\.com|checkout\.stripe/.test(a.primaryUrl || '') || !!a.price && !/free/i.test(a.price), price: a.price || '', icon: a.iconImage || '', glyph: a.glyph, accent: a.accent })),
      currency: ctx.loadSite().community?.currency || 'USD', stripe: ctx.stripeWrite()
    };
  }

  async function route(path, M, body) {
    if (!path.startsWith('/api/perks')) return undefined;
    if (path === '/api/perks' && M === 'GET') return state();
    if (path === '/api/perks' && M === 'POST') {
      const d = load(), b = body.perk || {}, i = d.perks.findIndex(p => p.id === b.id);
      const p = clean(b, i >= 0 ? d.perks[i] : { order: Math.max(0, ...d.perks.map(x => x.order + 1)) });
      if (i >= 0) d.perks[i] = p; else d.perks.push(p);
      save(d); return { perk: p, ...state() };
    }
    if (path === '/api/perks/order' && M === 'POST') { const d = load(); (body.ids || []).forEach((id, i) => { const p = d.perks.find(x => x.id === id); if (p) p.order = i; }); save(d); return state(); }
    if (path.startsWith('/api/perks/') && M === 'DELETE') {
      const id = decodeURIComponent(path.slice(11)), d = load();
      d.perks = d.perks.filter(p => p.id !== id); for (const g of Object.values(d.grants)) delete g[id]; delete d.drops[id];
      save(d); return state();
    }
    if (path === '/api/perks/give' && M === 'POST') {
      { // check stock before creating anyone, so a refused gift leaves no empty supporter behind
        const d0 = load();
        for (const pid of [].concat(body.perkIds || body.perkId || [])) {
          const p = d0.perks.find(x => x.id === pid); if (!p) throw new Error('Perk not found');
          if (stockLeft(d0, p) === 0) throw new Error(`${p.name} is out of stock (${p.limits.stock} given).`);
          if (p.type === 'key' && keysLeft(d0, p) <= 0) throw new Error(`${p.name} has no unused keys left. Add more keys to the perk.`);
        }
      }
      const s = body.supporterId ? ctx.loadSupporters().find(x => x.id === body.supporterId) : findOrAddSupporter(body.name, body.email);
      if (!s) throw new Error('Supporter not found');
      const d = load(), out = [];
      for (const pid of [].concat(body.perkIds || body.perkId || [])) { const r = grantTo(d, s.id, pid, 'manual', body.note); if (r.granted) out.push(r.perk); }
      save(d);
      const sup = ctx.loadSupporters().find(x => x.id === s.id);
      if (out.length && body.email !== false && body.notify !== false) ctx.onGranted(sup, out, 'manual');
      return { given: out.map(p => p.name), supporter: { id: sup.id, name: sup.name, email: sup.email, code: sup.code }, ...state() };
    }
    if (path === '/api/perks/revoke' && M === 'POST') {
      const d = load(), g = d.grants[body.supporterId]?.[body.perkId]; if (!g) throw new Error('They don’t have that perk.');
      if (body.restore) { delete g.revoked; delete g.revokedAt; g.at = now(); } else { g.revoked = 'manual'; g.revokedAt = now(); }
      save(d); return state();
    }
    if (path === '/api/perks/sync' && M === 'POST') { const r = await sync(); for (const x of r.granted) ctx.onGranted(x.supporter, [x.perk], 'auto'); return { granted: r.granted.length, revoked: r.revoked.length, ...state() }; }
    if (path === '/api/perks/sell' && M === 'POST') {
      const d = load(), p = d.perks.find(x => x.id === body.perkId); if (!p) throw new Error('Save the perk first.');
      const r = await ctx.createProduct({ name: `${p.name} (perk)`, description: p.tagline || `Unlocks the ${p.name} perk`, mode: 'fixed', amount: body.amount, thanks: `Thank you! Your ${p.name} perk and your personal code are on their way to your inbox.` });
      p.unlock.buy = { price: +body.amount, url: r.link, linkId: r.linkId, productId: r.productId, label: str(body.label, 40) };
      save(d); return { perk: p, ...state() };
    }
    if (path === '/api/perks/claims' && M === 'POST') { addClaim(body.text, body); return state(); }
    if (path === '/api/perks/claims/decide' && M === 'POST') {
      const r = decideClaim(body.key, !!body.approve, body);
      if (r.granted) ctx.onGranted(r.supporter, [r.perk], 'drop');
      return { result: { approved: !!r.granted, code: r.supporter?.code || '' }, ...state() };
    }
    if (path === '/api/perks/claims/delete' && M === 'POST') { const d = load(); d.claims = d.claims.filter(c => c.key !== body.key); save(d); return state(); }
    return undefined;
  }

  // For the Supporters list: the perks each supporter holds.
  function perksOf(sid) { const d = load(), g = d.grants[sid] || {}; return d.perks.filter(p => active(p, g[p.id])).map(p => ({ id: p.id, name: p.name, icon: p.icon, accent: p.accent })); }

  return { route, sync, publicData, submitAllowed, perksOf, mark, state, list: () => load().perks };
}
