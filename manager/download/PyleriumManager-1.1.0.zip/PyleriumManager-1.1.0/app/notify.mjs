// Discord alerts for Pylerium Manager: two webhooks (private owner channel + public community channel),
// background watchers (Stripe sales, GitHub submissions, YouTube uploads), a ready-to-send email outbox,
// scheduled posts, summaries and an activity log. Everything stays on this computer except the Discord posts.
import { existsSync, writeFileSync, rmSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { randomBytes } from 'node:crypto';
import { ACCENTS } from './shared/render.js';
import { smtpSend, htmlEmail, EMAIL_RE } from './mailer.mjs';

// ---------- event catalogue ----------
// priv/pub = default on/off per channel; pubOk = may go to the public channel at all; ping = default mention.
export const EVENTS = [
  { id: 'sale.new', group: 'Sales', emoji: '💸', label: 'New sale or donation', desc: 'Every successful Stripe payment: customer, product, amount, and the email ready to send.', priv: true, ping: true },
  { id: 'sale.eligible', group: 'Sales', emoji: '🔓', label: 'Supporter unlocks submissions', desc: 'A separate heads-up when someone reaches the threshold. The sale alert already includes this.', priv: false },
  { id: 'sale.refund', group: 'Sales', emoji: '↩️', label: 'Refund', desc: 'A payment was fully or partly refunded.', priv: true },
  { id: 'sale.dispute', group: 'Sales', emoji: '⚠️', label: 'Dispute or chargeback', desc: 'A customer disputed a payment. Respond in Stripe quickly.', priv: true, ping: true },
  { id: 'sale.failed', group: 'Sales', emoji: '❌', label: 'Failed payment', desc: 'A card was declined or a payment failed.', priv: false },
  { id: 'sale.held', group: 'Sales', emoji: '🛡️', label: 'Payment held for review', desc: 'Stripe flagged a payment as risky, so the hub held the supporter code until you approve it on the Live dashboard.', priv: true, ping: true },
  { id: 'sale.milestone', group: 'Sales', emoji: '🎉', label: 'Support milestone', desc: 'Total support passes a milestone, like 100 or 1,000.', priv: true, pubOk: true },
  { id: 'digest', group: 'Sales', emoji: '📊', label: 'Daily or weekly summary', desc: 'Sales, new supporters, submissions, videos and emails waiting.', priv: true },
  { id: 'supporter.code', group: 'Supporters', emoji: '🔑', label: 'Supporter code issued by hand', desc: 'When you issue a code in Community → Supporters, with the email ready.', priv: true },
  { id: 'perk.granted', group: 'Supporters', emoji: '🎁', label: 'Perk unlocked', desc: 'Someone got a perk: bought an app or the perk, gave enough, won a lucky drop, or you gave it by hand.', priv: true },
  { id: 'supporter.revoked', group: 'Supporters', emoji: '🚫', label: 'Supporter code revoked', desc: 'A code was revoked, by you or automatically after a refund or dispute.', priv: true },
  { id: 'email.sent', group: 'Emails', emoji: '📨', label: 'Email sent to a customer', desc: 'The hub emailed a supporter code or thank-you through Gmail.', priv: true },
  { id: 'email.failed', group: 'Emails', emoji: '📪', label: 'Email failed', desc: 'Gmail refused an email or the app password stopped working. The email stays in the outbox.', priv: true, ping: true },
  { id: 'store.changed', group: 'Store', emoji: '🏷️', label: 'Price or product changed', desc: 'You changed a price, created a product or turned a payment link on or off from the hub.', priv: true },
  { id: 'supporter.wall', group: 'Supporters', emoji: '🥤', label: 'New name on the supporters wall', desc: 'Thank them publicly once the wall is published.', priv: false, pubOk: true },
  { id: 'publish.needed', group: 'Supporters', emoji: '⏳', label: 'Codes waiting for a publish', desc: 'New codes only work after a publish. Sent when the hub can’t safely publish by itself.', priv: true, ping: true },
  { id: 'submission.new', group: 'Submissions', emoji: '📥', label: 'New app submission', desc: 'A supporter sent an app, mod or tool, with icon, screenshots and verification.', priv: true, ping: true },
  { id: 'submission.accepted', group: 'Submissions', emoji: '✅', label: 'Submission accepted', desc: 'You accepted a submission.', priv: false },
  { id: 'submission.declined', group: 'Submissions', emoji: '🙅', label: 'Submission declined', desc: 'You declined a submission.', priv: false },
  { id: 'app.new', group: 'Releases', emoji: '🚀', label: 'New app on the site', desc: 'An app goes live on your site for the first time.', priv: false, pub: true, pubOk: true, ping: true },
  { id: 'app.community', group: 'Releases', emoji: '🌟', label: 'Community app goes live', desc: 'An accepted supporter submission appears on the site.', pub: true, pubOk: true },
  { id: 'app.updated', group: 'Releases', emoji: '🔧', label: 'App update', desc: 'A published app gets a new version or changelog entry.', pub: true, pubOk: true },
  { id: 'app.available', group: 'Releases', emoji: '✅', label: 'App now available', desc: 'An app’s status changes to Available (for example from Coming soon).', pub: true, pubOk: true, ping: true },
  { id: 'app.featured', group: 'Releases', emoji: '⭐', label: 'App featured', desc: 'An app is added to the featured spotlight.', pub: false, pubOk: true },
  { id: 'app.removed', group: 'Releases', emoji: '📦', label: 'App taken off the site', desc: 'A published app was hidden or deleted.', priv: true },
  { id: 'site.announcement', group: 'Releases', emoji: '📣', label: 'Announcement bar changed', desc: 'Post the new announcement bar text when it goes live.', pub: false, pubOk: true },
  { id: 'yt.video', group: 'YouTube', emoji: '📺', label: 'New YouTube video', desc: 'A new upload on your channel (videos titled “test” are skipped).', pub: true, pubOk: true },
  { id: 'yt.short', group: 'YouTube', emoji: '⚡', label: 'New YouTube Short', desc: 'A new Short on your channel.', pub: true, pubOk: true },
  { id: 'publish.done', group: 'Hub', emoji: '🌐', label: 'Site published', desc: 'What changed, with the commit link.', priv: true },
  { id: 'publish.failed', group: 'Hub', emoji: '🛑', label: 'Publish failed', desc: 'A publish (manual or automatic) failed, with the error.', priv: true, ping: true },
  { id: 'hub.error', group: 'Hub', emoji: '🩺', label: 'Background check failed', desc: 'Stripe, GitHub or YouTube checks are failing (at most every 6 hours per problem).', priv: true },
  { id: 'hub.started', group: 'Hub', emoji: '🟢', label: 'Hub started', desc: 'The hub came online (useful when it runs at Windows start-up).', priv: false }
];
const EV = Object.fromEntries(EVENTS.map(e => [e.id, e]));

export const DEFAULT_TEMPLATES = {
  'app.new': '🚀 **{name}** just dropped on {brand}!',
  'app.community': '🌟 New community pick: **{name}** by {author}',
  'app.updated': '🔧 **{name} {version}** is out!',
  'app.available': '✅ **{name}** is now available!',
  'app.featured': '⭐ **{name}** is now featured on {brand}',
  'site.announcement': '📣 {text}',
  'yt.video': '📺 New video: **{title}**',
  'yt.short': '⚡ New Short: **{title}**',
  'supporter.wall': '🥤 Huge thanks to **{name}** for supplying the caffeine!',
  'sale.milestone': '🎉 The community just passed **{amount}** in support. Thank you all!'
};
const EMAIL_TEMPLATES = {
  code: {
    subject: 'Your {brand} supporter code 🥤',
    body: 'Hi {name},\n\nThank you so much for supplying the caffeine ({amount})! Your support keeps the apps coming.\n\nHere is your supporter code:\n\n    {code}\n\nIt unlocks app submissions on the {brand} showcase. Open {submitUrl}, enter the code, and tell us about your app, mod or tool. Accepted submissions get their own card with your name and links, and standout picks can be featured.\n\nThanks again,\n{brand}\n{siteUrl}'
  },
  thanks: {
    subject: 'Thank you for the caffeine 🥤',
    body: 'Hi {name},\n\nThank you so much for your support ({amount} for {product})! It genuinely keeps {brand} going.\n\nSupporters who give {threshold} or more in total unlock app submissions on the showcase. You’re at {total} so far.\n\nSee everything we’re building at {siteUrl}\n\nThanks again,\n{brand}'
  },
  perk: {
    subject: 'You unlocked {perk} 🎁',
    body: 'Hi {name},\n\nGood news: you just unlocked {perkCount}:\n\n{perks}\n\nOpen your perks here:\n{perksUrl}\n\nPress “My perks” and enter your personal code:\n\n    {code}\n\nKeep this code private. It opens your perks on any device.\n\nThank you for the support,\n{brand}'
  },
  licence: {
    subject: 'Your {app} licence key 🔑',
    body: 'Hi {name},\n\nHere is your licence key for {app}:{licence}\n\nKeep this email somewhere safe.\n\nIf anything doesn’t work, just reply to this email and we’ll sort it out.\n\nThanks,\n{brand}\n{siteUrl}'
  },
  download: {
    subject: 'Your download: {app}',
    body: 'Hi {name},\n\nThank you for buying {app} ({amount})!\n\nYour download page:\n{downloadUrl}{licence}\n\nThis link belongs to your purchase, so keep this email. Open it again any time you need to download {app} again.\n\nIf anything doesn’t work, just reply to this email and we’ll sort it out.\n\nThanks again,\n{brand}\n{siteUrl}'
  }
};

export function createNotifier(ctx) {
  const { cfg, readJson, writeJson } = ctx;
  let siteUrl = String(cfg.siteUrl || '').replace(/\/$/, '');
  const reconfig = () => { siteUrl = String(cfg.siteUrl || '').replace(/\/$/, ''); };
  const hubUrl = `http://localhost:${ctx.port}`;

  // ---------- settings / state / log / outbox ----------
  const isObj = v => v && typeof v === 'object' && !Array.isArray(v);
  const merge = (a, b) => { const o = { ...a }; for (const [k, v] of Object.entries(b || {})) o[k] = isObj(v) && isObj(a[k]) ? merge(a[k], v) : v; return o; };
  function defaults() {
    const events = {};
    for (const e of EVENTS) events[e.id] = { private: !!e.priv, public: !!(e.pubOk && e.pub), ping: !!e.ping };
    const avatar = ''; // empty = the studio's uploaded logo is used at send time
    return {
      channels: {
        private: { enabled: true, username: 'Pylerium Manager', avatar, ping: { type: 'here', id: '' } },
        public: { enabled: true, username: '', avatar, ping: { type: 'none', id: '' } }
      },
      events, templates: { ...DEFAULT_TEMPLATES },
      watch: { stripe: true, stripeMin: 2, submissions: true, submissionsMin: 10, youtube: true, youtubeMin: 30 },
      auto: { issueCodes: true, publishCodes: true, thanksEmail: true, waitLive: true, publishVideos: false, richCards: true, buttons: true },
      milestones: [50, 100, 250, 500, 1000, 2500, 5000, 10000],
      digest: { mode: 'daily', hour: 9, day: 1, skipEmpty: true },
      // Which payments count toward supporter perks. products: Stripe product or payment-link ids (empty = any payment).
      perks: { products: [], allowTest: false, holdRisky: true, revokeOnRefund: true, revokeOnDispute: true },
      email: { from: cfg.supportEmail || '', fromName: '', replyTo: '', auto: true, sendCodes: true, sendThanks: true, waitForLive: true, bccSelf: false, html: true, dailyCap: 300, templates: EMAIL_TEMPLATES }
    };
  }
  let SET = merge(defaults(), readJson('alerts.json', {}));
  const settings = () => SET;
  function saveSettings(next) {
    const d = defaults();
    SET = merge(d, next);
    for (const id of Object.keys(SET.events)) if (!EV[id]) delete SET.events[id];
    for (const [id, e] of Object.entries(SET.events)) if (!EV[id].pubOk) e.public = false;
    for (const c of ['private', 'public']) { const ch = SET.channels[c]; ch.username = String(ch.username || '').slice(0, 80); ch.avatar = /^https:\/\//.test(ch.avatar || '') ? ch.avatar : ''; }
    const n = (v, lo, hi, dflt) => Math.min(hi, Math.max(lo, Math.round(+v || dflt)));
    SET.watch.stripeMin = n(SET.watch.stripeMin, 1, 120, 2); SET.watch.submissionsMin = n(SET.watch.submissionsMin, 2, 240, 10); SET.watch.youtubeMin = n(SET.watch.youtubeMin, 5, 720, 30);
    SET.digest.hour = n(SET.digest.hour, 0, 23, 9); SET.digest.day = Math.min(6, Math.max(0, Math.round(+SET.digest.day || 0)));
    SET.milestones = (Array.isArray(SET.milestones) ? SET.milestones : String(SET.milestones).split(/[\s,]+/)).map(Number).filter(x => x > 0).sort((a, b) => a - b);
    SET.perks.products = [...new Set((Array.isArray(SET.perks.products) ? SET.perks.products : []).map(String).filter(x => /^(prod|plink)_\w+$/.test(x)))];
    SET.email.dailyCap = n(SET.email.dailyCap, 1, 2000, 300);
    SET.email.replyTo = EMAIL_RE.test(SET.email.replyTo || '') ? SET.email.replyTo.trim() : '';
    SET.email.fromName = String(SET.email.fromName || '').replace(/["<>\r\n]/g, '').slice(0, 60);
    writeJson('alerts.json', SET, false);
    return SET;
  }
  let ST = readJson('alerts-state.json', {});
  ST.last ||= {}; ST.watchers ||= {}; ST.errors ||= {}; ST.scheduled ||= []; ST.sales ||= []; ST.hooks ||= {};
  ST.ledger ||= {}; ST.held ||= []; ST.codeFor ||= {}; ST.smtp ||= {}; ST.mailDay ||= { day: '', n: 0 };
  const started = Date.now();
  const saveState = () => writeJson('alerts-state.json', ST, false);
  let LOG = readJson('alerts-log.json', []);
  const saveLog = () => { LOG = LOG.slice(0, 300); writeJson('alerts-log.json', LOG, false); };
  let OUT = readJson('outbox.json', []);
  const saveOut = () => { OUT = OUT.slice(0, 500); writeJson('outbox.json', OUT, false); };

  // ---------- helpers ----------
  const rid = () => randomBytes(6).toString('hex');
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const clip = (s, n) => { s = String(s ?? ''); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
  const B = () => ctx.loadSite().brand?.name || 'My Studio';
  const tpl = (s, v) => String(s || '').replace(/\{(\w+)\}/g, (m, k) => (v[k] ?? (k === 'brand' ? B() : '')) + '');
  const hex = c => parseInt(String(c || '#2DD4BF').replace('#', ''), 16) || 0x2dd4bf;
  const C = { sale: 0xF59E0B, good: 0x22C55E, bad: 0xEF4444, warn: 0xFBBF24, info: 0x38BDF8, violet: 0x8B5CF6, teal: 0x2DD4BF, yt: 0xFF0033 };
  const ZERO = new Set(['bif', 'clp', 'djf', 'gnf', 'jpy', 'kmf', 'krw', 'mga', 'pyg', 'rwf', 'ugx', 'vnd', 'vuv', 'xaf', 'xof', 'xpf']);
  const money = (minor, cur = 'aud') => {
    const c = String(cur || 'aud').toUpperCase(); const v = ZERO.has(c.toLowerCase()) ? minor : minor / 100;
    try { return new Intl.NumberFormat('en-US', { style: 'currency', currency: c, minimumFractionDigits: v % 1 ? 2 : 0, maximumFractionDigits: 2 }).format(v); } catch { return `${v} ${c}`; }
  };
  const aud = dollars => money(Math.round((+dollars || 0) * 100), ctx.loadSite().community?.currency || 'aud');
  const isUrl = u => /^https?:\/\/[^\s]+$/i.test(String(u || ''));
  const abs = p => (!p ? '' : /^https?:/i.test(p) ? p : /^(data|blob):/i.test(p) ? '' : `${siteUrl}/assets/apps/${p}`);
  const appUrl = a => `${siteUrl}/apps/${a.id}/`;
  const btn = (label, url, emoji) => (isUrl(url) && url.length <= 512 ? { type: 2, style: 5, label: clip(label, 80), url, ...(emoji ? { emoji: { name: emoji } } : {}) } : null);
  const row = (...b) => { const c = b.filter(Boolean).slice(0, 5); return c.length ? [{ type: 1, components: c }] : undefined; };
  const brandLogo = () => { const l = ctx.loadSite().brand?.logo; return l && /\.(png|jpe?g|webp|gif)$/i.test(l) && siteUrl ? `${siteUrl}/assets/brand/${l.split('/').pop()}` : ''; };
  const avatar = () => SET.channels.private.avatar || SET.channels.public.avatar || brandLogo() || undefined;
  const flag = cc => (/^[A-Z]{2}$/.test(cc || '') ? String.fromCodePoint(...[...cc].map(c => 0x1f1a5 + c.charCodeAt(0))) + ' ' + cc : '');
  const threshold = () => +(ctx.loadSite().community?.threshold ?? 10);
  const firstName = n => String(n || '').trim().split(/\s+/)[0] || 'there';

  // ---------- purchase ledger + perk rules ----------
  // Every successful Stripe charge is recorded with what was bought, so codes only come from payments that really qualify:
  // live mode, the site currency, a perk product (if any are chosen), not disputed, and net of refunds.
  const siteCur = () => String(ctx.loadSite().community?.currency || 'AUD').toLowerCase();
  const major = (minor, cur) => (ZERO.has(String(cur).toLowerCase()) ? minor : minor / 100);
  function ledgerPut(c, d) {
    if (!(c.status === 'succeeded' && c.paid)) return null;
    const e = ST.ledger[c.id] ||= {};
    Object.assign(e, { email: String(d?.email || e.email || c.billing_details?.email || c.receipt_email || '').toLowerCase(), name: d?.name || e.name || c.billing_details?.name || '',
      amount: c.amount, refunded: c.amount_refunded || 0, currency: String(c.currency).toLowerCase(), created: c.created, livemode: !!c.livemode,
      disputed: !!c.disputed || !!e.disputed, risk: c.outcome?.risk_level || e.risk || '' });
    if (d) Object.assign(e, { product: d.product, products: d.productIds || [], link: d.link || '', donation: !!d.isDonation, dash: d.dash, country: d.country });
    return e;
  }
  function whyNot(e) {
    if (!e) return 'Not a successful payment';
    if (!e.livemode && !SET.perks.allowTest) return 'Test-mode payment';
    if (e.currency !== siteCur()) return `Paid in ${e.currency.toUpperCase()} (perks count ${siteCur().toUpperCase()} only)`;
    if (e.disputed) return 'Payment is disputed';
    if (e.amount - e.refunded <= 0) return 'Fully refunded';
    const P = SET.perks.products;
    if (P.length && !(e.products || []).some(p => P.includes(p)) && !P.includes(e.link)) return `“${clip(e.product || 'This item', 60)}” isn’t a perk product`;
    return null;
  }
  const qualTotal = email => {
    const k = String(email || '').toLowerCase(); if (!k) return 0;
    return Object.values(ST.ledger).filter(e => e.email === k && !whyNot(e)).reduce((n, e) => n + major(Math.max(0, e.amount - e.refunded), e.currency), 0);
  };
  const manualPerk = s => s.type === 'lifetime' || s.type === 'manual' || (s.source === 'manual' && (s.total || 0) >= threshold());
  const eligible = s => !!s && (manualPerk(s) || qualTotal(s.email) >= threshold());
  function decide(d, e, sup) {
    if (!d.email) return { act: 'none', why: 'No email on the payment, so no supporter record' };
    const w = whyNot(e);
    if (w) return { act: 'none', why: `${w}, so it doesn’t count toward perks` };
    if (!sup) return { act: 'none', why: 'No supporter record yet (the Stripe sync failed). Sync in Community → Supporters.' };
    if (sup.code && !sup.revoked && sup.codeFor !== 'perks') return { act: 'already' };
    if (!eligible(sup)) return { act: 'none', why: `Needs ${aud(Math.max(0, threshold() - qualTotal(d.email)))} more in qualifying payments to unlock submissions` };
    if (SET.perks.holdRisky && /elevated|highest/.test(e.risk)) return { act: 'hold', why: `Stripe rated this payment “${e.risk}” risk` };
    if (!SET.auto.issueCodes) return { act: 'manual', why: 'Eligible. Automatic codes are off, so issue one in Community → Supporters.' };
    return { act: 'issue' };
  }
  const codeMailOpts = s => ({ status: SET.email.waitForLive ? 'waiting' : 'ready', codeHash: s.codeHash });
  function grantCode(sup, chargeId) { const s2 = sup.code && !sup.revoked && sup.codeFor === 'perks' ? ctx.upgradeCode(sup.id) : ctx.issueCode(sup.id); /* a perks-only code now unlocks submissions too */ ST.codeFor[sup.id] = chargeId || 'manual'; saveState(); return s2; }
  // After a refund or dispute: take the code back if their qualifying total fell below the threshold.
  async function recheckPerks(email, reason) {
    const sup = email ? ctx.loadSupporters().find(s => (s.email || '').toLowerCase() === email.toLowerCase()) : null;
    if (!sup?.code || sup.revoked || sup.codeFor === 'perks' || manualPerk(sup) || qualTotal(email) >= threshold()) return false;
    if (!(reason === 'dispute' ? SET.perks.revokeOnDispute : SET.perks.revokeOnRefund)) return 'kept';
    ctx.revokeCode(sup.id);
    for (const m of OUT) if (m.supporterId === sup.id && m.kind === 'code' && ['ready', 'waiting'].includes(m.status)) { m.status = 'cancelled'; m.error = `Cancelled: code revoked after a ${reason}`; }
    saveOut();
    await fire('supporter.revoked', () => ({ content: `🚫 Automatically revoked **${sup.name || sup.email}**’s supporter code after a ${reason}. Their qualifying total is now ${aud(qualTotal(email))} (needs ${aud(threshold())}).`, __title: `Auto-revoked: ${sup.name || sup.email}` }));
    return true;
  }

  // ---------- webhooks ----------
  const WH = /^https:\/\/(?:(?:canary|ptb)\.)?discord(?:app)?\.com\/api\/(?:v\d+\/)?webhooks\/(\d+)\/([\w-]+)\/?$/;
  const hookKey = ch => (ch === 'public' ? 'discordPublic' : 'discordPrivate');
  const hookUrl = ch => (ctx.secrets()[hookKey(ch)] || '').replace(/\/$/, '');
  const maskHook = u => { const m = String(u || '').match(WH); return m ? `…/webhooks/${m[1]}/${m[2].slice(0, 4)}…${m[2].slice(-4)}` : ''; };
  async function checkHook(url) {
    const res = await ctx.fetchT(url, {}, 12000);
    const j = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(res.status === 404 || res.status === 401 ? 'Discord says this webhook doesn’t exist (deleted or copied wrong).' : `Discord returned ${res.status}${j.message ? `: ${j.message}` : ''}`);
    return { name: j.name, channelId: j.channel_id, guildId: j.guild_id, avatarUrl: j.avatar ? `https://cdn.discordapp.com/avatars/${j.id}/${j.avatar}.png?size=128` : '', checkedAt: new Date().toISOString() };
  }
  async function setHook(channel, url) {
    url = String(url || '').trim().replace(/\/$/, '').replace(/\?.*$/, '');
    if (url && !WH.test(url)) throw new Error('That isn’t a Discord webhook link. In Discord: channel settings → Integrations → Webhooks → Copy Webhook URL.');
    const info = url ? await checkHook(url) : null;
    ctx.saveSecrets({ [hookKey(channel)]: url });
    if (info) ST.hooks[channel] = info; else delete ST.hooks[channel];
    saveState();
    return info;
  }
  function pingOf(p) {
    const t = p?.type, id = String(p?.id || '').replace(/\D/g, '');
    if (t === 'here') return { text: '@here', allowed: { parse: ['everyone'] } };
    if (t === 'everyone') return { text: '@everyone', allowed: { parse: ['everyone'] } };
    if (t === 'role' && id) return { text: `<@&${id}>`, allowed: { parse: [], roles: [id] } };
    if (t === 'user' && id) return { text: `<@${id}>`, allowed: { parse: [], users: [id] } };
    return null;
  }
  function fitEmbed(e) {
    if (!e) return e;
    const o = { ...e };
    if (o.title) o.title = clip(o.title, 256);
    if (o.description) o.description = clip(o.description, 4000);
    if (o.fields) o.fields = o.fields.filter(f => f && f.name && f.value).slice(0, 25).map(f => ({ ...f, name: clip(f.name, 256), value: clip(f.value, 1024) }));
    if (o.footer?.text) o.footer = { ...o.footer, text: clip(o.footer.text, 2048) };
    for (const k of ['image', 'thumbnail']) if (o[k] && !/^(https?|attachment):/.test(o[k].url || '')) delete o[k];
    if (o.url && !isUrl(o.url)) delete o.url;
    return o;
  }
  let chain = Promise.resolve();
  const enqueue = fn => { const p = chain.then(fn, fn); chain = p.catch(() => {}); return p; };
  const discordError = (j, status) => { const d = j?.errors ? ' ' + clip(JSON.stringify(j.errors), 300) : ''; return `Discord ${status}: ${j?.message || 'request failed'}${d}`; };
  async function rawSend(url, body, files) {
    for (let attempt = 0; attempt < 6; attempt++) {
      let init;
      if (files?.length) {
        const fd = new FormData();
        fd.append('payload_json', JSON.stringify({ ...body, attachments: files.map((f, i) => ({ id: i, filename: f.name })) }));
        files.forEach((f, i) => fd.append(`files[${i}]`, new Blob([f.data], { type: f.type }), f.name));
        init = { method: 'POST', body: fd };
      } else init = { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
      let res;
      try { res = await ctx.fetchT(url + '?wait=true' + (body.components ? '&with_components=true' : ''), init, 25000); }
      catch (e) { if (attempt < 3) { await sleep(2000 * (attempt + 1)); continue; } throw new Error('Couldn’t reach Discord (offline?)'); }
      if (res.status === 429) { const j = await res.json().catch(() => ({})); await sleep(Math.min(60, +j.retry_after || 2) * 1000 + 300); continue; }
      if (res.status >= 500) { await sleep(2000 * (attempt + 1)); continue; }
      const j = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (body.components && res.status === 400) { const { components, ...rest } = body; body = rest; continue; } // drop buttons, keep the message
        if (files?.length && res.status === 400) { files = null; continue; }
        throw new Error(discordError(j, res.status));
      }
      return j;
    }
    throw new Error('Discord kept rate-limiting; gave up.');
  }
  function addLog(entry) { LOG.unshift(entry); saveLog(); ctx.onActivity?.(); return entry; }

  // payload: Discord message body (plus optional __title/__files); meta: { event, ping, force, test }
  async function send(channel, payload, meta = {}) {
    const ch = SET.channels[channel];
    const { __title, __files, ...p } = payload;
    const entry = { id: rid(), at: new Date().toISOString(), channel, event: meta.event || 'custom', title: clip(__title || p.embeds?.[0]?.title || p.content || 'Message', 140), status: 'pending', test: !!meta.test };
    const url = hookUrl(channel);
    if (!url) return addLog({ ...entry, status: 'skipped', error: `No ${channel} webhook set`, payload: p });
    if (!ch.enabled && !meta.force) return addLog({ ...entry, status: 'skipped', error: `The ${channel} channel is turned off`, payload: p });
    const body = { ...p };
    if (!body.username) body.username = ch.username || (channel === 'public' ? B() : 'Pylerium Manager');
    if (!body.avatar_url && (ch.avatar || brandLogo())) body.avatar_url = ch.avatar || brandLogo();
    const pg = meta.ping ? pingOf(ch.ping) : null;
    body.content = clip([pg?.text, body.content].filter(Boolean).join(' '), 2000) || undefined;
    body.allowed_mentions = pg ? pg.allowed : { parse: [] };
    body.embeds = (body.embeds || []).filter(Boolean).slice(0, 10).map(fitEmbed);
    if (!body.embeds.length) delete body.embeds;
    if (!SET.auto.buttons || !body.components) delete body.components;
    if (!body.content && !body.embeds && !__files?.length) return addLog({ ...entry, status: 'skipped', error: 'Nothing to send' });
    return enqueue(async () => {
      try { const r = await rawSend(url, body, __files); entry.status = 'sent'; entry.messageId = r.id; entry.channelId = r.channel_id; entry.guildId = ST.hooks[channel]?.guildId; }
      catch (e) { entry.status = 'failed'; entry.error = e.message; }
      entry.payload = body;
      return addLog(entry);
    });
  }
  // Fire an event to whichever channels it is switched on for. build(channel) returns a payload or null.
  async function fire(event, build) {
    const e = SET.events[event], def = EV[event];
    if (!e || !def) return [];
    const out = [];
    for (const channel of ['private', 'public']) {
      if (!e[channel] || (channel === 'public' && !def.pubOk)) continue;
      try { const p = await build(channel); if (p) out.push(await send(channel, p, { event, ping: e.ping })); }
      catch (err) { addLog({ id: rid(), at: new Date().toISOString(), channel, event, title: def.label, status: 'failed', error: err.message }); }
    }
    return out;
  }
  const footer = extra => ({ text: ['Pylerium Manager', extra].filter(Boolean).join(' · '), icon_url: avatar() });

  // ---------- release payloads (also used by the composer and tests) ----------
  function appPayload(kind, a, extra = {}) {
    const site = ctx.loadSite();
    const cat = (site.categories || []).find(c => c.id === a.category);
    const acc = ACCENTS[a.accent] || ACCENTS.studio;
    const log0 = a.changelog?.[0];
    const vars = { name: a.name, tagline: a.tagline || '', version: a.version || log0?.ver || '', url: appUrl(a), author: a.author?.name || 'the community', note: log0?.note || '', category: cat?.label || '' };
    const content = tpl(SET.templates[kind] || DEFAULT_TEMPLATES[kind] || '**{name}**', vars);
    const body = kind === 'app.updated' && log0?.note
      ? `${a.tagline ? `*${a.tagline}*\n\n` : ''}**What’s new${log0.ver ? ` in ${log0.ver}` : ''}**\n${log0.note}`
      : [a.tagline && `**${a.tagline}**`, clip(a.description, 420)].filter(Boolean).join('\n\n');
    const fields = [['Category', cat?.label], ['Platform', a.platform], ['Price', a.price], ['Version', a.version],
      ['Made by', a.community && a.author?.name ? (isUrl(a.author.url) ? `[${a.author.name}](${a.author.url})` : a.author.name) : '']]
      .filter(f => f[1]).map(([name, value]) => ({ name, value: String(value), inline: true }));
    const embed = { author: { name: kind === 'app.community' ? `${B()} · Community` : B(), url: siteUrl, icon_url: avatar() },
      title: a.name + (kind === 'app.updated' && a.version ? ` ${a.version}` : ''), url: appUrl(a), description: body, color: hex(acc.a1), fields,
      thumbnail: abs(a.iconImage) ? { url: abs(a.iconImage) } : undefined, image: abs(a.cover) ? { url: abs(a.cover) } : undefined,
      footer: { text: siteUrl.replace(/^https?:\/\//, '') }, timestamp: new Date().toISOString() };
    return {
      content: SET.auto.richCards ? content : `${content}\n${appUrl(a)}`,
      embeds: SET.auto.richCards ? [embed] : undefined,
      components: row(btn(a.primaryLabel || 'Get it', a.primaryUrl || a.pageUrl, '⬇️'), btn(`View on ${B()}`, appUrl(a)), btn('Watch', a.videoUrl, '▶️'), btn('Source', a.repoUrl)),
      __title: `${EV[kind]?.label || 'App'}: ${a.name}`, ...extra
    };
  }
  function videoPayload(v) {
    const url = v.short ? `https://youtube.com/shorts/${v.id}` : `https://www.youtube.com/watch?v=${v.id}`;
    const ch = ctx.loadSite().youtube?.channelUrl;
    return {
      content: `${tpl(SET.templates[v.short ? 'yt.short' : 'yt.video'], { title: v.title, url })}\n${url}`,
      components: row(btn(v.short ? 'Watch the Short' : 'Watch on YouTube', url, '▶️'), btn('Subscribe', ch ? `${ch}?sub_confirmation=1` : '', '🔔'), btn(`More on ${B()}`, `${siteUrl}/#videos`)),
      __title: `${v.short ? 'Short' : 'Video'}: ${v.title}`
    };
  }

  // ---------- email outbox ----------
  function gmailUrl(m) {
    const q = new URLSearchParams({ view: 'cm', fs: '1', tf: '1', to: m.to, su: m.subject, body: m.body });
    if (SET.email.from) q.set('authuser', SET.email.from);
    return `https://mail.google.com/mail/?${q}`;
  }
  function renderMail(kind, s, d = {}) {
    const t = SET.email.templates?.[kind] || EMAIL_TEMPLATES[kind];
    const v = { name: firstName(s.name || d.name), fullName: s.name || d.name || '', code: s.code || '', amount: d.amount != null ? money(d.amount, d.currency) : aud(s.total), total: aud(s.total),
      product: d.product || 'your support', app: d.app || d.product || 'your purchase', downloadUrl: d.downloadUrl || '', threshold: aud(threshold()), siteUrl, submitUrl: `${siteUrl}/#submit`, email: s.email || d.email || '',
      perk: (d.perks || [])[0]?.name || 'a perk', perks: (d.perks || []).map(p => `  • ${p.name}${p.tagline ? ` (${p.tagline})` : ''}`).join('\n'), perkCount: (d.perks || []).length > 1 ? `${d.perks.length} perks` : 'a perk', perksUrl: `${siteUrl}/#perks`,
      licenceKey: d.licenceKey || '',
      licence: d.licenceKey ? `\n\nYour licence key:\n\n    ${d.licenceKey}\n\nWhen ${d.app || 'the app'} asks to activate, paste the whole key (it's one long line). The same key works again if you reinstall.` : '' };
    let body = tpl(t.body, v);
    // A customised download template without {licence} still gets the key.
    if (d.licenceKey && !body.includes(d.licenceKey)) body += v.licence;
    return { subject: tpl(t.subject, v), body };
  }
  const PENDING = ['ready', 'waiting'];
  function addMail(kind, s, d = {}, test = false, o = {}) {
    const to = s.email || d.email;
    if (!to) return null;
    const { subject, body } = renderMail(kind, s, d);
    const m = { id: 'em-' + rid(), kind, to, name: s.name || d.name || '', subject, body, supporterId: s.id || '', ref: d.id || '', createdAt: new Date().toISOString(), status: o.status || 'ready', codeHash: o.codeHash || undefined };
    m.gmail = gmailUrl(m);
    if (test) return m;
    const dup = OUT.find(x => PENDING.includes(x.status) && x.to === to && x.kind === kind && (kind !== 'code' || x.body.includes(s.code)) && (kind !== 'download' || x.ref === (d.id || '')) && (kind !== 'licence' || x.ref === (d.id || '')) && (kind !== 'perk' || x.ref === (d.id || '')));
    if (dup) return dup;
    OUT.unshift(m); saveOut(); ctx.onActivity?.();
    if (m.status === 'ready') setTimeout(() => processOutbox().catch(() => {}), 1500);
    return m;
  }
  const smtpReady = () => { const x = ctx.secrets(); return !!(x.smtpUser && x.smtpPass) && !ST.smtp.authFail; };
  const autoFor = m => SET.email.auto && smtpReady() && (m.kind === 'code' || m.kind === 'perk' ? SET.email.sendCodes : m.kind === 'download' || m.kind === 'licence' ? true : SET.email.sendThanks);
  const KIND = { perk: ['Perk email', 'perk', 'Perk'], code: ['Supporter code email', 'supporter code', 'Code'], download: ['Download link email', 'download link', 'Download'], licence: ['Licence key email', 'licence key', 'Licence'], thanks: ['Thank-you email', 'thank-you', 'Thank-you'] };
  // A licence issued by hand in the hub (Licences view): queued like any other email, sent automatically.
  const sendLicence = rec => addMail('licence', { name: rec.name, email: rec.email }, { id: rec.id, app: rec.appName || rec.app, licenceKey: rec.key });
  const kindOf = m => KIND[m.kind] || KIND.thanks;
  function mailEmbed(m) {
    if (!m) return null;
    const auto = autoFor(m);
    const how = m.status === 'waiting' ? (auto ? '⏳ **Sends automatically** the moment the code is live on the site.\n' : '⏳ Wait until the code is live on the site, then send.\n') : auto ? '⚡ **Sending automatically** through Gmail now.\n' : '';
    const head = `${how}**To:** ${m.to}\n**Subject:** ${m.subject}\n\n${auto ? '' : `[✉️ Open in Gmail, ready to send](${m.gmail}) · `}[Hub outbox](${hubUrl}/#/alerts/emails)\n`;
    const block = '```\n' + m.body.replace(/```/g, "'''") + '\n```';
    const desc = head.length + block.length < 4000 ? head + block : `**To:** ${m.to}\n**Subject:** ${m.subject}\n[Hub outbox](${hubUrl}/#/alerts/emails)\n${clip(block, 3600)}`;
    const what = kindOf(m)[0];
    return { title: `📧 ${what}${auto ? ', sending automatically' : ', ready to send'}`, description: desc, color: C.info };
  }

  // ---------- Stripe sales ----------
  const dashUrl = c => `https://dashboard.stripe.com/${c.livemode ? '' : 'test/'}payments/${c.payment_intent || c.id}`;
  async function saleDetails(c, key) {
    let session = null;
    if (c.payment_intent) {
      try { session = (await ctx.stripeGet(`checkout/sessions?payment_intent=${c.payment_intent}&expand[]=data.line_items`, key)).data?.[0] || null; }
      catch { try { session = (await ctx.stripeGet(`checkout/sessions?payment_intent=${c.payment_intent}`, key)).data?.[0] || null; } catch {} }
    }
    const items = (session?.line_items?.data || []).map(i => `${i.quantity > 1 ? i.quantity + '× ' : ''}${i.description || 'Item'}`);
    const product = items.join(', ') || c.description || c.calculated_statement_descriptor || 'Payment';
    const wall = (session?.custom_fields || []).find(f => /name|wall|credit/i.test(f.key + ' ' + (f.label?.custom || '')))?.text?.value || '';
    const card = c.payment_method_details?.card;
    const pm = card ? `${card.brand ? card.brand[0].toUpperCase() + card.brand.slice(1) : 'Card'} •••• ${card.last4}${card.wallet?.type ? ` (${card.wallet.type.replace(/_/g, ' ')})` : ''}` : (c.payment_method_details?.type || '').replace(/_/g, ' ');
    return {
      id: c.id, amount: c.amount, currency: c.currency, email: c.billing_details?.email || c.receipt_email || session?.customer_details?.email || '',
      name: c.billing_details?.name || session?.customer_details?.name || '', product, wall, pm,
      productIds: (session?.line_items?.data || []).map(i => (typeof i.price?.product === 'string' ? i.price.product : i.price?.product?.id)).filter(Boolean), link: session?.payment_link || '', sessionId: session?.id || '',
      country: c.billing_details?.address?.country || card?.country || session?.customer_details?.address?.country || '',
      isDonation: /caff|coffee|donat|tip\b|support/i.test(product) || (!!session?.payment_link && !items.length),
      receipt: c.receipt_url || '', dash: dashUrl(c), created: c.created, livemode: c.livemode, refunded: c.amount_refunded || 0, failure: c.failure_message || c.outcome?.seller_message || ''
    };
  }
  function salePayload(d, sup, x = {}) {
    const amt = money(d.amount, d.currency), who = d.name || d.wall || d.email || 'Someone';
    const dec = x.dec || {};
    const perks = x.newly ? `🔓 **Unlocked submissions**\nCode: \`${x.code}\`\n${x.codeNote || ''}`
      : dec.act === 'already' ? `✅ Already a supporter · \`${sup?.code}\``
      : dec.act === 'hold' ? `🛡️ **Code held for review.** ${dec.why}. Approve or dismiss it on the [Live dashboard](${hubUrl}/#/live).`
      : dec.why || (sup ? `Needs ${aud(Math.max(0, threshold() - qualTotal(sup.email)))} more to unlock submissions` : 'No email on the payment, so no supporter record');
    const embed = {
      title: d.isDonation ? `🥤 ${amt} of caffeine` : `🛒 New sale · ${amt}`, url: d.dash, color: d.isDonation ? C.sale : C.good,
      fields: [
        { name: 'Customer', value: [d.name, d.email].filter(Boolean).join('\n') || 'Unknown', inline: true },
        { name: 'Amount', value: `${amt} ${String(d.currency).toUpperCase()}`, inline: true },
        { name: d.isDonation ? 'For' : 'Item', value: d.product, inline: true },
        d.pm || d.country ? { name: 'Paid with', value: [d.pm, flag(d.country)].filter(Boolean).join(' · '), inline: true } : null,
        d.wall ? { name: 'Name for the wall', value: d.wall, inline: true } : null,
        sup ? { name: 'Lifetime support', value: `${aud(sup.total)} · ${sup.payments || 1} payment${(sup.payments || 1) > 1 ? 's' : ''}`, inline: true } : null,
        d.downloadUrl ? { name: 'Paid download', value: `🔐 ${d.app} · [download page](${d.downloadUrl})${d.licenceId ? `\n🔑 Licence \`${d.licenceId}\` in the email` : d.licenceError ? `\n❌ Licence failed: ${d.licenceError}` : ''}` } : null,
        { name: 'Supporter perks', value: perks }
      ],
      footer: footer(d.livemode === false ? 'Stripe TEST MODE' : 'Stripe'), timestamp: new Date(d.created * 1000).toISOString()
    };
    return {
      content: d.isDonation ? `🥤 **${who}** just supplied **${amt}** of caffeine!` : `🛒 **${who}** bought **${clip(d.product, 80)}** for **${amt}**`,
      embeds: [embed, mailEmbed(x.mail), mailEmbed(x.dlMail)].filter(Boolean), components: row(btn('Open in Stripe', d.dash, '💳'), btn('Receipt', d.receipt, '🧾')),
      __title: `${d.isDonation ? 'Caffeine' : 'Sale'} ${amt} from ${who}`
    };
  }
  async function handleSale(d, c) {
    const e = ledgerPut(c, d); saveState();
    const dl = d.link && d.sessionId && ctx.downloadFor ? await ctx.downloadFor(d.link).catch(() => null) : null;
    if (dl) Object.assign(d, { app: dl.name, downloadUrl: ctx.downloadUrl(d.sessionId), isDonation: false });
    if (dl?.app && d.email && ctx.licenceFor) {
      try { const lic = ctx.licenceFor(dl.app, d.email, d.name, c.id); if (lic) Object.assign(d, { licenceKey: lic.key, licenceId: lic.id }); }
      catch (err) { d.licenceError = err.message; }
    }
    const sup = d.email ? ctx.loadSupporters().find(s => (s.email || '').toLowerCase() === d.email.toLowerCase()) : null;
    const dec = decide(d, e, sup);
    let code = '', newly = false, mail = null;
    if (dec.act === 'issue') {
      const s2 = grantCode(sup, c.id); code = s2.code; newly = true;
      mail = addMail('code', s2, d, false, codeMailOpts(s2));
    } else if (dec.act === 'hold') {
      ST.held = ST.held.filter(h => h.chargeId !== c.id);
      ST.held.unshift({ id: 'hd-' + rid(), chargeId: c.id, supporterId: sup.id, name: d.name, email: d.email, amount: d.amount, currency: d.currency, product: d.product, risk: e.risk, why: dec.why, dash: d.dash, at: new Date().toISOString(), d });
      saveState();
    } else if (!dl && sup && SET.auto.thanksEmail && (e?.livemode || SET.perks.allowTest)) mail = addMail('thanks', sup, d);
    const dlMail = dl && d.email ? addMail('download', sup || { name: d.name, email: d.email }, d) : null;
    ST.sales.unshift({ at: new Date(d.created * 1000).toISOString(), amount: d.amount, currency: d.currency, donation: d.isDonation, email: d.email, code: !!code });
    ST.sales = ST.sales.slice(0, 1000); saveState();
    const pg = ctx.perksSync ? await ctx.perksSync(d.email).catch(() => null) : null;
    for (const x of pg?.granted || []) perkGranted(x.supporter, [x.perk], 'auto', d);
    if (pg?.granted?.length) newly = newly || pg.granted.some(x => x.newCode) || true;
    const codeNote = newly ? (SET.auto.publishCodes ? 'Goes live with an automatic publish in a moment.' : '⚠️ Publish the site so the code works.') : '';
    await fire('sale.new', () => salePayload(d, sup, { code, newly, mail, dlMail, codeNote, dec }));
    if (newly) await fire('sale.eligible', () => ({ content: `🔓 **${sup.name || sup.email}** unlocked app submissions (${aud(qualTotal(sup.email))} qualifying).`, embeds: [mailEmbed(mail)], __title: `Unlocked: ${sup.name || sup.email}` }));
    if (dec.act === 'hold') await fire('sale.held', () => ({ embeds: [{ title: `🛡️ Supporter code held · ${money(d.amount, d.currency)}`, url: d.dash, color: C.warn,
      description: `${d.name || d.email} qualifies for a code, but ${dec.why.charAt(0).toLowerCase() + dec.why.slice(1)}. Nothing was sent.\n\nCheck the payment in Stripe, then **Approve** or **Dismiss** it on the [Live dashboard](${hubUrl}/#/live).`, footer: footer('Stripe Radar') }],
      components: row(btn('Review in Stripe', d.dash, '🔎')), __title: `Held: ${d.name || d.email}` }));
    return { code: code || (pg?.granted?.length ? 'perk' : '') };
  }
  // A perk was granted (by a sale, a lucky drop or by hand): queue the email (sent once it's live) and tell Discord.
  function perkGranted(sup, perks, via, d = {}) {
    if (!sup || !perks.length) return null;
    const marks = perks.map(p => ctx.perkMark(sup.codeHash, p.id));
    const mail = sup.email ? addMail('perk', sup, { perks, id: marks.join(',') }, false, { status: SET.email.waitForLive ? 'waiting' : 'ready', codeHash: marks[marks.length - 1] }) : null;
    const how = { auto: d.product ? `bought **${clip(d.product, 60)}**` : 'reached the unlock rule', manual: 'given by you', drop: 'won a lucky drop' }[via] || via;
    fire('perk.granted', () => ({ embeds: [{ title: `🎁 ${sup.name || sup.email || 'A supporter'} unlocked ${perks.map(p => p.name).join(', ')}`, color: C.violet,
      description: `${how.charAt(0).toUpperCase() + how.slice(1)}.\nCode: \`${sup.code}\`${sup.email ? '' : '\n⚠️ No email on file, so send them the code yourself.'}`, footer: footer('Perks') }, mailEmbed(mail)].filter(Boolean), __title: `Perk: ${perks.map(p => p.name).join(', ')}` })).catch(() => {});
    return mail;
  }
  // Valid purchases for perk rules: any currency, live (or test if allowed), not disputed, not fully refunded.
  const purchases = email => { const k = String(email || '').toLowerCase(); return k ? Object.values(ST.ledger).filter(e => e.email === k && (e.livemode || SET.perks.allowTest) && !e.disputed && e.amount - e.refunded > 0) : []; };
  let stripeBusy = false;
  async function pollStripe() {
    const key = ctx.secrets().stripeKey;
    if (!key) return { skipped: 'Add a Stripe key in Community → Caffeine & perks.' };
    if (stripeBusy) return { busy: true };
    stripeBusy = true;
    try {
      const charges = (await ctx.stripeGet('charges?limit=100', key)).data || [];
      if (!ST.ledgerBuilt) { // one-time backfill so earlier payments count toward perks
        for (const c of charges) if (c.status === 'succeeded' && c.paid && !ST.ledger[c.id]?.product) ledgerPut(c, await saleDetails(c, key).catch(() => null));
        ST.ledgerBuilt = true; saveState();
      }
      const S0 = ST.stripe;
      if (!S0?.seeded) {
        ST.stripe = { seeded: true, seen: charges.map(c => c.id), refunded: Object.fromEntries(charges.map(c => [c.id, c.amount_refunded || 0])), disputed: charges.filter(c => c.disputed).map(c => c.id) };
        const total = ctx.loadSupporters().reduce((n, s) => n + (s.total || 0), 0);
        ST.milestonesHit = SET.milestones.filter(m => total >= m);
        saveState();
        return { seeded: charges.length, note: `Watching Stripe. ${charges.length} existing payment${charges.length === 1 ? '' : 's'} marked as already seen.` };
      }
      const seen = new Set(S0.seen), sales = [], failed = [], refunds = [], disputes = [];
      for (const c of [...charges].reverse()) {
        if (!seen.has(c.id)) {
          if (c.status === 'pending') continue; // look again next time
          seen.add(c.id);
          if (c.status === 'succeeded' && c.paid) sales.push(c); else if (c.status === 'failed') failed.push(c);
        }
        const prev = S0.refunded[c.id] ?? (sales.includes(c) ? 0 : c.amount_refunded || 0);
        if ((c.amount_refunded || 0) > prev) refunds.push({ c, delta: c.amount_refunded - prev });
        S0.refunded[c.id] = c.amount_refunded || 0;
        if (c.disputed && !S0.disputed.includes(c.id)) { S0.disputed.push(c.id); disputes.push(c); }
        if (ST.ledger[c.id]) ledgerPut(c);
      }
      const keep = new Set(charges.map(c => c.id));
      S0.seen = [...seen].slice(-1500);
      for (const id of Object.keys(S0.refunded)) if (!keep.has(id)) delete S0.refunded[id];
      S0.disputed = S0.disputed.slice(-300);
      saveState(); // before alerting, so a crash never double-alerts
      if (sales.length || refunds.length) { try { await ctx.stripeSync(); } catch {} }
      let codes = 0;
      let revoked = 0;
      for (const c of sales) { const r = await handleSale(await saleDetails(c, key), c); if (r.code) codes++; }
      for (const c of failed) {
        const d = await saleDetails(c, key);
        await fire('sale.failed', () => ({ embeds: [{ title: `❌ Payment failed · ${money(d.amount, d.currency)}`, url: d.dash, color: C.bad, description: `${d.name || d.email || 'Someone'} tried to pay for **${d.product}**.${d.failure ? `\n> ${d.failure}` : ''}`, footer: footer('Stripe') }], __title: `Failed payment ${money(d.amount, d.currency)}` }));
      }
      const perkNote = r => (r === true ? '\n🚫 Their supporter code was **revoked automatically** (qualifying total fell below the threshold). It stops working after the auto-publish.' : r === 'kept' ? '\n⚠️ They no longer qualify, but automatic revoking is off. Revoke the code in the hub if you want.' : '');
      const dropHeld = id => { ST.held = ST.held.filter(h => h.chargeId !== id); };
      for (const { c, delta } of refunds) {
        const d = await saleDetails(c, key);
        ledgerPut(c, d); if (c.refunded) dropHeld(c.id);
        const r = await recheckPerks(d.email, 'refund'); if (r === true) revoked++;
        if (ctx.perksSync) { const pr = await ctx.perksSync(d.email).catch(() => null); if (pr?.revoked?.length) revoked++; }
        await fire('sale.refund', () => ({ embeds: [{ title: `↩️ Refund · ${money(delta, d.currency)}`, url: d.dash, color: C.warn, description: `${c.refunded ? 'Fully refunded' : 'Partly refunded'}: **${d.product}** (${money(d.amount, d.currency)}) for ${d.name || d.email}.${perkNote(r)}`, footer: footer('Stripe') }], __title: `Refund ${money(delta, d.currency)}` }));
      }
      for (const c of disputes) {
        const d = await saleDetails(c, key);
        if (ST.ledger[c.id]) ST.ledger[c.id].disputed = true;
        dropHeld(c.id); saveState();
        const r = await recheckPerks(d.email, 'dispute'); if (r === true) revoked++;
        if (ctx.perksSync) { const pr = await ctx.perksSync(d.email).catch(() => null); if (pr?.revoked?.length) revoked++; }
        await fire('sale.dispute', () => ({ embeds: [{ title: `⚠️ Dispute opened · ${money(d.amount, d.currency)}`, url: d.dash, color: C.bad, description: `${d.name || d.email} disputed **${d.product}**. Respond in Stripe before the deadline to keep the money.${perkNote(r)}`, footer: footer('Stripe') }], components: row(btn('Respond in Stripe', d.dash, '⚖️')), __title: `Dispute ${money(d.amount, d.currency)}` }));
      }
      saveState();
      if (sales.length) await checkMilestones();
      if ((codes || revoked) && SET.auto.publishCodes) safeAutoPublish(codes ? 'new supporter code' : 'revoked supporter code', ['Supporter codes', 'Supporters wall', 'YouTube videos', 'Perks'], true).catch(() => {});
      else if (codes) await fire('publish.needed', () => ({ content: `⏳ ${codes} new supporter code${codes > 1 ? 's' : ''} won’t work on the site until you publish.`, components: row(), __title: 'Codes waiting for a publish' }));
      return { sales: sales.length, refunds: refunds.length, disputes: disputes.length, failed: failed.length, codes, revoked };
    } finally { stripeBusy = false; }
  }
  async function checkMilestones() {
    const list = ctx.loadSupporters();
    const total = list.reduce((n, s) => n + (s.total || 0), 0);
    ST.milestonesHit ||= [];
    const fresh = SET.milestones.filter(m => total >= m && !ST.milestonesHit.includes(m));
    if (!fresh.length) return;
    ST.milestonesHit.push(...fresh); saveState();
    const m = Math.max(...fresh), amount = aud(m);
    await fire('sale.milestone', ch => ch === 'public'
      ? { content: tpl(SET.templates['sale.milestone'], { amount, count: list.length }), components: row(btn('Supply caffeine', ctx.loadSite().donate?.url, '🥤')), __title: `Milestone ${amount}` }
      : { embeds: [{ title: `🎉 Support passed ${amount}`, color: C.sale, description: `Total from ${list.length} supporter${list.length === 1 ? '' : 's'}: **${aud(total)}**.`, footer: footer() }], __title: `Milestone ${amount}` });
  }

  // ---------- publishing ----------
  async function safeAutoPublish(reason, allowed, codes = false) {
    const st = await ctx.siteStatus();
    if (!st.changes.length && !st.ahead && !st.workingFiles) return { nothing: true };
    const other = st.changes.filter(c => !allowed.includes(c.name));
    if (other.length) {
      if (codes) await fire('publish.needed', () => ({ embeds: [{ title: '⏳ Publish needed', color: C.warn, description: `New supporter codes are waiting, but you also have other unpublished changes, so the hub didn’t publish by itself:\n${other.slice(0, 12).map(c => `• ${c.kind} ${c.name}`).join('\n')}\n\nOpen the [hub](${hubUrl}) and press **Publish** when you’re ready.`, footer: footer() }], __title: 'Publish needed' }));
      return { blocked: other.length };
    }
    try { return await ctx.publish(`Auto-publish: ${reason}`); } catch (e) { return { error: e.message }; }
  }
  async function waitLive(ids) {
    for (let i = 0; i < 24; i++) {
      try {
        const live = await (await ctx.fetchT(`${siteUrl}/apps.json?cb=${Date.now()}`, { headers: { 'Cache-Control': 'no-cache' } }, 10000)).json();
        const m = new Map(live.map(a => [a.id, a]));
        if (ids.every(([id, ver]) => m.has(id) && (!ver || m.get(id).version === ver))) return true;
      } catch {}
      await sleep(15000);
    }
    return false;
  }
  async function afterPublish(before, after, meta = {}) {
    const lines = (meta.changes || []).slice(0, 20).map(c => `• ${c.kind === 'added' ? '➕' : c.kind === 'removed' ? '➖' : '✏️'} ${c.name}`);
    await fire('publish.done', () => ({ embeds: [{ title: meta.auto ? '🌐 Site auto-published' : '🌐 Site published', url: siteUrl, color: C.good,
      description: `${meta.message ? `*${meta.message}*\n` : ''}${lines.join('\n') || 'Rebuilt with no catalog changes.'}`,
      fields: [meta.commit ? { name: 'Commit', value: meta.commitUrl ? `[${meta.commit}](${meta.commitUrl})` : meta.commit, inline: true } : null, { name: 'Apps on site', value: String(after.apps.length), inline: true }],
      footer: footer('Live in about a minute') }], __title: meta.auto ? 'Auto-published' : 'Published' }));
    if (!before) return;
    const B = new Map(before.apps.map(a => [a.id, a])), A = new Set(after.apps.map(a => a.id)), rel = [];
    for (const a of after.apps) {
      const b = B.get(a.id);
      if (!b) { rel.push([a.community ? 'app.community' : 'app.new', a]); continue; }
      const verUp = (a.version && a.version !== b.version) || (a.changelog?.[0] && JSON.stringify(a.changelog[0]) !== JSON.stringify(b.changelog?.[0]));
      if (a.status === 'live' && b.status !== 'live') rel.push(['app.available', a]); // a launch beats a changelog line
      else if (verUp) rel.push(['app.updated', a]);
      if (a.featured && !b.featured) rel.push(['app.featured', a]);
    }
    for (const b of before.apps) if (!A.has(b.id)) await fire('app.removed', () => ({ embeds: [{ title: `📦 ${b.name} is no longer on the site`, color: C.warn, footer: footer() }], __title: `Removed: ${b.name}` }));
    const an = after.site?.announcement, bn = before.site?.announcement;
    const annChanged = an?.enabled && an.text && (an.text !== bn?.text || !bn?.enabled);
    const newWall = (after.wall || []).filter(n => !(before.wall || []).includes(n));
    if (!rel.length && !annChanged && !newWall.length) return;
    (async () => {
      if (rel.length && SET.auto.waitLive) await waitLive(rel.map(([, a]) => [a.id, a.version]));
      for (const [kind, a] of rel) await fire(kind, () => appPayload(kind, a));
      if (annChanged) await fire('site.announcement', () => ({ content: tpl(SET.templates['site.announcement'], { text: an.text }), components: row(btn(an.linkLabel || 'Learn more', an.link ? (isUrl(an.link) ? an.link : `${siteUrl}/${an.link.replace(/^\//, '')}`) : siteUrl)), __title: 'Announcement' }));
      for (const name of newWall) await fire('supporter.wall', ch => ({ content: tpl(SET.templates['supporter.wall'], { name }), components: ch === 'public' ? row(btn('Supply caffeine', ctx.loadSite().donate?.url, '🥤')) : undefined, __title: `Wall: ${name}` }));
    })().catch(() => {});
  }
  const publishFailed = (err, auto) => fire('publish.failed', () => ({ embeds: [{ title: auto ? '🛑 Auto-publish failed' : '🛑 Publish failed', color: C.bad, description: `${err.message}\n\`\`\`\n${clip(String(err.log || '').split('\n').slice(-12).join('\n'), 1500)}\n\`\`\``, footer: footer() }], __title: 'Publish failed' }));

  // ---------- YouTube / submissions / supporters ----------
  async function newVideos(list) {
    for (const v of list.filter(v => !v.hidden)) await fire(v.short ? 'yt.short' : 'yt.video', () => videoPayload(v));
    if (list.some(v => !v.hidden) && SET.auto.publishVideos) safeAutoPublish('new YouTube upload', ['YouTube videos']).catch(() => {});
  }
  function submissionPayload(it) {
    const d = it.data || {}, files = [];
    const m = String(d.icon || '').match(/^data:image\/(png|webp|jpeg);base64,([A-Za-z0-9+/=]+)$/);
    let thumb;
    if (m) { const name = `icon.${m[1] === 'jpeg' ? 'jpg' : m[1]}`; files.push({ name, type: `image/${m[1]}`, data: Buffer.from(m[2], 'base64') }); thumb = { url: `attachment://${name}` }; }
    const cat = (ctx.loadSite().categories || []).find(c => c.id === d.category);
    return {
      content: `📥 New submission: **${d.name || 'Untitled'}**`,
      embeds: [{ title: d.name || 'Submission', url: it.url || undefined, color: C.violet, description: [d.tagline && `**${d.tagline}**`, clip(d.description, 600)].filter(Boolean).join('\n\n'),
        thumbnail: thumb, image: isUrl(d.screenshots?.[0]) ? { url: d.screenshots[0] } : undefined,
        fields: [{ name: 'Category', value: cat?.label || d.category || '—', inline: true }, d.platform ? { name: 'Platform', value: d.platform, inline: true } : null,
          { name: 'Author', value: d.author?.name ? (isUrl(d.author.url) ? `[${d.author.name}](${d.author.url})` : d.author.name) : '—', inline: true },
          { name: 'Sent via', value: it.source === 'github' ? `GitHub #${it.number}${it.user ? ` by @${it.user}` : ''}` : 'Email', inline: true },
          { name: 'Verification', value: it.verified ? `✅ Supporter: ${it.verified.name}${it.verified.total ? ` (${aud(it.verified.total)})` : ''}` : '⚠️ Not a verified supporter', inline: true }],
        footer: footer(`Review it in the hub: ${hubUrl}/#/community`) }],
      components: row(btn('Download', d.url, '⬇️'), btn('Source', d.repoUrl), btn('Video', d.videoUrl, '▶️'), btn('Open issue', it.url, '🐙')),
      __title: `Submission: ${d.name}`, __files: files
    };
  }
  async function seenSubmissions(items) {
    if (!ST.subsSeeded) { ST.seenSubs = items.map(i => i.key); ST.subsSeeded = true; saveState(); return; }
    const seen = new Set(ST.seenSubs || []);
    const fresh = items.filter(i => !seen.has(i.key));
    if (!fresh.length) return;
    for (const i of fresh) seen.add(i.key);
    ST.seenSubs = [...seen].slice(-2000); saveState();
    for (const it of fresh) if (!it.handled && it.state !== 'closed' && it.data) await fire('submission.new', () => submissionPayload(it));
  }
  const submissionDone = (accepted, it, app) => fire(accepted ? 'submission.accepted' : 'submission.declined', () => ({
    embeds: [{ title: `${accepted ? '✅ Accepted' : '🙅 Declined'}: ${it?.data?.name || 'submission'}`, color: accepted ? C.good : C.warn, url: it?.url || undefined,
      description: accepted ? `Added to your apps${app?.published ? ' and set to show on the site. It goes live with the next publish.' : ' as a draft.'}` : 'Moved to Reviewed.', footer: footer() }],
    __title: `${accepted ? 'Accepted' : 'Declined'}: ${it?.data?.name || ''}` }));
  async function codeIssued(s) {
    ST.codeFor[s.id] = 'manual'; saveState();
    const mail = addMail('code', s, {}, false, codeMailOpts(s));
    await fire('supporter.code', () => ({ content: `🔑 Supporter code for **${s.name || s.email}**: \`${s.code}\``, embeds: [mailEmbed(mail) || { description: 'No email address on file, so no email was drafted.', color: C.warn }], __title: `Code for ${s.name || s.email}` }));
    return mail;
  }
  const codeRevoked = s => fire('supporter.revoked', () => ({ content: `🚫 Revoked the supporter code for **${s.name || s.email}**. It stops working after the next publish.`, __title: `Revoked: ${s.name || s.email}` }));

  // ---------- automatic email (Gmail app password) ----------
  const dayKey = () => new Date().toLocaleDateString('en-CA');
  const capLeft = () => { if (ST.mailDay.day !== dayKey()) ST.mailDay = { day: dayKey(), n: 0 }; return SET.email.dailyCap - ST.mailDay.n; };
  function mailArgs(m) {
    const x = ctx.secrets();
    return { user: x.smtpUser, pass: x.smtpPass, from: x.smtpUser, fromName: SET.email.fromName, to: m.to, toName: m.name, replyTo: SET.email.replyTo,
      bcc: SET.email.bccSelf ? [x.smtpUser] : [], subject: m.subject, text: m.body,
      html: SET.email.html ? htmlEmail(m.body, { siteUrl, logo: avatar(), brand: SET.email.fromName || B() }) : '' };
  }
  async function deliver(m, manual = false) {
    if (m.kind === 'code' && m.supporterId) { // never email a code that was revoked or replaced
      const sup = ctx.loadSupporters().find(x => x.id === m.supporterId);
      if (sup && (sup.revoked || (m.codeHash && sup.codeHash !== m.codeHash))) { m.status = 'cancelled'; m.error = 'Cancelled: that code was revoked or replaced'; saveOut(); if (manual) throw new Error(m.error); return m; }
    }
    try {
      await smtpSend(mailArgs(m));
      Object.assign(m, { status: 'sent', sentAt: new Date().toISOString(), via: 'gmail', error: undefined, nextTry: undefined });
      ST.smtp = { ok: true, at: new Date().toISOString(), user: ctx.secrets().smtpUser };
      capLeft(); ST.mailDay.n++;
      saveOut(); saveState(); ctx.onActivity?.();
      fire('email.sent', () => ({ embeds: [{ title: `📨 Emailed the ${kindOf(m)[1]} to ${m.name || m.to}`, color: C.good,
        description: `**To:** ${m.to}\n**Subject:** ${m.subject}`, footer: footer(`Gmail · ${ctx.secrets().smtpUser}`) }], __title: `Emailed ${m.to}` })).catch(() => {});
      return m;
    } catch (e) {
      const auth = e.smtpCode === 535 || e.smtpCode === 534 || /App Password/.test(e.message);
      m.attempts = (m.attempts || 0) + 1; m.error = e.message;
      if (auth) ST.smtp = { ok: false, authFail: true, error: e.message, at: new Date().toISOString(), user: ctx.secrets().smtpUser };
      else if (!manual) m.nextTry = Date.now() + Math.min(6 * 3600e3, 60000 * 2 ** m.attempts);
      if (!auth && m.attempts >= 6) m.status = 'failed';
      saveOut(); saveState(); ctx.onActivity?.();
      const k = auth ? 'mail:auth' : 'mail:' + m.id;
      if (!ST.errors[k] || Date.now() - ST.errors[k] > 6 * 3600e3 || m.status === 'failed') {
        ST.errors[k] = Date.now(); saveState();
        fire('email.failed', () => ({ embeds: [{ title: auth ? '📪 Gmail stopped accepting the app password' : `📪 Couldn’t email ${m.name || m.to}`, color: C.bad,
          description: `${e.message}\n\n${auth ? 'Automatic emails are paused until you fix it in' : m.status === 'failed' ? 'Gave up after 6 tries. Send it by hand from' : 'The hub will retry. You can also send it from'} the [hub outbox](${hubUrl}/#/alerts/emails).`, footer: footer('Gmail') }], __title: 'Email failed' })).catch(() => {});
      }
      if (manual) throw e;
      return m;
    }
  }
  let mailing = false;
  async function processOutbox() {
    if (mailing || !SET.email.auto || !smtpReady()) return;
    mailing = true;
    try {
      const due = OUT.filter(m => m.status === 'ready' && autoFor(m) && (!m.nextTry || m.nextTry <= Date.now())).reverse();
      for (const m of due) { if (capLeft() <= 0 || !smtpReady()) break; await deliver(m); }
    } finally { mailing = false; }
  }
  // Code emails wait until the code's hash is in the live site, so customers never get a code that doesn't work yet.
  async function releaseLiveCodes(force = false) {
    const waiting = OUT.filter(m => m.status === 'waiting');
    if (!waiting.length) return 0;
    if (!force && Date.now() - (ST.last.liveCodes || 0) < 60000) return 0;
    ST.last.liveCodes = Date.now();
    let html = '';
    try { html = await (await ctx.fetchT(`${siteUrl}/?cb=${Date.now()}`, { headers: { 'Cache-Control': 'no-cache' } }, 12000)).text(); } catch { return 0; }
    let n = 0;
    for (const m of waiting) if (!m.codeHash || html.includes(m.codeHash)) { m.status = 'ready'; m.liveAt = new Date().toISOString(); n++; }
    if (n) { saveOut(); ctx.onActivity?.(); processOutbox().catch(() => {}); }
    return n;
  }
  async function approveHeld(id, approve) {
    const h = ST.held.find(x => x.id === id); if (!h) throw new Error('That review is already done.');
    ST.held = ST.held.filter(x => x.id !== id); saveState();
    if (!approve) return { dismissed: true };
    const sup = ctx.loadSupporters().find(x => x.id === h.supporterId); if (!sup) throw new Error('Supporter not found');
    if (sup.code && !sup.revoked) return { already: sup.code };
    const s2 = grantCode(sup, h.chargeId), mail = addMail('code', s2, h.d || {}, false, codeMailOpts(s2));
    await fire('supporter.code', () => ({ content: `🛡️ Approved after review. Supporter code for **${s2.name || s2.email}**: \`${s2.code}\``, embeds: [mailEmbed(mail)], __title: `Approved: ${s2.name || s2.email}` }));
    if (SET.auto.publishCodes) safeAutoPublish('approved supporter code', ['Supporter codes', 'Supporters wall', 'YouTube videos', 'Perks'], true).catch(() => {});
    return { code: s2.code };
  }

  // ---------- live dashboard snapshot ----------
  function live() {
    const now = Date.now(), sec = ctx.secrets(), cur = siteCur();
    const sod = new Date(); sod.setHours(0, 0, 0, 0);
    const L = Object.entries(ST.ledger).map(([id, e]) => ({ id, ...e }));
    const counted = L.filter(e => e.currency === cur && (e.livemode || SET.perks.allowTest));
    const net = e => major(Math.max(0, e.amount - e.refunded), e.currency);
    const since = t => counted.filter(e => e.created * 1000 >= t);
    const total = list => Math.round(list.reduce((n, e) => n + net(e), 0) * 100) / 100;
    const days = [];
    for (let i = 29; i >= 0; i--) {
      const d0 = new Date(sod); d0.setDate(d0.getDate() - i); const d1 = new Date(d0); d1.setDate(d1.getDate() + 1);
      const es = counted.filter(e => e.created * 1000 >= d0 && e.created * 1000 < d1);
      days.push({ day: d0.toLocaleDateString('en-CA'), amount: total(es), count: es.length });
    }
    const sups = ctx.loadSupporters();
    const codes = sups.filter(s => s.code && !s.revoked);
    const sales = [...L].sort((a, b) => b.created - a.created).slice(0, 10).map(e => {
      const sp = sups.find(s => (s.email || '').toLowerCase() === e.email);
      return { id: e.id, name: e.name, email: e.email, amount: e.amount, refunded: e.refunded, currency: e.currency, product: e.product, created: e.created, livemode: e.livemode,
        disputed: e.disputed, risk: e.risk, dash: e.dash, country: e.country, counts: !whyNot(e), why: whyNot(e), code: sp?.code && !sp.revoked && ST.codeFor[sp.id] === e.id ? 'issued' : sp?.code && !sp.revoked ? 'has' : '' };
    });
    const outBy = st => OUT.filter(m => m.status === st).length;
    const today = new Date().toLocaleDateString('en-CA');
    const logToday = LOG.filter(l => new Date(l.at) >= sod);
    const nextOf = (k, min) => (ST.last[k] ? ST.last[k] + min * 60000 : null);
    const feed = [
      ...LOG.slice(0, 40).map(l => ({ at: l.at, type: 'discord', status: l.status, channel: l.channel, event: l.event, title: l.title, error: l.error, test: l.test })),
      ...OUT.slice(0, 40).flatMap(m => [{ at: m.createdAt, type: 'mail', status: 'drafted', title: `${kindOf(m)[2]} email for ${m.name || m.to}` },
        m.sentAt ? { at: m.sentAt, type: 'mail', status: 'sent', title: `Emailed ${m.name || m.to}${m.via === 'gmail' ? '' : ' (by hand)'}` } : null]).filter(Boolean),
      ...L.slice(-40).map(e => ({ at: new Date(e.created * 1000).toISOString(), type: 'sale', status: e.refunded ? 'refunded' : 'paid', title: `${money(e.amount, e.currency)} from ${e.name || e.email || 'someone'}`, sub: e.product }))
    ].sort((a, b) => String(b.at).localeCompare(String(a.at))).slice(0, 40);
    return {
      now: new Date().toISOString(), uptime: now - started, currency: cur.toUpperCase(), threshold: threshold(),
      revenue: { today: total(since(+sod)), week: total(since(now - 7 * 864e5)), month: total(since(now - 30 * 864e5)), all: total(counted),
        countToday: since(+sod).length, countMonth: since(now - 30 * 864e5).length, refunded: total(counted.filter(e => e.refunded).map(e => ({ ...e, amount: e.refunded, refunded: 0 }))), days,
        last: sales[0] || null, testCount: L.filter(e => !e.livemode).length },
      sales,
      supporters: { total: sups.length, eligible: sups.filter(eligible).length, codes: codes.length, wall: sups.filter(s => s.wall).length,
        waitingPublish: OUT.filter(m => m.status === 'waiting').length, held: ST.held.map(({ d, ...h }) => h) },
      email: { connected: !!(sec.smtpUser && sec.smtpPass), user: sec.smtpUser || '', auto: SET.email.auto, smtp: ST.smtp,
        ready: outBy('ready'), waiting: outBy('waiting'), failed: outBy('failed'), sentToday: ST.mailDay.day === today ? ST.mailDay.n : 0, cap: SET.email.dailyCap,
        sent: outBy('sent'), retrying: OUT.filter(m => m.status === 'ready' && m.error).length },
      discord: { private: { set: !!sec.discordPrivate, enabled: SET.channels.private.enabled, name: ST.hooks.private?.name || '' }, public: { set: !!sec.discordPublic, enabled: SET.channels.public.enabled, name: ST.hooks.public?.name || '' },
        sentToday: logToday.filter(l => l.status === 'sent').length, failedToday: logToday.filter(l => l.status === 'failed').length,
        lastSent: LOG.find(l => l.status === 'sent')?.at || null, scheduled: ST.scheduled.slice(0, 5).map(x => ({ id: x.id, at: x.at, title: x.title, channel: x.channel })) },
      watchers: {
        stripe: { on: SET.watch.stripe && !!sec.stripeKey, keySet: !!sec.stripeKey, every: SET.watch.stripeMin, next: nextOf('stripe', SET.watch.stripeMin), ...ST.watchers.Stripe },
        submissions: { on: SET.watch.submissions && !!ctx.loadSite().community?.submissionsEnabled, every: SET.watch.submissionsMin, next: nextOf('submissions', SET.watch.submissionsMin), ...ST.watchers.Submissions },
        youtube: { on: SET.watch.youtube && !!ctx.loadSite().youtube?.channelUrl, every: SET.watch.youtubeMin, next: nextOf('youtube', SET.watch.youtubeMin), ...ST.watchers.YouTube }
      },
      perks: { products: SET.perks.products, holdRisky: SET.perks.holdRisky, allowTest: SET.perks.allowTest, autoIssue: SET.auto.issueCodes, autoPublish: SET.auto.publishCodes },
      autostart: autostart(), digest: { mode: SET.digest.mode, last: ST.lastDigest || null },
      feed
    };
  }

  // ---------- summary ----------
  async function digest(force = false) {
    const since = new Date(ST.lastDigest || Date.now() - 86400000);
    const inWin = iso => iso && new Date(iso) > since;
    const sales = ST.sales.filter(s => inWin(s.at));
    const byCur = {};
    for (const s of sales) byCur[s.currency] = (byCur[s.currency] || 0) + s.amount;
    const sup = ctx.loadSupporters(), newSup = sup.filter(s => inWin(s.firstAt)).length;
    const logs = LOG.filter(l => inWin(l.at) && l.status === 'sent');
    const subs = logs.filter(l => l.event === 'submission.new' && l.channel === 'private').length || logs.filter(l => l.event === 'submission.new').length;
    const vids = new Set(logs.filter(l => /^yt\./.test(l.event)).map(l => l.title)).size;
    const pubs = logs.filter(l => l.event === 'publish.done').length;
    const ready = OUT.filter(m => m.status === 'ready').length;
    ST.lastDigest = new Date().toISOString(); saveState();
    if (!force && SET.digest.skipEmpty && !sales.length && !newSup && !subs && !vids && !ready) return { skipped: 'Nothing happened' };
    const totalAll = sup.reduce((n, s) => n + (s.total || 0), 0);
    return send('private', { embeds: [{ title: `📊 ${SET.digest.mode === 'weekly' ? 'Weekly' : 'Daily'} summary`, color: C.teal,
      description: `Since ${since.toLocaleString('en-AU', { dateStyle: 'medium', timeStyle: 'short' })}`,
      fields: [{ name: 'Sales', value: sales.length ? `${sales.length} · ${Object.entries(byCur).map(([c, v]) => money(v, c)).join(' + ')}` : 'None', inline: true },
        { name: 'Caffeine vs purchases', value: `${sales.filter(s => s.donation).length} 🥤 · ${sales.filter(s => !s.donation).length} 🛒`, inline: true },
        { name: 'New supporters', value: String(newSup), inline: true }, { name: 'Submissions', value: String(subs), inline: true },
        { name: 'New videos', value: String(vids), inline: true }, { name: 'Publishes', value: String(pubs), inline: true },
        { name: 'Emails waiting', value: ready ? `**${ready}** → [open the outbox](${hubUrl}/#/alerts/emails)` : 'All sent ✅', inline: true },
        { name: 'All-time support', value: `${aud(totalAll)} from ${sup.length}`, inline: true }],
      footer: footer() }], __title: 'Summary' }, { event: 'digest', ping: SET.events.digest?.ping });
  }
  function digestDue() {
    const d = SET.digest; if (!SET.events.digest?.private || d.mode === 'off') return false;
    const now = new Date(), last = ST.lastDigest ? new Date(ST.lastDigest) : null;
    if (!last) { ST.lastDigest = now.toISOString(); saveState(); return false; }
    const slot = new Date(now); slot.setHours(d.hour, 0, 0, 0);
    if (d.mode === 'weekly') { slot.setDate(slot.getDate() - ((slot.getDay() - d.day + 7) % 7)); }
    if (slot > now) slot.setDate(slot.getDate() - (d.mode === 'weekly' ? 7 : 1));
    return last < slot;
  }

  // ---------- watchers ----------
  async function watch(name, fn) {
    const w = ST.watchers[name] = { ...(ST.watchers[name] || {}), at: new Date().toISOString(), running: true };
    try { const r = await fn(); Object.assign(w, { ok: true, msg: summary(name, r), running: false }); delete ST.errors[name]; return r; }
    catch (e) {
      Object.assign(w, { ok: false, msg: e.message, running: false });
      const key = name + ':' + e.message, last = ST.errors[key];
      if (!last || Date.now() - last > 6 * 3600e3) { ST.errors[key] = Date.now(); fire('hub.error', () => ({ embeds: [{ title: `🩺 ${name} check failed`, color: C.bad, description: e.message, footer: footer('Repeats at most every 6 hours') }], __title: `${name} check failed` })); }
      throw e;
    } finally { saveState(); ctx.onActivity?.(); }
  }
  function summary(name, r) {
    if (!r) return 'OK';
    if (name === 'Stripe') return r.skipped || r.note || (r.busy ? 'Already checking' : `${r.sales} new payment${r.sales === 1 ? '' : 's'}${r.refunds ? `, ${r.refunds} refund(s)` : ''}${r.codes ? `, ${r.codes} code(s) issued` : ''}`);
    if (name === 'YouTube') return `${r.videos?.length ?? 0} videos, ${r.added || 0} new`;
    if (name === 'Submissions') return `${r.items?.length ?? 0} submissions${r.ghError ? ` (GitHub: ${r.ghError})` : ''}`;
    return 'OK';
  }
  const runners = {
    stripe: () => watch('Stripe', pollStripe),
    submissions: () => watch('Submissions', () => ctx.listSubmissions()),
    youtube: () => watch('YouTube', () => ctx.youtubeSync()),
    digest: () => digest(true)
  };
  let ticking = false;
  async function tick() {
    if (ticking) return; ticking = true;
    try {
      const now = Date.now(), due = (k, min) => now - (ST.last[k] || 0) >= min * 60000;
      const w = SET.watch, site = ctx.loadSite();
      if (w.stripe && ctx.secrets().stripeKey && due('stripe', w.stripeMin)) { ST.last.stripe = now; await runners.stripe().catch(() => {}); }
      if (w.submissions && site.community?.submissionsEnabled && due('submissions', w.submissionsMin)) { ST.last.submissions = now; await runners.submissions().catch(() => {}); }
      if (w.youtube && site.youtube?.channelUrl && due('youtube', w.youtubeMin)) { ST.last.youtube = now; await runners.youtube().catch(() => {}); }
      const dueSched = ST.scheduled.filter(s => new Date(s.at) <= new Date());
      if (dueSched.length) {
        ST.scheduled = ST.scheduled.filter(s => !dueSched.includes(s)); saveState();
        for (const s of dueSched) await send(s.channel, { ...s.payload, __title: s.title }, { event: 'scheduled', ping: s.ping, force: true });
      }
      if (digestDue()) await digest().catch(() => {});
      await releaseLiveCodes().catch(() => {});
      await processOutbox().catch(() => {});
    } finally { ticking = false; }
  }
  function start() {
    setTimeout(() => { fire('hub.started', () => ({ content: `🟢 Pylerium Manager is online. Watching ${[SET.watch.stripe && ctx.secrets().stripeKey && 'Stripe', SET.watch.submissions && 'submissions', SET.watch.youtube && 'YouTube'].filter(Boolean).join(', ') || 'nothing yet'}.`, __title: 'Hub started' })); tick(); }, 4000);
    setInterval(tick, 30000).unref?.();
  }

  // ---------- tests ----------
  async function test(event, channel) {
    const site = ctx.loadSite(), apps = ctx.loadApps().filter(a => a.published);
    const app = apps.find(a => a.featured) || apps[0] || { id: 'sample', name: 'Sample App', tagline: 'A sample app', description: 'This is what a release post looks like.', accent: 'studio' };
    const vids = (site.youtube?.videos || []).filter(v => !v.hidden);
    const sampleSale = { id: 'ch_test', amount: 1500, currency: site.community?.currency || 'aud', email: 'supporter@example.com', name: 'Sample Supporter', product: 'Supply Caffeine', wall: 'Sample', pm: 'Visa •••• 4242', country: 'AU', isDonation: true, receipt: '', dash: 'https://dashboard.stripe.com/test/payments', created: Date.now() / 1000, livemode: false };
    let d = sampleSale, real = false;
    if (/^sale\./.test(event) && ctx.secrets().stripeKey) {
      try { const c = (await ctx.stripeGet('charges?limit=1', ctx.secrets().stripeKey)).data?.[0]; if (c) { d = await saleDetails(c, ctx.secrets().stripeKey); real = true; } } catch {}
    }
    const sup = { id: '', name: d.name, email: d.email, total: d.amount / 100, payments: 1, code: 'CAFE-TEST-TEST-TEST' };
    const subs = await (async () => { try { return (await ctx.listSubmissionsQuiet()).items.find(i => i.data); } catch { return null; } })();
    const P = {
      'sale.new': () => salePayload(d, sup, { code: sup.code, newly: true, mail: addMail('code', sup, d, true), codeNote: 'Test: no real code was issued.' }),
      'sale.eligible': () => ({ content: `🔓 **${sup.name || sup.email}** unlocked app submissions.`, embeds: [mailEmbed(addMail('code', sup, d, true))] }),
      'sale.refund': () => ({ embeds: [{ title: `↩️ Refund · ${money(d.amount, d.currency)}`, url: d.dash, color: C.warn, description: `Refunded **${d.product}** for ${d.name || d.email}.`, footer: footer('Stripe') }] }),
      'sale.dispute': () => ({ embeds: [{ title: `⚠️ Dispute opened · ${money(d.amount, d.currency)}`, url: d.dash, color: C.bad, description: `${d.name || d.email} disputed **${d.product}**.`, footer: footer('Stripe') }] }),
      'sale.failed': () => ({ embeds: [{ title: `❌ Payment failed · ${money(d.amount, d.currency)}`, color: C.bad, description: `Card declined for **${d.product}**.`, footer: footer('Stripe') }] }),
      'sale.milestone': () => channel === 'public' ? { content: tpl(SET.templates['sale.milestone'], { amount: aud(100), count: 12 }), components: row(btn('Supply caffeine', site.donate?.url, '🥤')) } : { embeds: [{ title: `🎉 Support passed ${aud(100)}`, color: C.sale, footer: footer() }] },
      'supporter.code': () => ({ content: `🔑 Supporter code for **${sup.name}**: \`${sup.code}\``, embeds: [mailEmbed(addMail('code', sup, d, true))] }),
      'supporter.revoked': () => ({ content: `🚫 Revoked the supporter code for **${sup.name}**.` }),
      'supporter.wall': () => ({ content: tpl(SET.templates['supporter.wall'], { name: 'Sample Supporter' }), components: row(btn('Supply caffeine', site.donate?.url, '🥤')) }),
      'publish.needed': () => ({ embeds: [{ title: '⏳ Publish needed', color: C.warn, description: 'New supporter codes are waiting for a publish.', footer: footer() }] }),
      'submission.new': () => subs ? submissionPayload(subs) : { content: '📥 New submission: **Sample Mod**', embeds: [{ title: 'Sample Mod', color: C.violet, description: '**A sample submission**', fields: [{ name: 'Verification', value: '✅ Supporter: Sample (A$15)', inline: true }], footer: footer() }] },
      'submission.accepted': () => ({ embeds: [{ title: '✅ Accepted: Sample Mod', color: C.good, footer: footer() }] }),
      'submission.declined': () => ({ embeds: [{ title: '🙅 Declined: Sample Mod', color: C.warn, footer: footer() }] }),
      'app.removed': () => ({ embeds: [{ title: `📦 ${app.name} is no longer on the site`, color: C.warn, footer: footer() }] }),
      'site.announcement': () => ({ content: tpl(SET.templates['site.announcement'], { text: site.announcement?.text || 'Sample announcement' }) }),
      'yt.video': () => (vids.find(v => !v.short) ? videoPayload(vids.find(v => !v.short)) : { content: 'No videos synced yet.' }),
      'yt.short': () => (vids.find(v => v.short) ? videoPayload(vids.find(v => v.short)) : { content: 'No Shorts synced yet.' }),
      'publish.done': () => ({ embeds: [{ title: '🌐 Site published', url: siteUrl, color: C.good, description: '• ✏️ Sample change', footer: footer() }] }),
      'publish.failed': () => ({ embeds: [{ title: '🛑 Publish failed', color: C.bad, description: 'Sample error', footer: footer() }] }),
      'hub.error': () => ({ embeds: [{ title: '🩺 Stripe check failed', color: C.bad, description: 'Sample error', footer: footer() }] }),
      'hub.started': () => ({ content: '🟢 Pylerium Manager is online.' }),
      digest: () => null
    };
    if (event === 'digest') return digest(true);
    const build = P[event] || (/^app\./.test(event) ? () => appPayload(event, app) : () => ({ content: `🧪 Test message from Pylerium Manager (${channel}).` }));
    const p = await build();
    const tag = `🧪 **Test**${real ? ' (your latest real payment, nothing was changed)' : ''} · `;
    p.content = tag + (p.content || EV[event]?.label || '');
    p.__title = `Test: ${EV[event]?.label || 'message'}`;
    return send(channel, p, { event, test: true, force: true, ping: false });
  }

  // ---------- composer ----------
  function composed(b) {
    const e = b.embed || {}, hasEmbed = ['title', 'description', 'image', 'thumbnail'].some(k => String(e[k] || '').trim());
    const embed = hasEmbed ? { title: e.title || undefined, url: isUrl(e.url) ? e.url : undefined, description: e.description || undefined, color: hex(e.color),
      image: isUrl(e.image) ? { url: e.image } : undefined, thumbnail: isUrl(e.thumbnail) ? { url: e.thumbnail } : undefined,
      footer: e.footer ? { text: e.footer } : undefined, timestamp: e.timestamp ? new Date().toISOString() : undefined, author: e.author ? { name: B(), url: siteUrl, icon_url: avatar() } : undefined } : null;
    const extra = Array.isArray(b.embeds) ? b.embeds : [];
    return { content: String(b.content || ''), embeds: [embed, ...extra].filter(Boolean), components: row(...(b.buttons || []).map(x => btn(x.label || 'Open', x.url, x.emoji || undefined))) };
  }
  async function compose(b) {
    const channel = b.channel === 'private' ? 'private' : 'public';
    const payload = composed(b);
    if (!payload.content.trim() && !payload.embeds.length) throw new Error('Write a message or fill in the card first.');
    const title = clip(b.title || b.embed?.title || b.content || 'Post', 140);
    if (b.at && new Date(b.at) > new Date(Date.now() + 30000)) {
      const s = { id: 'sc-' + rid(), at: new Date(b.at).toISOString(), channel, payload, ping: !!b.ping, title, createdAt: new Date().toISOString() };
      ST.scheduled.push(s); ST.scheduled.sort((x, y) => x.at.localeCompare(y.at)); saveState();
      return { scheduled: s };
    }
    return { entry: await send(channel, { ...payload, __title: title }, { event: 'custom', ping: !!b.ping, force: true }) };
  }

  // ---------- autostart (Windows) ----------
  const startupFile = () => join(process.env.APPDATA || '', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup', 'Pylerium Manager.vbs');
  function autostart(on) {
    const f = startupFile();
    if (on === undefined) return existsSync(f);
    if (on) {
      mkdirSync(join(f, '..'), { recursive: true });
      const q = s => s.replace(/"/g, '""');
      writeFileSync(f, `' Starts Pylerium Manager quietly at sign-in so alerts and emails keep running.\r\nSet sh = CreateObject("WScript.Shell")\r\nsh.CurrentDirectory = "${q(ctx.HUB)}"\r\nsh.Run """${q(process.execPath)}"" ""${q(join(ctx.HUB, 'hub.mjs'))}"" --no-open", 0, False\r\n`);
    } else if (existsSync(f)) rmSync(f);
    return existsSync(f);
  }

  // ---------- API ----------
  function stateForUi() {
    const sec = ctx.secrets();
    return {
      settings: SET, events: EVENTS, defaults: { templates: DEFAULT_TEMPLATES, email: EMAIL_TEMPLATES },
      hooks: Object.fromEntries(['private', 'public'].map(c => [c, { set: !!sec[hookKey(c)], masked: maskHook(sec[hookKey(c)]), info: ST.hooks[c] || null }])),
      watchers: ST.watchers, last: ST.last, stripeKey: !!sec.stripeKey, stripeSeeded: !!ST.stripe?.seeded, scheduled: ST.scheduled,
      outboxReady: OUT.filter(m => m.status === 'ready' || m.status === 'failed').length, autostart: autostart(), hubUrl, lastDigest: ST.lastDigest || null,
      stats: { sent: LOG.filter(l => l.status === 'sent').length, failed: LOG.filter(l => l.status === 'failed').length },
      mail: { user: sec.smtpUser || '', passSet: !!sec.smtpPass, smtp: ST.smtp, sentToday: ST.mailDay.day === dayKey() ? ST.mailDay.n : 0,
        waiting: OUT.filter(m => m.status === 'waiting').length, failed: OUT.filter(m => m.status === 'failed').length },
      held: ST.held.length
    };
  }
  async function route(path, M, body, url) {
    if (path === '/api/alerts' && M === 'GET') return stateForUi();
    if (path === '/api/alerts' && M === 'PUT') { saveSettings(body.settings || {}); return stateForUi(); }
    if (path === '/api/alerts/webhook' && M === 'PUT') { const info = await setHook(body.channel === 'public' ? 'public' : 'private', body.url); return { ...stateForUi(), info }; }
    if (path === '/api/alerts/webhook/check' && M === 'POST') { const ch = body.channel === 'public' ? 'public' : 'private'; const u = hookUrl(ch); if (!u) throw new Error('No webhook saved for that channel.'); ST.hooks[ch] = await checkHook(u); saveState(); return stateForUi(); }
    if (path === '/api/alerts/test' && M === 'POST') { const e = await test(String(body.event || ''), body.channel === 'public' ? 'public' : 'private'); return { entry: e }; }
    if (path === '/api/alerts/run' && M === 'POST') { const r = runners[body.what]; if (!r) throw new Error('Unknown check'); const out = await r(); return { result: out, ...stateForUi() }; }
    if (path === '/api/alerts/reset-stripe' && M === 'POST') { delete ST.stripe; saveState(); return { result: await runners.stripe(), ...stateForUi() }; }
    if (path === '/api/alerts/autostart' && M === 'POST') { autostart(!!body.on); return stateForUi(); }
    if (path === '/api/alerts/log' && M === 'GET') return { log: LOG };
    if (path === '/api/alerts/log' && M === 'DELETE') { LOG = []; saveLog(); return { log: LOG }; }
    if (path === '/api/alerts/retry' && M === 'POST') {
      const e = LOG.find(l => l.id === body.id); if (!e?.payload) throw new Error('Nothing to retry.');
      const { allowed_mentions, ...p } = e.payload;
      return { entry: await send(e.channel, { ...p, content: p.content, __title: e.title }, { event: e.event, force: true }), log: LOG };
    }
    if (path === '/api/alerts/unsend' && M === 'POST') {
      const e = LOG.find(l => l.id === body.id); if (!e?.messageId) throw new Error('That message has no Discord id.');
      const res = await ctx.fetchT(`${hookUrl(e.channel)}/messages/${e.messageId}`, { method: 'DELETE' });
      if (!res.ok && res.status !== 404) throw new Error(`Discord returned ${res.status}`);
      e.status = 'deleted'; e.deletedAt = new Date().toISOString(); saveLog(); return { log: LOG };
    }
    if (path === '/api/discord/send' && M === 'POST') return compose(body);
    if (path === '/api/discord/preview' && M === 'POST') return { payload: composed(body) };
    if (path === '/api/discord/build' && M === 'POST') {
      if (body.kind === 'video') { const v = (ctx.loadSite().youtube?.videos || []).find(x => x.id === body.id); if (!v) throw new Error('Video not found'); return { payload: videoPayload(v) }; }
      const a = ctx.loadApps().find(x => x.id === body.id); if (!a) throw new Error('App not found');
      return { payload: appPayload(body.kind || 'app.new', a) };
    }
    if (path.startsWith('/api/discord/scheduled/') && M === 'DELETE') { ST.scheduled = ST.scheduled.filter(s => s.id !== path.split('/').pop()); saveState(); return stateForUi(); }
    if (path === '/api/outbox' && M === 'GET') return { outbox: OUT };
    if (path === '/api/outbox/send' && M === 'POST') { const m = OUT.find(x => x.id === body.id); if (!m) throw new Error('Email not found'); if (!smtpReady()) throw new Error(ST.smtp.authFail ? 'Fix the Gmail app password first (Emails tab).' : 'Connect Gmail first (Emails tab).'); await deliver(m, true); return { outbox: OUT, ...stateForUi() }; }
    if (path === '/api/outbox/release' && M === 'POST') { const m = OUT.find(x => x.id === body.id); if (m && m.status === 'waiting') { m.status = 'ready'; saveOut(); processOutbox().catch(() => {}); } return { outbox: OUT }; }
    if (path === '/api/outbox/check-live' && M === 'POST') { const n = await releaseLiveCodes(true); return { released: n, outbox: OUT }; }
    if (path === '/api/email/account' && M === 'PUT') {
      const user = String(body.user || '').trim().toLowerCase(), pass = String(body.pass || '').replace(/\s+/g, '');
      if (!user && !pass) { ctx.saveSecrets({ smtpUser: '', smtpPass: '' }); ST.smtp = {}; saveState(); return stateForUi(); }
      if (!EMAIL_RE.test(user)) throw new Error('Enter the Gmail address you send from.');
      const usePass = pass || (user === ctx.secrets().smtpUser ? ctx.secrets().smtpPass : '');
      if (!/^[a-zA-Z]{16}$/.test(usePass)) throw new Error('A Gmail App Password is 16 letters (spaces are fine). Your normal password won’t work.');
      await smtpSend({ user, pass: usePass, verifyOnly: true });
      ctx.saveSecrets({ smtpUser: user, smtpPass: usePass });
      ST.smtp = { ok: true, at: new Date().toISOString(), user }; delete ST.errors['mail:auth']; saveState();
      if (!SET.email.from || SET.email.from !== user) { SET.email.from = user; writeJson('alerts.json', SET, false); }
      for (const m of OUT) if (m.status === 'ready') { delete m.nextTry; } saveOut();
      setTimeout(() => processOutbox().catch(() => {}), 500);
      return stateForUi();
    }
    if (path === '/api/email/verify' && M === 'POST') {
      const x = ctx.secrets(); if (!x.smtpUser) throw new Error('Connect Gmail first.');
      try { await smtpSend({ user: x.smtpUser, pass: x.smtpPass, verifyOnly: true }); ST.smtp = { ok: true, at: new Date().toISOString(), user: x.smtpUser }; }
      catch (e) { ST.smtp = { ok: false, authFail: e.smtpCode === 535 || e.smtpCode === 534, error: e.message, at: new Date().toISOString(), user: x.smtpUser }; saveState(); throw e; }
      saveState(); processOutbox().catch(() => {}); return stateForUi();
    }
    if (path === '/api/email/test' && M === 'POST') {
      const x = ctx.secrets(); if (!x.smtpUser) throw new Error('Connect Gmail first.');
      const to = String(body.to || x.smtpUser).trim(); if (!EMAIL_RE.test(to)) throw new Error('That isn’t a valid email address.');
      const kind = body.kind === 'thanks' ? 'thanks' : 'code';
      const sample = { name: 'Sample Supporter', email: to, total: threshold() + 5, code: 'CAFE-TEST-TEST-TEST' };
      const { subject, body: text } = renderMail(kind, sample, { amount: Math.round((threshold() + 5) * 100), currency: siteCur(), product: 'Supply Caffeine' });
      await smtpSend({ ...mailArgs({ to, name: '', subject: '[Test] ' + subject, body: text }), bcc: [] });
      ST.smtp = { ok: true, at: new Date().toISOString(), user: x.smtpUser }; saveState();
      return { sent: to };
    }
    if (path === '/api/perks/review' && M === 'POST') return { result: await approveHeld(String(body.id), !!body.approve), ...live() };
    if (path === '/api/live' && M === 'GET') return live();
    if (path === '/api/outbox/mark' && M === 'POST') { const m = OUT.find(x => x.id === body.id); if (m) { m.status = body.status === 'ready' ? 'ready' : 'sent'; m.sentAt = m.status === 'sent' ? new Date().toISOString() : undefined; saveOut(); } ctx.onActivity?.(); return { outbox: OUT }; }
    if (path === '/api/outbox/edit' && M === 'POST') { const m = OUT.find(x => x.id === body.id); if (m) { delete m.nextTry; delete m.error; m.attempts = 0; if (m.status === 'failed') m.status = 'ready'; m.subject = String(body.subject ?? m.subject); m.body = String(body.body ?? m.body); m.to = String(body.to ?? m.to).trim(); m.gmail = gmailUrl(m); saveOut(); } return { outbox: OUT }; }
    if (path.startsWith('/api/outbox/') && M === 'DELETE') { OUT = OUT.filter(m => m.id !== path.split('/').pop()); saveOut(); ctx.onActivity?.(); return { outbox: OUT }; }
    if (path === '/api/outbox/compose' && M === 'POST') {
      const s = ctx.loadSupporters().find(x => x.id === body.supporterId); if (!s) throw new Error('Supporter not found');
      const kind = body.kind === 'code' ? 'code' : 'thanks';
      if (kind === 'code' && !s.code) throw new Error('Issue them a code first.');
      const m = addMail(kind, s); if (!m) throw new Error('They have no email address.');
      return { mail: m, outbox: OUT };
    }
    return undefined;
  }

  function setPerks(fn) { const next = structuredClone(SET); next.perks.products = fn([...SET.perks.products]); saveSettings(next); }
  return { perkGranted, purchases, qualTotal, route, live, setPerks, reconfig, start, fire, send, sendLicence, afterPublish, publishFailed, newVideos, seenSubmissions, submissionDone, codeIssued, codeRevoked, pollStripe, settings, outboxReady: () => OUT.filter(m => m.status === 'ready').length };
}
