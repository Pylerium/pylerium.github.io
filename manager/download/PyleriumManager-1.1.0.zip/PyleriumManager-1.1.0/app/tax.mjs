// Tax: Stripe Tax collects the right GST/VAT at checkout; the hub watches where your sales come from.
//
//   - Status: is Stripe Tax active, where are you registered (read live from Stripe)
//   - Exposure: the last 12 months of sales per country (in AUD, from Stripe's own settlement amounts) against each
//     country's registration threshold (tax-rules.json, overridable with data/tax-rules.json)
//   - Alerts: one Discord alert when a country gets close to (80%) or passes its threshold and you're not registered
//   - Collect automatically: switches automatic tax on every active payment link (prices become tax-inclusive),
//     and new paid downloads are created with it
//   - Exports: every sale as CSV, and a quarterly BAS helper (Australian financial-year quarters)
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

export function createTax(ctx) {
  // ctx: dir, readJson, writeJson, store (store.mjs), alert(title, desc), log?
  const DEF = { collect: false, alerts: true };
  const load = () => ({ settings: { ...DEF }, alerted: {}, ...ctx.readJson('tax.json', {}) });
  const save = d => ctx.writeJson('tax.json', d, false);
  const settings = () => ({ ...DEF, ...load().settings });
  const DATA = ctx.dataDir || join(ctx.dir, 'data');
  const rules = () => {
    const own = join(DATA, 'tax-rules.json');
    return JSON.parse(readFileSync(existsSync(own) ? own : join(ctx.dir, 'tax-rules.json'), 'utf8'));
  };

  async function stripe(method, path, params, what) {
    try { return await ctx.store.stripe(method, path, params); }
    catch (e) {
      if (/allowed|permission|rak_|restricted/i.test(e.message) && what)
        throw new Error(`Your Stripe key can’t ${what[0]}. In Stripe → Developers → API keys, edit the hub’s key and set “${what[1]}” to ${what[2] || 'Read'}.`);
      throw e;
    }
  }

  // ---------- Stripe Tax status ----------
  async function status() {
    const out = { active: false, state: 'unknown', headOffice: '', defaults: {}, registrations: [], error: '' };
    try {
      const s = await stripe('GET', 'tax/settings', null, ['read your tax settings', 'Tax settings']);
      Object.assign(out, { state: s.status, active: s.status === 'active', country: String(s.head_office?.address?.country || '').toUpperCase(), headOffice: [s.head_office?.address?.city, s.head_office?.address?.country].filter(Boolean).join(', '),
        defaults: { taxBehavior: s.defaults?.tax_behavior || '', taxCode: s.defaults?.tax_code || '' }, missing: s.status_details?.pending?.missing_fields || [] });
    } catch (e) { out.error = e.message; return out; }
    try {
      const r = await stripe('GET', 'tax/registrations?status=active&limit=100', null, ['read your tax registrations', 'Tax registrations']);
      out.registrations = (r.data || []).map(x => ({ country: x.country, type: x.country_options?.[String(x.country).toLowerCase()]?.type || '', since: x.active_from ? new Date(x.active_from * 1000).toISOString().slice(0, 10) : '' }));
    } catch (e) { out.error = e.message; }
    return out;
  }

  // ---------- sales (last N months) ----------
  async function sales(months = 12) {
    const since = Math.floor(Date.now() / 1000) - Math.round(months * 30.44 * 86400);
    const rows = [], taxByPi = new Map();
    let after = '', pages = 0;
    do {
      const j = await stripe('GET', `charges?limit=100&created[gte]=${since}&expand[]=data.balance_transaction${after ? `&starting_after=${after}` : ''}`, null, ['read your payments', 'Charges', 'Read']);
      for (const c of j.data || []) {
        if (c.status !== 'succeeded' || !c.paid) continue;
        const bt = typeof c.balance_transaction === 'object' ? c.balance_transaction : null;
        const kept = c.amount ? 1 - (c.amount_refunded || 0) / c.amount : 1;
        const settleCur = String(bt?.currency || c.currency).toUpperCase(), settle = bt ? bt.amount : c.amount;
        rows.push({ id: c.id, pi: typeof c.payment_intent === 'string' ? c.payment_intent : c.payment_intent?.id || '', created: new Date(c.created * 1000).toISOString(),
          country: (c.billing_details?.address?.country || c.payment_method_details?.card?.country || '').toUpperCase() || '??',
          currency: String(c.currency).toUpperCase(), amount: c.amount / 100, refunded: (c.amount_refunded || 0) / 100,
          net: Math.round(settle * kept) / 100, settle: settleCur, description: c.description || c.calculated_statement_descriptor || '', live: !!c.livemode, tax: null });
      }
      after = j.has_more && j.data?.length ? j.data[j.data.length - 1].id : '';
    } while (after && ++pages < 30);
    // Tax collected (only exists on Checkout payments made with automatic tax)
    try {
      after = ''; pages = 0;
      do {
        const j = await stripe('GET', `checkout/sessions?limit=100&status=complete&created[gte]=${since}${after ? `&starting_after=${after}` : ''}`);
        for (const s of j.data || []) if (s.payment_intent) taxByPi.set(typeof s.payment_intent === 'string' ? s.payment_intent : s.payment_intent.id, (s.total_details?.amount_tax || 0) / 100);
        after = j.has_more && j.data?.length ? j.data[j.data.length - 1].id : '';
      } while (after && ++pages < 30);
      for (const r of rows) if (taxByPi.has(r.pi)) r.tax = taxByPi.get(r.pi);
    } catch { /* no Checkout read access: tax column stays empty */ }
    return rows;
  }

  // ---------- exposure per country / rule ----------
  // home: the seller's country (Stripe Tax head office), else tax-rules.json "home". The rule covering the home
  // country uses its home threshold/text and counts worldwide sales ("home" basis); every other rule is for selling abroad.
  function evaluate(rows, regs, homeCountry) {
    const R0 = rules(), home = homeCountry || R0.home || 'AU', countries = {};
    const R = { ...R0, home, rules: R0.rules.map(r => {
      const isHome = r.countries.includes(home);
      const basis = r.basis === 'home' ? (isHome ? 'world' : 'region') : r.basis;
      return isHome ? { ...r, basis, home: true, threshold: r.homeThreshold ?? r.threshold, text: r.homeText || r.text } : { ...r, basis };
    }).sort((a, b) => (b.home ? 1 : 0) - (a.home ? 1 : 0)) };
    // The account's settlement currency: what most payouts are in (Stripe settles each account in its own currency).
    const tally = rows.reduce((m, r) => (m[r.settle] = (m[r.settle] || 0) + 1, m), {});
    const cur = Object.entries(tally).sort((a, b) => b[1] - a[1])[0]?.[0] || R0.currency || 'AUD';
    const fx = R0.fx || {};
    const conv = (v, from, to) => (from === to ? v : fx[from] && fx[to] ? v / fx[from] * fx[to] : NaN);
    let world = 0, unknown = 0;
    for (const r of rows) {
      const c = (countries[r.country] ||= { country: r.country, count: 0, net: 0, tax: 0 });
      const v = r.settle === cur ? r.net : 0; if (r.settle !== cur) unknown++;
      c.count++; c.net += v; c.tax += r.tax || 0; world += v;
    }
    const regSet = new Set(regs.map(r => r.country));
    const out = R.rules.map(rule => {
      const inRule = rule.basis === 'world' ? Object.values(countries) : rule.countries.map(c => countries[c]).filter(Boolean);
      const salesNet = rule.basis === 'world' ? world : inRule.reduce((s, c) => s + c.net, 0);
      const count = rule.basis === 'world' ? rows.length : inRule.reduce((s, c) => s + c.count, 0);
      const regionCount = rule.countries.reduce((s, c) => s + (countries[c]?.count || 0), 0);
      const registered = rule.countries.some(c => regSet.has(c));
      const local = conv(salesNet, cur, rule.currency), thresholdCur = rule.threshold ? conv(rule.threshold, rule.currency, cur) : 0;
      const pct = rule.threshold ? (Number.isFinite(local) ? local / rule.threshold : 0) : (regionCount ? 1 : 0);
      const level = registered ? 'registered' : !regionCount && !rule.home ? 'none' : pct >= 1 ? 'register' : pct >= 0.8 ? 'near' : 'ok';
      return { ...rule, sales: Math.round(salesNet * 100) / 100, thresholdCur: Number.isFinite(thresholdCur) ? Math.round(thresholdCur) : null, count, regionCount, registered, pct: Math.min(pct, 9.99), level };
    });
    return { currency: cur, home, rules: out, countries: Object.values(countries).sort((a, b) => b.net - a.net), total: Math.round(world * 100) / 100, sales: rows.length, unknown, reviewed: R.reviewed, note: R.note };
  }

  let cache = null;
  async function report(force = false) {
    if (!force && cache && Date.now() - cache.at < 10 * 60000) return cache;
    const st = await status();
    let ev = null, error = '';
    try { ev = evaluate(await sales(12), st.registrations, st.country); } catch (e) { error = e.message; }
    cache = { at: Date.now(), status: st, exposure: ev, error, settings: settings() };
    if (ev) await alertIfNeeded(ev).catch(() => {});
    return cache;
  }

  async function alertIfNeeded(ev) {
    const d = load();
    if (!d.settings.alerts) return;
    for (const r of ev.rules) {
      if (!['near', 'register'].includes(r.level)) continue;
      const k = `${r.id}:${r.level}`;
      if (d.alerted[k]) continue;
      d.alerted[k] = new Date().toISOString();
      let money; try { money = new Intl.NumberFormat('en', { style: 'currency', currency: ev.currency, maximumFractionDigits: 0 }).format(r.sales); } catch { money = `${r.sales} ${ev.currency}`; }
      ctx.alert?.(r.level === 'register' ? `🧾 Tax: time to register in ${r.name}` : `🧾 Tax: getting close in ${r.name}`,
        `${r.regionCount || r.count} sale(s), ${money} in the last 12 months${r.threshold ? ` (threshold ${r.currency} ${r.threshold.toLocaleString('en-AU')})` : ' (no minimum for overseas sellers)'}.\n${r.text}\n${r.url}`);
    }
    save(d);
  }

  // ---------- collect automatically ----------
  async function setCollect(on) {
    const d = load(), done = { links: 0, prices: 0, skipped: [] };
    if (on) {
      const st = await status();
      if (st.error) throw new Error(st.error);
      if (!st.active) throw new Error('Turn on Stripe Tax first: Stripe dashboard → Tax → set your business address, then add a registration (for example Australia if you are registered for GST). Then switch this on again.');
      if (!st.defaults.taxBehavior || st.defaults.taxBehavior === 'inferred_by_currency')
        await stripe('POST', 'tax/settings', { defaults: { tax_behavior: 'inclusive' } }, ['change tax settings', 'Tax settings', 'Write']).catch(() => {});
    }
    let after = '', pages = 0;
    do {
      const j = await stripe('GET', `payment_links?active=true&limit=100&expand[]=data.line_items${after ? `&starting_after=${after}` : ''}`, null, ['read payment links', 'Payment Links']);
      for (const l of j.data || []) {
        if (!!l.automatic_tax?.enabled === on) continue;
        if (on) for (const li of l.line_items?.data || []) {
          const p = li.price;
          if (p && (!p.tax_behavior || p.tax_behavior === 'unspecified')) { await stripe('POST', `prices/${p.id}`, { tax_behavior: 'inclusive' }, ['update prices', 'Prices', 'Write']); done.prices++; }
        }
        try { await stripe('POST', `payment_links/${l.id}`, { automatic_tax: { enabled: on ? 'true' : 'false' } }, ['update payment links', 'Payment Links', 'Write']); done.links++; }
        catch (e) { done.skipped.push(`${l.url}: ${e.message}`); }
      }
      after = j.has_more && j.data?.length ? j.data[j.data.length - 1].id : '';
    } while (after && ++pages < 10);
    d.settings.collect = !!on; save(d);
    ctx.store.invalidate?.(); cache = null;
    ctx.alert?.(on ? '🧾 Automatic tax switched on' : '🧾 Automatic tax switched off', `${done.links} payment link(s) updated${done.prices ? `, ${done.prices} price(s) set to tax-inclusive` : ''}.${done.skipped.length ? `\nSkipped: ${done.skipped.join('; ')}` : ''}`);
    return done;
  }

  // ---------- exports ----------
  const csvCell = v => { const s = v == null ? '' : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const csv = rows => rows.map(r => r.map(csvCell).join(',')).join('\r\n') + '\r\n';
  // Australian financial-year quarter: Q1 = Jul–Sep
  const fyq = iso => { const d = new Date(iso), m = d.getUTCMonth(), y = d.getUTCFullYear(); const fy = m >= 6 ? y + 1 : y; const q = Math.floor(((m + 6) % 12) / 3) + 1; return `FY${fy} Q${q}`; };
  async function exportCsv(kind, months = 24) {
    const rows = (await sales(months)).sort((a, b) => a.created.localeCompare(b.created));
    const stamp = new Date().toISOString().slice(0, 10);
    if (kind === 'sales') {
      return { filename: `sales-${stamp}.csv`, csv: csv([['Date', 'Charge', 'Country', 'Currency', 'Amount', 'Refunded', 'Tax collected', 'Net settled', 'Settled currency', 'Description', 'Live'],
        ...rows.map(r => [r.created.slice(0, 10), r.id, r.country, r.currency, r.amount.toFixed(2), r.refunded.toFixed(2), r.tax == null ? '' : r.tax.toFixed(2), r.net.toFixed(2), r.settle, r.description, r.live ? 'yes' : 'test'])]) };
    }
    // BAS helper: totals per quarter. G1 total sales; GST-free = sales to customers outside Australia; 1A = GST collected from Australian customers.
    const home = (await status()).country || rules().home || 'AU', Q = new Map(), au = home === 'AU';
    const tally = rows.reduce((m, r) => (m[r.settle] = (m[r.settle] || 0) + 1, m), {});
    const cur = Object.entries(tally).sort((a, b) => b[1] - a[1])[0]?.[0] || 'AUD';
    for (const r of rows) {
      const q = Q.get(fyq(r.created)) || { q: fyq(r.created), total: 0, home: 0, overseas: 0, gst: 0, count: 0, unknown: 0 };
      const v = r.settle === cur ? r.net : 0; q.total += v; q.count++; if (r.settle !== cur) q.unknown++;
      if (r.country === home) { q.home += v; q.gst += r.currency === cur ? r.tax || 0 : 0; } else q.overseas += v;
      Q.set(q.q, q);
    }
    return { filename: `${au ? 'bas-helper' : 'quarterly-tax-summary'}-${stamp}.csv`, csv: csv([['Quarter (July–June year)', 'Sales', au ? `G1 total sales (${cur}, incl. GST)` : `Total sales (${cur})`, `Sales to ${home} customers`, 'Overseas sales', au ? '1A GST collected (Stripe Tax)' : `Tax collected from ${home} customers (Stripe Tax)`, `Sales not settled in ${cur} (excluded)`],
      ...[...Q.values()].map(q => [q.q, q.count, q.total.toFixed(2), q.home.toFixed(2), q.overseas.toFixed(2), q.gst.toFixed(2), q.unknown])]) };
  }

  let timer = null;
  function start() { timer = setInterval(() => report(true).catch(() => {}), 6 * 3600e3); timer.unref?.(); setTimeout(() => report(true).catch(() => {}), 60000).unref?.(); }

  async function route(path, M, body, url) {
    if (path === '/api/tax' && M === 'GET') return report(url?.searchParams.get('force') === '1');
    if (path === '/api/tax/settings' && M === 'PUT') {
      if (body.collect != null && !!body.collect !== settings().collect) await setCollect(!!body.collect);
      if (body.alerts != null) { const d = load(); d.settings.alerts = !!body.alerts; save(d); }
      cache = null; return report(true);
    }
    if (path === '/api/tax/export' && M === 'GET') return exportCsv(url.searchParams.get('kind') === 'bas' ? 'bas' : 'sales', +url.searchParams.get('months') || 24);
    if (path === '/api/tax/realert' && M === 'POST') { const d = load(); d.alerted = {}; save(d); cache = null; return report(true); }
    return undefined;
  }
  return { route, start, report, collecting: () => settings().collect };
}
