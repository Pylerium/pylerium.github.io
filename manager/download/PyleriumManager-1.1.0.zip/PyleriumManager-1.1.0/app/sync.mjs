// Auto-sync: keeps every app's public details in step with GitHub and Stripe, so nothing on the site goes stale.
//
//   GitHub release (the app's paid-download repo, or its repoUrl) → version, "Updated" date, release notes
//   Private repository                                          → Source button and dead GitHub download links hidden
//   Stripe paid-download link                                   → price, "Buy · price" button, switched-off links removed
//
// Runs shortly after the hub starts, then every few minutes, and right after a sale is set up. When something changes
// it saves the apps, posts a Discord note and (if auto-publish is on) publishes the site.
const GH_RE = /github\.com\/([\w.-]+)\/([\w.-]+?)(?:\.git)?(?:[/#?].*)?$/i;
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function createSync(ctx) {
  // ctx: readJson, writeJson, loadApps, saveApps, delivery, publish(message), alert(title, desc), log?
  const DEF = { enabled: true, autoPublish: true, everyMinutes: 15, versions: true, notes: true, prices: true, privacy: true };
  const settings = () => ({ ...DEF, ...(ctx.readJson('sync.json', {}).settings || {}) });
  const loadState = () => ({ lastRun: null, lastChange: null, lastError: '', history: [], ...ctx.readJson('sync.json', {}) });
  const saveState = st => ctx.writeJson('sync.json', st, false);
  let running = null, timer = null;

  const repoOf = url => { const m = String(url || '').match(GH_RE); return m ? `${m[1]}/${m[2]}` : ''; };
  const monthYear = iso => { const d = new Date(iso); return `${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}`; };
  // First meaningful line(s) of release notes, as plain text.
  function noteOf(body, tag) {
    const lines = String(body || '').split(/\r?\n/).map(l => l.replace(/^\s*(#+|[-*+]|\d+[.)])\s*/, '').replace(/\*\*|__|`/g, '').trim()).filter(Boolean)
      .filter(l => !/^(what'?s changed|full changelog|changelog|release notes?)\b/i.test(l) && !/^https?:\/\/\S+$/.test(l));
    let out = '';
    for (const l of lines) { const next = out ? out + (/[.!?:]$/.test(out) ? ' ' : ' · ') + l : l; if (next.length > 220) break; out = next; }
    return out || `Release ${tag}.`;
  }

  async function run(reason = 'scheduled') {
    if (running) return running;
    running = (async () => {
      const S = settings(), st = loadState(), changes = [];
      const errors = [];
      if (!S.enabled && reason === 'scheduled') return { skipped: true };
      const apps = ctx.loadApps();
      let products = [];
      try { products = await ctx.delivery.products(true); } catch (e) { if (!/Stripe key/i.test(e.message)) errors.push(`Stripe: ${e.message}`); }
      const repoCache = new Map();
      const repoInfo = async full => {
        if (!repoCache.has(full)) repoCache.set(full, await ctx.delivery.repoInfo(full).catch(e => ({ error: e.message })));
        return repoCache.get(full);
      };

      for (const a of apps) {
        const change = (field, from, to, what) => { a[field] = to; changes.push({ app: a.id, name: a.name, field, from, to, what }); };
        const sale = products.find(p => p.appId === a.id && p.onApp) || products.find(p => p.appId === a.id && p.active);

        // ---- prices & buy buttons (Stripe) ----
        if (S.prices && sale) {
          const onApp = sale.onApp;
          if (onApp && !sale.active) {
            change('primaryUrl', a.primaryUrl, '', 'Buy link switched off in Stripe, button removed');
            if (/^Buy\b/.test(a.primaryLabel || '')) a.primaryLabel = '';
            if (a.price) a.price = '';
          } else if (onApp && sale.label) {
            if (a.price !== sale.label) change('price', a.price || '', sale.label, `Price is now ${sale.label}`);
            const want = `Buy · ${sale.label}`;
            if ((!a.primaryLabel || /^Buy · /.test(a.primaryLabel)) && a.primaryLabel !== want) change('primaryLabel', a.primaryLabel || '', want, 'Buy button label');
          }
        }

        // ---- releases & privacy (GitHub) ----
        const srcRepo = sale?.repo || repoOf(a.repoUrl);
        if (!srcRepo || (!S.versions && !S.privacy)) continue;
        const info = await repoInfo(srcRepo);
        if (info?.error) { errors.push(`${a.name}: ${info.error}`); continue; }
        if (!info) continue;

        if (S.privacy) {
          const own = repoOf(a.repoUrl) === srcRepo;
          const priv = !!info.private && own;
          if (!!a.repoPrivate !== priv) change('repoPrivate', !!a.repoPrivate, priv, priv ? 'Repository is private: Source button hidden' : 'Repository is public again: Source button shown');
          if (priv && repoOf(a.primaryUrl) === srcRepo) { // a download button that points into a now-private repo is a dead link
            change('primaryUrl', a.primaryUrl, '', 'Download button pointed into the private repository, removed until it is for sale');
            if (!/^Buy\b/.test(a.primaryLabel || '')) a.primaryLabel = '';
          }
        }

        if (S.versions && info.release) {
          const r = info.release, tag = r.tag;
          if (a.version !== tag) {
            change('version', a.version || '', tag, `New release ${tag}`);
            const day = String(r.date || '').slice(0, 10);
            if (/^\d{4}-\d{2}-\d{2}$/.test(day) && a.updatedAt !== day) a.updatedAt = day;
          }
          if (S.notes && !(a.changelog || []).some(c => c.ver === tag)) {
            a.changelog = [{ ver: tag, date: monthYear(r.date || Date.now()), note: noteOf(r.body, tag) }, ...(a.changelog || [])].slice(0, 12);
            changes.push({ app: a.id, name: a.name, field: 'changelog', to: tag, what: `Release notes for ${tag} added` });
          }
        }
      }

      const now = new Date().toISOString();
      st.lastRun = now; st.lastError = [...new Set(errors)].join(' · '); st.lastReason = reason;
      let published = null;
      if (changes.length) {
        ctx.saveApps(apps);
        st.lastChange = now;
        st.history = [...changes.map(c => ({ at: now, app: c.app, name: c.name, what: c.what })), ...(st.history || [])].slice(0, 80);
        const byApp = {};
        for (const c of changes) (byApp[c.name] ||= []).push(c.what);
        ctx.alert?.(`🔄 Auto-sync updated ${Object.keys(byApp).length} app${Object.keys(byApp).length > 1 ? 's' : ''}`,
          Object.entries(byApp).map(([n, w]) => `**${n}**: ${w.join('; ')}`).join('\n'));
        if (S.autoPublish && changes.some(c => apps.find(x => x.id === c.app)?.published)) {
          try { published = await ctx.publish(`Auto-publish: ${Object.keys(byApp).join(', ')} updated from GitHub/Stripe`); st.lastPublish = now; }
          catch (e) { st.lastError = [st.lastError, `Publish: ${e.message}`].filter(Boolean).join(' · '); }
        }
      }
      saveState(st);
      return { changes, errors, published: !!published, at: now };
    })();
    try { return await running; } finally { running = null; }
  }

  function schedule() {
    clearInterval(timer);
    const m = Math.max(5, +settings().everyMinutes || 15);
    timer = setInterval(() => run('scheduled').catch(e => ctx.log?.('Auto-sync failed:', e.message)), m * 60000);
    timer.unref?.();
  }
  function start() { setTimeout(() => run('startup').catch(() => {}), 20000).unref?.(); schedule(); }

  async function route(path, M, body) {
    if (path === '/api/sync' && M === 'GET') return { settings: settings(), state: loadState(), running: !!running };
    if (path === '/api/sync' && M === 'POST') { const r = await run('manual'); return { result: r, settings: settings(), state: loadState() }; }
    if (path === '/api/sync/settings' && M === 'PUT') {
      const st = loadState(), cur = settings(), b = body || {};
      st.settings = { ...cur, ...Object.fromEntries(Object.entries(b).filter(([k]) => k in DEF).map(([k, v]) => [k, k === 'everyMinutes' ? Math.max(5, Math.min(1440, Math.round(+v || 15))) : !!v])) };
      saveState(st); schedule();
      return { settings: settings(), state: loadState() };
    }
    return undefined;
  }
  return { run, start, route, settings };
}
