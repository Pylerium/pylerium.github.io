// Licence keys for paid apps. One studio-wide ECDSA P-256 key signs every licence; each app ships only the public half
// and checks keys offline (no licence server). A key names the app it unlocks, so one app's key never opens another.
//
//   key = PYL1-<base64url JSON payload>.<base64url signature>     signature: ECDSA P-256 / SHA-256, IEEE P1363 (r‖s)
//   payload = { v: 1, app: "<app id>", id: "L…", email, name, iat, ref }
//
// Apps marked "Licensed" in the editor get a key automatically with every paid download (it goes into the download
// email). Keys are recorded in data/licences.json; the same purchase always gets the same key back.
// The private key is data/licence-key.pem: back it up, never publish it.
//
// CLI:  node licences.mjs pubkey                     public key to paste into an app
//       node licences.mjs issue <appId> <email> [name]   issue a key by hand (giveaways, support)
//       node licences.mjs verify <key>               check a key
import { readFileSync, writeFileSync, existsSync, mkdirSync, renameSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { generateKeyPairSync, createPrivateKey, createPublicKey, sign, verify, randomBytes } from 'node:crypto';

const b64u = b => Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = s => Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
export const KEY_RE = /^PYL1-([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function createLicences({ dataDir }) {
  const KEY_FILE = join(dataDir, 'licence-key.pem'), DB = join(dataDir, 'licences.json');
  const readDb = () => { try { return JSON.parse(readFileSync(DB, 'utf8')); } catch { return []; } };
  const writeDb = l => { writeFileSync(DB + '.tmp', JSON.stringify(l, null, 2) + '\n'); renameSync(DB + '.tmp', DB); };

  function privateKey() {
    if (!existsSync(KEY_FILE)) {
      mkdirSync(dirname(KEY_FILE), { recursive: true });
      const { privateKey } = generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
      writeFileSync(KEY_FILE, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
    }
    return createPrivateKey(readFileSync(KEY_FILE));
  }
  /** Public key (SPKI DER, base64) to embed in apps. */
  const publicKey = () => createPublicKey(privateKey()).export({ type: 'spki', format: 'der' }).toString('base64');

  function issue({ app, email, name = '', ref = '' }) {
    if (!/^[\w-]{1,64}$/.test(app || '')) throw new Error('Pick the app this licence is for.');
    email = String(email || '').trim().toLowerCase();
    if (!EMAIL_RE.test(email)) throw new Error('A valid customer email is required.');
    const db = readDb();
    if (ref) { const hit = db.find(x => x.ref === ref && x.app === app); if (hit) return hit; } // same purchase → same key
    const payload = { v: 1, app, id: 'L' + randomBytes(6).toString('hex').toUpperCase(), email, name: String(name || '').trim(), iat: new Date().toISOString(), ...(ref ? { ref } : {}) };
    const body = b64u(JSON.stringify(payload));
    const sig = b64u(sign('sha256', Buffer.from(body), { key: privateKey(), dsaEncoding: 'ieee-p1363' }));
    const rec = { ...payload, key: `PYL1-${body}.${sig}` };
    db.unshift(rec); writeDb(db);
    return rec;
  }
  function check(key) {
    const m = String(key || '').replace(/\s+/g, '').match(KEY_RE);
    if (!m) return { ok: false, why: 'Not a PYL1 licence key.' };
    const good = verify('sha256', Buffer.from(m[1]), { key: createPublicKey(privateKey()), dsaEncoding: 'ieee-p1363' }, unb64u(m[2]));
    if (!good) return { ok: false, why: 'Signature does not match (not issued by this hub, or damaged).' };
    return { ok: true, ...JSON.parse(unb64u(m[1]).toString('utf8')) };
  }
  const list = app => readDb().filter(x => !app || x.app === app);
  /** Drop-in licence check for one app, in one language, with the public key and app id filled in. */
  function kit(lang, app, siteUrl = '') {
    const K = KITS[lang];
    if (!K) throw new Error('Unknown language. Choose python, js, csharp or c.');
    if (!/^[\w-]{1,64}$/.test(app?.id || '')) throw new Error('Pick an app.');
    const clean = s => String(s || '').replace(/["\\\r\n]/g, '').trim();
    const vals = { __APP_ID__: app.id, __APP_NAME__: clean(app.name) || app.id, __PUBLIC_KEY__: publicKey(),
      __BUY_URL__: clean(siteUrl).replace(/\/$/, '') + `/apps/${app.id}/` };
    return { lang, label: K.label, files: K.files.map(f => ({ name: f, content: readFileSync(join(KIT_DIR, K.dir, f), 'utf8').replace(/__(APP_ID|APP_NAME|PUBLIC_KEY|BUY_URL)__/g, m => vals[m]) })) };
  }
  return { issue, check, list, publicKey, kit, keyFile: KEY_FILE };
}

const KIT_DIR = join(dirname(fileURLToPath(import.meta.url)), 'licence-kits');
export const KITS = {
  python: { label: 'Python', dir: 'python', files: ['pylerium_licence.py'] },
  js: { label: 'JavaScript', dir: 'js', files: ['pylerium-licence.mjs'] },
  csharp: { label: 'C#', dir: 'csharp', files: ['PyleriumLicence.cs'] },
  c: { label: 'C / C++', dir: 'c', files: ['pylerium_licence.h', 'pylerium_licence.c'] }
};

// ---------- CLI ----------
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const L = createLicences({ dataDir: join(dirname(fileURLToPath(import.meta.url)), 'data') });
  const [cmd, ...a] = process.argv.slice(2);
  if (cmd === 'pubkey') console.log(L.publicKey());
  else if (cmd === 'issue') { const r = L.issue({ app: a[0], email: a[1], name: a.slice(2).join(' ') }); console.log(`Licence ${r.id} for ${r.email} (${r.app})\n\n${r.key}\n`); }
  else if (cmd === 'verify') console.log(L.check(a[0]));
  else if (cmd === 'list') for (const r of L.list(a[0])) console.log(`${r.iat.slice(0, 10)}  ${r.app.padEnd(16)} ${r.id}  ${r.email}${r.ref ? `  (${r.ref})` : ''}`);
  else if (cmd === 'kit') {
    const [lang, appId, outDir = '.'] = a;
    const apps = JSON.parse(readFileSync(join(dirname(fileURLToPath(import.meta.url)), 'data', 'apps.json'), 'utf8'));
    const cfg = JSON.parse(readFileSync(join(dirname(fileURLToPath(import.meta.url)), 'data', 'config.json'), 'utf8'));
    const app = apps.find(x => x.id === appId) || { id: appId, name: appId };
    for (const f of L.kit(lang, app, cfg.siteUrl).files) { mkdirSync(outDir, { recursive: true }); writeFileSync(join(outDir, f.name), f.content); console.log('wrote', join(outDir, f.name)); }
  }
  else console.log('usage: node licences.mjs pubkey | issue <appId> <email> [name] | verify <key> | list [appId] | kit <python|js|csharp|c> <appId> [outDir]');
}
