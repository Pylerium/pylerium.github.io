// Store & pricing: read and change Stripe products, prices and payment links from the hub.
// Stripe prices can't be edited, so a price change creates a new Price plus a new Payment Link that copies the old
// link's settings, points the site (donate button / app buttons) at it, and retires the old link once the site is live.
const ZERO = new Set(['bif', 'clp', 'djf', 'gnf', 'jpy', 'kmf', 'krw', 'mga', 'pyg', 'rwf', 'ugx', 'vnd', 'vuv', 'xaf', 'xof', 'xpf']);

export function createStore(ctx) {
  const key = () => ctx.secrets().stripeWriteKey || ctx.secrets().stripeKey;
  const toMinor = (v, cur) => Math.round(+v * (ZERO.has(String(cur).toLowerCase()) ? 1 : 100));
  const toMajor = (v, cur) => (v == null ? null : ZERO.has(String(cur).toLowerCase()) ? v : v / 100);
  const linkCode = u => String(u || '').match(/stripe\.com\/(?:test_)?([\w]+)\/?$/)?.[1] || '';
  const money = (major, cur) => { try { return new Intl.NumberFormat('en-US', { style: 'currency', currency: String(cur).toUpperCase(), minimumFractionDigits: major % 1 ? 2 : 0 }).format(major); } catch { return `${major} ${cur}`; } };

  function enc(obj, prefix = '', out = []) {
    for (const [k, v] of Object.entries(obj)) {
      if (v === undefined || v === null) continue;
      const kk = prefix ? `${prefix}[${k}]` : k;
      if (Array.isArray(v)) v.forEach((x, i) => (x && typeof x === 'object' ? enc(x, `${kk}[${i}]`, out) : out.push([`${kk}[${i}]`, String(x)])));
      else if (typeof v === 'object') enc(v, kk, out);
      else out.push([kk, String(v)]);
    }
    return out;
  }
  async function stripe(method, path, params) {
    const k = key();
    if (!k) throw new Error('Add a Stripe key first (Community → Caffeine & perks, or Store → Stripe access).');
    const res = await ctx.fetchT((process.env.PM_STRIPE_API || 'https://api.stripe.com/v1') + '/' + path, {
      method, headers: { Authorization: `Bearer ${k}`, ...(params ? { 'Content-Type': 'application/x-www-form-urlencoded' } : {}) },
      body: params ? new URLSearchParams(enc(params)).toString() : undefined
    }, 20000);
    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      const m = j.error?.message || `Stripe returned ${res.status}`;
      if (res.status === 403 || /permission|rak_/i.test(m)) throw new Error(`Your Stripe key isn’t allowed to do that. In Stripe → Developers → API keys, edit the restricted key (or create one for the hub) and set Products, Prices and Payment Links to “Write”. (${m})`);
      throw new Error(m);
    }
    return j;
  }

  // ---------- read ----------
  let cache = null, cacheAt = 0;
  function shapePrice(p) {
    if (!p) return null;
    const cur = p.currency;
    const c = p.custom_unit_amount;
    return { id: p.id, currency: cur.toUpperCase(), mode: p.recurring ? 'recurring' : c ? 'custom' : 'fixed', amount: toMajor(p.unit_amount, cur),
      min: toMajor(c?.minimum, cur), max: toMajor(c?.maximum, cur), preset: toMajor(c?.preset, cur), interval: p.recurring?.interval || '', taxBehavior: p.tax_behavior, active: p.active };
  }
  const priceLabel = p => !p ? '' : p.mode === 'custom' ? (p.min ? `From ${money(p.min, p.currency)}` : 'Pay what you want') : p.mode === 'recurring' ? `${money(p.amount, p.currency)}/${p.interval}` : money(p.amount, p.currency);
  async function overview(force = false) {
    if (!force && cache && Date.now() - cacheAt < 60000) return cache;
    const [links, products] = await Promise.all([stripe('GET', 'payment_links?limit=100&expand[]=data.line_items'), stripe('GET', 'products?limit=100')]);
    const P = new Map(products.data.map(p => [p.id, p]));
    const site = ctx.loadSite(), apps = ctx.loadApps(), perk = ctx.perkProducts();
    const donate = linkCode(site.donate?.url);
    const out = links.data.map(l => {
      const li = l.line_items?.data?.[0], price = shapePrice(li?.price), prodId = typeof li?.price?.product === 'string' ? li.price.product : li?.price?.product?.id;
      const prod = P.get(prodId) || {};
      const code = linkCode(l.url);
      return { id: l.id, url: l.url, active: l.active, items: l.line_items?.data?.length || 0, price, label: priceLabel(price),
        product: { id: prodId, name: prod.name || li?.description || 'Item', description: prod.description || '', active: prod.active !== false, image: prod.images?.[0] || '' },
        submitType: l.submit_type, after: l.after_completion?.type === 'redirect' ? l.after_completion.redirect?.url : l.after_completion?.hosted_confirmation?.custom_message || '',
        isDonate: !!donate && code === donate, apps: apps.filter(a => linkCode(a.primaryUrl) === code && code).map(a => ({ id: a.id, name: a.name })),
        perk: perk.includes(prodId) || perk.includes(l.id), replaces: l.metadata?.replaces || '', livemode: l.livemode,
        deliver: l.metadata?.deliver_repo ? { repo: l.metadata.deliver_repo, tag: l.metadata.deliver_tag || 'latest', app: l.metadata.deliver_app || '' } : null };
    }).sort((a, b) => (b.active - a.active) || (b.isDonate - a.isDonate));
    cache = { links: out, products: products.data.map(p => ({ id: p.id, name: p.name, active: p.active })), currency: String(site.community?.currency || 'AUD').toUpperCase(),
      write: !!ctx.secrets().stripeWriteKey, keySet: !!key(), at: new Date().toISOString() };
    cacheAt = Date.now();
    return cache;
  }

  // ---------- write helpers ----------
  function validate(b, cur) {
    const lo = ZERO.has(cur.toLowerCase()) ? 50 : 0.5;
    if (b.mode === 'fixed') {
      if (!(+b.amount >= lo) || +b.amount > 999999) throw new Error(`Enter a price of at least ${money(lo, cur)}.`);
      return { unit_amount: toMinor(b.amount, cur) };
    }
    const c = { enabled: true };
    for (const k of ['minimum', 'maximum', 'preset']) { const v = b[k.slice(0, 3) === 'min' ? 'min' : k.slice(0, 3) === 'max' ? 'max' : 'preset']; if (v !== '' && v != null && !isNaN(+v)) c[k] = toMinor(v, cur); }
    if (c.minimum != null && c.minimum < toMinor(lo, cur)) throw new Error(`Stripe’s smallest payment is ${money(lo, cur)}.`);
    if (c.minimum != null && c.maximum != null && c.minimum > c.maximum) throw new Error('The minimum is higher than the maximum.');
    if (c.preset != null && ((c.minimum != null && c.preset < c.minimum) || (c.maximum != null && c.preset > c.maximum))) throw new Error('The suggested amount must sit between the minimum and maximum.');
    return { custom_unit_amount: c };
  }
  function copyLink(old) {
    const ac = old.after_completion || {};
    const ct = {};
    for (const k of ['submit', 'after_submit', 'shipping_address', 'terms_of_service_acceptance']) if (old.custom_text?.[k]?.message) ct[k] = { message: old.custom_text[k].message };
    return {
      after_completion: ac.type === 'redirect' && ac.redirect?.url ? { type: 'redirect', redirect: { url: ac.redirect.url } }
        : { type: 'hosted_confirmation', ...(ac.hosted_confirmation?.custom_message ? { hosted_confirmation: { custom_message: ac.hosted_confirmation.custom_message } } : {}) },
      allow_promotion_codes: old.allow_promotion_codes || undefined,
      billing_address_collection: old.billing_address_collection !== 'auto' ? old.billing_address_collection : undefined,
      custom_fields: (old.custom_fields || []).map(f => ({ key: f.key, type: f.type, optional: f.optional, label: { type: 'custom', custom: f.label?.custom || f.key },
        ...(f.type === 'dropdown' ? { dropdown: { options: (f.dropdown?.options || []).map(o => ({ label: o.label, value: o.value })) } } : {}) })),
      custom_text: Object.keys(ct).length ? ct : undefined,
      customer_creation: old.customer_creation || undefined,
      phone_number_collection: old.phone_number_collection?.enabled ? { enabled: true } : undefined,
      submit_type: old.submit_type && old.submit_type !== 'auto' ? old.submit_type : undefined,
      automatic_tax: old.automatic_tax?.enabled ? { enabled: true } : undefined,
      tax_id_collection: old.tax_id_collection?.enabled ? { enabled: true } : undefined,
      invoice_creation: old.invoice_creation?.enabled ? { enabled: true } : undefined
    };
  }
  async function createLink(params, fallback) {
    try { return await stripe('POST', 'payment_links', params); }
    catch (e) { if (!fallback || /isn’t allowed/.test(e.message)) throw e; return stripe('POST', 'payment_links', fallback); }
  }
  // Point the site and apps at a new link. Returns true if site content changed (needs a publish).
  function repoint(oldUrl, newUrl, label) {
    const code = linkCode(oldUrl); if (!code) return false;
    let changed = false;
    const site = ctx.loadSite();
    if (linkCode(site.donate?.url) === code) { site.donate.url = newUrl; ctx.saveSite(site); changed = true; }
    const apps = ctx.loadApps(); let ac = false;
    for (const a of apps) if (linkCode(a.primaryUrl) === code) { a.primaryUrl = newUrl; if (label && a.price) a.price = label; ac = true; }
    if (ac) { ctx.saveApps(apps); changed = true; }
    return changed;
  }

  // ---------- actions ----------
  async function setPrice(b) {
    const old = await stripe('GET', `payment_links/${encodeURIComponent(b.linkId)}?expand[]=line_items`);
    const li = old.line_items?.data?.[0]; if (!li) throw new Error('That payment link has no item.');
    if (old.line_items.data.length > 1) throw new Error('This link sells several items. Change it in the Stripe dashboard.');
    const oldPrice = li.price, cur = (b.currency || oldPrice.currency).toLowerCase(), prodId = typeof oldPrice.product === 'string' ? oldPrice.product : oldPrice.product.id;
    if (oldPrice.recurring) throw new Error('Subscription prices are managed in the Stripe dashboard.');
    const notes = [];
    // product name / description are editable in place
    const prod = await stripe('GET', `products/${prodId}`);
    const pp = {};
    if (b.name && b.name.trim() !== prod.name) pp.name = b.name.trim().slice(0, 250);
    if (b.description != null && b.description.trim() !== (prod.description || '')) pp.description = b.description.trim() || '';
    if (Object.keys(pp).length) { await stripe('POST', `products/${prodId}`, pp); notes.push('Product details updated'); }
    const want = validate(b, cur);
    const same = shapePrice(oldPrice);
    const unchanged = b.mode === same.mode && cur === oldPrice.currency && (b.mode === 'fixed' ? toMinor(b.amount, cur) === oldPrice.unit_amount
      : ['minimum', 'maximum', 'preset'].every(k => (want.custom_unit_amount[k] ?? null) === (oldPrice.custom_unit_amount?.[k] ?? null)));
    if (unchanged) { cache = null; return { changed: false, notes: notes.length ? notes : ['Nothing to change'], link: old.url }; }
    const price = await stripe('POST', 'prices', { product: prodId, currency: cur, ...want, nickname: b.nickname || undefined,
      tax_behavior: oldPrice.tax_behavior && oldPrice.tax_behavior !== 'unspecified' ? oldPrice.tax_behavior : undefined, metadata: { set_by: 'studio-hub' } });
    await stripe('POST', `products/${prodId}`, { default_price: price.id }).catch(() => {});
    const base = { line_items: [{ price: price.id, quantity: li.quantity || 1 }], metadata: { ...(old.metadata || {}), replaces: old.id } };
    const link = await createLink({ ...base, ...copyLink(old) }, { ...base, ...(old.submit_type && old.submit_type !== 'auto' ? { submit_type: old.submit_type } : {}) });
    const label = priceLabel(shapePrice(price));
    ctx.swapPerkLink?.(old.id, link.id);
    const siteChanged = repoint(old.url, link.url, label);
    let retired = false;
    if (!siteChanged && b.deactivateOld !== false) { await stripe('POST', `payment_links/${old.id}`, { active: false }); retired = true; }
    cache = null;
    ctx.alert?.(`🏷️ **${b.name || prod.name}** price changed: ${priceLabel(same)} → **${label}**`, [`New payment link: ${link.url}`, siteChanged ? 'The site now points at the new link; publish to make it live.' : retired ? 'The old link was switched off.' : ''].filter(Boolean).join('\n'));
    return { changed: true, link: link.url, linkId: link.id, oldLinkId: old.id, label, siteChanged, retired, notes };
  }
  async function createProduct(b) {
    const cur = String(b.currency || ctx.loadSite().community?.currency || 'AUD').toLowerCase();
    const name = String(b.name || '').trim(); if (!name) throw new Error('Give the product a name.');
    const want = validate(b, cur);
    const prod = await stripe('POST', 'products', { name: name.slice(0, 250), description: String(b.description || '').trim() || undefined, metadata: { set_by: 'studio-hub' } });
    const price = await stripe('POST', 'prices', { product: prod.id, currency: cur, ...want });
    await stripe('POST', `products/${prod.id}`, { default_price: price.id }).catch(() => {});
    const site = ctx.siteUrl.replace(/\/$/, '');
    const params = { line_items: [{ price: price.id, quantity: 1 }], metadata: { set_by: 'studio-hub' },
      after_completion: b.redirect ? { type: 'redirect', redirect: { url: /^https:\/\//.test(b.redirect) ? b.redirect : `${site}/?thanks=1` } } : { type: 'hosted_confirmation', hosted_confirmation: { custom_message: String(b.thanks || 'Thank you! Check your inbox for your receipt.').slice(0, 500) } },
      submit_type: b.donation ? 'donate' : 'pay', allow_promotion_codes: b.promo ? true : undefined,
      custom_fields: b.wallField ? [{ key: 'wallname', type: 'text', optional: true, label: { type: 'custom', custom: 'Name for the supporters wall (optional)' } }] : undefined };
    const link = await createLink(params, { line_items: params.line_items, submit_type: params.submit_type });
    if (b.perk) ctx.addPerk?.(prod.id);
    let attached = null;
    if (b.appId) attached = attach({ url: link.url, appId: b.appId, label: priceLabel(shapePrice(price)), buttonLabel: b.buttonLabel });
    cache = null;
    ctx.alert?.(`🏷️ New product **${name}** (${priceLabel(shapePrice(price))})`, `Payment link: ${link.url}${attached ? `\nAttached to ${attached.name}; publish to show it.` : ''}`);
    return { link: link.url, linkId: link.id, productId: prod.id, attached };
  }
  function attach({ url, appId, label, buttonLabel }) {
    const apps = ctx.loadApps(), a = apps.find(x => x.id === appId);
    if (!a) throw new Error('App not found');
    a.primaryUrl = url; a.primaryLabel = buttonLabel || a.primaryLabel || 'Buy now'; if (label) a.price = label;
    ctx.saveApps(apps); cache = null;
    return { id: a.id, name: a.name };
  }
  async function setActive(id, active) {
    const l = await stripe('POST', `payment_links/${encodeURIComponent(id)}`, { active: !!active });
    cache = null;
    ctx.alert?.(`🏷️ Payment link ${active ? 'switched on' : 'switched off'}`, l.url);
    return { active: l.active };
  }
  async function useAsDonate(id) {
    const l = await stripe('GET', `payment_links/${encodeURIComponent(id)}`);
    if (!l.active) throw new Error('Switch that link on first.');
    const site = ctx.loadSite(); site.donate = { ...(site.donate || {}), url: l.url, enabled: true }; ctx.saveSite(site); cache = null;
    return { url: l.url };
  }

  async function route(path, M, body) {
    if (path === '/api/store' && M === 'GET') return overview(false);
    if (path === '/api/store/refresh' && M === 'POST') return overview(true);
    if (path === '/api/store/price' && M === 'POST') { const r = await setPrice(body); return { result: r, ...(await overview(true)) }; }
    if (path === '/api/store/product' && M === 'POST') { const r = await createProduct(body); return { result: r, ...(await overview(true)) }; }
    if (path === '/api/store/active' && M === 'POST') { await setActive(body.id, body.active); return overview(true); }
    if (path === '/api/store/donate' && M === 'POST') { const r = await useAsDonate(body.id); return { result: r, ...(await overview(true)) }; }
    if (path === '/api/store/attach' && M === 'POST') { const r = attach(body); return { result: r, ...(await overview(true)) }; }
    if (path === '/api/store/key' && M === 'PUT') {
      const k = String(body.key || '').trim();
      if (k && !/^(rk|sk)_(live|test)_[\w]+$/.test(k)) throw new Error('That does not look like a Stripe key.');
      ctx.saveSecrets({ stripeWriteKey: k }); cache = null;
      return overview(true);
    }
    return undefined;
  }
  return { route, overview, linkCode, priceLabel, shapePrice, validate, stripe, money, invalidate: () => { cache = null; } };
}
