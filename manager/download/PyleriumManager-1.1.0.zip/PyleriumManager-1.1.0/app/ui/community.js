// Community: submissions inbox, supporters (Stripe sync + supporter codes) and the Supply caffeine / perks settings.
import { R, S, $, $$, esc, api, toast, confirmBox, formBox, touchSite, emit, refreshStatus, rel, on, clone, fmtMoney } from './core.js';
import * as Perks from './perks.js';

let tab = 'inbox';
let stripeKey = '';
let loadingInbox = false;
const get = (o, p) => p.split('.').reduce((x, k) => x?.[k], o);
const set = (o, p, v) => { const ks = p.split('.'); let x = o; for (const k of ks.slice(0, -1)) x = x[k] = x[k] ?? {}; x[ks.at(-1)] = v; };
const money = n => fmtMoney(n);
const threshold = () => +(S.siteDraft?.community?.threshold ?? 10);

export function init() {
  $('#commTabs').addEventListener('click', e => { const b = e.target.closest('[data-ct]'); if (b) location.hash = '#/community/' + b.dataset.ct; });
  const P = $('#commPanel');
  P.addEventListener('input', e => {
    const k = e.target.dataset.k; if (!k) return;
    let v = e.target.type === 'checkbox' ? e.target.checked : e.target.type === 'number' ? Math.max(0, +e.target.value) : e.target.value;
    if (k === 'community.perks') v = e.target.value.split('\n').map(s => s.trim()).filter(Boolean);
    set(S.siteDraft, k, v); touchSite();
    if (e.target.dataset.live) render();
  });
  P.addEventListener('click', onClick);
  P.addEventListener('click', e => { if (tab === 'perks') Perks.onClick(e); });
  P.addEventListener('change', e => { if (tab === 'perks') Perks.onChange(e); });
  S.reloadSupporters = async () => { await loadSupporters(); if (tab === 'supporters' && !$('main[data-view=community]').hidden) render(); };
  on(w => { if (w === 'site' && !$('main[data-view=community]').hidden) render(); });
}
export async function show(sub) {
  if (sub) tab = sub;
  $$('#commTabs button').forEach(b => b.classList.toggle('on', b.dataset.ct === tab));
  if (tab === 'supporters' || tab === 'settings') await loadSupporters();
  if (tab === 'supporters') await Perks.load().catch(() => {});
  if (tab === 'inbox' && !S.subs) await loadInbox();
  render();
}
export async function loadInbox(quiet) {
  if (loadingInbox) return; loadingInbox = true;
  try { S.subs = await api('GET', '/api/submissions'); emit('subs'); } catch (err) { if (!quiet) toast(err.message, 'err'); }
  finally { loadingInbox = false; }
  if (!$('main[data-view=community]').hidden && tab === 'inbox') render();
  counts();
}
async function loadSupporters() {
  try { const r = await api('GET', '/api/supporters'); S.supporters = r.supporters; stripeKey = r.stripeKey; counts(); } catch (err) { toast(err.message, 'err'); }
}
function counts() {
  const p = (S.subs?.items || []).filter(i => !i.handled && i.state !== 'closed').length;
  $('#nInbox').textContent = p || ''; $('#nSupp').textContent = S.supporters ? S.supporters.length || '' : '';
}

function render() {
  const P = $('#commPanel');
  if (tab === 'inbox') P.innerHTML = inboxHTML();
  if (tab === 'supporters') P.innerHTML = supportersHTML();
  if (tab === 'settings') P.innerHTML = settingsHTML();
  if (tab === 'perks') Perks.show(P);
}

// ---------- inbox ----------
function inboxHTML() {
  const s = S.subs;
  const c = S.siteDraft.community || {};
  const items = s?.items || [];
  const open = items.filter(i => !i.handled), done = items.filter(i => i.handled);
  return `<div class="card">
    <div class="card-head"><h3>${R.icon('inbox')}Submissions</h3><div class="row"><button type="button" class="hbtn ghost sm" id="pasteSub">${R.icon('mail')}Add from email</button><button type="button" class="hbtn primary sm" id="refreshSubs">${R.icon('refresh')}Check GitHub</button></div></div>
    <p class="sub">Supporters submit from your site's Community section. GitHub submissions arrive as issues on <code>${esc(s?.repo || c.repo || '')}</code>; email ones you paste here. A green tick means the sender proved they hold a valid supporter code.</p>
    ${!c.submissionsEnabled ? `<p class="note lock"><span>${R.icon('lock')}</span>Submissions are turned off on the site. Turn them on in Caffeine &amp; perks.</p>` : ''}
    ${s?.ghError ? `<p class="note lock"><span>${R.icon('info')}</span>Couldn't read GitHub issues: ${esc(s.ghError)}</p>` : ''}
    ${!s ? `<p class="empty-sm"><span class="spinner"></span> Loading…</p>` : !items.length ? `<div class="emptystate">${R.icon('inbox')}<h4>No submissions yet</h4><p>When supporters send apps from your site, they appear here for review.</p></div>` : ''}
    <div class="sublist">${open.map(subCard).join('')}</div>
    ${done.length ? `<details class="done-subs"><summary>Reviewed (${done.length})</summary><div class="sublist">${done.map(subCard).join('')}</div></details>` : ''}
  </div>`;
}
function subCard(it) {
  const d = it.data;
  if (!d) return `<div class="subcard bad"><b>Unreadable submission</b> ${it.url ? `<a href="${esc(it.url)}" target="_blank" rel="noopener">Open</a>` : ''}</div>`;
  const cat = R.categoryOf(d.category);
  return `<div class="subcard${it.handled ? ' handled' : ''}">
    <div class="sc-head">
      <span class="sc-ico">${d.icon ? `<img src="${esc(d.icon)}" alt="">` : R.icon(cat.icon)}</span>
      <div class="sc-title"><b>${esc(d.name)}</b><span>${esc(d.tagline)}</span></div>
      ${it.verified ? `<span class="vbadge ok">${R.icon('check')}Supporter: ${esc(it.verified.name)}${it.verified.total ? ` · ${money(it.verified.total)}` : ''}</span>` : `<span class="vbadge warn">${R.icon('info')}Not verified</span>`}
    </div>
    ${d.description ? `<p class="sc-desc">${esc(d.description)}</p>` : ''}
    <div class="sc-meta">
      <span>${R.icon(cat.icon)}${esc(cat.label)}</span>${d.platform ? `<span>${R.icon('monitor')}${esc(d.platform)}</span>` : ''}
      <span>${R.icon('users')}${d.author?.url ? `<a href="${esc(d.author.url)}" target="_blank" rel="noopener">${esc(d.author.name)}</a>` : esc(d.author?.name || '')}</span>
      <span>${R.icon(it.source === 'github' ? 'github' : 'mail')}${it.source === 'github' ? `<a href="${esc(it.url)}" target="_blank" rel="noopener">#${it.number}</a> by @${esc(it.user)}` : 'Email'}</span>
      <span>${R.icon('calendar')}${rel(it.createdAt)}</span>
    </div>
    <div class="sc-links">${[['Download', d.url, 'download'], ['Source', d.repoUrl, 'github'], ['Video', d.videoUrl, 'youtube']].filter(x => x[1]).map(([l, u, ic]) => `<a class="chip" href="${esc(u)}" target="_blank" rel="noopener">${R.icon(ic)}${l}</a>`).join('')}</div>
    ${(d.screenshots || []).length ? `<div class="sc-shots">${d.screenshots.map(u => `<a href="${esc(u)}" target="_blank" rel="noopener"><img src="${esc(u)}" alt="" loading="lazy" referrerpolicy="no-referrer"></a>`).join('')}</div>` : ''}
    <div class="sc-acts">${it.handled
      ? `<span class="hstate ${it.handled}">${it.handled === 'accepted' ? R.icon('check') + 'Accepted' : R.icon('x') + 'Declined'}</span><button type="button" class="hbtn ghost sm" data-reopen="${esc(it.key)}">Move back to inbox</button>`
      : `<button type="button" class="hbtn ghost sm danger" data-reject="${esc(it.key)}">${R.icon('x')}Decline</button><span class="sp"></span><button type="button" class="hbtn ghost sm" data-accept="${esc(it.key)}">${R.icon('check')}Accept as draft</button><button type="button" class="hbtn primary sm" data-accept="${esc(it.key)}" data-pub="1">${R.icon('rocket')}Accept &amp; show on site</button>`}</div>
  </div>`;
}

// ---------- supporters ----------
function supportersHTML() {
  const list = S.supporters || [];
  const th = threshold();
  const eligible = s => (s.total || 0) >= th || s.type === 'lifetime' || s.type === 'manual';
  const sorted = [...list].sort((a, b) => (b.total || 0) - (a.total || 0));
  const total = list.reduce((n, s) => n + (s.total || 0), 0);
  const noCode = list.filter(s => eligible(s) && !s.code).length;
  return `<div class="card">
    <div class="card-head"><h3>${R.icon('users')}Supporters</h3><div class="row">
      <button type="button" class="hbtn ghost sm" id="addSupp">${R.icon('plus')}Add manually</button>
      <button type="button" class="hbtn primary sm" id="stripeSync"${stripeKey ? '' : ' disabled title="Add a Stripe key in Caffeine & perks"'}>${R.icon('refresh')}Sync from Stripe</button></div></div>
    <div class="stats-row"><div><b>${list.length}</b><span>supporters</span></div><div><b>${money(total)}</b><span>total caffeine</span></div><div><b>${list.filter(eligible).length}</b><span>can submit (≥ ${money(th)})</span></div><div><b>${list.filter(s => s.wall).length}</b><span>on the wall</span></div></div>
    ${!stripeKey ? `<p class="note"><span>${R.icon('key')}</span>Connect Stripe in <a href="#/community/settings">Caffeine &amp; perks</a> to pull donors and lifetime buyers automatically. You can also add people by hand.</p>` : ''}
    ${noCode ? `<div class="bulk"><span>${R.icon('key')}${noCode} eligible supporter${noCode > 1 ? 's don’t' : ' doesn’t'} have a code yet.</span><button type="button" class="hbtn primary sm" id="codesAll">Issue codes to all</button></div>` : ''}
    <div class="supp-table">${sorted.length ? `<div class="st-head"><span>Supporter</span><span>Gave</span><span>Supporter code</span><span>Wall</span><span></span></div>` : ''}
    ${sorted.map(s => `<div class="st-row${eligible(s) ? '' : ' below'}">
      <div class="st-who"><b>${esc(s.name || s.email || 'Unnamed')}</b><small>${esc(s.email || '')}</small><span class="tchip t-${esc(s.type)}">${esc({ donation: 'Donation', purchase: 'Purchase', lifetime: 'Lifetime', manual: 'Manual', perk: 'Perks' }[s.type] || s.type)}</span>${Perks.chipsFor(s.id) ? `<span class="pk-minis">${Perks.chipsFor(s.id)}</span>` : ''}</div>
      <div class="st-amt"><b>${money(s.total)}</b>${s.otherCurrency ? `<small>+${(+s.otherCurrency).toFixed(2)} other</small>` : ''}${eligible(s) ? `<span class="elig">${R.icon('check')}Eligible</span>` : `<small>Needs ${money(th)}</small>`}</div>
      <div class="st-code">${s.code && !s.revoked ? `<code>${esc(s.code)}</code><div class="row"><button type="button" class="act" data-copycode="${esc(s.code)}" title="Copy">${R.icon('copy')}</button><a class="act" href="${mailto(s)}" title="Email the code">${R.icon('mail')}</a><button type="button" class="act" data-reissue="${esc(s.id)}" title="Replace with a new code">${R.icon('refresh')}</button><button type="button" class="act del" data-revoke="${esc(s.id)}" title="Revoke">${R.icon('x')}</button></div>`
        : `${s.revoked ? '<small class="revoked">Revoked</small>' : ''}<button type="button" class="hbtn ghost sm" data-issue="${esc(s.id)}">${R.icon('key')}Issue code</button>`}</div>
      <div class="st-wall"><label class="switch"><input type="checkbox" data-wall="${esc(s.id)}"${s.wall ? ' checked' : ''}><span class="track"><i></i></span></label>${s.wall ? `<small>${esc(s.wallName || s.name || '')}</small>` : ''}</div>
      <div class="st-acts"><button type="button" class="act" data-giveperk="${esc(s.id)}" title="Give a perk">${R.icon('gift')}</button><button type="button" class="act" data-esupp="${esc(s.id)}" title="Edit">${R.icon('edit')}</button><button type="button" class="act del" data-dsupp="${esc(s.id)}" title="Delete">${R.icon('trash')}</button></div>
    </div>`).join('') || `<div class="emptystate">${R.icon('can')}<h4>No supporters yet</h4><p>Share your Supply caffeine link. Donors show up here after a Stripe sync.</p></div>`}</div>
    <p class="note"><span>${R.icon('shield')}</span>Names, emails and codes stay in the hub. The website only receives scrambled (hashed) codes, plus the names you put on the wall.</p>
  </div>`;
}
function mailto(s) {
  const url = `${S.config.siteUrl}/#submit`;
  const subject = `Your ${S.site?.brand?.name || 'supporter'} supporter code`;
  const body = `Hi ${s.name || 'there'},\n\nThank you so much for supplying the caffeine! Your support keeps the apps coming.\n\nHere is your supporter code:\n\n    ${s.code}\n\nIt unlocks app submissions on the ${S.site?.brand?.name || 'studio'} showcase. Open ${url}, enter the code, and tell us about your app, mod or tool. Accepted submissions get their own card with your name and links, and standout picks can be featured.\n\nThanks again,\n${S.site?.brand?.name || ''}`;
  return `mailto:${encodeURIComponent(s.email || '')}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

// ---------- settings ----------
function settingsHTML() {
  const d = S.siteDraft.donate || {}, c = S.siteDraft.community || {};
  const f = (k, label, o = {}) => { const v = get(S.siteDraft, k) ?? ''; return o.type === 'checkbox' ? `<label class="switch"><input type="checkbox" data-k="${k}"${o.live ? ' data-live="1"' : ''}${v ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">${esc(label)}</span></label>`
    : o.type === 'textarea' ? `<label class="fld"><span>${esc(label)}${o.help ? ` <small>${esc(o.help)}</small>` : ''}</span><textarea data-k="${k}" rows="${o.rows || 3}">${esc(Array.isArray(v) ? v.join('\n') : v)}</textarea></label>`
    : `<label class="fld"><span>${esc(label)}${o.help ? ` <small>${esc(o.help)}</small>` : ''}</span><input data-k="${k}" type="${o.type || 'text'}" value="${esc(v)}" placeholder="${esc(o.ph || '')}"${o.live ? ' data-live="1"' : ''}></label>`; };
  return `<div class="cols">
    <div class="card"><h3>${R.icon('can')}Supply caffeine</h3>
      <p class="sub">A donation button in the nav, hero, community and support sections. It links to your Stripe Payment Link.</p>
      ${f('donate.enabled', 'Show the Supply caffeine button', { type: 'checkbox', live: 1 })}
      ${f('donate.label', 'Button label')}
      ${f('donate.url', 'Stripe Payment Link', { ph: 'https://buy.stripe.com/…', live: 1 })}
      ${f('donate.showInNav', 'Show it at the top of every page, in the navigation bar', { type: 'checkbox' })}
      ${f('donate.floating', 'Floating energy-drink badge in the bottom corner (like Buy Me a Coffee)', { type: 'checkbox' })}
      <div class="mini-pv center"><span class="pv-lbl">Preview</span><span class="caffeine-pv"><span class="steam"><i></i><i></i><i></i></span>${R.icon('can')}${esc(d.label || 'Supply caffeine')}</span>${!d.url ? `<small class="warn-txt">${R.icon('info')}Hidden on the site until you add the link.</small>` : ''}</div>
      <details class="howto" ${d.url ? '' : 'open'}><summary>${R.icon('info')}How to make the Stripe link (2 minutes)</summary><ol>
        <li>Stripe Dashboard → <b>Payment Links</b> → <b>New</b>.</li>
        <li>Add a product called <i>Supply caffeine</i> and choose <b>Customers choose what to pay</b>. Set a suggested amount (for example 10) and a small minimum, in your currency.</li>
        <li>Under <b>Options</b>, add a custom text field labelled <i>Name for the supporters wall (optional)</i> and make it optional. The hub reads it when you sync.</li>
        <li>Under <b>After payment</b>, choose <b>Don't show confirmation page</b> and redirect to <code>${esc(S.config.siteUrl)}/#thanks</code>.</li>
        <li>Create it, copy the link and paste it above.</li></ol></details>
    </div>
    <div class="card"><h3>${R.icon('crown')}Supporter submissions</h3>
      ${f('community.submissionsEnabled', 'Let supporters submit their own apps from the site', { type: 'checkbox', live: 1 })}
      <div class="f2">${f('community.threshold', 'Minimum to qualify', { type: 'number' })}${f('community.repo', 'GitHub repo for submissions', { help: 'issues land here' })}</div>
      ${f('community.perks', 'Benefits listed with submissions', { type: 'textarea', rows: 4, help: 'one per line' })}
      <p class="note"><span>${R.icon('gift')}</span>Want rewards people can unlock: downloads, keys, discount codes, Discord roles, lucky drops? Make them in <a href="#/community/perks">Perks</a>.</p>
      ${f('community.showWall', 'Show the supporters wall', { type: 'checkbox' })}
      ${f('community.wallTitle', 'Wall title')}
      <p class="note"><span>${R.icon('info')}</span>Your site is static, so the submit form is unlocked with a personal code you issue from Supporters. Every submission still comes to you for review here, with proof of which supporter sent it.</p>
    </div>
    <div class="card"><h3>${R.icon('key')}Connect Stripe <span class="muted">(optional)</span></h3>
      <p class="sub">Lets the hub find donors and lifetime buyers automatically. The key is stored only in <code>studio-hub/data/secrets.json</code> on this computer and is never published.</p>
      <form class="inrow" id="keyForm"><input name="key" type="password" autocomplete="off" placeholder="${stripeKey ? esc(stripeKey) : 'rk_live_…'}"><button class="hbtn primary sm" type="submit">${R.icon('save')}${stripeKey ? 'Replace' : 'Save key'}</button>${stripeKey ? `<button class="hbtn ghost sm" type="button" id="clearKey">Remove</button>` : ''}</form>
      ${stripeKey ? `<p class="ok-txt">${R.icon('check')}Connected (${esc(stripeKey)})</p>` : ''}
      <details class="howto"><summary>${R.icon('info')}Make a safe, read-only key</summary><ol>
        <li>Stripe Dashboard → <b>Developers</b> → <b>API keys</b> → <b>Create restricted key</b>.</li>
        <li>Name it <i>Pylerium Manager</i>. Set <b>Charges</b> and <b>Checkout Sessions</b> to <b>Read</b>. Leave everything else as None.</li>
        <li>Create it and paste it here. A restricted key can't move money or change anything.</li></ol></details>
    </div>
  </div>`;
}

// ---------- actions ----------
async function onClick(e) {
  const t = e.target;
  try {
    if (t.closest('#refreshSubs')) { S.subs = null; render(); await loadInbox(); toast('Checked GitHub for submissions'); return; }
    if (t.closest('#pasteSub')) {
      const r = await formBox('Add a submission from email', 'Paste the whole email body. The hub finds the submission data in it.', [{ name: 'text', label: 'Email text', type: 'textarea', rows: 10, mono: true }], 'Add');
      if (!r?.text.trim()) return;
      S.subs = await api('POST', '/api/submissions/paste', { text: r.text }); emit('subs'); render(); toast('Added to the inbox'); return;
    }
    const acc = t.closest('[data-accept]');
    if (acc) {
      const it = S.subs.items.find(i => i.key === acc.dataset.accept), pub = !!acc.dataset.pub;
      const gh = it.source === 'github';
      const r = await formBox(pub ? `Accept ${it.data.name} and show it` : `Accept ${it.data.name}`, `${pub ? 'It goes live with your next Publish.' : 'It is added as a draft so you can polish it first.'} Its icon and screenshots are saved into the hub.${it.verified ? '' : '<br><b style="color:#FBBF24">This sender is not a verified supporter.</b>'}`,
        gh ? [{ name: 'reply', label: 'Reply on GitHub', type: 'textarea', rows: 3, value: `Thanks ${it.data.author?.name || ''}! ${it.data.name} has been accepted and will appear in the Community section of the ${S.site?.brand?.name || 'studio'} showcase shortly.` }, { name: 'close', label: 'Close the issue', type: 'checkbox', value: true }] : [], pub ? 'Accept & show' : 'Accept');
      if (!r) return;
      const res = await api('POST', '/api/submissions/accept', { key: it.key, publish: pub, reply: r.reply || '', close: !!r.close });
      S.apps = res.apps; emit('apps'); await loadInbox(); refreshStatus();
      toast(`${res.app.name} added to your apps`);
      S.openEditor?.(res.app.id);
      return;
    }
    const rej = t.closest('[data-reject]');
    if (rej) {
      const it = S.subs.items.find(i => i.key === rej.dataset.reject);
      const r = await formBox(`Decline ${it.data?.name || 'submission'}?`, 'It moves to Reviewed. Nothing is added to your apps.', it.source === 'github' ? [{ name: 'reply', label: 'Reply on GitHub (optional)', type: 'textarea', rows: 3, value: '' }, { name: 'close', label: 'Close the issue', type: 'checkbox', value: true }] : [], 'Decline');
      if (!r) return;
      S.subs = await api('POST', '/api/submissions/reject', { key: it.key, reply: r.reply || '', close: !!r.close }); emit('subs'); render(); return;
    }
    const ro = t.closest('[data-reopen]'); if (ro) { S.subs = await api('POST', '/api/submissions/reopen', { key: ro.dataset.reopen }); emit('subs'); render(); return; }

    if (t.closest('#stripeSync')) {
      const b = t.closest('#stripeSync'); b.disabled = true; b.innerHTML = '<span class="spinner"></span>Syncing…';
      const r = await api('POST', '/api/stripe/sync'); S.supporters = r.supporters; render(); refreshStatus();
      toast(`Stripe: ${r.added} new, ${r.updated} updated`); return;
    }
    if (t.closest('#addSupp')) return editSupporter({});
    const gp = t.closest('[data-giveperk]'); if (gp) return Perks.give({ supporterId: gp.dataset.giveperk });
    const es = t.closest('[data-esupp]'); if (es) return editSupporter(S.supporters.find(s => s.id === es.dataset.esupp));
    const ds = t.closest('[data-dsupp]');
    if (ds) { const s = S.supporters.find(x => x.id === ds.dataset.dsupp); if (!(await confirmBox(`Delete ${s.name || s.email}?`, 'Their code stops working after your next publish.'))) return; S.supporters = (await api('DELETE', '/api/supporters/' + s.id)).supporters; render(); refreshStatus(); return; }
    const is = t.closest('[data-issue]') || t.closest('[data-reissue]');
    if (is) {
      const id = is.dataset.issue || is.dataset.reissue;
      if (is.dataset.reissue && !(await confirmBox('Replace this code?', 'The old code stops working after your next publish.', 'Replace', false))) return;
      const r = await api('POST', '/api/supporters/code', { id }); S.supporters = r.supporters; render(); refreshStatus();
      toast(`Code ready for ${r.supporter.name || r.supporter.email}. Email it, then publish.`); return;
    }
    if (t.closest('#codesAll')) {
      const th = threshold();
      const todo = S.supporters.filter(s => !s.code && ((s.total || 0) >= th || s.type === 'lifetime' || s.type === 'manual'));
      for (const s of todo) S.supporters = (await api('POST', '/api/supporters/code', { id: s.id })).supporters;
      render(); refreshStatus(); toast(`Issued ${todo.length} codes. Use the mail buttons to send them, then publish.`); return;
    }
    const rv = t.closest('[data-revoke]'); if (rv) { if (!(await confirmBox('Revoke this code?', 'It stops working after your next publish.', 'Revoke'))) return; S.supporters = (await api('POST', '/api/supporters/revoke', { id: rv.dataset.revoke })).supporters; render(); refreshStatus(); return; }
    const cc = t.closest('[data-copycode]'); if (cc) { await navigator.clipboard.writeText(cc.dataset.copycode); toast('Code copied'); return; }
    if (t.closest('#clearKey')) { await api('PUT', '/api/secrets', { stripeKey: '' }); stripeKey = ''; render(); toast('Stripe key removed'); return; }
  } catch (err) { toast(err.message, 'err'); render(); }
}
$('#commPanel')?.addEventListener('change', async e => {
  const w = e.target.closest('[data-wall]'); if (!w) return;
  const s = S.supporters.find(x => x.id === w.dataset.wall);
  let wallName = s.wallName;
  if (w.checked && !wallName) {
    const r = await formBox('Name on the wall', 'How should they appear? Only add people who are happy to be listed.', [{ name: 'wallName', label: 'Display name', value: s.name || '' }], 'Add to wall');
    if (!r) { w.checked = false; return; }
    wallName = r.wallName.trim();
  }
  try { S.supporters = (await api('POST', '/api/supporters', { supporter: { ...s, wall: w.checked, wallName } })).supporters; render(); refreshStatus(); } catch (err) { toast(err.message, 'err'); }
});
async function editSupporter(s) {
  const r = await formBox(s.id ? 'Edit supporter' : 'Add a supporter', 'For lifetime buyers, people who paid another way, or anyone you want to give submission access.', [
    { name: 'name', label: 'Name', value: s.name || '' }, { name: 'email', label: 'Email', type: 'email', value: s.email || '' },
    { name: 'type', label: 'Type', type: 'select', value: s.type || 'manual', options: [{ value: 'donation', label: 'Donation' }, { value: 'lifetime', label: 'Lifetime licence' }, { value: 'purchase', label: 'Other purchase' }, { value: 'manual', label: 'Manual (always eligible)' }] },
    { name: 'total', label: 'Amount given', type: 'number', value: s.total || 0 },
    { name: 'wallName', label: 'Name on the wall', value: s.wallName || '', help: 'optional' },
    { name: 'notes', label: 'Notes', type: 'textarea', rows: 2, value: s.notes || '' }], s.id ? 'Save' : 'Add');
  if (!r) return;
  S.supporters = (await api('POST', '/api/supporters', { supporter: { ...s, ...r, wall: s.wall || false } })).supporters; render(); refreshStatus();
}
document.addEventListener('submit', async e => {
  if (e.target.id !== 'keyForm') return;
  e.preventDefault();
  try { const r = await api('PUT', '/api/secrets', { stripeKey: e.target.key.value.trim() }); stripeKey = r.stripeKey; render(); toast('Stripe connected'); } catch (err) { toast(err.message, 'err'); }
});
