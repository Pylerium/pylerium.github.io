// Licences: which apps need a key, drop-in key checks for each language, manual keys, and every key issued.
import { R, S, $, esc, api, toast, rel, emit } from './core.js';

const I = n => R.icon(n);
let L = null, err = '', loading = false, q = '', fresh = null;
const F = { app: '', email: '', name: '', send: true };

export function init() {
  const P = $('#licPanel');
  P.addEventListener('click', onClick);
  P.addEventListener('change', onChange);
  P.addEventListener('submit', onSubmit);
  P.addEventListener('input', e => {
    const t = e.target;
    if (t.dataset.f) F[t.dataset.f] = t.type === 'checkbox' ? t.checked : t.value;
    if (t.id === 'licQ') { q = t.value; renderTable(); }
  });
}
export async function show() { await load(); }

async function load() {
  if (loading) return; loading = true; err = '';
  if (!L) render();
  try { L = await api('GET', '/api/licences'); } catch (e) { err = e.message; }
  loading = false;
  if (L && !F.app) F.app = (L.apps.find(a => a.licensed) || L.apps[0])?.id || '';
  render();
}

const appIcon = a => a.iconImage ? `<img src="/media/${esc(a.iconImage)}" alt="">` : `<span class="lc-gl" style="--ac:var(--${esc(a.accent || 'violet')}, #8B5CF6)">${I(a.glyph || 'package')}</span>`;
const kitBtns = a => (L.kits || []).map(k => `<button type="button" class="lc-kit" data-kit="${k.id}" data-app="${esc(a.id)}" title="Download the ${esc(k.label)} licence check for ${esc(a.name)} (${esc(k.files.join(' + '))})">${I('code')}${esc(k.label)}</button>`).join('');

function render() {
  const P = $('#licPanel');
  if (!L && !err) { P.innerHTML = `<div class="card lv-loading"><span class="spinner"></span>Loading licences…</div>`; return; }
  if (!L) { P.innerHTML = `<div class="card"><p class="note lock"><span>${I('alert')}</span>${esc(err)}</p></div>`; return; }
  const licensed = L.apps.filter(a => a.licensed), total = L.issued.length;
  P.innerHTML = `
  <div class="lc-tiles">
    <div class="tile"><span>Licensed apps</span><b>${licensed.length}<small> of ${L.apps.length}</small></b></div>
    <div class="tile"><span>Keys issued</span><b>${total}</b></div>
    <div class="tile"><span>Last key</span><b>${total ? esc(rel(L.issued[0].iat)) : '—'}</b></div>
    <div class="tile"><span>Kits</span><b>${(L.kits || []).length}<small> languages</small></b></div>
  </div>
  <div class="st-grid">
    <div class="st-main">
      <div class="card">
        <div class="card-head"><h3>${I('layers')}Apps</h3><button type="button" class="hbtn ghost sm" data-reload>${I('refresh')}Refresh</button></div>
        <p class="sub">Switch <b>Licensed</b> on and every paid download of that app emails the buyer a key. Then drop the matching kit into the app’s source: it already contains the studio public key and the app id, so it only accepts keys for that app.</p>
        <div class="lc-apps">${L.apps.map(a => `
          <div class="lc-app${a.licensed ? ' on' : ''}">
            <div class="lc-ah">${appIcon(a)}<div><b>${esc(a.name)}</b><small>${[a.version, a.price, a.published ? '' : 'not on the site'].filter(Boolean).map(esc).join(' · ') || '&nbsp;'}</small></div>
              <span class="lc-n" title="Keys issued">${I('key')}${a.issued}</span>
              <label class="switch"><input type="checkbox" data-licensed="${esc(a.id)}"${a.licensed ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Licensed</span></label></div>
            ${a.licensed ? `<div class="lc-kits"><span class="lc-kl">Get the key check:</span>${kitBtns(a)}</div>` : ''}
          </div>`).join('')}</div>
      </div>
      <div class="card" id="licTableCard">
        <div class="card-head"><h3>${I('key')}Issued keys</h3><input id="licQ" class="lc-q" placeholder="Search email, app or licence id" value="${esc(q)}"></div>
        <div id="licTable"></div>
      </div>
    </div>
    <div class="st-side">
      <div class="card">
        <h3>${I('send')}Issue a key</h3>
        <p class="sub">For giveaways, reviewers or a buyer whose email bounced. Paid downloads get their keys automatically.</p>
        <form class="fb" id="licIssue">
          <label class="fld"><span>App</span><select data-f="app">${L.apps.map(a => `<option value="${esc(a.id)}"${a.id === F.app ? ' selected' : ''}>${esc(a.name)}${a.licensed ? '' : ' (not licensed)'}</option>`).join('')}</select></label>
          <label class="fld"><span>Email</span><input type="email" data-f="email" value="${esc(F.email)}" placeholder="buyer@example.com" required></label>
          <label class="fld"><span>Name <small>optional</small></span><input data-f="name" value="${esc(F.name)}" placeholder="Their name"></label>
          <label class="switch"><input type="checkbox" data-f="send"${F.send ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Email it to them now</span></label>
          <button class="hbtn primary" type="submit">${I('key')}Create key</button>
        </form>
        ${fresh ? `<div class="lc-fresh"><div class="row"><b>${I('check')}Licence ${esc(fresh.id)}</b><span class="sp"></span><button type="button" class="hbtn ghost sm" data-copykey="${esc(fresh.key)}">${I('copy')}Copy</button></div><code>${esc(fresh.key)}</code><small>${fresh.mailed ? `Queued for ${esc(fresh.email)}. It sends in a moment (see Discord → Outbox).` : 'Not emailed. Copy it and send it yourself.'}</small></div>` : ''}
      </div>
      <div class="card">
        <h3>${I('shield')}Signing key</h3>
        <p class="sub">Every key is signed with the studio’s private key. Apps only hold the public half, so nobody can make keys from an app.</p>
        <p class="note lock"><span>${I('alert')}</span><span><b>Back up</b> <code>${esc(L.keyFile)}</code> (password manager or USB drive). If it’s lost, every app needs a new release with a new key; if it leaks, anyone can make keys.</span></p>
        <label class="fld"><span>Public key</span><div class="lc-pub"><code>${esc(L.publicKey)}</code><button type="button" class="act" data-copykey="${esc(L.publicKey)}" title="Copy">${I('copy')}</button></div></label>
        <form class="fb" id="licCheck"><label class="fld"><span>Check a key</span><input name="key" placeholder="PYL1-…" class="mono"></label><button class="hbtn ghost sm" type="submit">${I('search')}Check</button></form>
        <div id="licCheckOut"></div>
      </div>
    </div>
  </div>`;
  renderTable();
}

function renderTable() {
  const T = $('#licTable'); if (!T || !L) return;
  const s = q.trim().toLowerCase();
  const rows = L.issued.filter(r => !s || [r.email, r.appName, r.app, r.id, r.name, r.ref].some(v => String(v || '').toLowerCase().includes(s)));
  T.innerHTML = rows.length ? `<div class="lc-table">${rows.slice(0, 200).map(r => `
    <div class="lc-row"><span class="lc-when" title="${esc(r.iat)}">${esc(rel(r.iat))}</span><span class="dc-pill">${esc(r.appName)}</span>
      <span class="lc-who"><b>${esc(r.name || r.email)}</b>${r.name ? `<small>${esc(r.email)}</small>` : ''}</span>
      <code class="lc-id">${esc(r.id)}</code><span class="lc-src">${r.ref ? (String(r.ref).startsWith('manual') ? 'manual' : 'purchase') : 'manual'}</span>
      <span class="lc-acts"><button type="button" class="act" data-copyid="${esc(r.id)}" title="Copy key">${I('copy')}</button><button type="button" class="act" data-resend="${esc(r.id)}" title="Email the key again">${I('mail')}</button></span></div>`).join('')}</div>`
    : `<div class="emptystate">${I('key')}<h4>${s ? 'No matches' : 'No keys yet'}</h4><p>${s ? 'Try another search.' : 'Keys appear here when someone buys a licensed app, or when you create one.'}</p></div>`;
}

function download(name, content) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([content], { type: 'text/plain' }));
  a.download = name; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

async function onClick(e) {
  const b = e.target.closest('button'); if (!b) return;
  try {
    if (b.dataset.reload != null) return load();
    if (b.dataset.kit) {
      const k = await api('GET', `/api/licences/kit?lang=${encodeURIComponent(b.dataset.kit)}&app=${encodeURIComponent(b.dataset.app)}`);
      for (const f of k.files) download(f.name, f.content);
      return toast(`${k.label} kit downloaded: ${k.files.map(f => f.name).join(' + ')}`);
    }
    if (b.dataset.copykey) { await navigator.clipboard.writeText(b.dataset.copykey); return toast('Copied'); }
    if (b.dataset.copyid) { const r = await api('POST', '/api/licences/key', { id: b.dataset.copyid }); await navigator.clipboard.writeText(r.key); return toast('Key copied'); }
    if (b.dataset.resend) { await api('POST', '/api/licences/resend', { id: b.dataset.resend }); return toast('Queued: the key will be emailed again'); }
  } catch (x) { toast(x.message, 'err'); }
}
async function onChange(e) {
  const t = e.target;
  if (t.dataset.licensed) {
    try {
      await api('PUT', '/api/licences/app', { app: t.dataset.licensed, licensed: t.checked });
      const a = S.apps.find(x => x.id === t.dataset.licensed); if (a) { if (t.checked) a.licensed = true; else delete a.licensed; emit('apps'); }
      toast(t.checked ? 'Licensed: buyers get a key with every download' : 'No longer licensed');
      await load();
    } catch (x) { toast(x.message, 'err'); t.checked = !t.checked; }
  }
}
async function onSubmit(e) {
  e.preventDefault();
  try {
    if (e.target.id === 'licIssue') {
      const r = await api('POST', '/api/licences', F);
      fresh = { ...r.licence, mailed: r.mailed };
      F.email = ''; F.name = '';
      toast(`Licence ${r.licence.id} created`);
      await load();
    }
    if (e.target.id === 'licCheck') {
      const r = await api('POST', '/api/licences/verify', { key: e.target.elements.key.value });
      $('#licCheckOut').innerHTML = r.ok ? `<p class="note"><span>${I('check')}</span><span>Valid: <b>${esc(r.app)}</b> · ${esc(r.email)} · ${esc(r.id)} · issued ${esc(String(r.iat).slice(0, 10))}</span></p>`
        : `<p class="note lock"><span>${I('alert')}</span>${esc(r.why)}</p>`;
    }
  } catch (x) { toast(x.message, 'err'); }
}
