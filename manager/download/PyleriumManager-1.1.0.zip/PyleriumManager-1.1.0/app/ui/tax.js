// Tax: Stripe Tax status, automatic collection, sales per country against registration thresholds, and exports.
import { R, $, esc, api, toast, rel, confirmBox } from './core.js';

const I = n => R.icon(n);
let T = null, err = '', loading = false, busy = false;
let CUR = 'AUD';
const money = (v, cur = CUR) => { try { return new Intl.NumberFormat('en', { style: 'currency', currency: cur, currencyDisplay: 'narrowSymbol', minimumFractionDigits: (+v || 0) % 1 ? 2 : 0, maximumFractionDigits: 2 }).format(+v || 0); } catch { return `${v} ${cur}`; } };
const LEVEL = { registered: ['ok', 'Registered'], register: ['bad', 'Register now'], near: ['warn', 'Getting close'], ok: ['', 'Under threshold'], none: ['', 'No sales'] };

export function init() {
  const P = $('#taxPanel');
  P.addEventListener('click', onClick);
  P.addEventListener('change', onChange);
}
export async function show() { await load(false); }

async function load(force) {
  if (loading) return; loading = true; err = '';
  if (!T) render();
  try { T = await api('GET', '/api/tax' + (force ? '?force=1' : '')); } catch (e) { err = e.message; }
  loading = false; render();
}

function render() {
  const P = $('#taxPanel');
  if (!T && !err) { P.innerHTML = `<div class="card lv-loading"><span class="spinner"></span>Reading Stripe Tax and your sales…</div>`; return; }
  if (!T) { P.innerHTML = `<div class="card"><p class="note lock"><span>${I('alert')}</span>${esc(err)}</p></div>`; return; }
  const st = T.status || {}, ev = T.exposure, set = T.settings || {};
  CUR = ev?.currency || 'AUD';
  const act = (ev?.rules || []).filter(r => r.level === 'register' || r.level === 'near');
  const stateTxt = st.error ? 'Can’t read' : st.active ? 'Active' : st.state === 'pending' ? 'Not finished' : 'Off';
  P.innerHTML = `
  ${act.length ? `<div class="tx-banner">${I('alert')}<div><b>${act.length === 1 ? act[0].name : `${act.length} places`} ${act.some(r => r.level === 'register') ? 'need' : 'are close to needing'} a tax registration.</b><span>${act.map(r => esc(r.name)).join(' · ')}. Details below.</span></div></div>` : ''}
  <div class="lc-tiles">
    <div class="tile"><span>Stripe Tax</span><b class="${st.active ? 'tx-good' : 'tx-warn'}">${esc(stateTxt)}</b></div>
    <div class="tile"><span>Collecting tax</span><b>${set.collect ? 'Automatic' : 'Off'}</b></div>
    <div class="tile"><span>Sales, 12 months</span><b>${ev ? money(ev.total) : '—'}<small>${ev ? ` · ${ev.sales}` : ''}</small></b></div>
    <div class="tile"><span>Registrations</span><b>${(st.registrations || []).length}</b></div>
  </div>
  <div class="st-grid">
    <div class="st-main">
      <div class="card">
        <div class="card-head"><h3>${I('globe')}Where you may owe tax</h3><div class="row"><span class="muted">Checked ${esc(rel(new Date(T.at).toISOString()))}</span><button type="button" class="hbtn ghost sm" data-reload>${I('refresh')}Recheck</button></div></div>
        <p class="sub">Your last 12 months of sales per country (what Stripe settled to you, in ${esc(CUR)}), against each place’s registration rule${ev?.home ? `, as a business based in ${flag(ev.home)} ${esc(ev.home)}` : ''}. The hub posts to Discord once when a country gets to 80% and again when it passes.</p>
        ${T.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(T.error)}</p>` : ''}
        ${ev ? `<div class="tx-rules">${ev.rules.map(ruleRow).join('')}</div>
        <p class="note"><span>${I('info')}</span><span>${esc(ev.note)} Rules last reviewed ${esc(ev.reviewed)}. Edit them by copying <code>tax-rules.json</code> to <code>data/tax-rules.json</code>.</span></p>` : ''}
      </div>
      ${ev?.countries?.length ? `<div class="card"><h3>${I('chart')}Sales by country</h3>
        <div class="tx-countries">${ev.countries.map(c => `<div class="tx-c"><span class="tx-flag">${flag(c.country)}</span><b>${esc(c.country)}</b><span class="tx-bar"><i style="width:${Math.max(2, Math.round(c.net / (ev.countries[0].net || 1) * 100))}%"></i></span><span>${c.count}</span><b>${money(c.net)}</b>${c.tax ? `<small>tax ${c.tax.toFixed(2)}</small>` : '<small></small>'}</div>`).join('')}</div>
        ${ev.unknown ? `<p class="sub">${ev.unknown} sale(s) weren’t settled in ${esc(CUR)} and aren’t in the totals.</p>` : ''}</div>` : ''}
    </div>
    <div class="st-side">
      <div class="card">
        <h3>${I('shield')}Stripe Tax</h3>
        ${st.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(st.error)}</p>` : `
        <div class="tx-kv"><span>Status</span><b>${esc(stateTxt)}</b>${st.headOffice ? `<span>Business address</span><b>${esc(st.headOffice)}</b>` : ''}<span>Prices</span><b>${st.defaults?.taxBehavior === 'inclusive' ? 'Include tax' : st.defaults?.taxBehavior === 'exclusive' ? 'Tax added on top' : 'Not set'}</b></div>
        ${(st.registrations || []).length ? `<div class="row tx-regs">${st.registrations.map(r => `<span class="dc-pill ok" title="${esc(r.type)}${r.since ? ` since ${esc(r.since)}` : ''}">${flag(r.country)} ${esc(r.country)}</span>`).join('')}</div>` : `<p class="sub">No registrations yet. Add one in Stripe when you register somewhere (for example Australian GST), so Stripe charges tax there.</p>`}
        ${!st.active ? `<p class="note"><span>${I('info')}</span><span>Set up Stripe Tax once: add your business address and registrations. It costs about 0.5% per sale where tax is calculated.</span></p>` : ''}`}
        <label class="switch big"><input type="checkbox" data-collect${set.collect ? ' checked' : ''}${busy ? ' disabled' : ''}><span class="track"><i></i></span><span class="sw-lbl">Collect tax automatically</span></label>
        <p class="sub">Turns on automatic tax for every active payment link and every new paid download. Prices stay the same and include tax, so you keep a bit less where tax applies.</p>
        <label class="switch"><input type="checkbox" data-alerts${set.alerts ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Discord alerts near thresholds</span></label>
        <div class="row"><a class="hbtn ghost sm" href="https://dashboard.stripe.com/tax" target="_blank" rel="noopener">${I('external')}Stripe Tax</a><a class="hbtn ghost sm" href="https://dashboard.stripe.com/tax/registrations" target="_blank" rel="noopener">${I('external')}Registrations</a></div>
      </div>
      <div class="card">
        <h3>${I('download')}Reports</h3>
        <p class="sub">For your accountant, your tax return and Business Activity Statements (quarters run July to June).</p>
        <div class="tx-exp">
          <button type="button" class="hbtn ghost" data-export="sales">${I('list')}Every sale (CSV)</button>
          <button type="button" class="hbtn ghost" data-export="bas">${I('calendar')}Quarterly summary / BAS helper (CSV)</button>
        </div>
      </div>
    </div>
  </div>`;
}

function ruleRow(r) {
  const [cls, label] = LEVEL[r.level] || ['', r.level];
  const pct = r.threshold ? Math.min(100, Math.round(r.pct * 100)) : r.regionCount ? 100 : 0;
  const thr = r.threshold ? `${r.currency} ${r.threshold.toLocaleString('en-AU')}${r.basis === 'world' ? ' worldwide' : ''}` : 'From the first sale';
  return `<div class="tx-rule ${cls}">
    <div class="tx-rh"><b>${esc(r.name)}</b><span class="dc-pill ${cls === 'bad' ? 'bad' : cls}">${esc(label)}</span><span class="sp"></span><span class="muted">${r.basis === 'world' ? `${r.count} sales` : `${r.regionCount} sale${r.regionCount === 1 ? '' : 's'}`} · ${money(r.sales)}</span></div>
    <div class="tx-meter"><i style="width:${pct}%"></i></div>
    <div class="tx-rf"><span>Threshold: <b>${esc(thr)}</b>${r.threshold && r.thresholdCur && r.currency !== CUR ? ` (about ${money(r.thresholdCur)})` : ''}</span><a href="${esc(r.url)}" target="_blank" rel="noopener">${I('external')}Rules</a></div>
    ${r.level === 'register' || r.level === 'near' ? `<p>${esc(r.text)}</p>` : ''}
  </div>`;
}
const flag = cc => /^[A-Z]{2}$/.test(cc) ? String.fromCodePoint(...[...cc].map(c => 127397 + c.charCodeAt(0))) : '🌐';

async function onClick(e) {
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.reload != null) return load(true);
  if (b.dataset.export) {
    try {
      b.disabled = true;
      const r = await api('GET', `/api/tax/export?kind=${b.dataset.export}`);
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([r.csv], { type: 'text/csv' })); a.download = r.filename; document.body.append(a); a.click(); a.remove();
      toast(`${r.filename} downloaded`);
    } catch (x) { toast(x.message, 'err'); } finally { b.disabled = false; }
  }
}
async function onChange(e) {
  const t = e.target;
  if (t.dataset.collect != null) {
    if (t.checked && !(await confirmBox('Collect tax automatically?', 'Every active payment link (paid downloads, Supply caffeine and store products) switches to automatic tax, and prices that don’t say yet become tax-inclusive. Stripe Tax charges about 0.5% per sale where it calculates tax.', 'Switch on', false))) { t.checked = false; return; }
    busy = true; render();
    try { T = await api('PUT', '/api/tax/settings', { collect: t.checked }); toast(t.checked ? 'Automatic tax is on' : 'Automatic tax is off'); }
    catch (x) { toast(x.message, 'err', 9000); }
    busy = false; render();
  }
  if (t.dataset.alerts != null) {
    try { T = await api('PUT', '/api/tax/settings', { alerts: t.checked }); render(); } catch (x) { toast(x.message, 'err'); }
  }
}
