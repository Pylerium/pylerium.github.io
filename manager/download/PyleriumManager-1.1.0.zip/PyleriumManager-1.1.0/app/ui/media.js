// Videos & embeds: YouTube channel sync, which videos show, and custom embed blocks.
import { R, S, $, $$, esc, api, toast, confirmBox, formBox, touchSite, saveSite, siteDirty, clone, on, rel, emit, refreshStatus } from './core.js';

let filter = 'all';
const get = (o, p) => p.split('.').reduce((x, k) => x?.[k], o);
const set = (o, p, v) => { const ks = p.split('.'); let x = o; for (const k of ks.slice(0, -1)) x = x[k] = x[k] ?? {}; x[ks.at(-1)] = v; };

export function init() {
  for (const id of ['#ytPanel', '#embedPanel']) {
    $(id).addEventListener('input', e => {
      const k = e.target.dataset.k; if (!k) return;
      set(S.siteDraft, k, e.target.type === 'checkbox' ? e.target.checked : e.target.type === 'number' ? Math.max(0, +e.target.value) : e.target.value);
      touchSite();
      if (e.target.dataset.live) render();
      if (k.startsWith('embeds.') && k.endsWith('.code')) livePreview(+k.split('.')[1]);
    });
    $(id).addEventListener('click', onClick);
  }
  on(w => { if ((w === 'site' || w === 'apps') && !$('main[data-view=media]').hidden) render(); });
}
export function show() { render(); }

function render() { renderYT(); renderEmbeds(); }

function renderYT() {
  const y = S.siteDraft.youtube || (S.siteDraft.youtube = { videos: [] });
  const vids = y.videos || [];
  const list = vids.filter(v => filter === 'all' ? true : filter === 'hidden' ? v.hidden : filter === 'shorts' ? v.short && !v.hidden : !v.short && !v.hidden);
  const showing = { long: vids.filter(v => !v.short && !v.hidden).length, shorts: vids.filter(v => v.short && !v.hidden).length };
  const linked = id => S.apps.filter(a => R.youtubeId(a.videoUrl) === id);
  $('#ytPanel').innerHTML = `<div class="card">
    <div class="card-head"><h3>${R.icon('youtube')}YouTube channel</h3>${y.lastSync ? `<span class="muted">Last synced ${rel(y.lastSync)}</span>` : ''}</div>
    <div class="ytbar">
      <label class="fld grow"><span>Channel link</span><input data-k="youtube.channelUrl" value="${esc(y.channelUrl || '')}" placeholder="https://www.youtube.com/@YourChannel"></label>
      <button type="button" class="hbtn primary" id="ytSync">${R.icon('refresh')}Sync now</button>
      ${y.channelUrl ? `<a class="hbtn ghost" href="${esc(y.channelUrl)}" target="_blank" rel="noopener">${R.icon('external')}Open channel</a>` : ''}
    </div>
    <div class="ytopts">
      <label class="switch"><input type="checkbox" data-k="youtube.autoSync"${y.autoSync ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Fetch new uploads automatically every time you publish</span></label>
      <label class="switch"><input type="checkbox" data-k="youtube.showShorts" data-live="1"${y.showShorts ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Show a Shorts rail</span></label>
      <label class="numf">Videos on the site <input type="number" min="0" max="24" data-k="youtube.maxVideos" value="${y.maxVideos ?? 6}"></label>
      <label class="numf">Shorts on the site <input type="number" min="0" max="30" data-k="youtube.maxShorts" value="${y.maxShorts ?? 12}"></label>
    </div>
    <p class="note"><span>${R.icon('info')}</span>The hub reads your channel's public feed (the latest 15 uploads, no API key needed) and remembers older ones. Videos play right on your site. Pin a video to keep it first, or hide it.</p>
    <div class="vtools">
      <div class="seg">${[['all', `All ${vids.length}`], ['videos', `Videos ${showing.long}`], ['shorts', `Shorts ${showing.shorts}`], ['hidden', `Hidden ${vids.filter(v => v.hidden).length}`]].map(([k, l]) => `<button type="button" data-vf="${k}" class="${filter === k ? 'on' : ''}">${l}</button>`).join('')}</div>
      <form class="inrow" id="ytAdd"><input name="url" placeholder="Add any video or Short by link"><button class="hbtn ghost sm" type="submit">${R.icon('plus')}Add</button></form>
    </div>
    <div class="vlist">${list.map(v => { const i = vids.indexOf(v), apps = linked(v.id); return `<div class="vt${v.hidden ? ' hidden' : ''}${v.short ? ' short' : ''}">
      <a class="vt-img" href="https://www.youtube.com/${v.short ? 'shorts/' : 'watch?v='}${esc(v.id)}" target="_blank" rel="noopener"><img src="${R.ytThumb(v.id, 'mqdefault')}" alt="" loading="lazy">${v.short ? '<em class="b-short">Short</em>' : ''}${v.pinned ? `<em class="b-pin">${R.icon('star')}Pinned</em>` : ''}</a>
      <div class="vt-body"><b title="${esc(v.title)}">${esc(R.cleanTitle(v.title))}</b><small>${esc(R.fmtDate((v.published || '').slice(0, 10)))}${v.views ? ` · ${R.fmtViews(v.views)} views` : ''}</small>
        ${apps.length ? `<span class="vt-app">${R.icon('link')}${apps.map(a => esc(a.name)).join(', ')}</span>` : ''}</div>
      <div class="vt-acts">
        <button type="button" class="act${v.pinned ? ' on-star' : ''}" data-vpin="${i}" title="${v.pinned ? 'Unpin' : 'Pin to the front'}">${R.icon('star')}</button>
        <button type="button" class="act${v.hidden ? '' : ' on-pub'}" data-vhide="${i}" title="${v.hidden ? 'Hidden: click to show' : 'Showing: click to hide'}">${R.icon(v.hidden ? 'eyeoff' : 'eye')}</button>
        <button type="button" class="act" data-vshort="${i}" title="${v.short ? 'Treat as a regular video' : 'Treat as a Short'}">${R.icon(v.short ? 'phone' : 'film')}</button>
        <button type="button" class="act" data-vapp="${i}" title="Show on an app's page">${R.icon('link')}</button>
        ${v.manual ? `<button type="button" class="act del" data-vdel="${i}" title="Remove">${R.icon('trash')}</button>` : ''}
      </div></div>`; }).join('') || `<p class="empty-sm">${vids.length ? 'Nothing in this filter.' : 'No videos yet. Press Sync now.'}</p>`}</div>
  </div>`;
}

const EMBED_PRESETS = [
  ['YouTube video', 'youtube', u => { const id = R.youtubeId(u); return id && `<iframe width="100%" style="aspect-ratio:16/9" src="https://www.youtube-nocookie.com/embed/${id}" title="YouTube video" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>`; }],
  ['Spotify', 'music', u => { const m = u.match(/open\.spotify\.com\/(track|album|playlist|episode|show|artist)\/(\w+)/); return m && `<iframe style="border-radius:12px" src="https://open.spotify.com/embed/${m[1]}/${m[2]}" width="100%" height="352" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>`; }],
  ['Twitch channel', 'twitch', u => { const m = u.match(/twitch\.tv\/([\w]+)/); return m && `<iframe src="https://player.twitch.tv/?channel=${m[1]}&parent=${location.hostname === 'localhost' ? (S.config.siteUrl || '').replace(/^https?:\/\//, '').split('/')[0] : location.hostname}" width="100%" style="aspect-ratio:16/9" allowfullscreen></iframe>`; }],
  ['Vimeo', 'video', u => { const m = u.match(/vimeo\.com\/(\d+)/); return m && `<iframe src="https://player.vimeo.com/video/${m[1]}" width="100%" style="aspect-ratio:16/9" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>`; }],
  ['Discord server widget', 'discord', u => { const m = u.match(/(\d{17,20})/); return m && `<iframe src="https://discord.com/widget?id=${m[1]}&theme=dark" width="100%" height="420" allowtransparency="true" frameborder="0" sandbox="allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts"></iframe>`; }],
  ['Google Form or any page', 'globe', u => /^https?:\/\//.test(u) && `<iframe src="${u.replace(/"/g, '&quot;')}" width="100%" height="600" frameborder="0" loading="lazy"></iframe>`]
];
function renderEmbeds() {
  const em = S.siteDraft.embeds || (S.siteDraft.embeds = []);
  const sec = S.siteDraft.sections.find(s => s.id === 'embeds');
  $('#embedPanel').innerHTML = `<div class="card">
    <div class="card-head"><h3>${R.icon('code')}Embeds</h3>${sec && !sec.enabled ? `<button type="button" class="hbtn ghost sm" data-goto="site:sections">${R.icon('info')}The Embeds section is turned off</button>` : ''}</div>
    <p class="sub">Add anything that has embed code: a Discord widget, a Spotify playlist, a Twitch stream, a form, a trailer. Each block shows in the Embeds section of your home page. App-specific embeds go in the app's Media tab.</p>
    <form class="smart" id="smartEmbed"><span>${R.icon('sparkles')}</span><input name="url" placeholder="Paste a YouTube, Spotify, Twitch, Vimeo or Discord link to build the embed for you"><button class="hbtn primary sm" type="submit">Create embed</button></form>
    <div class="emlist">${em.map((e, i) => `<div class="emrow${e.enabled ? '' : ' off'}">
      <div class="em-top"><label class="switch"><input type="checkbox" data-k="embeds.${i}.enabled" data-live="1"${e.enabled ? ' checked' : ''}><span class="track"><i></i></span></label>
        <input class="em-title" data-k="embeds.${i}.title" value="${esc(e.title || '')}" placeholder="Title (optional)">
        <select data-k="embeds.${i}.width"><option value="full"${e.width !== 'half' ? ' selected' : ''}>Full width</option><option value="half"${e.width === 'half' ? ' selected' : ''}>Half width</option></select>
        <button type="button" class="act" data-emove="${i}:-1"${i ? '' : ' disabled'}>${R.icon('up')}</button><button type="button" class="act" data-emove="${i}:1"${i < em.length - 1 ? '' : ' disabled'}>${R.icon('down')}</button>
        <button type="button" class="act del" data-edel="${i}">${R.icon('trash')}</button></div>
      <input data-k="embeds.${i}.subtitle" value="${esc(e.subtitle || '')}" placeholder="Short description (optional)">
      <div class="em-grid"><textarea class="mono code" rows="6" data-k="embeds.${i}.code" placeholder="&lt;iframe …&gt;&lt;/iframe&gt;">${esc(e.code || '')}</textarea><div class="em-pv" id="empv-${i}"></div></div>
    </div>`).join('') || '<p class="empty-sm">No embeds yet.</p>'}</div>
    <div class="addrow"><button type="button" class="hbtn ghost sm" id="addEmbed">${R.icon('plus')}Blank embed</button><div class="chips">${EMBED_PRESETS.map(([l, ic], i) => `<button type="button" class="chip" data-preset="${i}">${R.icon(ic)}${esc(l)}</button>`).join('')}</div></div>
    <p class="note"><span>${R.icon('shield')}</span>Previews here run in a locked-down frame. On your website, embed code runs as-is, so only paste code from services you trust.</p>
  </div>`;
  em.forEach((_, i) => livePreview(i));
}
function livePreview(i) {
  const box = $('#empv-' + i), e = S.siteDraft.embeds[i];
  if (!box) return;
  if (!e.code?.trim()) { box.innerHTML = `<div class="em-ph">${R.icon('eye')}Preview</div>`; return; }
  const f = document.createElement('iframe');
  f.setAttribute('sandbox', 'allow-scripts allow-popups allow-forms allow-presentation');
  f.srcdoc = `<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#0B0D17;color:#ccc;font:14px system-ui}iframe{max-width:100%}</style>${e.code}`;
  box.replaceChildren(f);
}

async function onClick(e) {
  const t = e.target, y = S.siteDraft.youtube;
  const vf = t.closest('[data-vf]'); if (vf) { filter = vf.dataset.vf; renderYT(); return; }
  const flip = (attr, key) => { const b = t.closest(`[data-${attr}]`); if (!b) return false; const v = y.videos[+b.dataset[attr]]; v[key] = !v[key]; touchSite(); renderYT(); return true; };
  if (flip('vpin', 'pinned') || flip('vhide', 'hidden') || flip('vshort', 'short')) return;
  const vd = t.closest('[data-vdel]'); if (vd) { y.videos.splice(+vd.dataset.vdel, 1); touchSite(); renderYT(); return; }
  const va = t.closest('[data-vapp]');
  if (va) {
    const v = y.videos[+va.dataset.vapp];
    const r = await formBox('Show this video on an app', `“${esc(R.cleanTitle(v.title))}” will play in the app's details.`, [{ name: 'app', label: 'App', type: 'select', value: S.apps[0]?.id, options: S.apps.map(a => ({ value: a.id, label: a.name + (a.published ? '' : ' (draft)') })) }], 'Link video');
    if (!r) return;
    const a = clone(S.apps.find(x => x.id === r.app));
    a.videoUrl = v.short ? `https://youtube.com/shorts/${v.id}` : `https://youtu.be/${v.id}`;
    try { S.apps = (await api('POST', '/api/apps', { app: a, prevId: a.id })).apps; emit('apps'); refreshStatus(); toast(`Linked to ${a.name}`); } catch (err) { toast(err.message, 'err'); }
    return;
  }
  if (t.closest('#ytSync')) {
    const b = t.closest('#ytSync'); b.disabled = true; b.innerHTML = '<span class="spinner"></span>Syncing…';
    try {
      const channelUrl = S.siteDraft.youtube.channelUrl;
      if (siteDirty()) await saveSite();
      const r = await api('POST', '/api/youtube/sync', { channelUrl });
      S.site = r.site; S.siteDraft = clone(r.site); emit('site'); refreshStatus();
      toast(r.youtube.added ? `Found ${r.youtube.added} new video${r.youtube.added > 1 ? 's' : ''}` : 'Up to date: no new videos');
    } catch (err) { toast(err.message, 'err'); }
    render(); return;
  }
  const em = S.siteDraft.embeds;
  const mv = t.closest('[data-emove]'); if (mv) { const [i, d] = mv.dataset.emove.split(':').map(Number); const j = i + d; [em[i], em[j]] = [em[j], em[i]]; touchSite(); renderEmbeds(); return; }
  const del = t.closest('[data-edel]'); if (del) { if (await confirmBox('Delete this embed?', em[+del.dataset.edel].title || 'Untitled embed')) { em.splice(+del.dataset.edel, 1); touchSite(); renderEmbeds(); } return; }
  if (t.closest('#addEmbed')) { em.push({ id: 'em-' + Date.now().toString(36), title: '', subtitle: '', code: '', width: 'full', enabled: true }); touchSite(); renderEmbeds(); return; }
  const pr = t.closest('[data-preset]');
  if (pr) {
    const [label, , make] = EMBED_PRESETS[+pr.dataset.preset];
    const r = await formBox(label, 'Paste the link and the embed code is written for you.', [{ name: 'url', label: 'Link', placeholder: 'https://…' }], 'Create');
    if (!r) return;
    const code = make(r.url.trim());
    if (!code) return toast(`That doesn't look like a ${label} link`, 'err');
    em.push({ id: 'em-' + Date.now().toString(36), title: label === 'Discord server widget' ? 'Join the Discord' : '', subtitle: '', code, width: 'full', enabled: true });
    touchSite(); renderEmbeds(); return;
  }
}
document.addEventListener('submit', async e => {
  if (e.target.id === 'ytAdd') {
    e.preventDefault();
    const url = e.target.url.value.trim(); if (!url) return;
    try { if (siteDirty()) await saveSite(); const r = await api('POST', '/api/youtube/add', { url }); S.site = r.site; S.siteDraft = clone(r.site); emit('site'); refreshStatus(); toast('Video added'); render(); }
    catch (err) { toast(err.message, 'err'); }
  }
  if (e.target.id === 'smartEmbed') {
    e.preventDefault();
    const url = e.target.url.value.trim(); if (!url) return;
    for (const [label, , make] of EMBED_PRESETS) {
      const code = make(url);
      if (code) { S.siteDraft.embeds.push({ id: 'em-' + Date.now().toString(36), title: '', subtitle: '', code, width: 'full', enabled: true }); touchSite(); renderEmbeds(); toast(`Created a ${label} embed. Save to keep it.`, 'info'); return; }
    }
  }
});
