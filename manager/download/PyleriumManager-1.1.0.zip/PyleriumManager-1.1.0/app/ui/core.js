// Shared plumbing for the hub views: API, state, toasts, dialogs.
import * as R from '/shared/render.js';
export { R };

const TOKEN = document.querySelector('meta[name="hub-token"]').content;
export const MEDIA = '/media/';
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = R.esc;
export const today = () => new Date().toISOString().slice(0, 10);
export const slug = s => String(s || '').toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '').trim().replace(/[\s_]+/g, '-').replace(/-+/g, '-').slice(0, 48);
export const ico = (n, c) => R.icon(n, c);
export const currency = () => S.site?.community?.currency || 'USD';
export const fmtMoney = n => { try { return new Intl.NumberFormat('en', { style: 'currency', currency: currency(), currencyDisplay: 'narrowSymbol', minimumFractionDigits: (+n || 0) % 1 ? 2 : 0 }).format(+n || 0); } catch { return String(n); } };

// Shared state. `site` is the saved copy; `siteDraft` is what the settings views edit.
export const S = { apps: [], site: null, siteDraft: null, config: {}, status: null, subs: null, supporters: null, listeners: new Set() };
export const emit = what => S.listeners.forEach(fn => fn(what));
export const on = fn => S.listeners.add(fn);

export async function api(method, path, body) {
  const res = await fetch(path, { method, headers: { 'X-Hub-Token': TOKEN, ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || `Request failed (${res.status})`), { data });
  return data;
}
export function hydrate(root = document) { $$('[data-i]', root).forEach(el => { if (!el.firstChild) el.innerHTML = R.icon(el.dataset.i); }); }
export function toast(msg, kind = 'ok', ms = 3200) {
  const t = document.createElement('div');
  t.className = 'toast' + (kind === 'err' ? ' err' : '');
  t.innerHTML = R.icon(kind === 'err' ? 'x' : kind === 'info' ? 'info' : 'check') + `<span>${esc(msg)}</span>`;
  $('#toasts').append(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, ms);
}
export function confirmBox(title, text, yes = 'Delete', danger = true) {
  const d = $('#confirmDlg');
  $('#cfTitle').textContent = title; $('#cfText').textContent = text;
  const y = $('#cfYes'); y.textContent = yes; y.className = 'hbtn ' + (danger ? 'danger' : 'primary');
  d.showModal();
  return new Promise(ok => {
    const done = v => { d.close(); d.onclick = null; ok(v); };
    d.onclick = e => { const b = e.target.closest('button[value]'); if (b) done(b.value === 'yes'); else if (e.target === d) done(false); };
    d.oncancel = e => { e.preventDefault(); done(false); };
  });
}
// A small form dialog. fields: [{name,label,type,value,placeholder,options,help,rows}]. Resolves to values or null.
export function formBox(title, intro, fields, okLabel = 'Save', extraHTML = '') {
  const d = $('#formDlg'), b = $('#formBody');
  b.innerHTML = `<h3>${esc(title)}</h3>${intro ? `<p>${intro}</p>` : ''}<form id="fbForm" class="fb">${fields.map(f => {
    const v = f.value ?? '';
    const input = f.type === 'textarea' ? `<textarea name="${f.name}" rows="${f.rows || 4}" placeholder="${esc(f.placeholder || '')}"${f.mono ? ' class="mono"' : ''}>${esc(v)}</textarea>`
      : f.type === 'select' ? `<select name="${f.name}">${f.options.map(o => `<option value="${esc(o.value)}"${o.value === v ? ' selected' : ''}>${esc(o.label)}</option>`).join('')}</select>`
      : f.type === 'checkbox' ? `<label class="switch"><input type="checkbox" name="${f.name}"${v ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">${esc(f.label)}</span></label>`
      : `<input name="${f.name}" type="${f.type || 'text'}" value="${esc(v)}" placeholder="${esc(f.placeholder || '')}"${f.mono ? ' class="mono"' : ''}>`;
    return f.type === 'checkbox' ? `<div class="fld">${input}</div>` : `<label class="fld"><span>${esc(f.label)}${f.help ? ` <small>${esc(f.help)}</small>` : ''}</span>${input}</label>`;
  }).join('')}${extraHTML}<div class="m-foot"><button class="hbtn ghost" type="button" value="cancel">Cancel</button><button class="hbtn primary" type="submit">${esc(okLabel)}</button></div></form>`;
  d.showModal();
  setTimeout(() => b.querySelector('input:not([type=checkbox]),textarea')?.focus(), 50);
  return new Promise(ok => {
    const f = $('#fbForm');
    const done = v => { d.close(); ok(v); };
    f.onsubmit = e => { e.preventDefault(); const o = {}; for (const fl of fields) { const el = f.elements[fl.name]; o[fl.name] = fl.type === 'checkbox' ? el.checked : el.value; } done(o); };
    f.querySelector('[value=cancel]').onclick = () => done(null);
    d.onclick = e => { if (e.target === d) done(null); };
    d.oncancel = e => { e.preventDefault(); done(null); };
  });
}
export const rel = iso => {
  if (!iso) return '';
  const s = (Date.now() - new Date(iso)) / 1000;
  if (s < 90) return 'just now';
  if (s < 3600) return Math.round(s / 60) + ' min ago';
  if (s < 86400) return Math.round(s / 3600) + ' h ago';
  return Math.round(s / 86400) + ' d ago';
};
export const clone = o => structuredClone(o);

// ---------- site settings draft ----------
export function siteDirty() { return JSON.stringify(S.site) !== JSON.stringify(S.siteDraft); }
export function touchSite() { $('#saveBar').hidden = !siteDirty(); emit('siteDraft'); }
export async function saveSite(reassign) {
  const r = await api('PUT', '/api/site', { site: S.siteDraft, reassign });
  S.site = r.site; S.siteDraft = clone(r.site); S.apps = r.apps;
  R.setCategories(S.site.categories);
  $('#saveBar').hidden = true;
  emit('site'); emit('apps');
  refreshStatus();
}
export async function refreshStatus() {
  try { S.status = await api('GET', '/api/status'); } catch (e) { S.status = { repoOk: false, error: e.message }; }
  emit('status');
}
export function pendingCount() {
  const s = S.status;
  if (!s || !s.repoOk) return 0;
  return s.changes.length || (s.workingFiles || s.ahead ? 1 : 0);
}
