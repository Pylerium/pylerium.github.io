// Site settings: text, announcement, sections, categories and social links. Edits S.siteDraft; the save bar commits it.
import { R, S, $, $$, esc, toast, confirmBox, formBox, touchSite, saveSite, siteDirty, clone, on, slug } from './core.js';

let tab = 'general';
const get = (o, p) => p.split('.').reduce((x, k) => x?.[k], o);
const set = (o, p, v) => { const ks = p.split('.'); let x = o; for (const k of ks.slice(0, -1)) x = x[k] = x[k] ?? {}; x[ks.at(-1)] = v; };
const SECTION_INFO = {
  featured: ['star', 'Featured', 'Large cards for apps you star.'],
  apps: ['layers', 'All software', 'The full catalog with category tabs and search.'],
  videos: ['youtube', 'Videos', 'Your latest YouTube videos and a Shorts rail.'],
  embeds: ['code', 'Embeds', 'Custom embed blocks from Videos & embeds.'],
  perks: ['gift', 'Perks', 'The perks people can unlock, lucky drops, and the My perks button.'],
  community: ['crown', 'Community', 'Supporter perks, the submit button and the supporters wall.'],
  studio: ['sparkles', 'How we build', 'Three studio principles.'],
  support: ['mail', 'Support', 'Contact email, socials and Supply caffeine.']
};

export function init() {
  $('#siteTabs').addEventListener('click', e => { const b = e.target.closest('[data-st]'); if (b) location.hash = '#/site/' + b.dataset.st; });
  $('#saveSite').addEventListener('click', async () => { try { await saveSite(); toast('Site settings saved. Publish to put them live.'); } catch (err) { toast(err.message, 'err'); } });
  $('#discardSite').addEventListener('click', async () => { if (await confirmBox('Discard changes?', 'Undo all unsaved site settings?', 'Discard')) { S.siteDraft = clone(S.site); touchSite(); render(); } });
  const P = $('#sitePanel');
  P.addEventListener('input', e => {
    const k = e.target.dataset.k; if (!k) return;
    set(S.siteDraft, k, e.target.type === 'checkbox' ? e.target.checked : e.target.type === 'number' ? +e.target.value : e.target.value);
    touchSite();
    if (e.target.dataset.live) render();
  });
  P.addEventListener('click', onClick);
  on(w => { if (w === 'site' && !$('main[data-view=site]').hidden) render(); });
}
export function show(sub) { if (sub) tab = sub; $$('#siteTabs button').forEach(b => b.classList.toggle('on', b.dataset.st === tab)); render(); }

function field(k, label, opts = {}) {
  const v = get(S.siteDraft, k) ?? '';
  if (opts.type === 'checkbox') return `<label class="switch"><input type="checkbox" data-k="${k}"${v ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">${esc(label)}</span></label>`;
  if (opts.type === 'textarea') return `<label class="fld"><span>${esc(label)}${opts.help ? ` <small>${esc(opts.help)}</small>` : ''}</span><textarea data-k="${k}" rows="${opts.rows || 3}" placeholder="${esc(opts.ph || '')}">${esc(v)}</textarea></label>`;
  if (opts.type === 'select') return `<label class="fld"><span>${esc(label)}</span><select data-k="${k}">${opts.options.map(([val, l]) => `<option value="${val}"${val === v ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`;
  return `<label class="fld"><span>${esc(label)}${opts.help ? ` <small>${esc(opts.help)}</small>` : ''}</span><input data-k="${k}" type="${opts.type || 'text'}" value="${esc(v)}" placeholder="${esc(opts.ph || '')}"${opts.max ? ` maxlength="${opts.max}"` : ''}></label>`;
}

function render() {
  const P = $('#sitePanel'), d = S.siteDraft;
  if (!d) return;
  if (tab === 'general') {
    P.innerHTML = `<div class="cols">
      <div class="card"><h3>${R.icon('sparkles')}Hero</h3>
        <div class="f2">${field('brand.name', 'Studio name')}${field('brand.tagline', 'Tagline under the logo')}</div>
        ${field('hero.eyebrow', 'Eyebrow', { help: 'blank = "YOUR STUDIO · N APPS"' })}
        <div class="f2">${field('hero.title', 'Headline')}${field('hero.highlight', 'Headline (gradient part)')}</div>
        ${field('hero.lead', 'Intro paragraph', { type: 'textarea', rows: 3 })}
        ${field('hero.primaryLabel', 'Main button label')}
        <div class="stack">${field('hero.showStats', 'Show the stats row (apps, platforms, open source, available)', { type: 'checkbox' })}${field('hero.showSocials', 'Show social icons under the buttons', { type: 'checkbox' })}</div>
        <div class="mini-pv"><span class="pv-lbl">Preview</span><div class="hero-pv"><small>${esc(d.hero.eyebrow || `${(d.brand?.name || 'My Studio').toUpperCase()} · N APPS`)}</small><b>${esc(d.hero.title)} <span class="grad-text">${esc(d.hero.highlight)}</span></b><p>${esc(d.hero.lead)}</p></div></div>
      </div>
      <div class="card"><h3>${R.icon('megaphone')}Announcement bar</h3>
        <p class="sub">A strip across the top of every page. Visitors can dismiss it; changing the text shows it again.</p>
        ${field('announcement.enabled', 'Show the announcement', { type: 'checkbox' })}
        ${field('announcement.text', 'Message', { max: 140 })}
        <div class="f2">${field('announcement.linkLabel', 'Link label')}${field('announcement.url', 'Link', { ph: 'apps/my-app/ or https://…' })}</div>
        <div class="fld"><span>Colour</span><div class="tones">${['violet', 'teal', 'amber', 'rose'].map(t => `<button type="button" class="tone tone-${t}${d.announcement.tone === t ? ' on' : ''}" data-tone="${t}">${t}</button>`).join('')}</div></div>
        <div class="announce-pv tone-${esc(d.announcement.tone || 'violet')}${d.announcement.enabled ? '' : ' off'}">${R.icon('megaphone')}<span>${esc(d.announcement.text || 'Your message')}</span>${d.announcement.url ? `<em>${esc(d.announcement.linkLabel || 'Learn more')}${R.icon('arrow')}</em>` : ''}</div>
      </div></div>`;
    $$('[data-k^="hero."],[data-k^="announcement."]', P).forEach(el => (el.dataset.live = el.type === 'checkbox' || el.tagName === 'SELECT' ? '1' : ''));
    P.oninput = e => { if (e.target.dataset.k?.startsWith('hero.') || e.target.dataset.k?.startsWith('announcement.')) livePreview(); };
  }
  if (tab === 'sections') {
    P.innerHTML = `<div class="card"><h3>${R.icon('layers')}Home page sections</h3><p class="sub">Turn sections on or off, put them in order, and edit their headings.</p>
      <div class="seclist">${d.sections.map((s, i) => { const [ic, name, help] = SECTION_INFO[s.id] || ['code', s.id, '']; return `<div class="secrow${s.enabled ? '' : ' off'}">
        <div class="sec-top"><span class="sec-ico">${R.icon(ic)}</span><div class="sec-name"><b>${esc(name)}</b><small>${esc(help)}</small></div>
          <div class="sec-acts"><button type="button" class="act" data-move="${i}:-1" title="Move up"${i ? '' : ' disabled'}>${R.icon('up')}</button><button type="button" class="act" data-move="${i}:1" title="Move down"${i < d.sections.length - 1 ? '' : ' disabled'}>${R.icon('down')}</button>
          <label class="switch"><input type="checkbox" data-k="sections.${i}.enabled" data-live="1"${s.enabled ? ' checked' : ''}><span class="track"><i></i></span></label></div></div>
        ${s.enabled ? `<div class="f3">${field(`sections.${i}.kicker`, 'Kicker')}${field(`sections.${i}.title`, 'Heading')}${field(`sections.${i}.subtitle`, 'Subheading')}</div>` : ''}
      </div>`; }).join('')}</div></div>`;
  }
  if (tab === 'categories') {
    const count = id => S.apps.filter(a => a.category === id).length;
    P.innerHTML = `<div class="card"><h3>${R.icon('hash')}Categories</h3><p class="sub">Group your apps however you like: game mods, tools, Android, anything. Categories with no published apps are hidden on the site automatically.</p>
      <div class="catlist">${d.categories.map((c, i) => `<div class="catrow">
        <button type="button" class="cat-ico" data-catico="${i}" title="Change icon">${R.icon(c.icon)}</button>
        <input data-k="categories.${i}.label" value="${esc(c.label)}" placeholder="Category name" aria-label="Category name">
        <code class="cat-id">${esc(c.id)}</code><span class="cat-n">${count(c.id)} app${count(c.id) === 1 ? '' : 's'}</span>
        <button type="button" class="act" data-cmove="${i}:-1"${i ? '' : ' disabled'} title="Move up">${R.icon('up')}</button><button type="button" class="act" data-cmove="${i}:1"${i < d.categories.length - 1 ? '' : ' disabled'} title="Move down">${R.icon('down')}</button>
        <button type="button" class="act del" data-cdel="${i}" title="Delete">${R.icon('trash')}</button>
      </div>`).join('')}</div>
      <div class="addrow"><button type="button" class="hbtn ghost sm" id="addCat">${R.icon('plus')}Add category</button><div class="chips">${[['Game mods', 'gamepad'], ['GTA mods', 'car'], ['Tools', 'wrench'], ['Android', 'phone'], ['Music', 'music'], ['Bots', 'bot'], ['Templates', 'palette']].filter(([l]) => !d.categories.some(c => c.label === l)).map(([l, ic]) => `<button type="button" class="chip" data-quickcat="${esc(l)}|${ic}">${R.icon(ic)}${esc(l)}</button>`).join('')}</div></div>
      <div class="icon-picker" id="iconPicker" hidden></div></div>`;
  }
  if (tab === 'socials') {
    P.innerHTML = `<div class="card"><h3>${R.icon('share')}Social links</h3><p class="sub">Shown in the hero, the support section and the footer. Paste a link and the platform is detected.</p>
      <div class="soclist">${d.socials.map((s, i) => { const m = R.SOCIALS[s.type] || R.SOCIALS.website; return `<div class="socrow">
        <span class="soc-ico">${R.icon(m.icon)}</span>
        <select data-k="socials.${i}.type" data-live="1">${Object.entries(R.SOCIALS).map(([k, v]) => `<option value="${k}"${k === s.type ? ' selected' : ''}>${v.label}</option>`).join('')}</select>
        <input data-k="socials.${i}.url" value="${esc(s.url)}" placeholder="https://…">
        <input data-k="socials.${i}.label" value="${esc(s.label || '')}" placeholder="Label (optional)" class="soc-lbl">
        <button type="button" class="act" data-smove="${i}:-1"${i ? '' : ' disabled'}>${R.icon('up')}</button><button type="button" class="act" data-smove="${i}:1"${i < d.socials.length - 1 ? '' : ' disabled'}>${R.icon('down')}</button>
        <button type="button" class="act del" data-sdel="${i}">${R.icon('trash')}</button></div>`; }).join('') || '<p class="empty-sm">No social links yet.</p>'}</div>
      <form class="addsoc" id="addSoc"><input name="url" placeholder="Paste a link: YouTube, Discord, X, TikTok, Instagram, Twitch, Patreon, Ko-fi…"><button class="hbtn primary sm" type="submit">${R.icon('plus')}Add</button></form>
      <div class="mini-pv"><span class="pv-lbl">Preview</span>${R.socialLinksHTML(d.socials) || '<small>Nothing to show</small>'}</div></div>`;
  }
}
function livePreview() {
  const d = S.siteDraft, P = $('#sitePanel');
  const hp = $('.hero-pv', P); if (hp) hp.innerHTML = `<small>${esc(d.hero.eyebrow || `${(d.brand?.name || 'My Studio').toUpperCase()} · N APPS`)}</small><b>${esc(d.hero.title)} <span class="grad-text">${esc(d.hero.highlight)}</span></b><p>${esc(d.hero.lead)}</p>`;
  const ap = $('.announce-pv', P); if (ap) { ap.className = `announce-pv tone-${d.announcement.tone || 'violet'}${d.announcement.enabled ? '' : ' off'}`; ap.innerHTML = `${R.icon('megaphone')}<span>${esc(d.announcement.text || 'Your message')}</span>${d.announcement.url ? `<em>${esc(d.announcement.linkLabel || 'Learn more')}${R.icon('arrow')}</em>` : ''}`; }
}
const swap = (arr, i, dir) => { const j = i + dir; if (j < 0 || j >= arr.length) return; [arr[i], arr[j]] = [arr[j], arr[i]]; };

async function onClick(e) {
  const t = e.target, d = S.siteDraft;
  const tone = t.closest('[data-tone]'); if (tone) { d.announcement.tone = tone.dataset.tone; touchSite(); render(); return; }
  const mv = t.closest('[data-move]'); if (mv) { const [i, dir] = mv.dataset.move.split(':').map(Number); swap(d.sections, i, dir); touchSite(); render(); return; }
  const cm = t.closest('[data-cmove]'); if (cm) { const [i, dir] = cm.dataset.cmove.split(':').map(Number); swap(d.categories, i, dir); touchSite(); render(); return; }
  const sm = t.closest('[data-smove]'); if (sm) { const [i, dir] = sm.dataset.smove.split(':').map(Number); swap(d.socials, i, dir); touchSite(); render(); return; }
  const sd = t.closest('[data-sdel]'); if (sd) { d.socials.splice(+sd.dataset.sdel, 1); touchSite(); render(); return; }
  const ci = t.closest('[data-catico]');
  if (ci) {
    const pk = $('#iconPicker'), i = +ci.dataset.catico;
    pk.hidden = false; pk.innerHTML = `<p>Icon for <b>${esc(d.categories[i].label)}</b></p><div class="glyphs">${R.GLYPHS.map(g => `<button type="button" class="gl${d.categories[i].icon === g ? ' on' : ''}" data-pickico="${i}:${g}">${R.icon(g)}</button>`).join('')}</div>`;
    pk.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); return;
  }
  const pi = t.closest('[data-pickico]'); if (pi) { const [i, g] = pi.dataset.pickico.split(':'); d.categories[+i].icon = g; touchSite(); render(); return; }
  const qc = t.closest('[data-quickcat]'); if (qc) { const [label, icon] = qc.dataset.quickcat.split('|'); addCat(label, icon); return; }
  if (t.closest('#addCat')) {
    const v = await formBox('New category', 'Apps in this category get their own tab on the website.', [{ name: 'label', label: 'Name', placeholder: 'e.g. Game mods' }], 'Add');
    if (v?.label.trim()) addCat(v.label.trim(), 'code');
    return;
  }
  const cd = t.closest('[data-cdel]');
  if (cd) {
    const i = +cd.dataset.cdel, c = d.categories[i];
    if (d.categories.length < 2) return toast('Keep at least one category', 'err');
    const used = S.apps.filter(a => a.category === c.id);
    let reassign;
    if (used.length) {
      const others = d.categories.filter(x => x.id !== c.id);
      const v = await formBox(`Delete ${c.label}?`, `${used.length} app${used.length > 1 ? 's use' : ' uses'} it. Move ${used.length > 1 ? 'them' : 'it'} to:`, [{ name: 'to', label: 'New category', type: 'select', value: others[0].id, options: others.map(o => ({ value: o.id, label: o.label })) }], 'Delete & move');
      if (!v) return;
      reassign = { [c.id]: v.to };
    } else if (!(await confirmBox(`Delete ${c.label}?`, 'No apps use this category.'))) return;
    d.categories.splice(i, 1);
    try { await saveSite(reassign); toast(`Deleted ${c.label}`); } catch (err) { toast(err.message, 'err'); }
  }
}
function addCat(label, icon) {
  const d = S.siteDraft; let id = slug(label) || 'category', n = 2;
  while (d.categories.some(c => c.id === id)) id = `${slug(label)}-${n++}`;
  d.categories.push({ id, label, icon });
  touchSite(); render(); toast(`Added ${label}. Save to keep it.`, 'info');
}
document.addEventListener('submit', e => {
  if (e.target.id !== 'addSoc') return;
  e.preventDefault();
  const url = e.target.url.value.trim(); if (!url) return;
  const full = /^(https?:|mailto:)/i.test(url) ? url : /@/.test(url) && !/\//.test(url) ? 'mailto:' + url : 'https://' + url;
  S.siteDraft.socials.push({ type: R.detectSocial(full), url: full, label: '' });
  touchSite(); render();
});
