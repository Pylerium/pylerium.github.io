// Live: everything going on, at a glance. Polls /api/live every few seconds while open.
import { R, $, $$, esc, api, toast, confirmBox, rel } from './core.js';

let L = null, timer = 0, visible = false, busy = false;
const I = n => R.icon(n);
const money = (v, cur) => { try { return new Intl.NumberFormat('en-US', { style: 'currency', currency: cur || 'AUD', minimumFractionDigits: v % 1 ? 2 : 0, maximumFractionDigits: 2 }).format(v || 0); } catch { return `${v} ${cur}`; } };
const minor = (v, cur) => money(v / 100, String(cur).toUpperCase());
const until = t => { if (!t) return ''; const s = Math.round((t - Date.now()) / 1000); if (s <= 0) return 'due now'; if (s < 60) return `in ${s}s`; if (s < 3600) return `in ${Math.round(s / 60)} min`; return `in ${Math.round(s / 3600)} h`; };
const upFor = ms => { const m = Math.floor(ms / 60000); return m < 60 ? `${m} min` : m < 1440 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${Math.floor(m / 1440)} d ${Math.floor(m % 1440 / 60)} h`; };
// status: ok / warn / bad / off, always with an icon and a word, never colour alone
const ST = { ok: ['check', 'OK'], warn: ['alert', 'Check'], bad: ['x', 'Problem'], off: ['power', 'Off'] };
const badge = (s, word) => `<span class="lv-st ${s}">${I(ST[s][0])}${esc(word || ST[s][1])}</span>`;

export function init() {
  const P = $('#livePanel');
  P.addEventListener('click', onClick);
  P.addEventListener('mousemove', onHover);
  P.addEventListener('mouseleave', () => { const t = $('#lvTip'); if (t) t.hidden = true; });
  refresh(true);
  setInterval(() => { if (!visible) refresh(true); }, 30000);
  setInterval(() => { if (visible) $$('[data-until]').forEach(el => { el.textContent = until(+el.dataset.until); }); }, 1000);
}
export function show() { visible = true; render(); refresh(); clearInterval(timer); timer = setInterval(refresh, 5000); }
export function hide() { visible = false; clearInterval(timer); }

async function refresh(quiet) {
  if (busy) return; busy = true;
  try { L = await api('GET', '/api/live'); badge2(); if (visible) render(); }
  catch (e) { if (!quiet && visible) $('#livePanel').innerHTML = `<div class="card"><p class="bad">${esc(e.message)}</p></div>`; }
  finally { busy = false; }
}
function badge2() { const n = needs().filter(x => x.lvl !== 'info').length; $('#nLive').hidden = !n; $('#nLive').textContent = n; }

// ---------- what needs you ----------
function needs() {
  if (!L) return [];
  const out = [], w = L.watchers, e = L.email;
  for (const h of L.supporters.held) out.push({ lvl: 'bad', icon: 'shield', title: `Code held: ${h.name || h.email} · ${minor(h.amount, h.currency)}`, text: `${h.why}. Check the payment, then decide.`, actions: `<button class="hbtn primary sm" data-approve="${esc(h.id)}">${I('check')}Approve &amp; send code</button><button class="hbtn ghost sm" data-dismiss="${esc(h.id)}">Dismiss</button>${h.dash ? `<a class="hbtn ghost sm" href="${esc(h.dash)}" target="_blank" rel="noopener">${I('external')}Stripe</a>` : ''}` });
  if (e.smtp?.authFail) out.push({ lvl: 'bad', icon: 'mail', title: 'Gmail rejected the app password', text: 'Automatic emails are paused.', actions: `<a class="hbtn primary sm" href="#/alerts/emails">Fix it</a>` });
  if (e.failed) out.push({ lvl: 'bad', icon: 'mail', title: `${e.failed} email${e.failed > 1 ? 's' : ''} failed`, text: 'Gmail kept refusing them. Edit or send by hand.', actions: `<a class="hbtn ghost sm" href="#/alerts/emails">Open outbox</a>` });
  if (e.waiting && L.site.pending) out.push({ lvl: 'warn', icon: 'rocket', title: `${e.waiting} code email${e.waiting > 1 ? 's' : ''} waiting for a publish`, text: 'They send automatically once the code is live on the site.', actions: `<button class="hbtn primary sm" data-publish>${I('rocket')}Publish now</button>` });
  else if (e.waiting) out.push({ lvl: 'info', icon: 'clock', title: `${e.waiting} code email${e.waiting > 1 ? 's' : ''} waiting for the site to update`, text: 'GitHub Pages usually takes about a minute.', actions: '' });
  if (e.ready && !(e.connected && e.auto)) out.push({ lvl: 'warn', icon: 'mail', title: `${e.ready} email${e.ready > 1 ? 's' : ''} ready to send`, text: e.connected ? 'Automatic sending is off.' : 'Connect Gmail to send them automatically.', actions: `<a class="hbtn primary sm" href="#/alerts/emails">Open outbox</a>` });
  if (!e.connected) out.push({ lvl: 'info', icon: 'mail', title: 'Gmail isn’t connected', text: 'Customers get their emails only when you send them by hand.', actions: `<a class="hbtn ghost sm" href="#/alerts/emails">Connect Gmail</a>` });
  if (L.site.pending && !e.waiting) out.push({ lvl: 'info', icon: 'rocket', title: `${L.site.pending} unpublished change${L.site.pending > 1 ? 's' : ''}`, text: L.site.changes.map(c => c.name).slice(0, 4).join(', '), actions: `<button class="hbtn ghost sm" data-publish>${I('rocket')}Review &amp; publish</button>` });
  if (L.submissions?.pending) out.push({ lvl: 'warn', icon: 'inbox', title: `${L.submissions.pending} submission${L.submissions.pending > 1 ? 's' : ''} to review`, text: 'Supporters sent apps for the showcase.', actions: `<a class="hbtn ghost sm" href="#/community/inbox">Review</a>` });
  for (const [k, n] of [['stripe', 'Stripe'], ['submissions', 'Submissions'], ['youtube', 'YouTube']]) if (w[k].on && w[k].ok === false) out.push({ lvl: 'bad', icon: 'alert', title: `${n} check is failing`, text: w[k].msg || '', actions: `<button class="hbtn ghost sm" data-run="${k}">${I('refresh')}Try again</button>` });
  if (!w.stripe.keySet) out.push({ lvl: 'warn', icon: 'key', title: 'Stripe isn’t connected', text: 'Sales can’t be tracked.', actions: `<a class="hbtn ghost sm" href="#/community/settings">Add key</a>` });
  if (!L.discord.private.set) out.push({ lvl: 'warn', icon: 'discord', title: 'Private Discord alerts aren’t connected', text: '', actions: `<a class="hbtn ghost sm" href="#/alerts/setup">Connect</a>` });
  const fresh = L.site.lastPublish?.date && Date.now() - Date.parse(L.site.lastPublish.date) < 15 * 60000;
  if (L.site.ping && !L.site.ping.ok && fresh) out.push({ lvl: 'info', icon: 'clock', title: 'GitHub is still putting your site online', text: 'This can take a few minutes after a publish, longer the very first time.', actions: '' });
  else if (L.site.ping && !L.site.ping.ok) out.push({ lvl: 'bad', icon: 'globe', title: 'The live site isn’t responding', text: L.site.ping.error || `HTTP ${L.site.ping.status}`, actions: `<a class="hbtn ghost sm" href="${esc(L.site.url)}" target="_blank" rel="noopener">Open site</a>` });
  if (L.store?.donate && !L.store.donate.active) out.push({ lvl: 'bad', icon: 'can', title: 'The Supply caffeine link is switched off in Stripe', text: 'People can’t pay.', actions: `<a class="hbtn ghost sm" href="#/store">Open Store</a>` });
  if (!L.autostart) out.push({ lvl: 'info', icon: 'power', title: 'The hub doesn’t start with Windows', text: 'Alerts and emails only run while the hub is open.', actions: `<button class="hbtn ghost sm" data-autostart>Turn on</button>` });
  return out;
}

// ---------- render ----------
function render() {
  const P = $('#livePanel');
  if (!L) { P.innerHTML = `<div class="card lv-loading"><span class="spinner"></span>Loading live data…</div>`; return; }
  const r = L.revenue, cur = L.currency, n = needs(), urgent = n.filter(x => x.lvl !== 'info');
  $('#lvHealth').innerHTML = urgent.some(x => x.lvl === 'bad') ? badge('bad', `${urgent.length} thing${urgent.length > 1 ? 's' : ''} need you`) : urgent.length ? badge('warn', `${urgent.length} thing${urgent.length > 1 ? 's' : ''} to check`) : badge('ok', 'All systems go');
  $('#lvClock').textContent = `Updated ${new Date(L.now).toLocaleTimeString()} · hub up ${upFor(L.uptime)}`;
  const tiles = [
    ['Today', money(r.today, cur), `${r.countToday} payment${r.countToday === 1 ? '' : 's'}`, 'zap'],
    ['Last 7 days', money(r.week, cur), '', 'chart'],
    ['Last 30 days', money(r.month, cur), `${r.countMonth} payment${r.countMonth === 1 ? '' : 's'}`, 'activity'],
    ['All time', money(r.all, cur), r.refunded ? `${money(r.refunded, cur)} refunded` : 'net of refunds', 'crown'],
    ['Supporters', String(L.supporters.total), `${L.supporters.codes} active code${L.supporters.codes === 1 ? '' : 's'}`, 'users'],
    ['Emails today', String(L.email.sentToday), L.email.waiting ? `${L.email.waiting} waiting · ${L.email.ready} ready` : `${L.email.ready} ready`, 'mail']
  ];
  P.innerHTML = `
  <div class="lv-tiles">${tiles.map(([l, v, s, ic]) => `<div class="tile lv-tile"><span>${I(ic)}${l}</span><b>${esc(v)}</b><small>${esc(s)}</small></div>`).join('')}</div>
  <div class="lv-grid">
    <div class="card lv-chart"><div class="card-head"><h3>${I('chart')}Revenue, last 30 days</h3><span class="muted">${cur} · net of refunds${r.testCount ? ` · ${r.testCount} test payment${r.testCount > 1 ? 's' : ''} not counted` : ''}</span></div>${chart(r.days, cur)}
      <details class="lv-table"><summary>Show as a table</summary><table><thead><tr><th>Day</th><th>Payments</th><th>Revenue</th></tr></thead><tbody>${[...r.days].reverse().filter(d => d.count).map(d => `<tr><td>${esc(d.day)}</td><td>${d.count}</td><td>${money(d.amount, cur)}</td></tr>`).join('') || '<tr><td colspan="3" class="muted">No payments in the last 30 days.</td></tr>'}</tbody></table></details></div>
    <div class="card lv-needs"><div class="card-head"><h3>${I('bell')}Needs you</h3><span class="muted">${n.length ? `${n.length} item${n.length > 1 ? 's' : ''}` : ''}</span></div>
      ${n.length ? `<div class="lv-need-list">${n.map(x => `<div class="lv-need ${x.lvl}"><span class="lv-ni">${I(x.icon)}</span><div><b>${esc(x.title)}</b>${x.text ? `<small>${esc(x.text)}</small>` : ''}${x.actions ? `<div class="row">${x.actions}</div>` : ''}</div></div>`).join('')}</div>` : `<div class="emptystate">${I('check')}<h4>All clear</h4><p>Nothing needs you right now. Sales, codes and emails are handled automatically.</p></div>`}</div>
    <div class="card lv-sys"><div class="card-head"><h3>${I('cpu')}Systems</h3><button class="hbtn ghost sm" data-refresh>${I('refresh')}Refresh</button></div>${systems()}</div>
    <div class="card lv-sales"><div class="card-head"><h3>${I('card')}Recent payments</h3><a class="linkbtn" href="https://dashboard.stripe.com/payments" target="_blank" rel="noopener">Stripe dashboard</a></div>${salesList()}</div>
    <div class="card lv-feed"><div class="card-head"><h3>${I('activity')}Live feed</h3><span class="lv-pulse"><i></i>live</span></div>${feed()}</div>
    <div class="card lv-side">${sideInfo()}</div>
  </div><div id="lvTip" class="lv-tip" hidden></div>`;
}

function chart(days, cur) {
  const W = 640, H = 190, padL = 46, padB = 24, padT = 12, n = days.length, bw = (W - padL) / n;
  const max = Math.max(...days.map(d => d.amount), 0);
  const top = max ? niceMax(max) : 10;
  const y = v => H - padB - (v / top) * (H - padB - padT);
  const grid = [0, .5, 1].map(f => `<line x1="${padL}" x2="${W}" y1="${y(top * f)}" y2="${y(top * f)}" class="lv-grid${f ? '' : ' base'}"/><text x="${padL - 8}" y="${y(top * f) + 4}" class="lv-ax" text-anchor="end">${esc(money(top * f, cur))}</text>`).join('');
  const bars = days.map((d, i) => {
    const x = padL + i * bw + 1, w = Math.max(2, bw - 2), h = H - padB - y(d.amount);
    const r = Math.min(4, w / 2, h);
    const path = h > 0 ? `<path class="lv-bar" d="M${x},${H - padB} V${y(d.amount) + r} q0,-${r} ${r},-${r} h${w - 2 * r} q${r},0 ${r},${r} V${H - padB} Z"/>` : '';
    return `${path}<rect class="lv-hit" x="${padL + i * bw}" y="${padT}" width="${bw}" height="${H - padT - padB}" data-tip="${esc(`${new Date(d.day + 'T00:00').toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' })}|${money(d.amount, cur)}|${d.count} payment${d.count === 1 ? '' : 's'}`)}"/>`;
  }).join('');
  const labels = days.map((d, i) => ((i % 7 === 0 && n - 1 - i > 3) || i === n - 1) ? `<text x="${padL + i * bw + bw / 2}" y="${H - 6}" class="lv-ax" text-anchor="middle">${i === n - 1 ? 'Today' : esc(new Date(d.day + 'T00:00').toLocaleDateString(undefined, { day: 'numeric', month: 'short' }))}</text>` : '').join('');
  return `<div class="lv-svg"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Revenue per day for the last 30 days">${grid}${bars}${labels}</svg>${max ? '' : '<div class="lv-empty">No payments in the last 30 days yet. The first one shows up here within minutes.</div>'}</div>`;
}
function niceMax(v) { const p = 10 ** Math.floor(Math.log10(v)); for (const m of [1, 2, 2.5, 5, 10]) if (v <= m * p) return m * p; return 10 * p; }

function systems() {
  const w = L.watchers, e = L.email, d = L.discord, s = L.site;
  const watch = (x, name, ic) => {
    const st = !x.on ? 'off' : x.running ? 'warn' : x.ok === false ? 'bad' : x.at ? 'ok' : 'warn';
    return [ic, name, st, !x.on ? 'Off' : x.running ? 'Checking…' : x.ok === false ? 'Failing' : x.at ? 'Watching' : 'Starting', x.msg ? `${x.msg} · ${rel(x.at)}` : 'Not checked yet', x.on && x.next ? x.next : null];
  };
  const rows = [
    watch(w.stripe, 'Stripe sales', 'card'),
    watch(w.submissions, 'Submissions', 'inbox'),
    watch(w.youtube, 'YouTube', 'youtube'),
    ['discord', 'Discord · private', d.private.set ? (d.private.enabled ? 'ok' : 'off') : 'bad', d.private.set ? (d.private.enabled ? 'Connected' : 'Paused') : 'Not set', `${d.private.name || ''}${d.sentToday ? ` · ${d.sentToday} sent today` : ''}${d.failedToday ? ` · ${d.failedToday} failed` : ''}`, null],
    ['megaphone', 'Discord · public', d.public.set ? (d.public.enabled ? 'ok' : 'off') : 'warn', d.public.set ? (d.public.enabled ? 'Connected' : 'Paused') : 'Not set', d.public.name || 'Community announcements', null],
    ['mail', 'Gmail sending', !e.connected ? 'off' : e.smtp?.authFail || e.smtp?.ok === false ? 'bad' : e.auto ? 'ok' : 'warn', !e.connected ? 'Not connected' : e.smtp?.authFail ? 'Login rejected' : e.auto ? 'Automatic' : 'Manual', e.connected ? `${e.user} · ${e.sentToday}/${e.cap} today` : 'Emails wait for you', null],
    ['globe', 'Live website', !s.ping ? 'warn' : s.ping.ok ? 'ok' : 'bad', !s.ping ? 'Checking' : s.ping.ok ? `Up · ${s.ping.ms} ms` : 'Down', s.url.replace(/^https?:\/\//, ''), null],
    ['rocket', 'Publishing', !s.repoOk ? 'bad' : s.publishing ? 'warn' : s.pending ? 'warn' : 'ok', !s.repoOk ? (L.repo ? 'Repo problem' : 'No site yet') : s.publishing ? 'Publishing…' : s.pending ? `${s.pending} pending` : 'Up to date', s.lastPublish ? `Last: ${s.lastPublish.subject} · ${rel(s.lastPublish.date)}` : s.error || '', null],
    ['power', 'Start with Windows', L.autostart ? 'ok' : 'off', L.autostart ? 'On' : 'Off', 'Keeps alerts and emails running', null]
  ];
  return `<div class="lv-sys-list">${rows.map(([ic, name, st, word, sub, next]) => `<div class="lv-sys-row"><span class="lv-si">${I(ic)}</span><div><b>${esc(name)}</b><small>${esc(sub || '')}</small></div><div class="lv-sr">${badge(st, word)}${next ? `<small class="muted">next <span data-until="${next}">${until(next)}</span></small>` : ''}</div></div>`).join('')}</div>`;
}
function salesList() {
  if (!L.sales.length) return `<div class="emptystate">${I('card')}<h4>No payments yet</h4><p>When someone pays, it appears here within ${L.watchers.stripe.every || 2} minutes with what happened to their supporter code and email.</p></div>`;
  return `<div class="lv-sale-list">${L.sales.map(x => {
    const chip = x.disputed ? ['bad', 'Disputed'] : x.refunded >= x.amount ? ['off', 'Refunded'] : x.code === 'issued' ? ['ok', 'Code issued'] : x.code === 'has' ? ['ok', 'Supporter'] : x.counts ? ['ok', 'Counts toward perks'] : ['off', 'Doesn’t count'];
    return `<a class="lv-sale" href="${esc(x.dash || 'https://dashboard.stripe.com/payments')}" target="_blank" rel="noopener" title="${esc(x.why || '')}">
      <div><b>${esc(x.name || x.email || 'Someone')}</b><small>${esc(x.product || 'Payment')}${x.country ? ` · ${esc(x.country)}` : ''}${x.livemode ? '' : ' · TEST'} · ${rel(new Date(x.created * 1000).toISOString())}</small></div>
      <div class="lv-amt"><b>${minor(x.amount, x.currency)}</b>${badge(chip[0], chip[1])}</div></a>`;
  }).join('')}</div>`;
}
const FEED_IC = { discord: 'discord', mail: 'mail', sale: 'card' };
function feed() {
  if (!L.feed.length) return `<p class="muted">Nothing yet. Alerts, emails and payments stream in here.</p>`;
  return `<div class="lv-feed-list">${L.feed.map(f => {
    const st = f.status === 'failed' ? 'bad' : f.status === 'skipped' || f.status === 'deleted' ? 'off' : 'ok';
    const what = f.type === 'discord' ? `${f.channel === 'public' ? 'Public' : 'Private'} Discord${f.test ? ' · test' : ''}` : f.type === 'mail' ? (f.status === 'sent' ? 'Email sent' : 'Email written') : (f.status === 'refunded' ? 'Payment (refunded)' : 'Payment');
    return `<div class="lv-fi ${st}"><span class="lv-fic">${I(FEED_IC[f.type] || 'bell')}</span><div><b>${esc(f.title)}</b><small>${esc(what)}${f.sub ? ` · ${esc(f.sub)}` : ''}${f.error ? ` · ${esc(f.error)}` : ''}</small></div><time>${rel(f.at)}</time></div>`;
  }).join('')}</div>`;
}
function sideInfo() {
  const st = L.store, a = L.apps, v = L.videos, sch = L.discord.scheduled, p = L.perks;
  return `<div class="card-head"><h3>${I('layers')}Store, content &amp; schedule</h3></div>
  <div class="lv-kv">
    <div><span>${I('can')}Supply caffeine</span><b>${st?.donate ? `${esc(st.donate.label)}${st.donate.active ? '' : ' · OFF'}` : L.donateOn ? 'Linked' : 'Not set'}</b><a href="#/store">Prices</a></div>
    <div><span>${I('tag')}Payment links on</span><b>${st?.error ? '—' : st?.links ?? '—'}</b><a href="#/store">Store</a></div>
    <div><span>${I('key')}Code rules</span><b>${p.autoIssue ? 'Automatic' : 'Manual'} · ${p.products.length ? `${p.products.length} perk product${p.products.length > 1 ? 's' : ''}` : 'any payment'} · ${money(L.threshold, L.currency)}+</b><a href="#/store/perks">Rules</a></div>
    <div><span>${I('layers')}Apps on the site</span><b>${a.published} of ${a.total}${a.featured ? ` · ${a.featured} featured` : ''}</b><a href="#/apps">Apps</a></div>
    <div><span>${I('youtube')}Videos</span><b>${v.total}${v.latest ? ` · latest ${rel(v.latest.published)}` : ''}</b><a href="#/media">Videos</a></div>
    <div><span>${I('inbox')}Submissions</span><b>${L.submissions ? `${L.submissions.pending} to review` : 'Not checked yet'}</b><a href="#/community/inbox">Inbox</a></div>
    <div><span>${I('calendar')}Summary</span><b>${L.digest.mode === 'off' ? 'Off' : `${L.digest.mode === 'weekly' ? 'Weekly' : 'Daily'}${L.digest.last ? ` · last ${rel(L.digest.last)}` : ''}`}</b><a href="#/alerts/setup">Edit</a></div>
  </div>
  ${sch.length ? `<div class="lv-sched"><b>${I('clock')}Scheduled posts</b>${sch.map(x => `<div><span>${esc(x.title)}</span><small>${x.channel} · ${new Date(x.at).toLocaleString()}</small></div>`).join('')}</div>` : ''}
  ${v.latest ? `<a class="lv-video" href="https://www.youtube.com/watch?v=${esc(v.latest.id)}" target="_blank" rel="noopener"><img src="https://i.ytimg.com/vi/${esc(v.latest.id)}/mqdefault.jpg" alt=""><span>${esc(v.latest.title)}</span></a>` : ''}`;
}

// ---------- hover tooltip for the chart ----------
function onHover(e) {
  const t = $('#lvTip'); if (!t) return;
  const h = e.target.closest?.('.lv-hit');
  $$('.lv-hit.on').forEach(x => x !== h && x.classList.remove('on'));
  if (!h) { t.hidden = true; return; }
  h.classList.add('on');
  const [d, amt, c] = h.dataset.tip.split('|');
  t.innerHTML = `<small>${esc(d)}</small><b>${esc(amt)}</b><small>${esc(c)}</small>`;
  t.hidden = false;
  const box = $('#livePanel').getBoundingClientRect();
  t.style.left = Math.min(box.width - 150, e.clientX - box.left + 14) + 'px';
  t.style.top = (e.clientY - box.top - 10) + 'px';
}

async function onClick(e) {
  const q = s => e.target.closest(s);
  let b;
  try {
    if (q('[data-refresh]')) { await refresh(); toast('Up to date'); return; }
    if (q('[data-publish]')) { $('#publishBtn').click(); return; }
    if ((b = q('[data-run]'))) { b.disabled = true; b.innerHTML = '<span class="spinner"></span>Checking…'; await api('POST', '/api/alerts/run', { what: b.dataset.run }); await refresh(); return; }
    if (q('[data-autostart]')) { await api('POST', '/api/alerts/autostart', { on: true }); toast('The hub now starts quietly with Windows'); await refresh(); return; }
    if ((b = q('[data-approve]'))) {
      if (!(await confirmBox('Approve and issue the code?', 'A supporter code is created, the site publishes, and the email sends once the code is live.', 'Approve', false))) return;
      b.disabled = true; await api('POST', '/api/perks/review', { id: b.dataset.approve, approve: true }); toast('Approved. Code issued ✓'); await refresh(); return;
    }
    if ((b = q('[data-dismiss]'))) {
      if (!(await confirmBox('Dismiss this review?', 'No code is issued. You can still issue one by hand in Community → Supporters.', 'Dismiss'))) return;
      await api('POST', '/api/perks/review', { id: b.dataset.dismiss, approve: false }); await refresh(); return;
    }
  } catch (err) { toast(err.message, 'err'); refresh(); }
}
