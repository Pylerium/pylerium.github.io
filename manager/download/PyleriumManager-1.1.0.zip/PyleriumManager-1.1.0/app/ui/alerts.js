// Discord & alerts: webhooks, which events go where, watchers, the post composer, the email outbox and the activity log.
import { R, S, $, $$, esc, api, toast, confirmBox, formBox, rel, on, fmtMoney } from './core.js';

let A = null, LOG = null, OUT = null, tab = 'setup', logFilter = 'all', saveT = 0, openLog = null;
const D = { channel: 'public', content: '', embed: { title: '', url: '', description: '', color: '#2DD4BF', image: '', thumbnail: '', footer: '', author: true, timestamp: false }, buttons: [], ping: false, later: false, at: '' };
const SWATCH = ['#2DD4BF', '#8B5CF6', '#38BDF8', '#22C55E', '#F59E0B', '#F97316', '#FB7185', '#EF4444', '#5865F2'];
const get = (o, p) => p.split('|').reduce((x, k) => x?.[k], o);
const set = (o, p, v) => { const ks = p.split('|'); let x = o; for (const k of ks.slice(0, -1)) x = x[k] = x[k] ?? {}; x[ks.at(-1)] = v; };
const I = n => R.icon(n);

export function init() {
  $('#alTabs').addEventListener('click', e => { const b = e.target.closest('[data-at]'); if (b) location.hash = '#/alerts/' + b.dataset.at; });
  const P = $('#alPanel');
  P.addEventListener('input', onInput);
  P.addEventListener('change', onInput);
  P.addEventListener('click', onClick);
  P.addEventListener('submit', onSubmit);
  load(true);
  setInterval(() => load(true), 60000);
}
export async function show(sub) {
  if (sub) tab = sub;
  $$('#alTabs button').forEach(b => b.classList.toggle('on', b.dataset.at === tab));
  if (!A) await load();
  if (tab === 'log') await loadLog();
  if (tab === 'emails') await loadOut();
  render();
}
async function load(quiet) {
  try { A = await api('GET', '/api/alerts'); badges(); if (!quiet && !$('main[data-view=alerts]').hidden) render(); }
  catch (e) { if (!quiet) toast(e.message, 'err'); }
}
async function loadLog() { LOG = (await api('GET', '/api/alerts/log')).log; }
async function loadOut() { OUT = (await api('GET', '/api/outbox')).outbox; }
function badges() {
  const n = (A?.outboxReady || 0) + (A?.held || 0);
  $('#nAlerts').hidden = !n; $('#nAlerts').textContent = n; $('#nOutbox').textContent = n || '';
  const live = A && (A.hooks.private.set || A.hooks.public.set);
  $('#alStatus').innerHTML = !A ? '' : live ? `<span class="dc-live"><i></i>${A.hooks.private.set && A.hooks.public.set ? 'Both channels connected' : 'One channel connected'}</span>` : `<span class="dc-live off"><i></i>Not connected</span>`;
}
function render() {
  if (!A) return;
  const P = $('#alPanel');
  const scroll = scrollY;
  P.innerHTML = tab === 'events' ? eventsHTML() : tab === 'compose' ? composeHTML() : tab === 'emails' ? emailsHTML() : tab === 'log' ? logHTML() : setupHTML();
  if (tab === 'compose') preview();
  scrollTo({ top: scroll });
}

// ---------- form bits ----------
const sw = (path, label, o = {}) => `<label class="switch${o.cls ? ' ' + o.cls : ''}"${o.title ? ` title="${esc(o.title)}"` : ''}><input type="checkbox" data-s="${path}"${get(A.settings, path) ? ' checked' : ''}${o.disabled ? ' disabled' : ''}><span class="track"><i></i></span>${label ? `<span class="sw-lbl">${label}</span>` : ''}</label>`;
const inp = (path, label, o = {}) => `<label class="fld"><span>${esc(label)}${o.help ? ` <small>${esc(o.help)}</small>` : ''}</span><input data-s="${path}" type="${o.type || 'text'}" value="${esc(get(A.settings, path) ?? '')}" placeholder="${esc(o.ph || '')}"${o.min != null ? ` min="${o.min}"` : ''}${o.mono ? ' class="mono"' : ''}></label>`;
const sel = (path, opts, o = {}) => `<select data-s="${path}"${o.cls ? ` class="${o.cls}"` : ''}>${opts.map(([v, l]) => `<option value="${esc(v)}"${String(get(A.settings, path)) === String(v) ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>`;

// ---------- setup ----------
function channelCard(ch) {
  const h = A.hooks[ch], c = A.settings.channels[ch], info = h.info;
  const priv = ch === 'private';
  return `<div class="card dc-ch ${ch}">
    <div class="card-head"><h3>${I(priv ? 'lock' : 'megaphone')}${priv ? 'Private alerts' : 'Public announcements'}</h3>${h.set ? `<span class="dc-pill ok">${I('check')}Connected</span>` : `<span class="dc-pill">Not connected</span>`}</div>
    <p class="sub">${priv ? 'Just for you: sales, customer emails, submissions, errors. Never share this webhook.' : 'Your community channel: new apps, updates, videos and milestones.'}</p>
    ${info ? `<div class="dc-hook"><img src="${esc(info.avatarUrl || c.avatar || '/site/assets/studio-mark.svg')}" alt=""><div><b>${esc(info.name || 'Webhook')}</b><small>Channel ${esc(info.channelId || '')} · checked ${rel(info.checkedAt)}</small></div><button type="button" class="act" data-recheck="${ch}" title="Check it still works">${I('refresh')}</button></div>` : ''}
    <form class="inrow" data-hook="${ch}"><input name="url" type="password" autocomplete="off" placeholder="${esc(h.masked || 'https://discord.com/api/webhooks/…')}"><button class="hbtn ${h.set ? 'ghost' : 'primary'} sm" type="submit">${I('save')}${h.set ? 'Replace' : 'Connect'}</button>${h.set ? `<button class="hbtn ghost sm" type="button" data-unhook="${ch}">Remove</button>` : ''}</form>
    ${sw(`channels|${ch}|enabled`, priv ? 'Send private alerts' : 'Post announcements')}
    <div class="f2">${inp(`channels|${ch}|username`, 'Posts as', { ph: priv ? 'Pylerium Manager' : (S.site?.brand?.name || 'My Studio') })}${inp(`channels|${ch}|avatar`, 'Avatar image URL', { ph: 'https://…png', help: 'optional' })}</div>
    <div class="f2"><label class="fld"><span>Ping on important alerts</span>${sel(`channels|${ch}|ping|type`, [['none', 'No ping'], ['here', '@here (people online)'], ['everyone', '@everyone'], ['role', 'A role…'], ['user', 'Just me (user ID)…']])}</label>
      ${['role', 'user'].includes(c.ping?.type) ? inp(`channels|${ch}|ping|id`, c.ping.type === 'role' ? 'Role ID' : 'Your user ID', { ph: '123456789012345678', mono: 1, help: 'Developer Mode → right-click → Copy ID' }) : `<div class="fld"><span>&nbsp;</span><small class="help">Which alerts ping is set per alert in <a href="#/alerts/events">Alerts</a>.</small></div>`}</div>
    <div class="row"><button type="button" class="hbtn ghost sm" data-test="hello" data-ch="${ch}"${h.set ? '' : ' disabled'}>${I('send')}Send a test message</button></div>
  </div>`;
}
function watcherRow(key, name, path, minPath, help, extra = '') {
  const w = A.watchers[name] || {};
  return `<div class="wt-row">
    <div class="wt-l">${sw(path, '')}<div><b>${name}</b><small>${help}</small>${w.at ? `<small class="${w.ok === false ? 'bad' : 'ok'}">${w.ok === false ? I('x') : I('check')} ${rel(w.at)} · ${esc(w.msg || '')}</small>` : '<small>Not checked yet</small>'}${extra}</div></div>
    <div class="wt-r"><span class="muted">every</span><input class="num" type="number" min="1" data-s="${minPath}" value="${esc(get(A.settings, minPath))}"><span class="muted">min</span><button type="button" class="hbtn ghost sm" data-run="${key}">${I('refresh')}Check now</button></div>
  </div>`;
}
function setupHTML() {
  const a = A.settings.auto, dg = A.settings.digest;
  const hours = Array.from({ length: 24 }, (_, h) => [h, new Date(2000, 0, 1, h).toLocaleTimeString([], { hour: 'numeric' })]);
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map((d, i) => [i, d]);
  return `<div class="cols">${channelCard('private')}${channelCard('public')}</div>
  <div class="cols" style="margin-top:18px">
    <div class="card"><div class="card-head"><h3>${I('zap')}Watchers</h3><span class="muted">run while the hub is open</span></div>
      <p class="sub">The hub checks these in the background and alerts Discord the moment something happens.</p>
      ${watcherRow('stripe', 'Stripe', 'watch|stripe', 'watch|stripeMin', 'New sales, donations, refunds and disputes', !A.stripeKey ? `<small class="bad">${I('key')} Add a Stripe key in <a href="#/community/settings">Caffeine &amp; perks</a></small>` : '')}
      ${watcherRow('submissions', 'Submissions', 'watch|submissions', 'watch|submissionsMin', 'New app submissions on GitHub')}
      ${watcherRow('youtube', 'YouTube', 'watch|youtube', 'watch|youtubeMin', 'New videos and Shorts on your channel')}
      <label class="switch big"><input type="checkbox" data-autostart${A.autostart ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Start the hub quietly when Windows starts, so no sale is missed</span></label>
      ${A.stripeSeeded ? `<button type="button" class="linkbtn" data-reseed>Reset Stripe tracking (marks every existing payment as seen)</button>` : ''}
    </div>
    <div class="card"><h3>${I('sparkles')}Automatic actions</h3>
      <div class="auto-list">
        ${[['issueCodes', 'Issue supporter codes automatically', 'Only for qualifying payments (rules in Store → Perk rules): live, right product, not refunded or disputed.'],
          ['publishCodes', 'Publish so new codes work right away', 'Only if nothing else is waiting to be published. Otherwise you get a “publish needed” alert.'],
          ['thanksEmail', 'Thank-you email for every other payment', 'Sent automatically when Gmail is connected (Emails tab).'],
          ['waitLive', 'Announce releases only once they’re live', 'Waits for GitHub Pages to finish (about a minute) so links work.'],
          ['publishVideos', 'Publish the site when a new video appears', 'Same safety rule as codes.'],
          ['richCards', 'Rich cards with images and details', 'Off = plain text with a link.'],
          ['buttons', 'Link buttons under posts', 'Get it, Watch, Open in Stripe, Receipt…']]
          .map(([k, l, h]) => `<div class="auto-row">${sw(`auto|${k}`, '')}<div><b>${l}</b><small>${h}</small></div></div>`).join('')}
      </div>
    </div>
    <div class="card"><h3>${I('calendar')}Summary &amp; milestones</h3>
      <div class="f2"><label class="fld"><span>Summary</span>${sel('digest|mode', [['daily', 'Every day'], ['weekly', 'Every week'], ['off', 'Off']])}</label>
        <label class="fld"><span>At</span>${sel('digest|hour', hours)}</label></div>
      ${dg.mode === 'weekly' ? `<label class="fld"><span>On</span>${sel('digest|day', days)}</label>` : ''}
      ${sw('digest|skipEmpty', 'Skip it when nothing happened')}
      <label class="fld"><span>Milestones <small>amounts, comma separated</small></span><input data-s="milestones" data-list value="${esc(A.settings.milestones.join(', '))}"></label>
      <div class="row"><button type="button" class="hbtn ghost sm" data-run="digest"${A.hooks.private.set ? '' : ' disabled'}>${I('send')}Send a summary now</button>${A.lastDigest ? `<span class="muted">Last: ${rel(A.lastDigest)}</span>` : ''}</div>
    </div>
  </div>`;
}

// ---------- events ----------
function eventsHTML() {
  const groups = [...new Set(A.events.map(e => e.group))];
  const s = A.settings;
  const prev = id => (s.templates[id] ?? A.defaults.templates[id]);
  return `<div class="card">
    <div class="card-head"><h3>${I('bell')}What gets posted where</h3><div class="row">
      <button type="button" class="hbtn ghost sm" data-preset="recommended">Recommended</button>
      <button type="button" class="hbtn ghost sm" data-preset="all">Everything to private</button>
      <button type="button" class="hbtn ghost sm" data-preset="quiet">Only sales &amp; errors</button></div></div>
    <p class="sub">Turn each alert on for your private channel, your public channel, or both. <b>Ping</b> uses the mention you chose for that channel in Setup. 🧪 sends a sample right now.</p>
    ${!A.hooks.private.set && !A.hooks.public.set ? `<p class="note lock"><span>${I('info')}</span>Connect a webhook in <a href="#/alerts/setup">Setup</a> first.</p>` : ''}
    <div class="ev-table">
      <div class="ev-head"><span>Alert</span><span>${I('lock')}Private</span><span>${I('megaphone')}Public</span><span>${I('bell')}Ping</span><span>Test</span></div>
      ${groups.map(g => `<div class="ev-group">${esc(g)}</div>${A.events.filter(e => e.group === g).map(e => {
        const st = s.events[e.id] || {};
        return `<div class="ev-row${st.private || st.public ? ' on' : ''}">
          <div class="ev-l"><span class="ev-emo">${e.emoji}</span><div><b>${esc(e.label)}</b><small>${esc(e.desc)}</small></div></div>
          <div class="ev-c" data-lbl="Private">${sw(`events|${e.id}|private`, '')}</div>
          <div class="ev-c" data-lbl="Public">${e.pubOk ? sw(`events|${e.id}|public`, '') : '<span class="dash" title="Private only: contains customer details">—</span>'}</div>
          <div class="ev-c" data-lbl="Ping">${sw(`events|${e.id}|ping`, '', { cls: 'sm' })}</div>
          <div class="ev-c ev-t"><button type="button" class="act" data-test="${e.id}" data-ch="private" title="Send a sample to private"${A.hooks.private.set ? '' : ' disabled'}>${I('lock')}</button>${e.pubOk ? `<button type="button" class="act" data-test="${e.id}" data-ch="public" title="Send a sample to public"${A.hooks.public.set ? '' : ' disabled'}>${I('megaphone')}</button>` : ''}</div>
          ${A.defaults.templates[e.id] ? `<div class="ev-tpl"><span>Message</span><input data-s="templates|${e.id}" value="${esc(prev(e.id))}" placeholder="${esc(A.defaults.templates[e.id])}"><button type="button" class="act" data-tplreset="${e.id}" title="Reset">${I('refresh')}</button></div>` : ''}
        </div>`;
      }).join('')}`).join('')}
    </div>
    <p class="note"><span>${I('info')}</span>Placeholders: <code>{name}</code> <code>{tagline}</code> <code>{version}</code> <code>{author}</code> <code>{url}</code> for apps, <code>{title}</code> for videos, <code>{text}</code> for announcements, <code>{amount}</code> <code>{count}</code> for milestones. Use <code>**bold**</code> like in Discord.</p>
  </div>`;
}

// ---------- composer ----------
function composeHTML() {
  const pub = S.apps.filter(a => a.published);
  const vids = (S.site?.youtube?.videos || []).filter(v => !v.hidden).slice(0, 12);
  const e = D.embed;
  return `<div class="compose">
    <div class="card">
      <div class="card-head"><h3>${I('send')}Post to Discord</h3><div class="seg" id="dChan"><button type="button" data-chan="public" class="${D.channel === 'public' ? 'on' : ''}">${I('megaphone')}Public</button><button type="button" data-chan="private" class="${D.channel === 'private' ? 'on' : ''}">${I('lock')}Private</button></div></div>
      <label class="fld"><span>Start from</span><select id="dFrom"><option value="">Blank post</option>
        <optgroup label="Announce an app">${pub.map(a => `<option value="app.new:${esc(a.id)}">🚀 ${esc(a.name)}</option>`).join('')}</optgroup>
        <optgroup label="Announce an update">${pub.map(a => `<option value="app.updated:${esc(a.id)}">🔧 ${esc(a.name)}${a.version ? ' ' + esc(a.version) : ''}</option>`).join('')}</optgroup>
        <optgroup label="Share a video">${vids.map(v => `<option value="video:${esc(v.id)}">${v.short ? '⚡' : '📺'} ${esc(R.cleanTitle ? R.cleanTitle(v.title) : v.title)}</option>`).join('')}</optgroup>
        <optgroup label="Quick posts"><option value="q:devlog">🛠️ Devlog / progress update</option><option value="q:caffeine">🥤 Supply caffeine shout-out</option><option value="q:submit">📥 Invite submissions</option><option value="q:poll">💬 Ask the community</option></optgroup>
      </select></label>
      <label class="fld"><span>Message <small id="dCount">${D.content.length}/2000</small></span><textarea rows="3" data-d="content" maxlength="2000" placeholder="Text above the card. **bold**, links and emoji work.">${esc(D.content)}</textarea></label>
      <details class="dc-sec" open><summary>${I('image')}Card</summary>
        <div class="f2"><label class="fld"><span>Title</span><input data-d="embed|title" value="${esc(e.title)}" maxlength="256"></label><label class="fld"><span>Title link</span><input data-d="embed|url" value="${esc(e.url)}" placeholder="https://"></label></div>
        <label class="fld"><span>Description</span><textarea rows="5" data-d="embed|description" maxlength="4000">${esc(e.description)}</textarea></label>
        <div class="f2"><label class="fld"><span>Big image URL</span><input data-d="embed|image" value="${esc(e.image)}" placeholder="https://…"></label><label class="fld"><span>Small image (corner)</span><input data-d="embed|thumbnail" value="${esc(e.thumbnail)}" placeholder="https://…"></label></div>
        <div class="f2"><label class="fld"><span>Footer</span><input data-d="embed|footer" value="${esc(e.footer)}"></label>
          <div class="fld"><span>Colour</span><div class="swatches">${SWATCH.map(c => `<button type="button" data-color="${c}" style="background:${c}" class="${e.color.toLowerCase() === c.toLowerCase() ? 'on' : ''}" aria-label="${c}"></button>`).join('')}<input type="color" data-d="embed|color" value="${esc(e.color)}"></div></div></div>
        <div class="row">${['author', 'timestamp'].map(k => `<label class="switch"><input type="checkbox" data-d="embed|${k}"${e[k] ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">${k === 'author' ? 'Studio name header' : 'Show time'}</span></label>`).join('')}</div>
      </details>
      <details class="dc-sec"${D.buttons.length ? ' open' : ''}><summary>${I('link')}Link buttons <small>${D.buttons.length}/5</small></summary>
        ${D.buttons.map((b, i) => `<div class="btn-row"><input data-d="buttons|${i}|emoji" value="${esc(b.emoji || '')}" placeholder="🔗" class="emo"><input data-d="buttons|${i}|label" value="${esc(b.label)}" placeholder="Label"><input data-d="buttons|${i}|url" value="${esc(b.url)}" placeholder="https://"><button type="button" class="act del" data-delbtn="${i}">${I('x')}</button></div>`).join('')}
        ${D.buttons.length < 5 ? `<button type="button" class="hbtn ghost sm" id="addBtn">${I('plus')}Add a button</button>` : ''}
      </details>
      <div class="send-row">
        <label class="switch"><input type="checkbox" data-d="ping"${D.ping ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Ping (${esc(pingLabel(D.channel))})</span></label>
        <label class="switch"><input type="checkbox" data-d="later"${D.later ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Schedule</span></label>
        ${D.later ? `<input type="datetime-local" data-d="at" value="${esc(D.at)}" class="dt">` : ''}
        <span class="sp"></span><button type="button" class="hbtn ghost sm" id="dClear">Clear</button>
        <button type="button" class="hbtn primary" id="dSend"${A.hooks[D.channel].set ? '' : ' disabled title="Connect this channel in Setup"'}>${I(D.later ? 'calendar' : 'send')}${D.later ? 'Schedule' : `Post to ${D.channel}`}</button>
      </div>
    </div>
    <div class="dc-pvwrap"><div class="pv-head"><span>Discord preview</span><span class="muted">#${D.channel === 'public' ? 'announcements' : 'studio-alerts'}</span></div><div class="dc-screen" id="dPrev"></div>
      ${A.scheduled.length ? `<div class="card sched"><h3>${I('calendar')}Scheduled</h3>${A.scheduled.map(s => `<div class="sc-row"><span class="dc-pill ${s.channel}">${s.channel}</span><div><b>${esc(s.title)}</b><small>${new Date(s.at).toLocaleString()}</small></div><button type="button" class="act del" data-unsched="${esc(s.id)}" title="Cancel">${I('x')}</button></div>`).join('')}</div>` : ''}
    </div>
  </div>`;
}
const pingLabel = ch => { const p = A.settings.channels[ch].ping || {}; return { here: '@here', everyone: '@everyone', role: 'role', user: 'you' }[p.type] || 'none set'; };
function draftPayload() {
  const e = D.embed, has = ['title', 'description', 'image', 'thumbnail'].some(k => String(e[k] || '').trim());
  const ok = u => /^https?:\/\/\S+$/.test(u || '');
  return {
    content: D.content,
    embeds: has ? [{ title: e.title, url: ok(e.url) ? e.url : '', description: e.description, color: parseInt(e.color.slice(1), 16), image: ok(e.image) ? { url: e.image } : null, thumbnail: ok(e.thumbnail) ? { url: e.thumbnail } : null, footer: e.footer ? { text: e.footer } : null, timestamp: e.timestamp ? new Date().toISOString() : null, author: e.author ? { name: S.site?.brand?.name || 'My Studio' } : null }] : [],
    components: D.buttons.filter(b => b.label && ok(b.url)).length ? [{ type: 1, components: D.buttons.filter(b => b.label && ok(b.url)).map(b => ({ type: 2, style: 5, label: b.label, url: b.url, emoji: b.emoji ? { name: b.emoji } : null })) }] : null
  };
}
function preview() {
  const el = $('#dPrev'); if (!el) return;
  const ch = A.settings.channels[D.channel], p = draftPayload();
  const pg = D.ping && ch.ping?.type !== 'none' ? { here: '@here', everyone: '@everyone', role: `<@&${ch.ping.id}>`, user: `<@${ch.ping.id}>` }[ch.ping.type] : '';
  el.innerHTML = dcMessage({ ...p, content: [pg, p.content].filter(Boolean).join(' '), username: ch.username || (D.channel === 'public' ? S.site?.brand?.name || 'My Studio' : 'Pylerium Manager'), avatar_url: ch.avatar || A.hooks[D.channel].info?.avatarUrl });
  const c = $('#dCount'); if (c) c.textContent = `${D.content.length}/2000`;
}
function fromPayload(p) {
  const e = p.embeds?.[0] || {};
  D.content = p.content || '';
  D.embed = { title: e.title || '', url: e.url || '', description: e.description || '', color: e.color != null ? '#' + e.color.toString(16).padStart(6, '0') : '#2DD4BF', image: e.image?.url || '', thumbnail: e.thumbnail?.url || '', footer: e.footer?.text || '', author: !!e.author, timestamp: !!e.timestamp };
  D.buttons = (p.components?.[0]?.components || []).map(b => ({ label: b.label, url: b.url, emoji: b.emoji?.name || '' }));
}
const QUICK = {
  devlog: () => ({ content: '🛠️ **Devlog**', embeds: [{ title: 'What I’m working on', description: '• \n• \n• \n\nWhat should come next? Reply below 👇', color: 0x8B5CF6, author: { name: S.site?.brand?.name || 'My Studio' }, timestamp: 1 }] }),
  caffeine: () => ({ content: '🥤 Enjoying the apps? Every energy drink keeps the updates coming.', embeds: [{ title: S.site.donate?.label || 'Supply caffeine', url: S.site.donate?.url || '', description: `Supporters who give **${fmtMoney(S.site.community?.threshold ?? 10)}+** unlock app submissions on the showcase, and can get their own apps featured.`, color: 0xF59E0B, author: { name: S.site?.brand?.name || 'My Studio' } }], components: [{ components: [{ label: 'Supply caffeine', url: S.site.donate?.url || '', emoji: { name: '🥤' } }, { label: 'See the apps', url: S.config.siteUrl }] }] }),
  submit: () => ({ content: '📥 **Built something cool?**', embeds: [{ title: `Get your app, mod or tool on ${S.site?.brand?.name || 'the showcase'}`, url: `${S.config.siteUrl}/#community`, description: 'Supporters can submit their own projects straight from the site. Accepted ones get a card with your name and links, and the best get featured.', color: 0x2DD4BF, author: { name: S.site?.brand?.name || 'My Studio' } }], components: [{ components: [{ label: 'How it works', url: `${S.config.siteUrl}/#community` }] }] }),
  poll: () => ({ content: '💬 **Quick question for everyone:**\n\nReact with 1️⃣ 2️⃣ 3️⃣', embeds: [] })
};

// ---------- emails ----------
function gmailCard() {
  const g = A.mail, st = g.smtp || {}, on = g.user && g.passSet;
  const pill = !on ? `<span class="dc-pill">Not connected</span>` : st.authFail ? `<span class="dc-pill bad">${I('x')}Password rejected</span>` : st.ok === false ? `<span class="dc-pill warn">Problem</span>` : `<span class="dc-pill ok">${I('check')}Connected</span>`;
  return `<div class="card gm-card">
    <div class="card-head"><h3>${I('mail')}Send automatically with Gmail</h3>${pill}</div>
    <p class="sub">The hub signs in to Gmail with an <b>App Password</b> and sends each email itself: codes the moment they’re live on the site, thank-yous straight away. Nothing leaves this computer except the email.</p>
    ${on ? `<div class="dc-hook"><span class="gm-av">${I('mail')}</span><div><b>${esc(g.user)}</b><small>${st.at ? `${st.ok === false ? 'Failed' : 'Worked'} ${rel(st.at)}` : 'Not tested yet'} · ${g.sentToday} sent today (limit ${A.settings.email.dailyCap})</small>${st.error ? `<small class="bad">${esc(st.error)}</small>` : ''}</div><button type="button" class="act" data-gmverify title="Test the connection">${I('refresh')}</button></div>` : ''}
    <form class="fb" id="gmForm">
      <div class="f2"><label class="fld"><span>Gmail address</span><input name="user" type="email" autocomplete="off" value="${esc(g.user || A.settings.email.from || '')}" placeholder="you@gmail.com"></label>
      <label class="fld"><span>App Password <small>16 letters</small></span><input name="pass" type="password" autocomplete="new-password" placeholder="${g.passSet ? '•••• •••• •••• •••• (saved)' : 'abcd efgh ijkl mnop'}"></label></div>
      <div class="row"><button class="hbtn primary sm" type="submit">${I('check')}${on ? 'Save &amp; test' : 'Connect Gmail'}</button>${on ? `<button type="button" class="hbtn ghost sm" data-gmtest>${I('send')}Send me a test email</button><button type="button" class="hbtn ghost sm" data-gmremove>Disconnect</button>` : ''}</div>
    </form>
    <details class="gm-help"${on ? '' : ' open'}><summary>How to get an App Password (2 minutes)</summary><ol>
      <li>Open <a href="https://myaccount.google.com/signinoptions/twosv" target="_blank" rel="noopener">2-Step Verification</a> for the Gmail account you send from and make sure it’s <b>on</b>.</li>
      <li>Open <a href="https://myaccount.google.com/apppasswords" target="_blank" rel="noopener">App passwords</a>, type a name like <i>Pylerium Manager</i> and press <b>Create</b>.</li>
      <li>Copy the 16-letter password Google shows, paste it above and press <b>Connect Gmail</b>. The hub tests it before saving.</li></ol>
      <p class="muted">It’s stored only in <code>studio-hub/data/secrets.json</code> on this PC. Revoke it any time on the same Google page.</p></details>
    <div class="auto-list">
      ${[['auto', 'Send emails automatically', 'Off = the outbox waits for you to press Send.'],
        ['sendCodes', 'Send supporter-code emails', 'Only after the code is live on the site (checked every minute).'],
        ['sendThanks', 'Send thank-you emails', 'For payments that don’t unlock a code.'],
        ['waitForLive', 'Hold code emails until the code works on the live site', 'Strongly recommended. Codes go live with the next publish.'],
        ['html', 'Branded HTML email', 'A clean card with your logo; the plain-text version is always included.'],
        ['bccSelf', 'BCC myself a copy', 'Keeps a copy of every customer email in your inbox.']]
        .map(([k, l, h]) => `<div class="auto-row">${sw(`email|${k}`, '')}<div><b>${l}</b><small>${h}</small></div></div>`).join('')}
    </div>
    <div class="f2">${inp('email|fromName', 'Sender name', { ph: S.site?.brand?.name || 'My Studio' })}${inp('email|replyTo', 'Replies go to', { ph: 'optional, e.g. your support address', help: 'Reply-To' })}</div>
    <div class="f2">${inp('email|dailyCap', 'Daily sending limit', { type: 'number', min: 1, help: 'Gmail allows about 500/day' })}<div></div></div>
  </div>`;
}
const MAIL_ST = { ready: ['Ready', ''], waiting: ['Waiting for code to go live', 'warn'], sent: ['Sent', 'ok'], failed: ['Failed', 'bad'], cancelled: ['Cancelled', ''] };
function emailsHTML() {
  const list = OUT || [], open = list.filter(m => ['ready', 'waiting', 'failed'].includes(m.status)), done = list.filter(m => !['ready', 'waiting', 'failed'].includes(m.status));
  const t = A.settings.email.templates, auto = A.settings.email.auto && A.mail.user && A.mail.passSet && !A.mail.smtp?.authFail;
  return `<div class="cols mail-cols">
    <div class="card">
      <div class="card-head"><h3>${I('mail')}Outbox</h3><div class="row"><span class="muted">${open.length} to send${A.mail.waiting ? ` · ${A.mail.waiting} waiting for publish` : ''}</span>${A.mail.waiting ? `<button type="button" class="hbtn ghost sm" data-checklive>${I('refresh')}Check site now</button>` : ''}</div></div>
      <p class="sub">${auto ? `${I('zap')} <b>Automatic:</b> emails send through ${esc(A.mail.user)} by themselves. You can still edit or send any email right now.` : 'Every sale writes the right email here. Connect Gmail (right) to send them automatically, or open each one in Gmail.'}</p>
      ${!list.length ? `<div class="emptystate">${I('mail')}<h4>Nothing to send</h4><p>Emails appear here when someone buys or donates, or when you issue a code.</p></div>` : ''}
      <div class="mail-list">${open.map(mailCard).join('')}</div>
      ${done.length ? `<details class="done-subs"><summary>Sent &amp; cancelled (${done.length})</summary><div class="mail-list">${done.map(mailCard).join('')}</div></details>` : ''}
    </div>
    <div class="stack">
      ${gmailCard()}
      <div class="card">
        <h3>${I('edit')}Email templates</h3>
        ${['code', 'thanks'].map(k => `<div class="tpl-box"><b>${k === 'code' ? 'Supporter code (threshold reached)' : 'Thank you (every other payment)'}</b>
          ${inp(`email|templates|${k}|subject`, 'Subject')}
          <label class="fld"><span>Body</span><textarea rows="9" data-s="email|templates|${k}|body">${esc(t[k].body)}</textarea></label>
          <div class="row"><button type="button" class="linkbtn" data-mailreset="${k}">Reset to default</button>${A.mail.user ? `<button type="button" class="linkbtn" data-gmtest="${k}">Send this to me as a test</button>` : ''}</div></div>`).join('')}
        <p class="note"><span>${I('info')}</span><span>Placeholders: <code>{name}</code> (first name) <code>{fullName}</code> <code>{code}</code> <code>{amount}</code> <code>{total}</code> <code>{product}</code> <code>{threshold}</code> <code>{submitUrl}</code> <code>{siteUrl}</code>. A line indented with 4 spaces becomes the big code box in the HTML email.</span></p>
      </div>
    </div>
  </div>`;
}
function mailCard(m) {
  const mailto = `mailto:${encodeURIComponent(m.to)}?subject=${encodeURIComponent(m.subject)}&body=${encodeURIComponent(m.body)}`;
  const [stl, stc] = MAIL_ST[m.status] || [m.status, ''];
  const openish = ['ready', 'waiting', 'failed'].includes(m.status);
  return `<div class="mail${openish ? '' : ' sent'}">
    <div class="mail-h"><span class="tchip t-${m.kind === 'code' ? 'lifetime' : 'donation'}">${m.kind === 'code' ? 'Code' : 'Thanks'}</span><div><b>${esc(m.name || m.to)}</b><small>${esc(m.to)} · ${rel(m.createdAt)}${m.sentAt ? ` · sent ${rel(m.sentAt)}${m.via === 'gmail' ? ' automatically' : ''}` : ''}</small></div><span class="mst ${stc}">${esc(stl)}</span></div>
    <div class="mail-s">${esc(m.subject)}</div>
    ${m.error ? `<div class="mail-err">${I('info')}${esc(m.error)}${m.attempts ? ` (try ${m.attempts})` : ''}</div>` : ''}
    <details><summary>Show email</summary><pre>${esc(m.body)}</pre></details>
    <div class="row">${openish
      ? `${A.mail.user && A.mail.passSet ? `<button type="button" class="hbtn primary sm" data-sendmail="${esc(m.id)}"${m.status === 'waiting' ? ' title="The code may not work on the site yet"' : ''}>${I('send')}Send now</button>` : `<a class="hbtn primary sm" href="${esc(m.gmail)}" target="_blank" rel="noopener" data-opened="${esc(m.id)}">${I('mail')}Open in Gmail</a>`}
        ${m.status === 'waiting' ? `<button type="button" class="hbtn ghost sm" data-release="${esc(m.id)}" title="Stop waiting for the site">Don’t wait</button>` : ''}
        <a class="hbtn ghost sm" href="${esc(mailto)}">Mail app</a><button type="button" class="hbtn ghost sm" data-copymail="${esc(m.id)}">${I('copy')}Copy</button><span class="sp"></span><button type="button" class="act" data-editmail="${esc(m.id)}" title="Edit">${I('edit')}</button><button type="button" class="hbtn ghost sm" data-marksent="${esc(m.id)}">${I('check')}Mark sent</button>`
      : `<button type="button" class="hbtn ghost sm" data-markready="${esc(m.id)}">Move back to outbox</button>`}<button type="button" class="act del" data-delmail="${esc(m.id)}" title="Delete">${I('trash')}</button></div>
  </div>`;
}

// ---------- log ----------
const evLabel = id => A.events.find(e => e.id === id)?.label || { custom: 'Custom post', scheduled: 'Scheduled post', hello: 'Test message' }[id] || id;
function logHTML() {
  const L = (LOG || []).filter(l => logFilter === 'all' || (logFilter === 'failed' ? l.status === 'failed' : l.channel === logFilter));
  return `<div class="card">
    <div class="card-head"><h3>${I('list')}Activity</h3><div class="row"><div class="seg" id="logSeg">${[['all', 'All'], ['private', 'Private'], ['public', 'Public'], ['failed', 'Failed']].map(([v, l]) => `<button type="button" data-lf="${v}" class="${logFilter === v ? 'on' : ''}">${l}</button>`).join('')}</div><button type="button" class="hbtn ghost sm" id="logRefresh">${I('refresh')}</button>${LOG?.length ? `<button type="button" class="hbtn ghost sm" id="logClear">Clear</button>` : ''}</div></div>
    <div class="stats-row"><div><b>${A.stats.sent}</b><span>sent</span></div><div><b>${A.stats.failed}</b><span>failed</span></div><div><b>${A.scheduled.length}</b><span>scheduled</span></div><div><b>${A.outboxReady}</b><span>emails ready</span></div></div>
    ${!L.length ? `<div class="emptystate">${I('bell')}<h4>Nothing yet</h4><p>Alerts and posts appear here as they go out.</p></div>` : ''}
    <div class="log-list">${L.map(l => `<div class="log${openLog === l.id ? ' open' : ''}">
      <button type="button" class="log-h" data-openlog="${esc(l.id)}"><span class="st st-${l.status}" title="${esc(l.status)}"></span><span class="dc-pill ${l.channel}">${l.channel}</span><span class="log-t"><b>${esc(l.title)}</b><small>${esc(evLabel(l.event))}${l.test ? ' · test' : ''}${l.error ? ` · <em>${esc(l.error)}</em>` : ''}</small></span><time>${rel(l.at)}</time></button>
      ${openLog === l.id ? `<div class="log-b"><div class="dc-screen">${l.payload ? dcMessage(l.payload) : '<p class="muted">No message body stored.</p>'}</div>
        <div class="row">${l.status !== 'sent' && l.payload ? `<button type="button" class="hbtn primary sm" data-retry="${esc(l.id)}">${I('refresh')}Send again</button>` : ''}
        ${l.status === 'sent' && l.messageId ? `${l.guildId ? `<a class="hbtn ghost sm" href="https://discord.com/channels/${esc(l.guildId)}/${esc(l.channelId)}/${esc(l.messageId)}" target="_blank" rel="noopener">${I('external')}Open in Discord</a>` : ''}<button type="button" class="hbtn ghost sm danger" data-unsend="${esc(l.id)}">${I('trash')}Delete from Discord</button>` : ''}
        ${l.status === 'deleted' ? '<span class="muted">Deleted from Discord.</span>' : ''}</div></div>` : ''}
    </div>`).join('')}</div>
  </div>`;
}

// ---------- Discord look-alike renderer ----------
function md(s) {
  let h = esc(s || '');
  const blocks = [];
  h = h.replace(/```(?:[a-z]*\n)?([\s\S]*?)```/g, (m, c) => `\u0000${blocks.push(`<pre>${c.replace(/^\n|\n$/g, '')}</pre>`) - 1}\u0000`);
  h = h.replace(/`([^`\n]+)`/g, '<code>$1</code>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>')
    .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/__([^_]+)__/g, '<u>$1</u>').replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<i>$2</i>')
    .replace(/&lt;@&amp;(\d*)&gt;/g, '<span class="dc-men">@role</span>').replace(/&lt;@(\d*)&gt;/g, '<span class="dc-men">@you</span>')
    .replace(/@(everyone|here)\b/g, '<span class="dc-men">@$1</span>')
    .replace(/(^|\s)(https?:\/\/[^\s<]+)/g, '$1<a href="$2" target="_blank" rel="noopener">$2</a>')
    .replace(/^&gt; (.*)$/gm, '<span class="dc-q">$1</span>');
  return h.replace(/\u0000(\d+)\u0000/g, (m, i) => blocks[i]);
}
export function dcMessage(p) {
  const time = new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const embed = e => {
    if (!e) return '';
    const col = e.color != null ? '#' + Number(e.color).toString(16).padStart(6, '0') : '#202225';
    const fields = (e.fields || []).filter(f => f && f.name);
    const img = u => (/^https?:/.test(u || '') ? u : '');
    return `<div class="dc-embed" style="--c:${col}"><div class="dc-e-main">
      ${e.author?.name ? `<div class="dc-e-author">${img(e.author.icon_url) ? `<img src="${esc(e.author.icon_url)}" alt="">` : ''}${esc(e.author.name)}</div>` : ''}
      ${e.title ? `<div class="dc-e-title">${e.url ? `<a href="${esc(e.url)}" target="_blank" rel="noopener">${esc(e.title)}</a>` : esc(e.title)}</div>` : ''}
      ${e.description ? `<div class="dc-e-desc">${md(e.description)}</div>` : ''}
      ${fields.length ? `<div class="dc-fields">${fields.map(f => `<div class="dc-f${f.inline ? ' in' : ''}"><b>${md(f.name)}</b><div>${md(f.value)}</div></div>`).join('')}</div>` : ''}
      ${img(e.image?.url) ? `<img class="dc-e-img" src="${esc(e.image.url)}" alt="" loading="lazy">` : ''}
      ${e.footer?.text || e.timestamp ? `<div class="dc-e-foot">${img(e.footer?.icon_url) ? `<img src="${esc(e.footer.icon_url)}" alt="">` : ''}${esc(e.footer?.text || '')}${e.footer?.text && e.timestamp ? ' • ' : ''}${e.timestamp ? 'Today at ' + time : ''}</div>` : ''}
    </div>${img(e.thumbnail?.url) ? `<img class="dc-e-thumb" src="${esc(e.thumbnail.url)}" alt="">` : ''}</div>`;
  };
  const btns = (p.components || []).flatMap(r => r.components || []).filter(b => b.label);
  return `<div class="dc-msg"><img class="dc-av" src="${esc(p.avatar_url || '/site/assets/studio-mark.svg')}" alt="" onerror="this.onerror=null;this.src='/site/assets/studio-avatar.png'"><div class="dc-body">
    <div class="dc-head"><b>${esc(p.username || S.site?.brand?.name || 'My Studio')}</b><span class="dc-app">APP</span><time>Today at ${time}</time></div>
    ${p.content ? `<div class="dc-content">${md(p.content)}</div>` : ''}
    ${(p.embeds || []).map(embed).join('')}
    ${btns.length ? `<div class="dc-btns">${btns.map(b => `<a class="dc-btn" href="${esc(b.url || '#')}" target="_blank" rel="noopener">${b.emoji?.name ? esc(b.emoji.name) + ' ' : ''}${esc(b.label)}${I('external')}</a>`).join('')}</div>` : ''}
    ${!p.content && !(p.embeds || []).length && !btns.length ? '<div class="dc-content muted">Your post will appear here.</div>' : ''}
  </div></div>`;
}

// ---------- events ----------
function saveSoon() {
  clearTimeout(saveT);
  $('#alSaved').textContent = 'Saving…';
  saveT = setTimeout(async () => {
    try { const r = await api('PUT', '/api/alerts', { settings: A.settings }); A = r; $('#alSaved').textContent = 'Saved ✓'; badges(); }
    catch (e) { toast(e.message, 'err'); $('#alSaved').textContent = ''; }
    setTimeout(() => { if ($('#alSaved').textContent === 'Saved ✓') $('#alSaved').textContent = ''; }, 1800);
  }, 450);
}
function onInput(e) {
  const t = e.target;
  if (t.dataset.s) {
    if (e.type === 'input' && (t.type === 'checkbox' || t.tagName === 'SELECT')) return;
    if (e.type === 'change' && t.type !== 'checkbox' && t.tagName !== 'SELECT' && t.type !== 'number') return;
    let v = t.type === 'checkbox' ? t.checked : t.type === 'number' ? +t.value : t.value;
    if ('list' in t.dataset) v = t.value.split(/[\s,]+/).map(Number).filter(x => x > 0);
    if (/\|(hour|day)$/.test(t.dataset.s)) v = +v;
    set(A.settings, t.dataset.s, v);
    saveSoon();
    if (t.tagName === 'SELECT' || t.type === 'checkbox') render();
    return;
  }
  if (t.dataset.d) {
    if (e.type === 'change' && t.type !== 'checkbox' && t.type !== 'color' && t.type !== 'datetime-local') return;
    set(D, t.dataset.d, t.type === 'checkbox' ? t.checked : t.value);
    if (t.type === 'checkbox') { if (t.dataset.d === 'later' && D.later && !D.at) { const d = new Date(Date.now() + 3600e3); d.setMinutes(0, 0, 0); D.at = new Date(d - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 16); } render(); }
    else preview();
    if (t.type === 'color') $$('.swatches button').forEach(b => b.classList.remove('on'));
    return;
  }
  if (t.matches('[data-autostart]') && e.type === 'change') {
    api('POST', '/api/alerts/autostart', { on: t.checked }).then(r => { A = r; toast(r.autostart ? 'The hub will start quietly with Windows' : 'Removed from Windows start-up'); }).catch(err => toast(err.message, 'err'));
  }
  if (t.id === 'dFrom' && e.type === 'change') pickFrom(t.value);
}
async function pickFrom(v) {
  if (!v) { Object.assign(D, { content: '', buttons: [] }); D.embed = { ...D.embed, title: '', url: '', description: '', image: '', thumbnail: '', footer: '' }; render(); return; }
  const [kind, id] = v.split(':');
  try {
    if (kind === 'q') { fromPayload(QUICK[id]()); }
    else { const r = await api('POST', '/api/discord/build', { kind, id }); fromPayload(r.payload); }
    render(); $('#dFrom').value = v;
  } catch (err) { toast(err.message, 'err'); }
}
const PRESETS = {
  recommended: ev => ({ private: !!ev.priv, public: !!(ev.pubOk && ev.pub), ping: !!ev.ping }),
  all: ev => ({ private: true, public: !!(ev.pubOk && ev.pub), ping: !!ev.ping }),
  quiet: ev => ({ private: /^sale\.(new|dispute|refund)$|^publish\.failed$|^hub\.error$|^publish\.needed$/.test(ev.id), public: !!(ev.pubOk && ev.pub), ping: !!ev.ping })
};
async function onClick(e) {
  const t = e.target;
  const q = s => t.closest(s);
  try {
    let b;
    if ((b = q('[data-test]'))) {
      b.disabled = true;
      const r = await api('POST', '/api/alerts/test', { event: b.dataset.test, channel: b.dataset.ch });
      const en = r.entry || {};
      if (en.status === 'sent') toast(`Sent to ${b.dataset.ch} ✓`); else if (en.status) toast(`${en.status}: ${en.error || ''}`, 'err'); else toast(en.skipped ? `Skipped: ${en.skipped}` : 'Summary sent');
      b.disabled = false; load(true); return;
    }
    if ((b = q('[data-run]'))) {
      b.disabled = true; b.innerHTML = '<span class="spinner"></span>Checking…';
      try { const r = await api('POST', '/api/alerts/run', { what: b.dataset.run }); A = r; toast(b.dataset.run === 'digest' ? 'Summary sent' : `${b.dataset.run[0].toUpperCase() + b.dataset.run.slice(1)} checked`); }
      finally { render(); }
      return;
    }
    if (q('[data-reseed]')) { if (!(await confirmBox('Reset Stripe tracking?', 'Every existing payment is marked as already seen. Only payments after this get alerts.', 'Reset', false))) return; A = await api('POST', '/api/alerts/reset-stripe'); render(); toast('Stripe tracking reset'); return; }
    if ((b = q('[data-recheck]'))) { A = await api('POST', '/api/alerts/webhook/check', { channel: b.dataset.recheck }); render(); toast('Webhook works ✓'); return; }
    if ((b = q('[data-unhook]'))) { if (!(await confirmBox('Remove this webhook?', 'Alerts for this channel stop until you connect one again.', 'Remove'))) return; A = await api('PUT', '/api/alerts/webhook', { channel: b.dataset.unhook, url: '' }); render(); badges(); return; }
    if ((b = q('[data-preset]'))) { for (const ev of A.events) A.settings.events[ev.id] = PRESETS[b.dataset.preset](ev); saveSoon(); render(); return; }
    if ((b = q('[data-tplreset]'))) { A.settings.templates[b.dataset.tplreset] = A.defaults.templates[b.dataset.tplreset]; saveSoon(); render(); return; }
    if ((b = q('[data-mailreset]'))) { A.settings.email.templates[b.dataset.mailreset] = { ...A.defaults.email[b.dataset.mailreset] }; saveSoon(); render(); return; }
    // composer
    if ((b = q('[data-chan]'))) { D.channel = b.dataset.chan; render(); return; }
    if ((b = q('[data-color]'))) { D.embed.color = b.dataset.color; render(); return; }
    if (q('#addBtn')) { D.buttons.push({ label: '', url: '', emoji: '' }); render(); return; }
    if ((b = q('[data-delbtn]'))) { D.buttons.splice(+b.dataset.delbtn, 1); render(); return; }
    if (q('#dClear')) { pickFrom(''); return; }
    if (q('#dSend')) {
      const btn = q('#dSend'); btn.disabled = true;
      const p = draftPayload();
      const body = { channel: D.channel, content: D.content, ping: D.ping, embed: p.embeds[0] ? { ...D.embed } : null, buttons: D.buttons, at: D.later && D.at ? new Date(D.at).toISOString() : '' };
      if (D.channel === 'public' && !D.later && !(await confirmBox('Post to your public channel?', 'Everyone in that channel will see it.', 'Post it', false))) { btn.disabled = false; return; }
      const r = await api('POST', '/api/discord/send', body);
      if (r.scheduled) { toast(`Scheduled for ${new Date(r.scheduled.at).toLocaleString()}`); await load(true); render(); return; }
      if (r.entry.status === 'sent') { toast(`Posted to ${D.channel} ✓`); pickFrom(''); } else toast(`${r.entry.status}: ${r.entry.error || ''}`, 'err');
      btn.disabled = false; load(true); return;
    }
    if ((b = q('[data-unsched]'))) { A = await api('DELETE', '/api/discord/scheduled/' + b.dataset.unsched); render(); toast('Cancelled'); return; }
    // emails
    if ((b = q('[data-sendmail]'))) {
      const m = OUT.find(x => x.id === b.dataset.sendmail);
      if (m?.status === 'waiting' && !(await confirmBox('Send before the code is live?', 'The site hasn’t been published with this code yet, so it may not work for a minute or two.', 'Send anyway', false))) return;
      b.disabled = true; b.innerHTML = '<span class="spinner"></span>Sending…';
      const r = await api('POST', '/api/outbox/send', { id: b.dataset.sendmail }); OUT = r.outbox; A = { ...A, ...r }; toast(`Sent to ${m?.to || 'customer'} ✓`); badges(); render(); return;
    }
    if ((b = q('[data-release]'))) { OUT = (await api('POST', '/api/outbox/release', { id: b.dataset.release })).outbox; await load(true); render(); return; }
    if (q('[data-checklive]')) { const r = await api('POST', '/api/outbox/check-live'); OUT = r.outbox; toast(r.released ? `${r.released} code email(s) released` : 'Codes aren’t live yet. Publish the site first.', r.released ? 'ok' : 'info'); await load(true); render(); return; }
    if (q('[data-gmverify]')) { try { A = await api('POST', '/api/email/verify'); toast('Gmail works ✓'); } catch (err) { await load(true); throw err; } render(); return; }
    if ((b = q('[data-gmtest]'))) {
      const r = await formBox('Send a test email', 'A sample with a fake code, so you can see exactly what customers get.', [{ name: 'to', label: 'Send to', type: 'email', value: A.mail.user }], 'Send test');
      if (!r) return; await api('POST', '/api/email/test', { to: r.to, kind: b.dataset.gmtest || 'code' }); toast(`Test sent to ${r.to} ✓`); load(true); return;
    }
    if (q('[data-gmremove]')) { if (!(await confirmBox('Disconnect Gmail?', 'Automatic emails stop. The app password is deleted from this PC (also revoke it on Google’s App passwords page).', 'Disconnect'))) return; A = await api('PUT', '/api/email/account', { user: '', pass: '' }); render(); return; }
    if ((b = q('[data-marksent]')) || (b = q('[data-markready]'))) { OUT = (await api('POST', '/api/outbox/mark', { id: b.dataset.marksent || b.dataset.markready, status: b.dataset.marksent ? 'sent' : 'ready' })).outbox; await load(true); render(); return; }
    if ((b = q('[data-delmail]'))) { if (!(await confirmBox('Delete this email?', 'It is removed from the outbox.'))) return; OUT = (await api('DELETE', '/api/outbox/' + b.dataset.delmail)).outbox; await load(true); render(); return; }
    if ((b = q('[data-copymail]'))) { const m = OUT.find(x => x.id === b.dataset.copymail); await navigator.clipboard.writeText(`To: ${m.to}\nSubject: ${m.subject}\n\n${m.body}`); toast('Email copied'); return; }
    if ((b = q('[data-editmail]'))) {
      const m = OUT.find(x => x.id === b.dataset.editmail);
      const r = await formBox('Edit email', '', [{ name: 'to', label: 'To', value: m.to }, { name: 'subject', label: 'Subject', value: m.subject }, { name: 'body', label: 'Body', type: 'textarea', rows: 12, value: m.body }], 'Save');
      if (!r) return; OUT = (await api('POST', '/api/outbox/edit', { id: m.id, ...r })).outbox; render(); return;
    }
    if ((b = q('[data-opened]'))) {
      const id = b.dataset.opened;
      setTimeout(async () => { if (await confirmBox('Did you send it?', 'Mark this email as sent so it leaves the outbox.', 'Mark sent', false)) { OUT = (await api('POST', '/api/outbox/mark', { id, status: 'sent' })).outbox; await load(true); render(); } }, 1200);
      return;
    }
    // log
    if ((b = q('[data-lf]'))) { logFilter = b.dataset.lf; render(); return; }
    if (q('#logRefresh')) { await Promise.all([loadLog(), load(true)]); render(); return; }
    if (q('#logClear')) { if (!(await confirmBox('Clear the activity log?', 'This only clears the list in the hub. Messages stay in Discord.', 'Clear'))) return; LOG = (await api('DELETE', '/api/alerts/log')).log; render(); return; }
    if ((b = q('[data-openlog]'))) { openLog = openLog === b.dataset.openlog ? null : b.dataset.openlog; render(); return; }
    if ((b = q('[data-retry]'))) { const r = await api('POST', '/api/alerts/retry', { id: b.dataset.retry }); LOG = r.log; toast(r.entry.status === 'sent' ? 'Sent ✓' : r.entry.error, r.entry.status === 'sent' ? 'ok' : 'err'); render(); return; }
    if ((b = q('[data-unsend]'))) { if (!(await confirmBox('Delete this message from Discord?', 'It disappears from the channel for everyone.'))) return; LOG = (await api('POST', '/api/alerts/unsend', { id: b.dataset.unsend })).log; toast('Deleted from Discord'); render(); return; }
  } catch (err) { toast(err.message, 'err'); render(); }
}
async function onSubmit(e) {
  if (e.target.id === 'gmForm') {
    e.preventDefault();
    const f = e.target, btn = f.querySelector('button[type=submit]'); btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>Signing in to Gmail…';
    try { A = await api('PUT', '/api/email/account', { user: f.user.value, pass: f.pass.value }); toast('Gmail connected. Emails now send automatically ✓'); badges(); }
    catch (err) { toast(err.message, 'err', 9000); }
    render(); return;
  }
  const f = e.target.closest('[data-hook]'); if (!f) return;
  e.preventDefault();
  const url = f.url.value.trim(); if (!url) return;
  const btn = f.querySelector('button[type=submit]'); btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>Checking…';
  try { A = await api('PUT', '/api/alerts/webhook', { channel: f.dataset.hook, url }); toast(`Connected to “${A.info?.name || 'Discord'}” ✓`); badges(); }
  catch (err) { toast(err.message, 'err'); }
  render();
}
on(w => { if ((w === 'apps' || w === 'site') && tab === 'compose' && !$('main[data-view=alerts]').hidden) render(); });
