// Markdown editor for long app descriptions: toolbar, shortcuts, list continuation, live preview (the same renderer the
// website uses), split view and a full-screen mode. It edits a normal <textarea>, so the form keeps working as before.
import { R } from './core.js';

const KEY = 'hub.mdedit.view';
let box, ta, prev, stats, view = localStorage.getItem(KEY) || 'write', raf = 0;

export function attach(root) {
  box = root; ta = root.querySelector('textarea'); prev = root.querySelector('.mded-prev'); stats = root.querySelector('.mded-stats');
  root.querySelectorAll('[data-i]').forEach(el => { if (!el.firstChild) el.innerHTML = R.icon(el.dataset.i); });
  root.addEventListener('click', onClick);
  ta.addEventListener('input', schedule);
  ta.addEventListener('keydown', onKey);
  ta.addEventListener('scroll', () => { if (view === 'split') { const m = ta.scrollHeight - ta.clientHeight; prev.scrollTop = m > 0 ? (ta.scrollTop / m) * (prev.scrollHeight - prev.clientHeight) : 0; } });
  ta.addEventListener('paste', () => setTimeout(fit, 0));
  addEventListener('resize', fit);
  setView(view);
}
// Call after the form is filled (a different app was opened).
export function refresh() { if (!box) return; if (box.classList.contains('full')) toggleFull(false); render(); fit(); ta.scrollTop = 0; prev.scrollTop = 0; }

function schedule() { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => { render(); fit(); }); }
function render() {
  const v = ta.value;
  if (view !== 'write') prev.innerHTML = v.trim() ? R.md(v) : '<p class="mded-empty">Nothing to preview yet.</p>';
  const words = (R.mdPlain(v).match(/\S+/g) || []).length;
  stats.textContent = v ? `${words.toLocaleString()} word${words === 1 ? '' : 's'} · about ${Math.max(1, Math.round(words / 220))} min read · ${v.length.toLocaleString()} characters` : 'Markdown works here: headings, lists, links, tables, code.';
}
function fit() {
  if (!ta || box.classList.contains('full')) { ta && (ta.style.height = ''); return; }
  if (view === 'write') { ta.style.height = 'auto'; ta.style.height = `${Math.min(Math.max(ta.scrollHeight + 2, 220), Math.round(innerHeight * 0.62))}px`; }
  else ta.style.height = '';
}
function setView(v) {
  view = v; localStorage.setItem(KEY, v);
  box.dataset.view = v;
  box.querySelectorAll('[data-mdv]').forEach(b => b.classList.toggle('on', b.dataset.mdv === v));
  render(); fit();
}
function toggleFull(on = !box.classList.contains('full')) {
  box.classList.toggle('full', on);
  document.documentElement.classList.toggle('mded-lock', on);
  const b = box.querySelector('[data-md="full"]');
  b.innerHTML = R.icon(on ? 'x' : 'grid'); b.title = on ? 'Close full screen (Esc)' : 'Full screen editor';
  if (on && view === 'write') setView('split'); else { render(); fit(); }
  ta.focus();
}

// ---------- editing ----------
function replace(start, end, text, selStart, selEnd) {
  ta.focus();
  ta.setSelectionRange(start, end);
  if (!document.execCommand('insertText', false, text)) { ta.setRangeText(text, start, end, 'end'); ta.dispatchEvent(new Event('input', { bubbles: true })); }
  if (selStart != null) ta.setSelectionRange(selStart, selEnd ?? selStart);
}
function wrap(before, after = before, placeholder = 'text') {
  const { selectionStart: s, selectionEnd: e, value: v } = ta;
  const sel = v.slice(s, e);
  if (sel && v.slice(s - before.length, s) === before && v.slice(e, e + after.length) === after) return replace(s - before.length, e + after.length, sel, s - before.length, e - before.length);
  const t = sel || placeholder;
  replace(s, e, before + t + after, s + before.length, s + before.length + t.length);
}
function lineRange() {
  const v = ta.value, s = ta.selectionStart, e = ta.selectionEnd;
  const a = v.lastIndexOf('\n', s - 1) + 1, b = v.indexOf('\n', e - (e > s && v[e - 1] === '\n' ? 1 : 0));
  return [a, b < 0 ? v.length : b];
}
function prefix(make, strip) {
  const [a, b] = lineRange(), lines = ta.value.slice(a, b).split('\n');
  const all = lines.filter(l => l.trim()).every(l => strip.test(l));
  let n = 0;
  const out = lines.map(l => (!l.trim() && lines.length > 1 ? l : all ? l.replace(strip, '') : make(l.replace(strip, ''), n++))).join('\n');
  replace(a, b, out, a, a + out.length);
}
const LIST = /^(\s*)([-*+]|\d{1,3}[.)])\s+(\[[ xX]\]\s+)?/;
const ACT = {
  bold: () => wrap('**', '**', 'bold text'),
  italic: () => wrap('_', '_', 'italic text'),
  strike: () => wrap('~~', '~~', 'text'),
  code: () => { const s = ta.value.slice(ta.selectionStart, ta.selectionEnd); s.includes('\n') ? wrap('```\n', '\n```', 'code') : wrap('`', '`', 'code'); },
  h: () => { const [a, b] = lineRange(); const l = ta.value.slice(a, b); const m = l.match(/^(#{1,3})\s+/); const next = !m ? '## ' : m[1].length === 2 ? '### ' : m[1].length === 3 ? '' : '## '; const out = next + l.replace(/^#{1,6}\s+/, ''); replace(a, b, out, a + out.length); },
  ul: () => prefix(l => `- ${l}`, /^\s*[-*+]\s+(\[[ xX]\]\s+)?/),
  ol: () => prefix((l, i) => `${i + 1}. ${l}`, /^\s*\d{1,3}[.)]\s+/),
  task: () => prefix(l => `- [ ] ${l}`, /^\s*[-*+]\s+\[[ xX]\]\s+/),
  quote: () => prefix(l => `> ${l}`, /^\s{0,3}>\s?/),
  link: () => {
    const { selectionStart: s, selectionEnd: e, value: v } = ta, sel = v.slice(s, e);
    if (/^https?:\/\/\S+$/.test(sel)) return replace(s, e, `[link text](${sel})`, s + 1, s + 10);
    const t = sel || 'link text';
    replace(s, e, `[${t}](https://)`, s + t.length + 3, s + t.length + 11);
  },
  hr: () => { const s = ta.selectionStart, v = ta.value; const pre = s && v[s - 1] !== '\n' ? '\n\n' : v[s - 2] === '\n' || !s ? '' : '\n'; replace(s, ta.selectionEnd, `${pre}---\n\n`); },
  table: () => { const s = ta.selectionStart, v = ta.value; const pre = s && v[s - 1] !== '\n' ? '\n\n' : ''; const t = `${pre}| Feature | Details |\n| --- | --- |\n| One | Something it does |\n| Two | Something else |\n`; replace(s, ta.selectionEnd, t, s + pre.length + 2, s + pre.length + 9); }
};

function onClick(e) {
  const b = e.target.closest('button'); if (!b || !box.contains(b)) return;
  if (b.dataset.mdv) return setView(b.dataset.mdv);
  if (b.dataset.md === 'full') return toggleFull();
  if (ACT[b.dataset.md]) { e.preventDefault(); ACT[b.dataset.md](); }
}
function onKey(e) {
  const mod = e.ctrlKey || e.metaKey;
  if (mod && !e.shiftKey && !e.altKey) {
    const k = e.key.toLowerCase();
    if (k === 'b') { e.preventDefault(); return ACT.bold(); }
    if (k === 'i') { e.preventDefault(); return ACT.italic(); }
    if (k === 'k') { e.preventDefault(); e.stopPropagation(); return ACT.link(); }
  }
  if (e.key === 'Escape' && box.classList.contains('full')) { e.preventDefault(); e.stopPropagation(); return toggleFull(false); }
  if (e.key === 'Enter' && !mod && !e.shiftKey && ta.selectionStart === ta.selectionEnd) {
    const v = ta.value, s = ta.selectionStart, a = v.lastIndexOf('\n', s - 1) + 1, line = v.slice(a, s);
    const m = line.match(LIST);
    if (!m) return;
    e.preventDefault();
    if (line.trim() === m[0].trim()) return replace(a, s, '');            // empty item: end the list
    const num = m[2].match(/^(\d+)([.)])$/);
    const marker = num ? `${+num[1] + 1}${num[2]}` : m[2];
    replace(s, s, `\n${m[1]}${marker} ${m[3] ? '[ ] ' : ''}`);
  }
  if (e.key === 'Tab' && LIST.test(ta.value.slice(lineRange()[0], lineRange()[1]))) {
    e.preventDefault();
    const [a, b] = lineRange(), out = ta.value.slice(a, b).split('\n').map(l => (e.shiftKey ? l.replace(/^ {1,2}/, '') : `  ${l}`)).join('\n');
    replace(a, b, out, a, a + out.length);
  }
}
