// Perk maker (Community → Perks): design perks, choose how people unlock them, give them out, approve lucky-drop claims.
import { R, S, $, $$, esc, api, toast, confirmBox, refreshStatus } from './core.js';

const I = (n, c) => R.icon(n, c);
let ST = null, draft = null, edTab = 'reward', busy = false;
const money = v => { try { return new Intl.NumberFormat('en', { style: 'currency', currency: ST?.currency || 'USD', currencyDisplay: 'narrowSymbol', minimumFractionDigits: (+v || 0) % 1 ? 2 : 0 }).format(+v || 0); } catch { return String(v); } };
const clone = o => structuredClone(o);
const ICONS = ['gift', 'crown', 'key', 'unlock', 'sparkles', 'zap', 'star', 'heart', 'rocket', 'download', 'tag', 'discord', 'lock', 'film', 'chart', 'activity', 'mail', 'megaphone', 'github', 'palette', 'music', 'gamepad', 'code', 'package', 'can', 'coffee', 'shield', 'bell', 'book', 'video', 'image', 'puzzle', 'users', 'send', 'globe', 'cpu', 'tv', 'car', 'bot', 'moon', 'eye', 'compass', 'wrench', 'phone', 'mic'];

// What each reward type asks for. Fields: url, label, text, code, keys, appId, instructions.
const FIELDS = {
  submit: [], download: ['url', 'label', 'text', 'instructions'], early: ['appId', 'url', 'label', 'text', 'instructions'], discount: ['code', 'text', 'url', 'label'],
  discord: ['url', 'text', 'instructions'], secret: ['text'], key: ['keys', 'appId', 'url', 'label', 'instructions'], wall: ['text', 'instructions'], credits: ['appId', 'text', 'instructions'],
  vote: ['url', 'label', 'text'], beta: ['appId', 'url', 'label', 'instructions'], support: ['url', 'label', 'text', 'instructions'], shoutout: ['url', 'label', 'instructions'],
  source: ['url', 'label', 'instructions'], assets: ['url', 'label', 'text'], custom: ['url', 'label', 'text', 'code', 'instructions']
};
const NEED = { download: 'url', early: 'url', discount: 'code', secret: 'text', key: 'keys', vote: 'url', assets: 'url' };
const FIELD_INFO = {
  url: ['Link', 'https://…', 'Only holders see it. A file, a page, a Discord invite, a form…'],
  label: ['Button text', 'e.g. Download the pack', 'optional'],
  text: ['Message', 'Write anything: thanks, instructions, a story. **Markdown** works.', 'shown to holders'],
  code: ['Code to reveal', 'e.g. THANKYOU20', 'the same code for every holder'],
  keys: ['Licence keys', 'One key per line. Each holder gets their own.', 'one per line'],
  appId: ['For app', '', 'optional'],
  instructions: ['How to use it', 'e.g. Reply to your code email with your Discord name and we’ll add the role.', 'optional, short']
};

// Starting points. Each one is a full perk the creator can tweak.
const TEMPLATES = [
  ['submit', 'Community creator', 'Submit your own apps, mods and tools to the showcase.', 'send', 'studio', { unlock: { total: 10 } }],
  ['early', 'Early access', 'Get new versions a week before everyone else.', 'zap', 'amber', { unlock: { total: 15 } }],
  ['discount', '20% off', 'A thank-you discount on any app in the store.', 'tag', 'emerald', { reward: { code: 'THANKYOU20', text: 'Use it at checkout on any app.' }, unlock: { dropMode: 'instant' } }],
  ['key', 'Free licence', 'A full licence key, on the house.', 'key', 'violet', { unlock: { dropMode: 'claim', dropStock: 10 }, limits: { stock: 10 } }],
  ['discord', 'Insider role', 'A private Discord channel and a special colour.', 'discord', 'sky', { reward: { instructions: 'Reply to your code email with your Discord username and we’ll add the role.' }, unlock: { total: 5 } }],
  ['download', 'Bonus build', 'An exclusive build with extra goodies.', 'download', 'ember', {}],
  ['assets', 'Wallpaper pack', 'Hi-res wallpapers and icons from the apps.', 'palette', 'rose', { unlock: { dropMode: 'instant' } }],
  ['secret', 'Developer diary', 'Behind-the-scenes notes on how the apps are made.', 'book', 'sky', { unlock: { total: 3 } }],
  ['wall', 'Gold name on the wall', 'A highlighted spot on the supporters wall.', 'crown', 'amber', { unlock: { total: 25 } }],
  ['credits', 'In the credits', 'Your name in the app’s credits screen.', 'film', 'crimson', { unlock: { total: 50 } }],
  ['vote', 'Roadmap vote', 'Help decide what gets built next.', 'chart', 'lime', { unlock: { total: 5 } }],
  ['beta', 'Beta tester', 'Try new builds first and shape them.', 'activity', 'studio', {}],
  ['support', 'Priority support', 'Jump the queue whenever you need help.', 'mail', 'sky', { unlock: { total: 20 } }],
  ['shoutout', 'Video shout-out', 'Your name in the next YouTube video.', 'megaphone', 'crimson', { limits: { stock: 10 } }],
  ['source', 'Source access', 'Read the source of a closed-source app.', 'github', 'violet', { reward: { instructions: 'Reply to your code email with your GitHub username and we’ll invite you.' } }],
  ['custom', 'Mystery perk', 'Something special. You’ll see.', 'sparkles', 'rose', {}]
];
function fromTemplate(i) {
  const [type, name, tagline, icon, accent, extra] = TEMPLATES[i];
  const p = { type, name, tagline, icon, accent, enabled: true, show: 'public', reward: { url: '', label: '', text: '', code: '', keys: [], appId: '', instructions: '' },
    unlock: { total: 0, apps: [], appsAll: false, products: [], buy: null, drops: [], dropMode: 'claim', dropDaily: 0, dropStock: 0 }, limits: { stock: 0, days: 0, endsAt: '', keepOnRefund: false } };
  for (const k of ['reward', 'unlock', 'limits']) Object.assign(p[k], extra[k] || {});
  return p;
}

// ---------- data ----------
export async function load() { ST = await api('GET', '/api/perks'); return ST; }
export const state = () => ST;
export async function show(P) {
  P.innerHTML = `<div class="card"><p class="empty-sm"><span class="spinner"></span> Loading perks…</p></div>`;
  try { await load(); } catch (e) { P.innerHTML = `<div class="card"><p class="note lock"><span>${I('info')}</span>${esc(e.message)}</p></div>`; return; }
  render(P);
}
const panel = () => $('#commPanel');
function render(P = panel()) { if (!P || !ST) return; P.innerHTML = mainHTML(); }

// How a perk is unlocked, in the same shape the site uses (for the preview and the list chips).
function howOf(p) {
  const u = p.unlock, how = [], app = id => ST.apps.find(a => a.id === id);
  if (+u.total) how.push({ k: 'total', amount: +u.total });
  if (u.buy && (u.buy.url || u.buy.price)) how.push({ k: 'buy', url: u.buy.url || '#', price: u.buy.price, label: u.buy.label });
  const ap = u.apps.map(id => app(id)).filter(Boolean); if (ap.length) how.push({ k: 'apps', all: u.appsAll && ap.length > 1, apps: ap.map(a => ({ id: a.id, name: a.name })) });
  const dr = u.drops.map(d => ({ ...d, a: app(d.appId) })).filter(d => d.a); if (dr.length) how.push({ k: 'drop', apps: dr.map(d => ({ id: d.a.id, name: d.a.name, chance: d.chance })) });
  if (!how.length) how.push({ k: 'gift' });
  return how;
}
const previewOf = p => ({ ...p, how: howOf(p), left: p.limits.stock ? Math.max(0, p.limits.stock - (p.holders || 0)) : null, endsAt: p.limits.endsAt, days: p.limits.days, holders: p.holders || 0 });
const missing = p => { const f = NEED[p.type]; return f && !(f === 'keys' ? p.reward.keys.length : p.reward[f]); };

// ---------- main view ----------
function mainHTML() {
  const perks = ST.perks, pending = ST.claims.filter(c => c.status === 'pending');
  const holders = new Set(Object.entries(ST.grants).filter(([, g]) => Object.values(g).some(x => !x.revoked && !x.expired)).map(([s]) => s)).size;
  const won = perks.reduce((n, p) => n + (p.dropsWon || 0), 0);
  return `<div class="pk">
    <div class="pk-hero">
      <div class="pk-hero-txt"><h2>${I('gift')}Perk maker</h2><p>Design thank-yous people can unlock: by buying an app, giving enough, buying the perk itself, or by luck when they download one of your apps. Give any perk by hand whenever you like.</p></div>
      <div class="pk-hero-acts"><button type="button" class="hbtn primary" data-pk="new">${I('plus')}New perk</button><button type="button" class="hbtn ghost" data-pk="give">${I('gift')}Give a perk</button><button type="button" class="hbtn ghost" data-pk="sync" title="Check Stripe purchases and support totals, and hand out anything people have earned">${I('refresh')}Check purchases</button></div>
      <div class="pk-stats"><div><b>${perks.filter(p => p.enabled).length}</b><span>perks live</span></div><div><b>${holders}</b><span>people with perks</span></div><div><b>${won}</b><span>lucky drops won</span></div><div class="${pending.length ? 'hot' : ''}"><b>${pending.length}</b><span>claims to check</span></div></div>
    </div>
    ${pending.length || ST.claims.length ? claimsHTML() : ''}
    ${perks.length ? `<div class="pk-list">${perks.map(tileHTML).join('')}</div>` : ''}
    <div class="card pk-tpl-card"><div class="card-head"><h3>${I('sparkles')}${perks.length ? 'Add another perk' : 'Start with a template'}</h3><button type="button" class="hbtn ghost sm" data-pk="paste">${I('mail')}Paste a lucky-drop claim</button></div>
      <p class="sub">Pick a starting point. Everything can be changed: the reward, the look, and how people unlock it.</p>
      <div class="pk-tpls">${TEMPLATES.map(([type, name, tagline, icon, accent], i) => { const a = R.ACCENTS[accent]; return `<button type="button" class="pk-tpl" data-tpl="${i}" style="--a1:${a.a1};--a2:${a.a2}"><span class="perk-ico">${I(icon)}</span><b>${esc(name)}</b><small>${esc(R.perkKind(type)[1])}</small></button>`; }).join('')}</div>
    </div>
    <p class="note"><span>${I('shield')}</span>Your site is static, so each person’s perks are published <b>encrypted with their own code</b>. Links, keys and messages can’t be read from the page source. Changes go live when you publish.</p>
  </div>`;
}
function tileHTML(p) {
  const a = R.ACCENTS[p.accent] || R.ACCENTS.violet, [kic, kind] = R.perkKind(p.type), how = howOf(p);
  const chips = how.map(h => h.k === 'total' ? `<span class="pk-chip">${I('can')}${money(h.amount)}+ support</span>`
    : h.k === 'buy' ? `<span class="pk-chip buy">${I('card')}${h.url && h.url !== '#' ? '' : 'Needs a link · '}${money(h.price)}</span>`
    : h.k === 'apps' ? `<span class="pk-chip">${I('store')}With ${esc(h.apps.map(x => x.name).join(h.all ? ' + ' : ' / '))}</span>`
    : h.k === 'drop' ? `<span class="pk-chip pk-dropchip">${I('sparkles')}Drop: ${h.apps.map(x => `${x.chance}% ${esc(x.name)}`).join(', ')}</span>`
    : `<span class="pk-chip">${I('gift')}Given by hand</span>`).join('');
  const stock = p.limits.stock ? `<div class="pk-bar" title="${p.holders} of ${p.limits.stock} given"><i style="width:${Math.min(100, (p.holders / p.limits.stock) * 100)}%"></i></div>` : '';
  const warn = missing(p) ? `<span class="pk-warn">${I('info')}Add the ${esc(FIELD_INFO[NEED[p.type]][0].toLowerCase())}</span>` : p.ended ? `<span class="pk-warn">${I('clock')}Ended</span>` : p.type === 'key' && p.keysLeft != null && p.keysLeft < 3 ? `<span class="pk-warn">${I('key')}${p.keysLeft} key${p.keysLeft === 1 ? '' : 's'} left</span>` : '';
  return `<article class="pk-tile${p.enabled ? '' : ' off'}" data-id="${esc(p.id)}" style="--a1:${a.a1};--a2:${a.a2}">
    <div class="pk-tile-head"><span class="perk-ico">${I(p.icon || kic)}</span><div class="pk-tile-t"><b>${esc(p.name)}</b><small>${esc(kind)}${p.show === 'secret' ? ` · ${I('eyeoff')}secret` : ''}</small></div>
      <label class="switch" title="${p.enabled ? 'On: people can unlock it' : 'Off'}"><input type="checkbox" data-pk-on="${esc(p.id)}"${p.enabled ? ' checked' : ''}><span class="track"><i></i></span></label></div>
    ${p.tagline ? `<p class="pk-tag">${esc(p.tagline)}</p>` : ''}
    <div class="pk-chips">${chips}</div>
    ${warn}
    <div class="pk-tile-foot"><button type="button" class="pk-holders" data-pk-holders="${esc(p.id)}">${I('users')}<b>${p.holders}</b>${p.limits.stock ? ` / ${p.limits.stock}` : ''} holder${p.holders === 1 ? '' : 's'}${p.dropsWon ? ` · ${p.dropsWon} won` : ''}</button>${stock}<span class="sp"></span>
      <button type="button" class="act" data-pk-give="${esc(p.id)}" title="Give to someone">${I('gift')}</button>
      <button type="button" class="act" data-pk-edit="${esc(p.id)}" title="Edit">${I('edit')}</button>
      <button type="button" class="act" data-pk-dup="${esc(p.id)}" title="Duplicate">${I('copy')}</button>
      <button type="button" class="act del" data-pk-del="${esc(p.id)}" title="Delete">${I('trash')}</button></div>
  </article>`;
}
function claimsHTML() {
  const sorted = [...ST.claims].sort((a, b) => (a.status !== 'pending') - (b.status !== 'pending') || b.at.localeCompare(a.at)).slice(0, 30);
  return `<div class="card pk-claims"><div class="card-head"><h3>${I('sparkles')}Lucky-drop claims</h3><button type="button" class="hbtn ghost sm" data-pk="paste">${I('mail')}Paste a claim</button></div>
    <p class="sub">Winners email you a claim from your site. Check it looks genuine, then approve: they get the perk and their code by email.</p>
    <div class="pk-claim-list">${sorted.map(c => { const app = ST.apps.find(a => a.id === c.appId); const p = ST.perks.find(x => x.id === c.perkId); return `<div class="pk-claim ${c.status}">
      <span class="perk-ico sm" style="--a1:${(R.ACCENTS[p?.accent] || R.ACCENTS.violet).a1};--a2:${(R.ACCENTS[p?.accent] || R.ACCENTS.violet).a2}">${I(p?.icon || 'gift')}</span>
      <div class="grow"><b>${esc(c.name || 'Someone')}</b> <small>${esc(c.email)}</small><div class="muted small">won <b>${esc(c.perkName)}</b>${app ? ` on ${esc(app.name)}` : ''} · ${esc((c.wonAt || c.at).slice(0, 10))}</div></div>
      ${c.status === 'pending' ? `<button type="button" class="hbtn ghost sm danger" data-claim-no="${esc(c.key)}">${I('x')}Reject</button><button type="button" class="hbtn primary sm" data-claim-yes="${esc(c.key)}">${I('check')}Approve</button>`
        : `<span class="dc-pill ${c.status === 'approved' ? 'ok' : 'bad'}">${c.status === 'approved' ? 'Approved' : 'Rejected'}</span><button type="button" class="act del" data-claim-del="${esc(c.key)}" title="Remove from the list">${I('trash')}</button>`}</div>`; }).join('')}</div></div>`;
}

// ---------- editor ----------
let dlg = null;
function ensureDlg() {
  if (dlg) return dlg;
  dlg = document.createElement('dialog'); dlg.className = 'modal pk-modal'; dlg.innerHTML = '<div class="m-in" id="pkBody"></div>';
  document.body.append(dlg);
  dlg.addEventListener('click', onDlgClick); dlg.addEventListener('input', onDlgInput); dlg.addEventListener('change', onDlgInput);
  dlg.addEventListener('cancel', e => { e.preventDefault(); closeDlg(); });
  return dlg;
}
function closeDlg() { dlg?.close(); draft = null; const b = $('#pkBody'); if (b) b.onclick = null; }
function openEditor(p) {
  draft = clone(p); edTab = 'reward'; ensureDlg(); $('#pkBody').onclick = null;
  renderEditor(); if (!dlg.open) dlg.showModal();
  setTimeout(() => $('#pkBody [data-f="name"]')?.focus(), 60);
}
function renderEditor() {
  const p = draft, a = R.ACCENTS[p.accent] || R.ACCENTS.violet;
  $('#pkBody').innerHTML = `<div class="pk-ed" style="--a1:${a.a1};--a2:${a.a2}">
    <div class="pk-ed-main">
      <div class="pk-ed-head"><h3>${I('gift')}${p.id ? 'Edit perk' : 'New perk'}</h3><button type="button" class="act" data-x title="Close">${I('x')}</button></div>
      <div class="f2"><label class="fld"><span>Name</span><input data-f="name" value="${esc(p.name)}" maxlength="60" placeholder="e.g. Early access"></label>
        <label class="fld"><span>Type</span><select data-f="type">${Object.entries(R.PERK_KINDS).map(([k, [, l]]) => `<option value="${k}"${k === p.type ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select></label></div>
      <label class="fld"><span>Tagline <small>shown on the perk card</small></span><input data-f="tagline" value="${esc(p.tagline)}" maxlength="160" placeholder="${esc(R.perkKind(p.type)[2])}"></label>
      <div class="pk-look"><div class="pk-swatches">${Object.entries(R.ACCENTS).map(([k, x]) => `<button type="button" class="pk-sw${k === p.accent ? ' on' : ''}" data-accent="${k}" title="${esc(x.label)}" style="--a1:${x.a1};--a2:${x.a2}"></button>`).join('')}</div>
        <details class="pk-icons"><summary><span class="perk-ico sm">${I(p.icon)}</span>Icon</summary><div class="pk-icon-grid">${ICONS.map(n => `<button type="button" data-icon="${n}" class="${n === p.icon ? 'on' : ''}" title="${n}">${I(n)}</button>`).join('')}</div></details>
        <div class="seg"><button type="button" data-show="public" class="${p.show === 'public' ? 'on' : ''}">${I('eye')}On the site</button><button type="button" data-show="secret" class="${p.show === 'secret' ? 'on' : ''}" title="Not listed on the site: only given by hand or won">${I('eyeoff')}Secret</button></div></div>
      <div class="pk-tabs">${[['reward', 'gift', 'What they get'], ['unlock', 'unlock', 'How to unlock'], ['limits', 'clock', 'Limits']].map(([k, ic, l]) => `<button type="button" data-edtab="${k}" class="${edTab === k ? 'on' : ''}">${I(ic)}${l}${k === 'reward' && missing(p) ? '<i class="dot"></i>' : ''}</button>`).join('')}</div>
      <div class="pk-pane">${edTab === 'reward' ? rewardPane(p) : edTab === 'unlock' ? unlockPane(p) : limitsPane(p)}</div>
      <div class="m-foot">${p.id ? `<label class="switch"><input type="checkbox" data-f="enabled"${p.enabled ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Perk is on</span></label>` : ''}<span class="sp"></span><button class="hbtn ghost" type="button" data-x>Cancel</button><button class="hbtn primary" type="button" data-save>${I('save')}${p.id ? 'Save perk' : 'Create perk'}</button></div>
    </div>
    <aside class="pk-ed-side"><div class="pk-pv-lbl">${I('eye')}On your site</div><div id="pkPreview">${previewHTML()}</div>
      <div class="pk-pv-lbl">${I('unlock')}What holders see</div><div id="pkOwn">${ownHTML()}</div></aside>
  </div>`;
}
const previewHTML = () => draft.show === 'secret' ? `<div class="pk-secret-pv">${I('eyeoff')}<b>Secret perk</b><span>Not listed on the site. People get it from you by hand or as a lucky drop.</span></div>` : R.perkCardHTML(previewOf(draft), { money });
function ownHTML() {
  const p = draft, r = p.reward, app = ST.apps.find(a => a.id === r.appId);
  const rows = [r.text && `<div class="pk-own-txt">${R.md(r.text)}</div>`, r.code && `<div class="pk-own-code"><small>${p.type === 'discount' ? 'Discount code' : 'Code'}</small><code>${esc(r.code)}</code></div>`,
    p.type === 'key' && `<div class="pk-own-code"><small>Their own licence key</small><code>${esc(r.keys[0] || 'XXXX-XXXX-XXXX')}</code></div>`,
    r.instructions && `<p class="pk-own-note">${I('info')}${esc(r.instructions)}</p>`,
    r.url && `<span class="pk-own-btn">${esc(r.label || 'Open')}${I('arrow')}</span>`, p.type === 'submit' && `<span class="pk-own-btn">${I('send')}Submit your app</span>`].filter(Boolean);
  return `<div class="pk-own"><div class="perk-top"><span class="perk-ico">${I(p.icon)}</span><div><b>${esc(p.name || 'Untitled perk')}</b><small>${esc(R.perkKind(p.type)[1])}${app ? ` · ${esc(app.name)}` : ''}</small></div></div>${rows.join('') || `<p class="muted small">Nothing to show yet: fill in “What they get”.</p>`}</div>`;
}
function field(k, p) {
  const [label, ph, help] = FIELD_INFO[k], r = p.reward, need = NEED[p.type] === k;
  const lbl = `<span>${esc(k === 'url' && p.type === 'discord' ? 'Discord invite link' : k === 'url' && p.type === 'early' ? 'Early-access link' : k === 'url' && p.type === 'vote' ? 'Voting link (a poll or form)' : label)}${need ? ' <b class="req">required</b>' : help ? ` <small>${esc(help)}</small>` : ''}</span>`;
  if (k === 'text') return `<label class="fld">${lbl}<textarea data-r="text" rows="4" placeholder="${esc(ph)}">${esc(r.text)}</textarea></label>`;
  if (k === 'keys') { const left = p.keysLeft ?? r.keys.length; return `<label class="fld">${lbl}<textarea data-r="keys" rows="5" class="mono" placeholder="${esc(ph)}">${esc(r.keys.join('\n'))}</textarea><small class="help">${r.keys.length} key${r.keys.length === 1 ? '' : 's'}${p.id ? ` · ${left} unused` : ''}. Keys already given out stay with their holders.</small></label>`; }
  if (k === 'appId') return `<label class="fld">${lbl}<select data-r="appId"><option value="">No particular app</option>${ST.apps.map(a => `<option value="${esc(a.id)}"${a.id === r.appId ? ' selected' : ''}>${esc(a.name)}${a.published ? '' : ' (draft)'}</option>`).join('')}</select></label>`;
  return `<label class="fld">${lbl}<input data-r="${k}" value="${esc(r[k])}" placeholder="${esc(ph)}"${k === 'code' ? ' class="mono"' : ''}></label>`;
}
function rewardPane(p) {
  const f = FIELDS[p.type] || FIELDS.custom;
  return `<p class="pk-kind-help">${I(R.perkKind(p.type)[0])}${esc(R.perkKind(p.type)[2])}</p>
    ${p.type === 'submit' ? `<p class="note"><span>${I('info')}</span>Holders can open the app-submission form on your site with their code, even if they gave less than the usual minimum. Turn submissions on in Caffeine &amp; perks.</p>` : ''}
    ${p.type === 'wall' ? `<p class="note"><span>${I('info')}</span>Add holders to the wall from Supporters. Use the message to tell them what their badge means.</p>` : ''}
    ${f.map(k => field(k, p)).join('')}`;
}
function appPicker(sel, attr, apps = ST.apps) {
  return `<div class="pk-apps">${apps.filter(a => a.published).map(a => `<button type="button" class="pk-app${sel.includes(a.id) ? ' on' : ''}" data-${attr}="${esc(a.id)}">${a.icon ? `<img src="/media/${esc(a.icon)}" alt="">` : I(a.glyph || 'package')}<span>${esc(a.name)}</span>${a.paid ? `<em>${esc(a.price || 'Paid')}</em>` : '<em class="free">Free</em>'}</button>`).join('') || '<p class="muted small">Publish an app first.</p>'}</div>`;
}
function unlockPane(p) {
  const u = p.unlock, on = k => ({ total: !!+u.total || u._total, apps: u.apps.length || u._apps, buy: !!u.buy, drops: u.drops.length || u._drops })[k];
  const box = (k, ic, title, desc, inner) => `<div class="pk-way${on(k) ? ' on' : ''}"><label class="pk-way-head"><span class="pk-way-ico">${I(ic)}</span><span class="grow"><b>${title}</b><small>${desc}</small></span><span class="switch"><input type="checkbox" data-way="${k}"${on(k) ? ' checked' : ''}><span class="track"><i></i></span></span></label>${on(k) ? `<div class="pk-way-body">${inner}</div>` : ''}</div>`;
  const buy = u.buy || {};
  return `<p class="pk-kind-help">${I('info')}Turn on any mix. Meeting <b>any one</b> unlocks the perk. Purchases are checked automatically while the hub watches Stripe.</p>
  ${box('total', 'can', 'Total support', 'Everyone who has given at least this much, across all their payments.', `<label class="fld pk-amt"><span>At least</span><div class="pk-money"><i>${esc(ST.currency)}</i><input type="number" min="1" step="1" data-u="total" value="${esc(u.total || '')}" placeholder="10"></div></label>`)}
  ${box('apps', 'store', 'Comes with an app', 'Buying one of these apps unlocks it. Works with buy buttons and paid downloads.', `${appPicker(u.apps, 'uapp')}${u.apps.length > 1 ? `<div class="seg"><button type="button" data-all="0" class="${u.appsAll ? '' : 'on'}">Any of them</button><button type="button" data-all="1" class="${u.appsAll ? 'on' : ''}">All of them (bundle)</button></div>` : ''}`)}
  ${box('buy', 'card', 'Sell it', 'Its own price and Stripe buy button on the perk card.', `<div class="pk-sell"><label class="fld pk-amt"><span>Price</span><div class="pk-money"><i>${esc(ST.currency)}</i><input type="number" min="0.5" step="0.5" data-buy="price" value="${esc(buy.price || '')}" placeholder="5"></div></label>
      <label class="fld"><span>Button text <small>optional</small></span><input data-buy="label" value="${esc(buy.label || '')}" placeholder="Get this perk"></label></div>
      ${buy.url ? `<p class="ok-txt">${I('check')}Stripe link ready: <a href="${esc(buy.url)}" target="_blank" rel="noopener">${esc(buy.url.replace(/^https:\/\//, ''))}</a></p>` : ''}
      <div class="row">${ST.stripe ? `<button type="button" class="hbtn ${buy.url ? 'ghost' : 'primary'} sm" data-mklink>${I('card')}${buy.url ? 'Make a new link at this price' : 'Create the Stripe link'}</button>` : `<span class="muted small">${I('key')} Add a Stripe key (Community → Caffeine &amp; perks) to create the link here, or paste one:</span>`}</div>
      <label class="fld"><span>Or paste a Stripe payment link</span><input data-buy="url" value="${esc(buy.url || '')}" placeholder="https://buy.stripe.com/…"></label>`)}
  ${box('drops', 'sparkles', 'Lucky drops', 'A chance to win it when someone presses download on these apps. Great for free apps.', `${appPicker(u.drops.map(d => d.appId), 'dapp')}
      ${u.drops.length ? `<div class="pk-odds">${u.drops.map(d => { const a = ST.apps.find(x => x.id === d.appId); return `<label><span>${esc(a?.name || d.appId)}</span><input type="range" min="0.5" max="50" step="0.5" data-odds="${esc(d.appId)}" value="${d.chance}"><b>${d.chance}%</b></label>`; }).join('')}</div>` : ''}
      <div class="f2"><div class="fld"><span>When someone wins</span><div class="seg"><button type="button" data-dmode="claim" class="${u.dropMode === 'claim' ? 'on' : ''}" title="They email a claim, you approve it">${I('mail')}They claim it</button><button type="button" data-dmode="instant" class="${u.dropMode === 'instant' ? 'on' : ''}" title="The reward shows right away">${I('zap')}Show it instantly</button></div></div>
        <label class="fld"><span>Drops in total <small>0 = no limit</small></span><input type="number" min="0" data-u="dropStock" value="${esc(u.dropStock || '')}" placeholder="No limit"></label></div>
      <p class="note ${u.dropMode === 'instant' ? 'lock' : ''}"><span>${I(u.dropMode === 'instant' ? 'info' : 'shield')}</span>${u.dropMode === 'instant' ? 'Instant drops reveal the reward in the browser. A determined person could dig it out of the page, so use them for small rewards (wallpapers, a discount code). Licence keys always go through claims.' : 'Each visitor gets one try per app per day and can win each perk once. Claims come to you by email; paste them above to approve.'}</p>`)}
  <p class="pk-kind-help">${I('gift')}You can always give it by hand: the gift button on the perk, or from Supporters.</p>`;
}
function limitsPane(p) {
  const l = p.limits;
  return `<div class="f3"><label class="fld"><span>How many can have it <small>0 = no limit</small></span><input type="number" min="0" data-l="stock" value="${esc(l.stock || '')}" placeholder="No limit"></label>
    <label class="fld"><span>Lasts <small>days after unlocking</small></span><input type="number" min="0" data-l="days" value="${esc(l.days || '')}" placeholder="Forever"></label>
    <label class="fld"><span>Available until <small>optional</small></span><input type="date" data-l="endsAt" value="${esc(l.endsAt)}"></label></div>
    ${p.type === 'key' ? `<p class="note"><span>${I('key')}</span>Licence-key perks also stop when the keys run out. You have ${p.reward.keys.length} key${p.reward.keys.length === 1 ? '' : 's'}.</p>` : ''}
    <label class="switch big"><input type="checkbox" data-l="keepOnRefund"${l.keepOnRefund ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Let people keep it after a refund or dispute</span></label>
    <p class="muted small">When this is off, perks that came from a purchase or support total are taken back automatically if the payment is refunded or disputed. Perks you gave by hand are never taken back automatically.</p>`;
}
function refreshPreview() { const pv = $('#pkPreview'), own = $('#pkOwn'); if (pv) pv.innerHTML = previewHTML(); if (own) own.innerHTML = ownHTML(); }

function onDlgInput(e) {
  const t = e.target, p = draft; if (!p) return;
  if (t.dataset.f === 'type') { p.type = t.value; const [ic] = R.perkKind(p.type); if (!p.id) p.icon = ic; renderEditor(); return; }
  if (t.dataset.f === 'enabled') { p.enabled = t.checked; return; }
  if (t.dataset.f) { p[t.dataset.f] = t.value; refreshPreview(); return; }
  if (t.dataset.r) { p.reward[t.dataset.r] = t.dataset.r === 'keys' ? t.value.split('\n').map(x => x.trim()).filter(Boolean) : t.value; if (e.type === 'change' && t.dataset.r === 'keys') renderEditor(); refreshPreview(); return; }
  if (t.dataset.u) { p.unlock[t.dataset.u] = +t.value || 0; refreshPreview(); return; }
  if (t.dataset.l) { p.limits[t.dataset.l] = t.type === 'checkbox' ? t.checked : t.type === 'date' ? t.value : +t.value || 0; refreshPreview(); return; }
  if (t.dataset.buy) { p.unlock.buy ||= {}; p.unlock.buy[t.dataset.buy] = t.dataset.buy === 'price' ? +t.value || 0 : t.value.trim(); refreshPreview(); return; }
  if (t.dataset.odds) { const d = p.unlock.drops.find(x => x.appId === t.dataset.odds); d.chance = +t.value; t.nextElementSibling.textContent = `${d.chance}%`; refreshPreview(); return; }
  if (t.dataset.way && e.type === 'change') {
    const u = p.unlock, k = t.dataset.way;
    if (k === 'total') { if (t.checked) { u._total = true; u.total ||= 10; } else { u.total = 0; u._total = false; } }
    if (k === 'apps') { u._apps = t.checked; if (!t.checked) u.apps = []; }
    if (k === 'buy') u.buy = t.checked ? (u.buy || { price: 5, url: '', label: '' }) : null;
    if (k === 'drops') { u._drops = t.checked; if (!t.checked) u.drops = []; }
    renderEditor();
  }
}
async function onDlgClick(e) {
  const t = e.target, p = draft;
  if (e.target === dlg || t.closest('[data-x]')) return closeDlg();
  const g = t.closest('[data-pkgive-go]'); if (g) return doGive(g);
  if (!p) return;
  const b = s => t.closest(s);
  if (b('[data-accent]')) { p.accent = b('[data-accent]').dataset.accent; renderEditor(); return; }
  if (b('[data-icon]')) { p.icon = b('[data-icon]').dataset.icon; renderEditor(); $('#pkBody .pk-icons')?.removeAttribute('open'); return; }
  if (b('[data-show]')) { p.show = b('[data-show]').dataset.show; renderEditor(); return; }
  if (b('[data-edtab]')) { edTab = b('[data-edtab]').dataset.edtab; renderEditor(); return; }
  if (b('[data-uapp]')) { const id = b('[data-uapp]').dataset.uapp, l = p.unlock.apps; p.unlock.apps = l.includes(id) ? l.filter(x => x !== id) : [...l, id]; p.unlock._apps = true; renderEditor(); return; }
  if (b('[data-all]')) { p.unlock.appsAll = b('[data-all]').dataset.all === '1'; renderEditor(); return; }
  if (b('[data-dapp]')) { const id = b('[data-dapp]').dataset.dapp, l = p.unlock.drops; p.unlock.drops = l.some(d => d.appId === id) ? l.filter(d => d.appId !== id) : [...l, { appId: id, chance: 5 }]; p.unlock._drops = true; renderEditor(); return; }
  if (b('[data-dmode]')) { p.unlock.dropMode = b('[data-dmode]').dataset.dmode; renderEditor(); return; }
  if (b('[data-mklink]')) return makeLink(b('[data-mklink]'));
  if (b('[data-save]')) return save(b('[data-save]'));
}
function tidy(p) { const o = clone(p); for (const k of ['_total', '_apps', '_drops']) delete o.unlock[k]; if (o.unlock.buy && !o.unlock.buy.url && !o.unlock.buy.price) o.unlock.buy = null; return o; }
async function save(btn) {
  const p = draft;
  if (!p.name.trim()) { edTab = 'reward'; renderEditor(); toast('Give the perk a name', 'err'); return; }
  if (p.type === 'key' && p.unlock.dropMode === 'instant' && p.unlock.drops.length) p.unlock.dropMode = 'claim';
  btn.disabled = true;
  try {
    const r = await api('POST', '/api/perks', { perk: tidy(p) }); ST = r;
    const needLink = p.unlock.buy && p.unlock.buy.price && !p.unlock.buy.url;
    closeDlg(); render(); refreshStatus();
    toast(`${r.perk.name} saved${missing(r.perk) ? '. Add what holders get before you share it' : ''}. Publish to put it on your site.`, missing(r.perk) ? 'info' : 'ok', 5000);
    if (needLink && ST.stripe && await confirmBox('Create its Stripe link?', `So people can buy ${r.perk.name} for ${money(p.unlock.buy.price)} from your site.`, 'Create link', false)) {
      ST = await api('POST', '/api/perks/sell', { perkId: r.perk.id, amount: p.unlock.buy.price, label: p.unlock.buy.label }); render(); toast('Stripe link created ✓');
    }
  } catch (e) { btn.disabled = false; toast(e.message, 'err', 8000); }
}
async function makeLink(btn) {
  const p = draft, price = +(p.unlock.buy?.price || 0);
  if (!(price > 0)) return toast('Set a price first', 'err');
  btn.disabled = true; btn.innerHTML = `<span class="spinner"></span>Creating…`;
  try {
    const saved = await api('POST', '/api/perks', { perk: tidy(p) });
    const r = await api('POST', '/api/perks/sell', { perkId: saved.perk.id, amount: price, label: p.unlock.buy.label });
    ST = r; draft = clone({ ...r.perk, holders: saved.perk.holders }); renderEditor(); render(); toast('Stripe link created ✓');
  } catch (e) { toast(e.message, 'err', 9000); renderEditor(); }
}

// ---------- give ----------
export async function give({ perkId, supporterId } = {}) {
  if (!ST) await load();
  if (!ST.perks.length) { toast('Make a perk first (Community → Perks)', 'info'); location.hash = '#/community/perks'; return; }
  ensureDlg(); draft = null;
  const sel = new Set(perkId ? [perkId] : []);
  $('#pkBody').innerHTML = `<div class="pk-give"><div class="pk-ed-head"><h3>${I('gift')}Give a perk</h3><button type="button" class="act" data-x title="Close">${I('x')}</button></div>
    <div class="fld"><span>Perks to give</span><div class="pk-pick">${ST.perks.map(p => { const a = R.ACCENTS[p.accent] || R.ACCENTS.violet; return `<label class="pk-pick-item" style="--a1:${a.a1};--a2:${a.a2}"><input type="checkbox" name="perk" value="${esc(p.id)}"${sel.has(p.id) ? ' checked' : ''}><span class="perk-ico sm">${I(p.icon)}</span><span>${esc(p.name)}${p.limits.stock ? `<small>${p.left} left</small>` : ''}</span></label>`; }).join('')}</div></div>
    <label class="fld"><span>To</span><select name="sup"><option value="">Someone new…</option>${ST.supporters.map(s => `<option value="${esc(s.id)}"${s.id === supporterId ? ' selected' : ''}>${esc(s.name || s.email)}${s.email && s.name ? ` · ${esc(s.email)}` : ''}</option>`).join('')}</select></label>
    <div class="f2 pk-new"${supporterId ? ' hidden' : ''}><label class="fld"><span>Name</span><input name="name" maxlength="80"></label><label class="fld"><span>Email</span><input name="email" type="email" maxlength="120"></label></div>
    <label class="fld"><span>Note <small>private, for you</small></span><input name="note" maxlength="200" placeholder="e.g. Won the stream giveaway"></label>
    <label class="switch big"><input type="checkbox" name="notify" checked><span class="track"><i></i></span><span class="sw-lbl">Email them their code once it’s live</span></label>
    <div class="m-foot"><span class="sp"></span><button class="hbtn ghost" type="button" data-x>Cancel</button><button class="hbtn primary" type="button" data-pkgive-go>${I('gift')}Give</button></div></div>`;
  $('#pkBody select[name=sup]').addEventListener('change', e => { $('#pkBody .pk-new').hidden = !!e.target.value; });
  if (!dlg.open) dlg.showModal();
}
async function doGive(btn) {
  const B = $('#pkBody'), perkIds = $$('input[name=perk]:checked', B).map(x => x.value);
  if (!perkIds.length) return toast('Pick at least one perk', 'err');
  const sid = B.querySelector('[name=sup]').value;
  btn.disabled = true;
  try {
    const r = await api('POST', '/api/perks/give', { perkIds, supporterId: sid || undefined, name: B.querySelector('[name=name]')?.value, email: B.querySelector('[name=email]')?.value, note: B.querySelector('[name=note]').value, notify: B.querySelector('[name=notify]').checked });
    ST = r;
    if (!r.given.length) { toast('They already have that.', 'info'); closeDlg(); return; }
    const who = r.supporter.name || r.supporter.email;
    $('#pkBody').innerHTML = `<div class="pk-give done"><div class="pk-done-ico">${I('gift')}</div><h3>Given to ${esc(who)}</h3><p>${esc(r.given.join(', '))}. ${r.supporter.email ? 'Their email goes out once you publish and the site updates.' : 'They have no email on file, so send them the code yourself.'}</p>
      <div class="st-url"><code>${esc(r.supporter.code)}</code><button type="button" class="act" data-copytxt="${esc(r.supporter.code)}" title="Copy">${I('copy')}</button></div>
      <div class="m-foot"><span class="sp"></span><button class="hbtn primary" type="button" data-x>Done</button></div></div>`;
    $('#pkBody [data-copytxt]').addEventListener('click', async e => { await navigator.clipboard.writeText(e.currentTarget.dataset.copytxt); toast('Code copied'); });
    render(); refreshStatus(); S.supporters && S.reloadSupporters?.();
  } catch (e) { btn.disabled = false; toast(e.message, 'err', 8000); }
}

// ---------- holders ----------
function holders(perkId) {
  const p = ST.perks.find(x => x.id === perkId); ensureDlg(); draft = null;
  const rows = Object.entries(ST.grants).filter(([, g]) => g[perkId]).map(([sid, g]) => ({ s: ST.supporters.find(x => x.id === sid) || { id: sid, name: '(deleted)' }, g: g[perkId] })).sort((a, b) => b.g.at.localeCompare(a.g.at));
  const via = { manual: 'Given by you', auto: 'Earned', drop: 'Lucky drop' };
  $('#pkBody').innerHTML = `<div class="pk-give"><div class="pk-ed-head"><h3>${I('users')}${esc(p.name)} · holders</h3><button type="button" class="act" data-x title="Close">${I('x')}</button></div>
    ${rows.length ? `<div class="pk-holder-list">${rows.map(({ s, g }) => `<div class="pk-holder${g.revoked || g.expired ? ' off' : ''}"><div class="grow"><b>${esc(s.name || s.email || 'Unnamed')}</b><small>${esc(s.email || '')}</small><div class="muted small">${via[g.via] || g.via} · ${esc(g.at.slice(0, 10))}${g.note ? ` · ${esc(g.note)}` : ''}${g.revoked ? ` · <b>taken back${g.revoked === 'refund' ? ' after a refund' : ''}</b>` : g.expired ? ' · expired' : ''}</div></div>
      ${g.revoked ? `<button type="button" class="hbtn ghost sm" data-restore="${esc(s.id)}">Give back</button>` : `<button type="button" class="hbtn ghost sm danger" data-revoke="${esc(s.id)}">Take back</button>`}</div>`).join('')}</div>` : `<div class="emptystate">${I('users')}<h4>Nobody has it yet</h4><p>Give it by hand, or wait for someone to unlock it.</p></div>`}
    <div class="m-foot"><span class="sp"></span><button class="hbtn ghost" type="button" data-x>Close</button><button class="hbtn primary" type="button" data-pk-give="${esc(perkId)}">${I('gift')}Give to someone</button></div></div>`;
  $('#pkBody').onclick = async e => {
    const rv = e.target.closest('[data-revoke],[data-restore]'); if (rv) {
      const sid = rv.dataset.revoke || rv.dataset.restore;
      if (rv.dataset.revoke && !(await confirmBox('Take it back?', 'They lose the perk after your next publish.', 'Take back'))) return;
      ST = await api('POST', '/api/perks/revoke', { perkId, supporterId: sid, restore: !!rv.dataset.restore }); holders(perkId); render(); refreshStatus(); return;
    }
    const gv = e.target.closest('[data-pk-give]'); if (gv) { $('#pkBody').onclick = null; give({ perkId }); }
  };
  if (!dlg.open) dlg.showModal();
}

// ---------- main view clicks ----------
export async function onClick(e) {
  const t = e.target, b = s => t.closest(s);
  if (busy) return;
  try {
    if (b('[data-pk="new"]')) return openEditor(fromTemplate(TEMPLATES.length - 1));
    if (b('[data-tpl]')) return openEditor(fromTemplate(+b('[data-tpl]').dataset.tpl));
    if (b('[data-pk="give"]')) return give();
    if (b('[data-pk-give]')) return give({ perkId: b('[data-pk-give]').dataset.pkGive });
    if (b('[data-pk-holders]')) return holders(b('[data-pk-holders]').dataset.pkHolders);
    if (b('[data-pk-edit]')) { const p = ST.perks.find(x => x.id === b('[data-pk-edit]').dataset.pkEdit); return openEditor({ ...p, reward: { ...p.reward } }); }
    if (b('[data-pk-dup]')) { const p = clone(ST.perks.find(x => x.id === b('[data-pk-dup]').dataset.pkDup)); delete p.id; p.name += ' (copy)'; p.holders = 0; if (p.unlock.buy) p.unlock.buy = { ...p.unlock.buy, url: '', linkId: '', productId: '' }; return openEditor(p); }
    if (b('[data-pk-del]')) {
      const p = ST.perks.find(x => x.id === b('[data-pk-del]').dataset.pkDel);
      if (!(await confirmBox(`Delete ${p.name}?`, p.holders ? `${p.holders} ${p.holders === 1 ? 'person loses' : 'people lose'} it after your next publish.` : 'It disappears from your site after your next publish.'))) return;
      ST = await api('DELETE', '/api/perks/' + encodeURIComponent(p.id)); render(); refreshStatus(); return;
    }
    if (b('[data-pk="sync"]')) {
      busy = true; const btn = b('[data-pk="sync"]'); btn.disabled = true; btn.innerHTML = `<span class="spinner"></span>Checking…`;
      const r = await api('POST', '/api/perks/sync'); ST = r; render(); refreshStatus();
      toast(r.granted || r.revoked ? `${r.granted} perk${r.granted === 1 ? '' : 's'} handed out${r.revoked ? `, ${r.revoked} taken back` : ''}. Publish to make it live.` : 'Everyone already has what they earned.'); return;
    }
    if (b('[data-pk="paste"]')) return pasteClaim();
    if (b('[data-claim-yes]')) {
      const c = ST.claims.find(x => x.key === b('[data-claim-yes]').dataset.claimYes);
      if (!(await confirmBox(`Give ${c.perkName} to ${c.name || c.email}?`, `They get the perk and their personal code by email (${c.email}) once you publish.`, 'Approve', false))) return;
      const r = await api('POST', '/api/perks/claims/decide', { key: c.key, approve: true }); ST = r; render(); refreshStatus(); toast(`Approved. Code ${r.result.code}`, 'ok', 6000); return;
    }
    if (b('[data-claim-no]')) { ST = await api('POST', '/api/perks/claims/decide', { key: b('[data-claim-no]').dataset.claimNo, approve: false }); render(); return; }
    if (b('[data-claim-del]')) { ST = await api('POST', '/api/perks/claims/delete', { key: b('[data-claim-del]').dataset.claimDel }); render(); return; }
  } catch (err) { toast(err.message, 'err', 8000); render(); } finally { busy = false; }
}
export async function onChange(e) {
  const t = e.target.closest('[data-pk-on]'); if (!t) return;
  const p = ST.perks.find(x => x.id === t.dataset.pkOn);
  try { ST = await api('POST', '/api/perks', { perk: { ...p, enabled: t.checked } }); render(); refreshStatus(); toast(`${p.name} ${t.checked ? 'is on' : 'is off'}`); } catch (err) { toast(err.message, 'err'); }
}
async function pasteClaim() {
  ensureDlg(); draft = null;
  $('#pkBody').innerHTML = `<div class="pk-give"><div class="pk-ed-head"><h3>${I('mail')}Paste a lucky-drop claim</h3><button type="button" class="act" data-x title="Close">${I('x')}</button></div>
    <p class="sub">Paste the whole claim email. The hub finds the claim line (it starts with PERK-CLAIM).</p>
    <label class="fld"><span>Email text</span><textarea rows="8" class="mono" id="pkClaimTxt"></textarea></label>
    <div class="m-foot"><span class="sp"></span><button class="hbtn ghost" type="button" data-x>Cancel</button><button class="hbtn primary" type="button" id="pkClaimGo">${I('plus')}Add claim</button></div></div>`;
  $('#pkClaimGo').onclick = async () => { try { ST = await api('POST', '/api/perks/claims', { text: $('#pkClaimTxt').value }); closeDlg(); render(); toast('Claim added. Approve or reject it below.'); } catch (err) { toast(err.message, 'err', 8000); } };
  if (!dlg.open) dlg.showModal();
  setTimeout(() => $('#pkClaimTxt')?.focus(), 60);
}
// Supporters list helper: perk chips for one supporter.
export function chipsFor(sid) {
  const g = ST?.grants?.[sid]; if (!g) return '';
  return Object.entries(g).filter(([, x]) => !x.revoked && !x.expired).map(([pid]) => ST.perks.find(p => p.id === pid)).filter(Boolean)
    .map(p => { const a = R.ACCENTS[p.accent] || R.ACCENTS.violet; return `<span class="pk-mini" style="--a1:${a.a1};--a2:${a.a2}" title="${esc(p.name)}">${I(p.icon)}</span>`; }).join('');
}
