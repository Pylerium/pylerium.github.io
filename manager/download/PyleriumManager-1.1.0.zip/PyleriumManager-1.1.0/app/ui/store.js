// Store & pricing: Stripe payment links, prices, new products, and the rules for which payments unlock supporter codes.
import { R, S, $, $$, esc, api, toast, confirmBox, formBox, rel, saveSite, refreshStatus } from './core.js';

let O = null, AL = null, editing = null, loading = false, err = '';
const I = n => R.icon(n);
const D = { mode: 'custom', name: '', description: '', amount: '', min: '', preset: '', max: '', donation: false, perk: true, wallField: false, promo: false, appId: '', thanks: 'Thank you! Your support means a lot. Check your inbox for your receipt.' };

export function init() {
  const P = $('#storePanel');
  P.addEventListener('click', onClick);
  P.addEventListener('submit', onSubmit);
  P.addEventListener('change', onChange);
  P.addEventListener('input', e => { const t = e.target; if (t.dataset.nd) D[t.dataset.nd] = t.type === 'checkbox' ? t.checked : t.value; });
}
export async function show(sub) {
  await load(false);
  if (sub === 'perks') setTimeout(() => $('#perkCard')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
}
async function load(force) {
  if (loading) return; loading = true; err = '';
  if (!O) render();
  try { [O, AL] = await Promise.all([api(force ? 'POST' : 'GET', force ? '/api/store/refresh' : '/api/store'), api('GET', '/api/alerts')]); }
  catch (e) { err = e.message; try { AL = await api('GET', '/api/alerts'); } catch {} }
  loading = false; render();
}

function render() {
  const P = $('#storePanel');
  if (!O && !err) { P.innerHTML = `<div class="card lv-loading"><span class="spinner"></span>Loading your Stripe products…</div>`; return; }
  P.innerHTML = `<div class="st-grid">
    <div class="st-main">
      <div class="card"><div class="card-head"><h3>${I('tag')}Payment links &amp; prices</h3><div class="row">${O ? `<span class="muted">Synced ${rel(O.at)}</span>` : ''}<button type="button" class="hbtn ghost sm" data-reload>${I('refresh')}Sync from Stripe</button></div></div>
        <p class="sub">Change a price here and the hub updates Stripe, points your site at the new link and retires the old one once the site is live. Changes you make in the Stripe dashboard show up when you sync.</p>
        ${err ? `<p class="note lock"><span>${I('alert')}</span>${esc(err)}</p>` : ''}
        ${O && !O.links.length ? `<div class="emptystate">${I('tag')}<h4>No payment links yet</h4><p>Create your first product on the right.</p></div>` : ''}
        <div class="st-links">${(O?.links || []).map(linkCard).join('')}</div>
      </div>
    </div>
    <div class="st-side">
      ${newProductCard()}
      ${perkCard()}
      ${accessCard()}
    </div>
  </div>`;
}

const priceInputs = (o, pre) => `<div class="seg st-mode">${[['custom', 'Pay what you want'], ['fixed', 'Fixed price']].map(([v, l]) => `<button type="button" data-${pre}mode="${v}" class="${o.mode === v ? 'on' : ''}">${l}</button>`).join('')}</div>
  ${o.mode === 'fixed' ? `<label class="fld"><span>Price (${esc(O?.currency || 'AUD')})</span><input type="number" step="0.01" min="0.5" name="amount" data-${pre}="amount" value="${esc(o.amount ?? '')}" placeholder="10" required></label>`
    : `<div class="f3"><label class="fld"><span>Minimum</span><input type="number" step="0.01" min="0.5" name="min" data-${pre}="min" value="${esc(o.min ?? '')}" placeholder="none"></label><label class="fld"><span>Suggested</span><input type="number" step="0.01" name="preset" data-${pre}="preset" value="${esc(o.preset ?? '')}" placeholder="none"></label><label class="fld"><span>Maximum</span><input type="number" step="0.01" name="max" data-${pre}="max" value="${esc(o.max ?? '')}" placeholder="none"></label></div>`}`;

function linkCard(l) {
  const p = l.price || {}, ed = editing?.id === l.id ? editing : null;
  const tags = [l.isDonate && `<span class="dc-pill ok">${I('can')}Supply caffeine button</span>`, ...l.apps.map(a => `<span class="dc-pill">${I('layers')}${esc(a.name)}</span>`),
    l.perk && `<span class="dc-pill violet">${I('key')}Unlocks perks</span>`, l.deliver && `<a class="dc-pill ok" href="#/downloads">${I('download')}Paid download</a>`, !l.livemode && `<span class="dc-pill warn">Test mode</span>`].filter(Boolean).join('');
  return `<div class="st-link${l.active ? '' : ' off'}">
    <div class="st-lh">${l.product.image ? `<img src="${esc(l.product.image)}" alt="">` : `<span class="st-ic">${I(l.isDonate ? 'can' : 'tag')}</span>`}
      <div><b>${esc(l.product.name)}</b><small>${esc(l.product.description || (p.mode === 'custom' ? 'Customers choose the amount' : ''))}</small></div>
      <div class="st-price"><b>${esc(l.label || '—')}</b><small>${l.active ? 'Live' : 'Switched off'}</small></div></div>
    ${tags ? `<div class="row st-tags">${tags}</div>` : ''}
    ${p.mode === 'custom' ? `<div class="st-pw">${[['Minimum', p.min], ['Suggested', p.preset], ['Maximum', p.max]].map(([k, v]) => `<span>${k}: <b>${v != null ? esc(String(v)) : 'none'}</b></span>`).join('')}</div>` : ''}
    <div class="st-url"><code>${esc(l.url)}</code><button type="button" class="act" data-copy="${esc(l.url)}" title="Copy link">${I('copy')}</button><a class="act" href="${esc(l.url)}" target="_blank" rel="noopener" title="Open checkout">${I('external')}</a></div>
    ${ed ? `<form class="fb st-edit" data-editform="${esc(l.id)}">
        <div class="f2"><label class="fld"><span>Product name</span><input name="name" value="${esc(ed.name)}" data-ed="name"></label><label class="fld"><span>Description</span><input name="description" value="${esc(ed.description)}" data-ed="description" placeholder="optional"></label></div>
        ${priceInputs(ed, 'ed')}
        <label class="switch"><input type="checkbox" data-ed="deactivateOld"${ed.deactivateOld ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Switch the old link off once the site uses the new one</span></label>
        <p class="note"><span>${I('info')}</span>Stripe can’t edit an existing price, so this makes a new price and a new link with the same checkout settings. Past payments and receipts aren’t affected.</p>
        <div class="row"><button class="hbtn primary sm" type="submit">${I('check')}Apply in Stripe</button><button class="hbtn ghost sm" type="button" data-canceledit>Cancel</button></div>
      </form>`
      : `<div class="row">${p.mode !== 'recurring' && l.items === 1 ? `<button type="button" class="hbtn ghost sm" data-edit="${esc(l.id)}">${I('edit')}Change price</button>` : ''}
        ${!l.isDonate && l.active ? `<button type="button" class="hbtn ghost sm" data-donate="${esc(l.id)}">${I('can')}Use for Supply caffeine</button>` : ''}
        <button type="button" class="hbtn ghost sm" data-attach="${esc(l.id)}">${I('layers')}Put on an app</button>
        <span class="sp"></span><button type="button" class="hbtn ${l.active ? 'ghost' : 'primary'} sm" data-active="${esc(l.id)}" data-on="${l.active ? '0' : '1'}">${l.active ? 'Switch off' : 'Switch on'}</button></div>`}
  </div>`;
}

function newProductCard() {
  return `<div class="card"><h3>${I('plus')}New product</h3>
    <p class="sub">Sell an app, a pack, a membership tier or another way to support. Creates the product, price and payment link in one go.</p>
    <form class="fb" id="newProd">
      <label class="fld"><span>Name</span><input data-nd="name" value="${esc(D.name)}" placeholder="e.g. TelemetryVault Pro" required></label>
      <label class="fld"><span>Description <small>shown at checkout</small></span><input data-nd="description" value="${esc(D.description)}" placeholder="optional"></label>
      ${priceInputs(D, 'nd')}
      <label class="fld"><span>Put the buy button on an app <small>optional</small></span><select data-nd="appId"><option value="">No app</option>${S.apps.map(a => `<option value="${esc(a.id)}"${D.appId === a.id ? ' selected' : ''}>${esc(a.name)}</option>`).join('')}</select></label>
      <label class="fld"><span>Message after paying</span><input data-nd="thanks" value="${esc(D.thanks)}"></label>
      ${[['perk', 'Counts toward supporter perks (codes)'], ['donation', 'It’s a donation (checkout button says “Donate”)'], ['wallField', 'Ask for a name for the supporters wall'], ['promo', 'Allow promotion codes']].map(([k, l]) => `<label class="switch"><input type="checkbox" data-nd="${k}"${D[k] ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">${l}</span></label>`).join('')}
      <div class="row"><button class="hbtn primary sm" type="submit">${I('plus')}Create in Stripe</button></div>
    </form></div>`;
}

function perkCard() {
  if (!AL) return '';
  const pk = AL.settings.perks, au = AL.settings.auto, th = S.site?.community?.threshold ?? 10;
  const prods = O?.products || [];
  const sw = (path, label, help) => `<div class="auto-row"><label class="switch"><input type="checkbox" data-pk="${path}"${path.split('|').reduce((x, k) => x?.[k], AL.settings) ? ' checked' : ''}><span class="track"><i></i></span></label><div><b>${label}</b><small>${help}</small></div></div>`;
  return `<div class="card" id="perkCard"><h3>${I('key')}Perk rules: who gets a code</h3>
    <p class="sub">A supporter code (which unlocks app submissions) is only issued when <b>every</b> rule passes. Refunds and disputes are re-checked automatically.</p>
    <label class="fld"><span>Minimum total (${esc(S.site?.community?.currency || 'AUD')}) <small>across qualifying payments</small></span><input type="number" min="1" step="1" id="pkThreshold" value="${esc(th)}"></label>
    <div class="fld"><span>Payments that count</span>
      <div class="pk-prods">${prods.length ? prods.map(p => `<label class="chk"><input type="checkbox" data-pkprod="${esc(p.id)}"${pk.products.includes(p.id) ? ' checked' : ''}><span>${esc(p.name)}${p.active ? '' : ' <small>(archived)</small>'}</span></label>`).join('') : '<small class="muted">Sync Stripe to list your products.</small>'}</div>
      <small class="help">${pk.products.length ? 'Only these products count.' : 'Nothing ticked = <b>any</b> payment counts.'}</small></div>
    <div class="auto-list">
      ${sw('auto|issueCodes', 'Issue codes automatically', 'Off = you get an alert and issue codes by hand.')}
      ${sw('perks|holdRisky', 'Hold risky payments for review', 'If Stripe Radar rates a payment elevated or high risk, the code waits for your approval on the Live dashboard.')}
      ${sw('perks|revokeOnRefund', 'Revoke codes after refunds', 'If a refund drops them below the minimum.')}
      ${sw('perks|revokeOnDispute', 'Revoke codes after disputes', 'Disputed payments never count.')}
      ${sw('auto|publishCodes', 'Publish automatically so codes work straight away', 'Only when nothing else is waiting to be published.')}
      ${sw('perks|allowTest', 'Count Stripe test-mode payments', 'For testing only. Leave off in normal use.')}
    </div>
    <p class="note"><span>${I('shield')}</span>Always enforced: the payment succeeded, it’s in your site currency, it isn’t refunded or disputed, there’s an email address, and the person doesn’t already have an active code. Code emails only send once the code works on the live site.</p>
  </div>`;
}

function accessCard() {
  return `<div class="card"><h3>${I('lock')}Stripe access</h3>
    <p class="sub">${O?.keySet ? 'The hub uses your Stripe key from Community → Caffeine &amp; perks.' : 'Add a Stripe key in Community → Caffeine &amp; perks first.'} To change prices it needs <b>Write</b> access to Products, Prices and Payment Links. Your current key already has Products write; if a change is refused, add a separate key here.</p>
    <form class="inrow" id="wkForm"><input name="key" type="password" autocomplete="off" placeholder="${O?.write ? 'Separate write key saved (rk_live_…)' : 'Optional: rk_live_… with write access'}"><button class="hbtn ghost sm" type="submit">${I('save')}Save</button>${O?.write ? `<button class="hbtn ghost sm" type="button" data-rmwk>Remove</button>` : ''}</form>
    <p class="muted small">Stored only in <code>studio-hub/data/secrets.json</code>. The hub never touches payouts, customers or refunds.</p></div>`;
}

// ---------- actions ----------
async function saveAlerts() { AL = await api('PUT', '/api/alerts', { settings: AL.settings }); }
function onChange(e) {
  const t = e.target;
  if (t.dataset.pk) { const ks = t.dataset.pk.split('|'); AL.settings[ks[0]][ks[1]] = t.checked; saveAlerts().then(() => toast('Saved')).catch(x => toast(x.message, 'err')); return; }
  if (t.dataset.pkprod) { const l = new Set(AL.settings.perks.products); t.checked ? l.add(t.dataset.pkprod) : l.delete(t.dataset.pkprod); AL.settings.perks.products = [...l]; saveAlerts().then(() => { toast('Saved'); render(); }).catch(x => toast(x.message, 'err')); return; }
  if (t.id === 'pkThreshold') { const v = Math.max(1, Math.round(+t.value || 10)); S.siteDraft.community = { ...S.siteDraft.community, threshold: v }; saveSite().then(() => { toast(`Minimum set to ${v}. Publish so the site shows it.`); refreshStatus(); }).catch(x => toast(x.message, 'err')); return; }
  if (t.dataset.ed && editing) { editing[t.dataset.ed] = t.type === 'checkbox' ? t.checked : t.value; }
  if (t.dataset.nd) { D[t.dataset.nd] = t.type === 'checkbox' ? t.checked : t.value; }
}
async function onClick(e) {
  const q = s => e.target.closest(s);
  let b;
  try {
    if (q('[data-reload]')) { await load(true); toast('Synced with Stripe'); return; }
    if ((b = q('[data-copy]'))) { await navigator.clipboard.writeText(b.dataset.copy); toast('Link copied'); return; }
    if ((b = q('[data-edit]'))) { const l = O.links.find(x => x.id === b.dataset.edit); const p = l.price; editing = { id: l.id, name: l.product.name, description: l.product.description, mode: p.mode === 'fixed' ? 'fixed' : 'custom', amount: p.amount ?? '', min: p.min ?? '', preset: p.preset ?? '', max: p.max ?? '', deactivateOld: true }; render(); return; }
    if (q('[data-canceledit]')) { editing = null; render(); return; }
    if ((b = q('[data-edmode]'))) { editing.mode = b.dataset.edmode; render(); return; }
    if ((b = q('[data-ndmode]'))) { D.mode = b.dataset.ndmode; render(); return; }
    if ((b = q('[data-active]'))) {
      const on = b.dataset.on === '1', l = O.links.find(x => x.id === b.dataset.active);
      if (!on && !(await confirmBox('Switch this link off?', `${l.isDonate || l.apps.length ? 'Your site links to it, so ' : ''}people won’t be able to pay with it until you switch it back on.`, 'Switch off'))) return;
      O = await api('POST', '/api/store/active', { id: b.dataset.active, active: on }); toast(on ? 'Link is live' : 'Link switched off'); render(); return;
    }
    if ((b = q('[data-donate]'))) { const r = await api('POST', '/api/store/donate', { id: b.dataset.donate }); O = r; await reloadSite(); await askPublish('The Supply caffeine button now uses this link.'); return; }
    if ((b = q('[data-attach]'))) {
      const l = O.links.find(x => x.id === b.dataset.attach);
      const r = await formBox('Put this on an app', `The app’s main button will open this checkout (${esc(l.label)}).`, [{ name: 'appId', label: 'App', type: 'select', options: S.apps.map(a => ({ value: a.id, label: a.name })), value: S.apps[0]?.id }, { name: 'buttonLabel', label: 'Button text', value: 'Buy now' }, { name: 'label', label: 'Price shown on the card', value: l.label }], 'Attach');
      if (!r) return; O = await api('POST', '/api/store/attach', { url: l.url, ...r }); await reloadSite(); await askPublish('The app’s button now opens this checkout.'); return;
    }
    if (q('[data-rmwk]')) { O = await api('PUT', '/api/store/key', { key: '' }); render(); return; }
  } catch (err2) { toast(err2.message, 'err', 9000); render(); }
}
async function onSubmit(e) {
  e.preventDefault();
  const f = e.target, btn = f.querySelector('button[type=submit]');
  const busy = t => { btn.disabled = true; btn.innerHTML = `<span class="spinner"></span>${t}`; };
  try {
    if (f.dataset.editform) {
      const l = O.links.find(x => x.id === f.dataset.editform);
      if (!(await confirmBox('Change this price in Stripe?', `${l.product.name}: ${l.label} → ${editing.mode === 'fixed' ? `${editing.amount} ${O.currency}` : 'pay what you want'}${l.isDonate || l.apps.length ? '. Your site will be pointed at the new link.' : ''}`, 'Apply', false))) return;
      busy('Updating Stripe…');
      const r = await api('POST', '/api/store/price', { linkId: l.id, ...editing });
      O = r; editing = null;
      if (!r.result.changed) { toast(r.result.notes.join(', ')); render(); return; }
      toast(`New price ${r.result.label} is live in Stripe ✓`);
      if (r.result.siteChanged) {
        await reloadSite();
        const published = await askPublish('Your site now points at the new payment link.');
        if (published && l && r.result.oldLinkId && f.querySelector('[data-ed=deactivateOld]')?.checked !== false) {
          O = await api('POST', '/api/store/active', { id: r.result.oldLinkId, active: false }); toast('Old link switched off'); render();
        } else if (!published) toast('The old link stays on until you publish. Switch it off here afterwards.', 'info', 7000);
      }
      render(); return;
    }
    if (f.id === 'newProd') {
      if (!D.name.trim()) return toast('Give it a name', 'err');
      busy('Creating in Stripe…');
      const r = await api('POST', '/api/store/product', { ...D, currency: O?.currency });
      O = r; toast('Product and payment link created ✓');
      navigator.clipboard?.writeText(r.result.link).catch(() => {});
      Object.assign(D, { name: '', description: '', amount: '', min: '', preset: '', max: '', appId: '' });
      try { AL = await api('GET', '/api/alerts'); } catch {}
      if (r.result.attached) { await reloadSite(); await askPublish(`${r.result.attached.name} now has a buy button.`); }
      render(); return;
    }
    if (f.id === 'wkForm') { busy('Saving…'); O = await api('PUT', '/api/store/key', { key: f.key.value }); toast('Saved'); render(); return; }
  } catch (err2) { toast(err2.message, 'err', 10000); render(); }
}
async function reloadSite() {
  const st = await api('GET', '/api/state');
  S.apps = st.apps; S.site = st.site; S.siteDraft = structuredClone(st.site);
  refreshStatus();
}
async function askPublish(what) {
  if (!(await confirmBox('Publish the site now?', `${what} Publish so visitors get it (about a minute).`, 'Publish now', false))) return false;
  toast('Publishing…', 'info');
  try { await api('POST', '/api/publish', { message: 'Update prices and payment links' }); toast('Published ✓'); refreshStatus(); return true; }
  catch (e) { toast(e.message, 'err', 9000); return false; }
}
