// Tiny zero-dependency SMTP client for Gmail app passwords (implicit TLS on port 465).
// Used by the notifier's outbox to send supporter-code and thank-you emails automatically.
import tls from 'node:tls';
import { randomBytes } from 'node:crypto';

export const EMAIL_RE = /^[^\s@<>"',;]+@[^\s@<>"',;]+\.[a-z]{2,}$/i;

function friendly(code, text) {
  if (code === 535 || code === 534) return 'Gmail rejected the login. Use a 16-letter App Password (Google Account → Security → 2-Step Verification → App passwords), not your normal password, and make sure the address matches that Google account.';
  if (code === 550 || code === 553) return `Gmail refused the address: ${text}`;
  if (code === 552 || code === 554) return `Gmail refused the message: ${text}`;
  if (code === 421 || code === 454) return 'Gmail is busy or rate-limiting this account. The hub will try again shortly.';
  return `Mail server said ${code}: ${text}`;
}

// One SMTP conversation. Replies are read as complete (possibly multi-line) responses.
function connect(host, port, timeout) {
  return new Promise((resolve, reject) => {
    const sock = tls.connect({ host, port, servername: host });
    let buf = '', lines = [];
    const replies = [], waiters = [];
    let dead = null;
    const push = r => { const w = waiters.shift(); if (w) w.ok(r); else replies.push(r); };
    sock.setTimeout(timeout, () => sock.destroy(new Error('Timed out talking to Gmail.')));
    sock.on('data', d => {
      buf += d.toString('utf8');
      let i;
      while ((i = buf.indexOf('\r\n')) >= 0) {
        const l = buf.slice(0, i); buf = buf.slice(i + 2);
        lines.push(l);
        if (/^\d{3}(?: |$)/.test(l)) { push({ code: +l.slice(0, 3), text: lines.map(x => x.slice(4)).join(' ').trim() }); lines = []; }
      }
    });
    sock.on('error', e => { dead = e; while (waiters.length) waiters.shift().fail(e); });
    sock.on('close', () => { dead ||= new Error('Gmail closed the connection.'); while (waiters.length) waiters.shift().fail(dead); });
    const read = () => (replies.length ? Promise.resolve(replies.shift()) : dead ? Promise.reject(dead) : new Promise((ok, fail) => waiters.push({ ok, fail })));
    async function cmd(line, expect) {
      if (line != null) sock.write(line + '\r\n');
      const r = await read();
      if (expect && !expect.includes(r.code)) throw Object.assign(new Error(friendly(r.code, r.text)), { smtpCode: r.code });
      return r;
    }
    sock.once('secureConnect', () => resolve({ cmd, write: s => sock.write(s), end: () => { try { sock.end(); } catch {} } }));
    sock.once('error', reject);
  });
}

const b64 = s => Buffer.from(s, 'utf8').toString('base64');
const wrap = s => s.replace(/.{1,76}/g, '$&\r\n');
const encWord = s => (/^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${b64(s)}?=`);
const addr = (name, email) => {
  if (!name) return `<${email}>`;
  const n = String(name).replace(/["\r\n]/g, '');
  return /^[\x20-\x7e]*$/.test(n) ? `"${n}" <${email}>` : `${encWord(n)} <${email}>`; // encoded words must not be quoted
};

export function buildMessage({ from, fromName, to, toName, replyTo, subject, text, html }) {
  const boundary = 'b_' + randomBytes(12).toString('hex');
  const domain = String(from).split('@')[1] || 'localhost';
  const head = [
    `From: ${addr(fromName, from)}`,
    `To: ${addr(toName, to)}`,
    replyTo ? `Reply-To: ${replyTo}` : '',
    `Subject: ${encWord(subject)}`,
    `Date: ${new Date().toUTCString().replace('GMT', '+0000')}`,
    `Message-ID: <${Date.now().toString(36)}.${randomBytes(8).toString('hex')}@${domain}>`,
    'MIME-Version: 1.0',
    html ? `Content-Type: multipart/alternative; boundary="${boundary}"` : 'Content-Type: text/plain; charset=UTF-8',
    html ? '' : 'Content-Transfer-Encoding: base64'
  ].filter(Boolean).join('\r\n');
  if (!html) return `${head}\r\n\r\n${wrap(b64(text))}`;
  const part = (type, body) => `--${boundary}\r\nContent-Type: ${type}; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${wrap(b64(body))}`;
  return `${head}\r\n\r\n${part('text/plain', text)}\r\n${part('text/html', html)}\r\n--${boundary}--\r\n`;
}

// verifyOnly: log in and quit (used by "Test connection").
export async function smtpSend(o) {
  const { host = 'smtp.gmail.com', port = 465, user, pass, timeout = 25000, verifyOnly = false } = o;
  if (!user || !pass) throw new Error('Add your Gmail address and App Password first.');
  const c = await connect(host, port, timeout);
  try {
    await c.cmd(null, [220]);
    await c.cmd('EHLO pylerium-manager', [250]);
    await c.cmd('AUTH PLAIN ' + b64(`\0${user}\0${String(pass).replace(/\s+/g, '')}`), [235]);
    if (verifyOnly) { await c.cmd('QUIT').catch(() => {}); return { ok: true }; }
    const rcpts = [o.to, ...(o.bcc || [])].filter(Boolean);
    for (const r of rcpts) if (!EMAIL_RE.test(r)) throw new Error(`“${r}” isn’t a valid email address.`);
    await c.cmd(`MAIL FROM:<${user}>`, [250]);
    for (const r of rcpts) await c.cmd(`RCPT TO:<${r}>`, [250, 251]);
    await c.cmd('DATA', [354]);
    const msg = buildMessage({ ...o, from: o.from || user }).replace(/\r\n\./g, '\r\n..');
    c.write(msg + '\r\n.\r\n');
    const r = await c.cmd(null, [250]);
    await c.cmd('QUIT').catch(() => {});
    return { ok: true, response: r.text };
  } finally { c.end(); }
}

// ---------- branded HTML version of a plain-text email ----------
const escH = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const linkify = s => s.replace(/(https?:\/\/[^\s<]+[^\s<.,;:!?)\]'"])/g, '<a href="$1" style="color:#0D9488;font-weight:600;text-decoration:none">$1</a>');
export function htmlEmail(text, { brand = 'My Studio', siteUrl = '', logo = '', accent = '#2DD4BF' } = {}) {
  const blocks = String(text).replace(/\r/g, '').split(/\n{2,}/);
  const body = blocks.map(b => {
    if (/^ {4}\S/.test(b) && !b.includes('\n')) // indented line = the code box
      return b.trim().length > 32
        ? `<div style="margin:18px 0;padding:14px 16px;border-radius:12px;background:#0B1120;color:#5EEAD4;font:600 13px/1.5 Consolas,Menlo,monospace;word-break:break-all">${escH(b.trim())}</div>`
        : `<div style="margin:18px 0;padding:16px;border-radius:12px;background:#0B1120;color:#5EEAD4;font:700 22px/1.3 Consolas,Menlo,monospace;letter-spacing:.06em;text-align:center">${escH(b.trim())}</div>`;
    return `<p style="margin:0 0 14px">${linkify(escH(b)).replace(/\n/g, '<br>')}</p>`;
  }).join('');
  const host = siteUrl.replace(/^https?:\/\//, '').replace(/\/$/, '');
  return `<!DOCTYPE html><html><body style="margin:0;padding:0;background:#EEF2F7">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#EEF2F7;padding:28px 12px"><tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#FFFFFF;border-radius:18px;overflow:hidden;font:15px/1.6 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#1E293B">
<tr><td style="padding:22px 28px;background:linear-gradient(120deg,#7C3AED,#0EA5E9 60%,${accent});color:#fff">
${logo ? `<img src="${escH(logo)}" width="36" height="36" alt="" style="vertical-align:middle;border-radius:10px;margin-right:10px">` : ''}<b style="font-size:18px;vertical-align:middle">${escH(brand)}</b></td></tr>
<tr><td style="padding:26px 28px 10px">${body}</td></tr>
${host ? `<tr><td style="padding:6px 28px 26px"><a href="${escH(siteUrl)}" style="display:inline-block;padding:11px 18px;border-radius:10px;background:#0F172A;color:#fff;font-weight:600;text-decoration:none">Visit ${escH(host)}</a></td></tr>` : ''}
</table>
<p style="margin:14px 0 0;font:12px Segoe UI,Arial,sans-serif;color:#64748B">${escH(brand)}${host ? ` · <a href="${escH(siteUrl)}" style="color:#64748B">${escH(host)}</a>` : ''}</p>
</td></tr></table></body></html>`;
}
