// GitHub for Pylerium Manager: sign-in (device flow or token), creating the github.io site repo,
// turning on Pages, and publishing a built folder straight through the API, so customers never need git installed.
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative, sep } from 'node:path';
import { createHash } from 'node:crypto';

const API = process.env.PM_GITHUB_API || 'https://api.github.com'; // overridable for tests
const gitSha = buf => createHash('sha1').update(`blob ${buf.length}\0`).update(buf).digest('hex');
const walk = dir => readdirSync(dir).flatMap(n => { const p = join(dir, n); return statSync(p).isDirectory() ? walk(p) : [p]; });
const sleep = ms => new Promise(r => setTimeout(r, ms));

export function createGitHub({ token, fetchT }) {
  async function api(path, { method = 'GET', body, auth = true, ok404 = false } = {}) {
    const t = token();
    if (auth && !t) throw new Error('Connect GitHub first (Settings → GitHub).');
    const res = await fetchT(path.startsWith('http') ? path : API + path, {
      method, headers: { Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', ...(auth && t ? { Authorization: `Bearer ${t}` } : {}), ...(body ? { 'Content-Type': 'application/json' } : {}) },
      body: body ? JSON.stringify(body) : undefined
    }, 30000);
    if (res.status === 204) return {};
    const j = await res.json().catch(() => ({}));
    if (res.status === 404 && ok404) return null;
    if (!res.ok) {
      const msg = j.message || `GitHub returned ${res.status}`;
      if (res.status === 401) throw Object.assign(new Error('GitHub says the sign-in has expired or was revoked. Reconnect GitHub in Settings.'), { status: 401 });
      if (res.status === 403 && /rate limit/i.test(msg)) throw new Error('GitHub rate limit reached. Try again in a few minutes.');
      if (res.status === 403 || (res.status === 404 && auth)) throw Object.assign(new Error(`GitHub refused this (${msg}). Make sure the token has the “public_repo” (or “repo”) permission.`), { status: res.status });
      const detail = (j.errors || []).map(e => e.message || e.code).filter(Boolean).join('; ');
      throw Object.assign(new Error(`${msg}${detail ? `: ${detail}` : ''}`), { status: res.status });
    }
    return j;
  }

  // ---------- sign-in ----------
  async function me() {
    const res = await fetchT(API + '/user', { headers: { Accept: 'application/vnd.github+json', Authorization: `Bearer ${token()}` } }, 15000);
    const j = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(res.status === 401 ? 'That token doesn’t work. Check you copied all of it.' : j.message || `GitHub returned ${res.status}`);
    const scopes = (res.headers.get('x-oauth-scopes') || '').split(',').map(s => s.trim()).filter(Boolean);
    return { login: j.login, name: j.name || j.login, avatar: j.avatar_url, url: j.html_url, scopes, fineGrained: !res.headers.get('x-oauth-scopes') };
  }
  async function deviceStart(clientId) {
    const res = await fetchT('https://github.com/login/device/code', { method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, body: JSON.stringify({ client_id: clientId, scope: 'public_repo' }) }, 15000);
    const j = await res.json();
    if (!res.ok || j.error) throw new Error(j.error_description || 'GitHub sign-in isn’t available right now. Use a token instead.');
    return { deviceCode: j.device_code, userCode: j.user_code, url: j.verification_uri, interval: j.interval || 5, expiresIn: j.expires_in };
  }
  async function devicePoll(clientId, deviceCode) {
    const res = await fetchT('https://github.com/login/oauth/access_token', { method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({ client_id: clientId, device_code: deviceCode, grant_type: 'urn:ietf:params:oauth:grant-type:device_code' }) }, 15000);
    const j = await res.json();
    if (j.access_token) return { token: j.access_token };
    if (j.error === 'authorization_pending' || j.error === 'slow_down') return { pending: true, slow: j.error === 'slow_down' };
    throw new Error(j.error === 'access_denied' ? 'You cancelled the GitHub sign-in.' : j.error === 'expired_token' ? 'The code expired. Start again.' : j.error_description || 'GitHub sign-in failed.');
  }

  // ---------- repos & Pages ----------
  const repo = full => api(`/repos/${full}`, { ok404: true });
  async function listRepos() {
    const r = await api('/user/repos?per_page=100&sort=updated&affiliation=owner');
    return r.map(x => ({ full: x.full_name, name: x.name, private: x.private, pages: x.has_pages, url: x.html_url, empty: x.size === 0, defaultBranch: x.default_branch }));
  }
  async function ensureRepo(owner, name, description) {
    const full = `${owner}/${name}`;
    let r = await repo(full);
    let created = false;
    if (!r) {
      r = await api('/user/repos', { method: 'POST', body: { name, description, homepage: siteUrlFor(owner, name), private: false, auto_init: true, has_issues: true, has_wiki: false, has_projects: false } });
      created = true;
      for (let i = 0; i < 10; i++) { if (await api(`/repos/${full}/git/ref/heads/${r.default_branch || 'main'}`, { ok404: true })) break; await sleep(1500); }
    }
    if (r.private) throw new Error(`${full} is private. GitHub Pages on free accounts needs a public repository.`);
    if (!r.has_issues) await api(`/repos/${full}`, { method: 'PATCH', body: { has_issues: true } }).catch(() => {});
    return { full: r.full_name, branch: r.default_branch || 'main', created, url: r.html_url };
  }
  async function ensurePages(full, branch) {
    let p = await api(`/repos/${full}/pages`, { ok404: true });
    if (!p) {
      try { p = await api(`/repos/${full}/pages`, { method: 'POST', body: { build_type: 'legacy', source: { branch, path: '/' } } }); }
      catch (e) { if (e.status !== 409) throw e; p = await api(`/repos/${full}/pages`, { ok404: true }); }
    } else if (p.source && (p.source.branch !== branch || p.source.path !== '/') && p.build_type !== 'workflow') {
      await api(`/repos/${full}/pages`, { method: 'PUT', body: { source: { branch, path: '/' } } }).catch(() => {});
    }
    return { url: p?.html_url || '', status: p?.status || 'building', cname: p?.cname || '' };
  }
  const pagesStatus = full => api(`/repos/${full}/pages`, { ok404: true });

  // ---------- publish a folder ----------
  // Uploads only files whose content changed, deletes files we generated last time that no longer exist,
  // and leaves every other file in the repo alone (README, CNAME, the owner's own pages).
  async function pushDir(full, branch, dir, { message, previous = {}, onStep = () => {} } = {}) {
    let ref = await api(`/repos/${full}/git/ref/heads/${branch}`, { ok404: true });
    if (!ref) { // brand-new empty repo: create the branch with a README so there is something to build on
      await api(`/repos/${full}/contents/README.md`, { method: 'PUT', body: { message: 'Initial commit', content: Buffer.from('Published with Pylerium Manager.\n').toString('base64'), branch } });
      ref = await api(`/repos/${full}/git/ref/heads/${branch}`);
    }
    const head = ref.object.sha;
    const commit = await api(`/repos/${full}/git/commits/${head}`);
    const tree = await api(`/repos/${full}/git/trees/${commit.tree.sha}?recursive=1`);
    const remote = new Map((tree.tree || []).filter(e => e.type === 'blob').map(e => [e.path, e.sha]));
    const files = {}, uploads = [];
    for (const f of walk(dir)) {
      const path = relative(dir, f).split(sep).join('/');
      const buf = readFileSync(f), s = gitSha(buf);
      files[path] = s;
      if (remote.get(path) !== s) uploads.push({ path, buf });
    }
    const removed = Object.keys(previous).filter(p => !files[p] && remote.has(p));
    if (!uploads.length && !removed.length) return { nothing: true, files, commit: head.slice(0, 7), commitUrl: `https://github.com/${full}/commit/${head}` };
    onStep(`Uploading ${uploads.length} changed file${uploads.length === 1 ? '' : 's'}${removed.length ? `, removing ${removed.length}` : ''}…`);
    const entries = [];
    let i = 0;
    const worker = async () => {
      while (i < uploads.length) {
        const u = uploads[i++];
        const b = await api(`/repos/${full}/git/blobs`, { method: 'POST', body: { content: u.buf.toString('base64'), encoding: 'base64' } });
        entries.push({ path: u.path, mode: '100644', type: 'blob', sha: b.sha });
      }
    };
    await Promise.all(Array.from({ length: Math.min(5, uploads.length) }, worker));
    for (const p of removed) entries.push({ path: p, mode: '100644', type: 'blob', sha: null });
    const t = await api(`/repos/${full}/git/trees`, { method: 'POST', body: { base_tree: commit.tree.sha, tree: entries } });
    const c = await api(`/repos/${full}/git/commits`, { method: 'POST', body: { message: message || 'Update site', tree: t.sha, parents: [head] } });
    await api(`/repos/${full}/git/refs/heads/${branch}`, { method: 'PATCH', body: { sha: c.sha } });
    return { files, uploaded: uploads.length, removed: removed.length, commit: c.sha.slice(0, 7), commitUrl: c.html_url || `https://github.com/${full}/commit/${c.sha}` };
  }

  return { api, me, deviceStart, devicePoll, repo, listRepos, ensureRepo, ensurePages, pagesStatus, pushDir };
}

export const siteUrlFor = (owner, name) => (name.toLowerCase() === `${owner.toLowerCase()}.github.io` ? `https://${owner.toLowerCase()}.github.io` : `https://${owner.toLowerCase()}.github.io/${name}`);
