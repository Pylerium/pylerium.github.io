// Paid downloads: the delivery service the hub deploys to your Cloudflare account.
//
// A buyer pays through a Stripe Payment Link. Stripe sends them to <site>/download/?session_id=cs_…
// That page asks this worker what they bought; the worker checks the purchase with Stripe, reads which private
// GitHub repo and release belong to it (stored on the Payment Link as metadata), and hands out the files.
// Your Stripe key and GitHub token stay here as encrypted secrets. Buyers never see the repo or the token: a download
// is a redirect to a GitHub link that is signed for that one file and expires within minutes.
//
// Secrets: STRIPE_KEY, GITHUB_TOKEN, ADMIN_KEY.  Settings: DOWNLOAD_DAYS (0 = links never expire), SUPPORT_EMAIL, STORE_NAME, SITE_URL.
// Deployed and updated by the hub (Paid downloads → Delivery service). Editing it here by hand is not needed.

const VERSION = '1.0.0';
const GH = 'https://api.github.com';
const cache = new Map(); // small per-instance cache: payment link metadata and release listings

class Fail extends Error { constructor(status, code, message) { super(message); this.status = status; this.code = code; } }

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (req.method === 'OPTIONS') return withCors(new Response(null, { status: 204 }));
    if (req.method !== 'GET' && req.method !== 'HEAD') return json({ error: 'Method not allowed' }, 405);
    try {
      if (url.pathname === '/' || url.pathname === '/health') return json(await health(env, url, req.headers.get('x-admin-key')));
      if (url.pathname === '/api/order') return json(await order(env, url.searchParams.get('session_id')));
      if (url.pathname === '/dl') return await download(env, url);
      return json({ error: 'Not found', code: 'not_found' }, 404);
    } catch (e) {
      const status = e instanceof Fail ? e.status : 500;
      return json({ error: e instanceof Fail ? e.message : 'Something went wrong on our side. Please try again in a minute.', code: e.code || 'error', support: env.SUPPORT_EMAIL || '' }, status);
    }
  }
};

// ---------- purchase check ----------
async function verify(env, sessionId) {
  if (!sessionId || !/^cs_(live|test)_[A-Za-z0-9]+$/.test(sessionId)) throw new Fail(400, 'bad_link', 'This download link is incomplete. Open the link from your purchase confirmation again.');
  let s;
  try { s = await stripe(env, `checkout/sessions/${encodeURIComponent(sessionId)}?expand[]=payment_intent.latest_charge`); }
  catch (e) { if (e.status === 404) throw new Fail(404, 'not_found', 'We couldn’t find this purchase. Check that you copied the whole link.'); throw e; }
  if (s.status === 'expired') throw new Fail(402, 'unpaid', 'This checkout was never completed, so there is nothing to download.');
  if (s.status !== 'complete' || !['paid', 'no_payment_required'].includes(s.payment_status)) throw new Fail(402, 'pending', 'Your payment is still being confirmed. This page will update by itself in a moment.');
  const charge = s.payment_intent && typeof s.payment_intent === 'object' ? s.payment_intent.latest_charge : null;
  if (charge && typeof charge === 'object') {
    if (charge.refunded || (charge.amount_refunded && charge.amount_refunded >= charge.amount)) throw new Fail(410, 'refunded', 'This purchase was refunded, so its downloads are switched off.');
    if (charge.disputed) throw new Fail(410, 'disputed', 'This purchase is under dispute, so its downloads are paused.');
  }
  const days = +env.DOWNLOAD_DAYS || 0;
  const expires = days > 0 ? new Date((s.created + days * 86400) * 1000) : null;
  if (expires && Date.now() > expires.getTime()) throw new Fail(410, 'expired', `Download links last ${days} days and this one has expired.`);
  if (!s.payment_link) throw new Fail(403, 'no_download', 'This purchase doesn’t include a download.');
  const meta = await linkMeta(env, s.payment_link);
  if (!meta.deliver_repo) throw new Fail(403, 'no_download', 'This purchase doesn’t include a download.');
  return { s, meta, expires };
}

async function order(env, sessionId) {
  const { s, meta, expires } = await verify(env, sessionId);
  const rel = await release(env, meta.deliver_repo, meta.deliver_tag || 'latest');
  return {
    ok: true,
    app: { id: meta.deliver_app || '', name: meta.deliver_name || rel.name || 'Your download' },
    release: { tag: rel.tag, name: rel.name, date: rel.date, notes: (rel.notes || '').slice(0, 4000) },
    files: rel.files.map(f => ({ name: f.name, size: f.size, updated: f.updated })),
    email: mask(s.customer_details?.email || ''),
    purchased: new Date(s.created * 1000).toISOString(),
    expires: expires ? expires.toISOString() : null,
    test: !s.livemode,
    store: env.STORE_NAME || '', support: env.SUPPORT_EMAIL || ''
  };
}

async function download(env, url) {
  const { meta } = await verify(env, url.searchParams.get('session_id'));
  const rel = await release(env, meta.deliver_repo, meta.deliver_tag || 'latest');
  const want = url.searchParams.get('file');
  const file = want ? rel.files.find(f => f.name === want) : rel.files[0];
  if (!file) throw new Fail(404, 'no_file', want ? 'That file isn’t in the current release any more. Go back to the download page to see the latest files.' : 'There are no files in this release yet. Please contact support.');
  // Ask GitHub for the file; it answers with a short-lived signed link, which we pass straight to the buyer.
  const r = await fetch(`${GH}/repos/${meta.deliver_repo}/releases/assets/${file.id}`, { headers: ghHeaders(env, 'application/octet-stream'), redirect: 'manual' });
  const loc = r.headers.get('location');
  if (r.status >= 300 && r.status < 400 && loc) return new Response(null, { status: 302, headers: { Location: loc, 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' } });
  if (r.ok) return new Response(r.body, { headers: { 'Content-Type': 'application/octet-stream', 'Content-Disposition': `attachment; filename="${file.name.replace(/"/g, '')}"`, 'Cache-Control': 'no-store' } });
  throw ghFail(r.status);
}

// ---------- Stripe ----------
async function stripe(env, path) {
  if (!env.STRIPE_KEY) throw new Fail(503, 'config', 'Downloads aren’t set up yet. Please contact support.');
  const r = await fetch(`https://api.stripe.com/v1/${path}`, { headers: { Authorization: `Bearer ${env.STRIPE_KEY}` } });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (r.status === 404) throw Object.assign(new Fail(404, 'not_found', 'Not found'), { status: 404 });
    throw new Fail(503, 'config', r.status === 401 || r.status === 403 ? 'The store’s download service can’t check purchases right now. Please contact support.' : 'Couldn’t reach the payment provider. Please try again in a minute.');
  }
  return j;
}
async function linkMeta(env, id) {
  const k = 'pl:' + id, hit = cache.get(k);
  if (hit && Date.now() - hit.at < 300000) return hit.v;
  const l = await stripe(env, `payment_links/${encodeURIComponent(id)}`);
  const v = l.metadata || {};
  cache.set(k, { at: Date.now(), v });
  return v;
}

// ---------- GitHub ----------
const ghHeaders = (env, accept = 'application/vnd.github+json') => ({ Authorization: `Bearer ${env.GITHUB_TOKEN}`, Accept: accept, 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'paid-downloads-worker' });
const ghFail = status => new Fail(503, 'files', status === 401 ? 'The store’s file storage needs to be reconnected. Please contact support.' : status === 404 ? 'The files for this purchase couldn’t be found. Please contact support.' : 'Couldn’t reach the file storage. Please try again in a minute.');
async function release(env, repo, tag) {
  if (!env.GITHUB_TOKEN) throw new Fail(503, 'config', 'Downloads aren’t set up yet. Please contact support.');
  if (!/^[\w.-]+\/[\w.-]+$/.test(repo)) throw new Fail(503, 'config', 'This product’s download isn’t configured correctly. Please contact support.');
  const k = `rel:${repo}@${tag}`, hit = cache.get(k);
  if (hit && Date.now() - hit.at < 60000) return hit.v;
  const r = await fetch(`${GH}/repos/${repo}/releases/${tag === 'latest' ? 'latest' : `tags/${encodeURIComponent(tag)}`}`, { headers: ghHeaders(env) });
  if (!r.ok) throw ghFail(r.status);
  const j = await r.json();
  const v = { tag: j.tag_name, name: j.name || j.tag_name, date: j.published_at || j.created_at, notes: j.body || '',
    files: (j.assets || []).filter(a => a.state === 'uploaded').map(a => ({ id: a.id, name: a.name, size: a.size, updated: a.updated_at })) };
  cache.set(k, { at: Date.now(), v });
  return v;
}

// ---------- health (the hub sends its admin key in a header for a full self-test) ----------
async function health(env, url, key) {
  const base = { ok: true, service: 'paid-downloads', version: VERSION };
  if (!key || !env.ADMIN_KEY || key !== env.ADMIN_KEY) return base;
  const checks = {};
  const probe = async (name, fn) => { try { checks[name] = { ok: true, ...(await fn()) }; } catch (e) { checks[name] = { ok: false, error: e.message }; } };
  await probe('stripe', async () => {
    const need = { 'checkout/sessions?limit=1': 'Checkout Sessions', 'payment_links?limit=1': 'Payment Links', 'payment_intents?limit=1': 'PaymentIntents', 'charges?limit=1': 'Charges' };
    const missing = [];
    let live = null;
    for (const [p, label] of Object.entries(need)) {
      const r = await fetch(`https://api.stripe.com/v1/${p}`, { headers: { Authorization: `Bearer ${env.STRIPE_KEY}` } });
      if (r.status === 401) throw new Error('The Stripe key was rejected.');
      if (!r.ok) missing.push(label);
      else if (live === null) live = !/_test_/.test(env.STRIPE_KEY || '');
    }
    if (missing.length) throw new Error(`The Stripe key needs Read access to: ${missing.join(', ')}.`);
    return { live };
  });
  await probe('github', async () => {
    const r = await fetch(`${GH}/user`, { headers: ghHeaders(env) });
    if (!r.ok) throw new Error(r.status === 401 ? 'The GitHub token was rejected or has expired.' : `GitHub returned ${r.status}.`);
    return { login: (await r.json()).login };
  });
  const repo = url.searchParams.get('repo');
  if (repo) await probe('release', async () => {
    cache.delete(`rel:${repo}@${url.searchParams.get('tag') || 'latest'}`);
    const rel = await release(env, repo, url.searchParams.get('tag') || 'latest');
    return { tag: rel.tag, files: rel.files.map(f => ({ name: f.name, size: f.size })) };
  });
  return { ...base, ok: Object.values(checks).every(c => c.ok), checks, settings: { days: +env.DOWNLOAD_DAYS || 0, support: env.SUPPORT_EMAIL || '', store: env.STORE_NAME || '' } };
}

// ---------- helpers ----------
function mask(e) {
  const [u, d] = String(e).split('@');
  if (!d) return '';
  return `${u.slice(0, 2)}${'•'.repeat(Math.max(1, Math.min(6, u.length - 2)))}@${d}`;
}
function withCors(r) {
  r.headers.set('Access-Control-Allow-Origin', '*');
  r.headers.set('Access-Control-Allow-Methods', 'GET, OPTIONS');
  r.headers.set('Access-Control-Max-Age', '86400');
  return r;
}
function json(v, status = 200) {
  return withCors(new Response(JSON.stringify(v), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } }));
}
