# Licence kits

Drop-in licence checks for Pylerium Studio apps. Each kit is one self-contained file (two for C) with no
dependencies. It verifies `PYL1-…` keys offline and saves the activated key per user.

**Don't copy these templates directly.** Get a filled-in kit for a specific app: Hub → **Licences** → switch the app to
*Licensed* → press the language button. Or from the command line:

```
node licences.mjs kit <python|js|csharp|c> <appId> [outDir]
```

The generated file has the studio public key, the app id and the app name filled in. It only accepts keys issued for
that app.

| Kit | File(s) | Works with | API |
|---|---|---|---|
| Python | `pylerium_licence.py` | Python 3.8+, pure Python | `verify(key)`, `activate(key)`, `current()`, `deactivate()`, `LicenceError` |
| JavaScript | `pylerium-licence.mjs` | Node 18+, Electron, Deno, Bun, browsers (WebCrypto) | `await verify/activate/current/deactivate`, `LicenceError` |
| C# | `PyleriumLicence.cs` | .NET 6+ (WinForms, WPF, console) | `Licence.Verify/Activate/Current/Deactivate`, `LicenceException` |
| C / C++ | `pylerium_licence.h` + `.c` | Windows (CNG, `bcrypt.lib`), Linux/macOS (OpenSSL, `-lcrypto`) | `pyl_verify/pyl_activate/pyl_current/pyl_deactivate` |

Every kit follows the same pattern at startup:

1. Call `current()`. If it returns a licence, run the app.
2. Otherwise ask for a key, call `activate(key)`, and show the error message as-is if it fails. The messages are written for users.
3. Offer a *Buy* button that opens `BUY_URL` (the app's page on the site).

Keys are saved under the user's app-data folder (`%APPDATA%\<App>\licence.key`, `~/Library/Application Support/<App>/`,
`~/.config/<App>/`), and in `localStorage` in browsers.

Tested against hub-issued keys: valid key, a key for another app, a tampered signature, junk input, and names with
accents, quotes and CJK characters. The C kit was compiled and run on Windows (CNG, MSVC); its OpenSSL path for Linux/macOS is written but not yet tested there.
