@echo off
rem Pylerium Manager: double-click to start. The first start sets everything up (about a minute).
title Pylerium Manager
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher\start.ps1" %*
if errorlevel 1 (
  echo.
  echo Something went wrong starting Pylerium Manager. The message above says why.
  echo Need help? Email danqhu3@gmail.com
  pause
)
