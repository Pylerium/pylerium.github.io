#!/bin/sh
# Pylerium Manager launcher for macOS and Linux. Finds Node.js 18+, or downloads a private copy, then starts the app.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/app"
PORT="${PM_PORT:-4380}"
URL="http://localhost:$PORT/"
RT="$HOME/.pylerium-manager/runtime"
NODE_VER="v22.12.0"

open_url() { if command -v open >/dev/null 2>&1; then open "$1"; elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$1" >/dev/null 2>&1; else echo "Open $1 in your browser"; fi; }
running() { curl -fsS --max-time 2 "$URL" 2>/dev/null | grep -q "Pylerium Manager"; }

echo ""; echo "  Pylerium Manager"; echo ""
if running; then echo "  Already running. Opening it..."; open_url "$URL"; exit 0; fi

NODE=""
if command -v node >/dev/null 2>&1 && [ "$(node -p 'process.versions.node.split(".")[0]')" -ge 18 ]; then NODE="node"
elif [ -x "$RT/node/bin/node" ]; then NODE="$RT/node/bin/node"
else
  OS="$(uname -s | tr '[:upper:]' '[:lower:]')"; case "$OS" in darwin|linux) ;; *) echo "Unsupported system: $OS"; exit 1;; esac
  ARCH="$(uname -m)"; case "$ARCH" in x86_64|amd64) ARCH=x64;; arm64|aarch64) ARCH=arm64;; *) echo "Unsupported CPU: $ARCH"; exit 1;; esac
  NAME="node-$NODE_VER-$OS-$ARCH"
  echo "  First start: downloading the runtime Pylerium Manager needs (about 40 MB)..."
  mkdir -p "$RT"; TMP="$(mktemp -d)"
  curl -fL --progress-bar "https://nodejs.org/dist/$NODE_VER/$NAME.tar.gz" -o "$TMP/node.tgz"
  EXPECTED="$(curl -fsS "https://nodejs.org/dist/$NODE_VER/SHASUMS256.txt" | grep " $NAME.tar.gz\$" | cut -d' ' -f1)"
  if command -v shasum >/dev/null 2>&1; then ACTUAL="$(shasum -a 256 "$TMP/node.tgz" | cut -d' ' -f1)"; else ACTUAL="$(sha256sum "$TMP/node.tgz" | cut -d' ' -f1)"; fi
  if [ -z "$EXPECTED" ] || [ "$EXPECTED" != "$ACTUAL" ]; then echo "  The download did not pass its safety check. Please try again."; rm -rf "$TMP"; exit 1; fi
  tar -xzf "$TMP/node.tgz" -C "$TMP"; rm -rf "$RT/node"; mv "$TMP/$NAME" "$RT/node"; rm -rf "$TMP"
  NODE="$RT/node/bin/node"; echo "  Runtime ready."
fi

cd "$APP"
nohup "$NODE" "$APP/hub.mjs" >/dev/null 2>&1 &
i=0; while [ $i -lt 40 ] && ! running; do sleep 0.25; i=$((i+1)); done
if running; then echo "  Running at $URL (it opened in your browser). You can close this window."; else echo "  It didn't start. Email danqhu3@gmail.com for help."; exit 1; fi
