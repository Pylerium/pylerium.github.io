# Pylerium Manager launcher for Windows.
# 1. If it's already running, just opens it.  2. Finds Node.js 18+, or downloads a private portable copy (checksum-verified).
# 3. Adds Desktop and Start-menu shortcuts the first time.  4. Starts the app in the background and opens the browser.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $PSScriptRoot
$App = Join-Path $Root 'app'
$Product = Get-Content (Join-Path $App 'product.json') -Raw | ConvertFrom-Json
$Port = if ($env:PM_PORT) { $env:PM_PORT } else { $Product.port }
$Url = "http://localhost:$Port/"
$Home2 = Join-Path $env:LOCALAPPDATA 'Pylerium Manager'
$Runtime = Join-Path $Home2 'runtime'
$NodeVer = 'v22.12.0'
$Quiet = $args -contains '--quiet'

function Say($t, $c = 'Gray') { if (-not $Quiet) { Write-Host "  $t" -ForegroundColor $c } }
function Running { try { $r = Invoke-WebRequest $Url -UseBasicParsing -TimeoutSec 2; return ($r.Content -match 'Pylerium Manager') } catch { return $false } }
function NodeMajor($exe) { try { $v = & $exe --version 2>$null; if ($v -match '^v(\d+)') { return [int]$Matches[1] } } catch {}; return 0 }

if (-not $Quiet) { Write-Host ''; Write-Host '  Pylerium Manager' -ForegroundColor Cyan; Write-Host '' }
if (Running) { Say 'Already running. Opening it in your browser...' 'Green'; Start-Process $Url; exit 0 }

# ---- Node.js runtime ----
$Node = Join-Path $Runtime 'node\node.exe'
if (-not (Test-Path $Node)) {
  $sys = (Get-Command node -ErrorAction SilentlyContinue)
  if ($sys -and (NodeMajor $sys.Source) -ge 18) { $Node = $sys.Source }
  else {
    $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } elseif ([Environment]::Is64BitOperatingSystem) { 'x64' } else { 'x86' }
    $name = "node-$NodeVer-win-$arch"
    Say "First start: downloading the runtime Pylerium Manager needs (about 30 MB)..." 'Yellow'
    New-Item -ItemType Directory -Force -Path $Runtime | Out-Null
    $zip = Join-Path $env:TEMP "$name.zip"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest "https://nodejs.org/dist/$NodeVer/$name.zip" -OutFile $zip -UseBasicParsing
    $sums = (Invoke-WebRequest "https://nodejs.org/dist/$NodeVer/SHASUMS256.txt" -UseBasicParsing).Content
    $line = ($sums -split "`n") | Where-Object { $_ -match "\s$([regex]::Escape($name)).zip\s*$" } | Select-Object -First 1
    $expected = ($line -split '\s+')[0].Trim().ToLower()
    $actual = (Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
    if (-not $expected -or $expected -ne $actual) { Remove-Item $zip -Force; throw 'The download did not pass its safety check. Please try again.' }
    Say 'Verified. Unpacking...'
    $tmp = Join-Path $Runtime 'tmp'
    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
    Expand-Archive $zip -DestinationPath $tmp -Force
    if (Test-Path (Join-Path $Runtime 'node')) { Remove-Item (Join-Path $Runtime 'node') -Recurse -Force }
    Move-Item (Join-Path $tmp $name) (Join-Path $Runtime 'node')
    Remove-Item $tmp -Recurse -Force; Remove-Item $zip -Force
    $Node = Join-Path $Runtime 'node\node.exe'
    Say 'Runtime ready.' 'Green'
  }
}

# ---- shortcuts (first start only) ----
$Marker = Join-Path $Home2 'shortcuts.done'
if (-not (Test-Path $Marker)) {
  try {
    $sh = New-Object -ComObject WScript.Shell
    $ico = Join-Path $Root 'launcher\pylerium-manager.ico'
    $ps = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    foreach ($dir in @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'))) {
      $lnk = $sh.CreateShortcut((Join-Path $dir 'Pylerium Manager.lnk'))
      $lnk.TargetPath = $ps
      $lnk.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PSScriptRoot\start.ps1`" --quiet"
      $lnk.WorkingDirectory = $Root
      if (Test-Path $ico) { $lnk.IconLocation = "$ico,0" }
      $lnk.Description = 'Pylerium Manager'
      $lnk.WindowStyle = 7
      $lnk.Save()
    }
    New-Item -ItemType Directory -Force -Path $Home2 | Out-Null
    Set-Content $Marker (Get-Date -Format o)
    Say 'Added Pylerium Manager to your Desktop and Start menu.' 'Green'
  } catch { Say "Couldn't add shortcuts ($($_.Exception.Message)). You can always start it from this folder." 'Yellow' }
}

# ---- start ----
Say 'Starting...'
Start-Process -FilePath $Node -ArgumentList "`"$(Join-Path $App 'hub.mjs')`"" -WorkingDirectory $App -WindowStyle Hidden
for ($i = 0; $i -lt 40 -and -not (Running); $i++) { Start-Sleep -Milliseconds 250 }
if (Running) { Say "Pylerium Manager is running: $Url" 'Green'; Say 'You can close this window. The app keeps running in the background.' }
else { throw "Pylerium Manager didn't start. Try again, or email $($Product.supportEmail)." }
