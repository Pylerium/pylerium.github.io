#!/bin/sh
# Pylerium Manager for macOS: double-click to start. (Linux: run launcher/start.sh)
exec "$(dirname "$0")/launcher/start.sh"
