// Connectors: every outside service in one tab (Core, Social, Stores, AI), the post composer with Ollama drafts,
// automation rules for hub events, the post queue, and the "Latest posts" feed on the website.
// Discord keeps its own screens (alerts.js) as a sub-tab, with its Connectors posting options above them.
import { R, S, $, $$, esc, api, toast, confirmBox, rel, siteDirty, clone, emit } from './core.js';
import * as Alerts from './alerts.js';

const I = n => R.icon(n);
let C = null, loading = false, tab = 'overview', sub = '', busy = '';
const LIM = { x: 280, mastodon: 500, linkedin: 3000, telegram: 4096, devto: 100000, discord: 2000 };
const POSTERS = ['x', 'mastodon', 'linkedin', 'telegram', 'devto', 'discord'];
const extra = {};                      // per-tab loaded data (games, models, chats, items, mastodon posts, previews)
const draft = { source: 'app', appId: '', videoId: '', event: 'app.updated', link: 'page', customLink: '', image: true, brief: '', tone: 'friendly', extra: '', platforms: [], posts: {}, when: 'review', at: '', facts: null, factsKey: '' };
const TONES = ['friendly', 'excited', 'professional', 'casual', 'technical', 'playful', 'humble'];
const REWRITES = [['shorter', 'Shorter'], ['longer', 'Longer'], ['casual', 'More casual'], ['punchy', 'Punchier'], ['question', 'End with a question'], ['formal', 'More polished']];
const GROUPS = [['Start', ['overview', 'compose', 'automation', 'queue', 'feed']], ['Core', ['discord', 'github', 'stripe', 'cloudflare', 'gmail', 'youtube']], ['Social', ['x', 'linkedin', 'mastodon', 'telegram', 'devto']], ['Stores', ['itch', 'cws']], ['AI', ['ollama']]];
const PAGES = { overview: ['Overview', 'grid'], compose: ['Compose a post', 'sparkle'], automation: ['Automation', 'zap'], queue: ['Queue & history', 'list'], feed: ['Website feed', 'megaphone'] };
const FEED_NOTE = { x: 'Posts the hub sent (reading your X timeline costs API credits, so posts made elsewhere aren’t fetched).', linkedin: 'Posts the hub sent. Add your profile or page link below for the Follow button.', telegram: 'Posts the hub sent to public channels (t.me links).', mastodon: 'Your public posts, including ones you made outside the hub.', devto: 'Your published articles, including ones you wrote on dev.to.' };
const ANGLES = [['app.new', 'Introducing it'], ['app.available', 'It’s out now'], ['app.updated', 'A new version'], ['app.featured', 'Featured'], ['manual', 'Something else']];

export function init() {
  const P = $('#cxPanel');
  $('#cxNav').addEventListener('click', e => { const a = e.target.closest('[data-cx]'); if (a) location.hash = '#/connectors/' + a.dataset.cx; });
  P.addEventListener('click', onClick);
  P.addEventListener('change', onChange);
  P.addEventListener('input', onInput);
  P.addEventListener('submit', onSubmit);
  P.addEventListener('toggle', e => { if (e.target.classList?.contains('cx-know')) draft.factsOpen = e.target.open; }, true);
  setInterval(() => { if (!$('main[data-view="connectors"]').hidden && (tab === 'queue' || tab === 'overview')) load(false, true); }, 20000);
}
export async function show(t, s) {
  tab = t || 'overview'; sub = s || '';
  const isDiscord = tab === 'discord';
  $('#cxDiscord').hidden = !isDiscord; $('#cxPanel').hidden = false;
  navRender();
  if (!C) await load(); else render();
  if (isDiscord) await Alerts.show(sub || undefined);
  loadExtra();
}
async function load(force, quiet) {
  if (loading) return; loading = true;
  if (!C && !quiet) $('#cxPanel').innerHTML = `<div class="card lv-loading"><span class="spinner"></span>Checking your connections…</div>`;
  try { C = await api('GET', '/api/connectors' + (force ? '?force=1' : '')); } catch (e) { if (!quiet) toast(e.message, 'err'); }
  loading = false;
  if (!draft.platforms.length && C) draft.platforms = POSTERS.filter(p => def(p)?.status?.ok);
  if (!draft.appId && C?.apps?.length) draft.appId = C.apps[0].id;
  navRender(); if (!(quiet && document.activeElement?.closest('#cxPanel'))) render();
}
const def = id => C?.connectors.find(c => c.id === id);
const stateOf = d => d?.status?.state === 'on' ? 'on' : d?.status?.state === 'error' ? 'error' : 'off';
const pill = d => { const s = stateOf(d); return `<span class="cx-pill ${s}">${s === 'on' ? `${I('check')}Connected` : s === 'error' ? `${I('alert')}Needs attention` : 'Not connected'}</span>`; };
const logo = (d, big) => `<span class="cx-logo ${big ? 'big' : ''} b-${esc(d.id)}">${I(d.icon)}</span>`;
const nameOf = p => def(p)?.name || p;
const aiOn = () => def('ollama')?.status?.ok;
const appOpts = () => [['', 'Choose…'], ...C.apps.map(a => [a.id, a.name])];
const mediaUrl = p => (p && !/^https?:/.test(p) ? `/media/${p}` : p || '');
const linkify = t => esc(t).replace(/(https?:\/\/[^\s<]+)/g, '<a>$1</a>').replace(/(^|\s)(#[\p{L}\p{N}_]+)/gu, '$1<a>$2</a>');

function navRender() {
  const N = $('#cxNav'); if (!N) return;
  const review = (C?.queue || []).filter(p => p.status === 'review').length, failed = (C?.queue || []).filter(p => p.status === 'failed').length;
  N.innerHTML = GROUPS.map(([g, ids]) => `<div class="cx-ng"><span class="cx-gl">${esc(g)}</span>${ids.map(id => {
    const d = def(id), page = PAGES[id];
    const label = page ? page[0] : d?.name || id, icon = page ? page[1] : d?.icon || 'plug';
    const badge = id === 'queue' && (review || failed) ? `<em class="${failed ? 'bad' : ''}">${review + failed}</em>` : id === 'feed' && C?.feed?.items?.length ? `<em class="ok">${C.feed.items.length}</em>` : '';
    return `<button type="button" data-cx="${id}" class="${tab === id ? 'on' : ''}"><span class="cx-ni b-${id}">${I(icon)}</span><span>${esc(label)}</span>${badge}${d && !page ? `<i class="cx-dot ${stateOf(d)}"></i>` : ''}</button>`;
  }).join('')}</div>`).join('');
}

// ============================================================ render
function render() {
  const P = $('#cxPanel'); if (!C || P.hidden) return;
  const d = def(tab);
  const body = tab === 'overview' ? overview() : tab === 'compose' ? compose() : tab === 'automation' ? automation() : tab === 'queue' ? queue() : tab === 'feed' ? feedPage()
    : tab === 'discord' ? discordPanel() : d?.kind === 'core' ? core(d) : d ? service(d) : overview();
  P.innerHTML = body;
}
const pageHead = (icon, title, text, right = '') => `<div class="cx-phead"><div><h2>${I(icon)}${esc(title)}</h2><p>${text}</p></div>${right}</div>`;

// ---------- overview ----------
function overview() {
  const on = C.connectors.filter(d => stateOf(d) === 'on').length, review = C.queue.filter(p => p.status === 'review').length;
  const week = C.history.filter(p => Date.now() - Date.parse(p.postedAt || p.createdAt) < 7 * 864e5).length;
  const rules = Object.values(C.rules || {}).filter(r => r.enabled).length;
  const attention = [
    ...C.connectors.filter(d => stateOf(d) === 'error').map(d => [d.id, 'alert', `${d.name}: ${d.status.error || 'needs attention'}`]),
    ...C.queue.filter(p => p.status === 'failed').slice(0, 3).map(p => ['queue', 'alert', `${nameOf(p.platform)} post failed: ${p.error || ''}`]),
    review ? ['queue', 'eye', `${review} post${review > 1 ? 's' : ''} waiting for your review`] : null,
    Object.values(C.rules || {}).some(r => r.enabled && r.ai) && !aiOn() ? ['ollama', 'ollama', 'Automation uses Ollama, but Ollama isn’t running: templates are used instead'] : null,
    (() => { const s = def('linkedin')?.settings; const days = s?.expiresAt ? Math.round((s.expiresAt - Date.now()) / 864e5) : null; return days != null && days < 10 ? ['linkedin', 'clock', days > 0 ? `LinkedIn sign-in ends in ${days} days: connect again` : 'LinkedIn sign-in has ended: connect again'] : null; })()
  ].filter(Boolean);
  const upcoming = C.queue.filter(p => ['scheduled', 'review', 'approved', 'retry'].includes(p.status)).slice(0, 6);
  return `${pageHead('plug', 'Connectors', 'Every account the hub uses, social posting with drafts from your own AI model, automation, and store uploads.', `<div class="row"><button type="button" class="hbtn ghost sm" data-recheck>${I('refresh')}Recheck all</button><button type="button" class="hbtn primary sm" data-go="compose">${I('sparkle')}Compose a post</button></div>`)}
    <div class="lc-tiles">
      <div class="tile"><span>Connected</span><b>${on}<small> of ${C.connectors.length}</small></b></div>
      <div class="tile"><span>Waiting for review</span><b>${review}</b></div>
      <div class="tile"><span>Posted this week</span><b>${week}</b></div>
      <div class="tile"><span>Automations on</span><b>${rules}<small> of ${C.events.length}</small></b></div>
      <div class="tile"><span>Posts on your website</span><b>${C.feed.items.length}</b></div></div>
    ${attention.length ? `<div class="card cx-attn"><h3>${I('alert')}Needs attention</h3>${attention.map(([go, ic, t]) => `<button type="button" class="cx-attn-i" data-go="${go}">${I(ic)}<span>${esc(t)}</span>${I('chevron')}</button>`).join('')}</div>` : ''}
    ${GROUPS.slice(1).map(([g, ids]) => `<h4 class="cx-h">${esc(g)}</h4><div class="cx-grid">${ids.map(id => { const d = def(id); return `
      <button type="button" class="cx-card ${stateOf(d)}" data-go="${id}">${logo(d)}<div class="cx-ct"><b>${esc(d.name)}</b>${pill(d)}</div>
        <p>${esc(d.status?.account ? `${d.status.account}${d.status.detail ? ` · ${d.status.detail}` : ''}` : d.status?.error || d.blurb)}</p></button>`; }).join('')}</div>`).join('')}
    <div class="cx-two">
      <div class="card"><div class="card-head"><h3>${I('activity')}Recent activity</h3></div>${(C.activity || []).length ? `<div class="cx-act">${C.activity.slice(0, 10).map(a => `<div class="cx-ai k-${esc(a.kind)}"><i></i><span>${esc(a.text)}</span><small>${esc(rel(a.at))}</small>${a.url ? `<a class="act" href="${esc(a.url)}" target="_blank" rel="noopener" title="Open">${I('external')}</a>` : ''}</div>`).join('')}</div>` : '<p class="muted">Posts, automation events and feed updates show here.</p>'}</div>
      <div class="card"><div class="card-head"><h3>${I('calendar')}Coming up</h3><button type="button" class="hbtn ghost sm" data-go="queue">Open queue</button></div>${upcoming.length ? `<div class="cx-act">${upcoming.map(p => `<div class="cx-ai k-${esc(p.status)}"><span class="cx-ni b-${p.platform}">${I(def(p.platform)?.icon || 'plug')}</span><span>${esc((p.title || p.text || '').split('\n')[0].slice(0, 90))}</span><small>${p.status === 'scheduled' && p.at ? esc(new Date(p.at).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })) : esc(p.status)}</small></div>`).join('')}</div>` : '<p class="muted">Nothing scheduled or waiting.</p>'}</div>
    </div>`;
}

function core(d) {
  const st = d.status || {};
  const used = Object.entries(C.rules || {}).filter(([, r]) => r.enabled).map(([ev]) => C.events.find(e => e.id === ev)?.label).filter(Boolean);
  return `<div class="card cx-hero">${logo(d, true)}<div><h3>${esc(d.name)}</h3><p class="sub">${esc(d.blurb)}</p></div><span class="sp"></span>${pill(d)}</div>
    <div class="st-grid"><div class="st-main"><div class="card"><h3>${I('activity')}Status</h3>
      ${stateOf(d) === 'off' ? `<p class="sub">Not set up yet.</p>` : `<div class="tx-kv"><span>Account</span><b>${esc(st.account || '—')}</b>${st.detail ? `<span>Details</span><b>${esc(st.detail)}</b>` : ''}</div>`}
      ${st.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(st.error)}</p>` : ''}
      <div class="row"><a class="hbtn primary sm" href="${esc(st.manage || '#/connectors')}">${I('sliders')}${stateOf(d) === 'off' ? 'Set it up' : 'Manage'}</a><button type="button" class="hbtn ghost sm" data-recheck>${I('refresh')}Recheck</button></div></div>
      ${d.id === 'youtube' ? `<div class="card"><h3>${I('zap')}Automation</h3><p class="sub">New videos and Shorts can post to your socials by themselves.</p><div class="row">${['yt.video', 'yt.short'].map(ev => `<span class="dc-pill${C.rules[ev]?.enabled ? ' ok' : ''}">${esc(C.events.find(e => e.id === ev)?.label)}: ${C.rules[ev]?.enabled ? 'on' : 'off'}</span>`).join('')}<span class="sp"></span><button type="button" class="hbtn ghost sm" data-go="automation">${I('zap')}Automation</button></div></div>` : ''}
      ${d.id === 'github' ? `<div class="card"><h3>${I('rocket')}Releases</h3><p class="sub">A new GitHub release updates the app’s version and notes on your site, which fires “${esc(C.events.find(e => e.id === 'app.updated')?.label)}” in Automation${C.rules['app.updated']?.enabled ? ` (on: posts to ${(C.rules['app.updated'].platforms || []).map(nameOf).join(', ') || 'nothing yet'})` : ' (off)'}.</p></div>` : ''}
    </div>
    <div class="st-side"><div class="card"><h3>${I('info')}Where it’s used</h3><p class="sub">${esc(coreUse[d.id] || '')}</p>${d.id === 'youtube' || d.id === 'github' ? `<p class="muted small">${used.length} automation rule${used.length === 1 ? '' : 's'} on.</p>` : ''}</div></div></div>`;
}
const coreUse = {
  github: 'Publishing your website, private repositories for paid downloads, release versions and notes for auto-sync, and release files for itch.io and Chrome Web Store uploads.',
  stripe: 'Store prices and checkout links, paid downloads, licence keys, sales alerts, supporter codes and the Tax tab.',
  cloudflare: 'The delivery service that hands out paid downloads and answers subscription licence checks.',
  gmail: 'Download links, licence keys, supporter codes and thank-you emails (Discord → Emails shows the outbox).',
  youtube: 'Your latest videos and shorts on the site, YouTube alerts, and video posts in Automation.'
};

// Discord: the alerts screens below, with how Connectors posts look in the public channel above them
function discordPanel() {
  const o = def('discord')?.settings?.defaults || {};
  return `<div class="card cx-dpost" data-defs="discord"><div class="card-head"><h3>${I('send')}Posts from Connectors</h3><button type="button" class="hbtn ghost sm" data-savedefs="discord">${I('save')}Save</button></div>
    <p class="sub">How Compose and Automation post to your public channel. Alerts, emails and the Post tab are below.</p>
    <div class="cx-cols"><div class="cx-sw">${chk('card', o.card !== false, 'Post about apps as a rich card (title, link, cover image)')}${chk('image', o.image !== false, 'Show the app’s cover in the card')}${chk('ping', o.ping, 'Mention @everyone (only if the webhook may)')}</div>
    <div>${txt('button', o.button, 'Link button label', 'e.g. Get it (empty: no button)')}${extrasFields('discord', o)}</div></div></div>`;
}

// ---------- a service (social, store, AI) ----------
function service(d) {
  const s = d.settings || {}, dflt = s.defaults || {};
  const main = d.id === 'x' ? xPanel(dflt) : d.id === 'devto' ? devtoPanel(d, dflt) : d.id === 'linkedin' ? linkedinPanel(d, dflt) : d.id === 'mastodon' ? mastodonPanel(d, dflt) : d.id === 'telegram' ? telegramPanel(d, dflt) : d.id === 'itch' ? itchPanel(d) : d.id === 'cws' ? cwsPanel(d) : d.id === 'ollama' ? ollamaPanel(d) : '';
  return `<div class="card cx-hero">${logo(d, true)}<div><h3>${esc(d.name)}</h3><p class="sub">${esc(d.blurb)}</p></div><span class="sp"></span>${pill(d)}</div>
  <div class="st-grid"><div class="st-main">${main}${C.feed.feedable.includes(d.id) ? websiteCard(d) : ''}</div><div class="st-side">${setupCard(d)}${d.kind === 'social' ? usedByCard(d) : ''}</div></div>`;
}
function setupCard(d) {
  const st = d.status || {};
  return `<div class="card"><div class="card-head"><h3>${I('key')}Connection</h3>${d.docs ? `<a class="hbtn ghost sm" href="${esc(d.docs)}" target="_blank" rel="noopener">${I('external')}Open</a>` : ''}</div>
    ${stateOf(d) === 'on' ? `<div class="tx-kv"><span>Account</span><b>${esc(st.account || '')}</b>${st.detail ? `<span>Details</span><b>${esc(st.detail)}</b>` : ''}</div>` : ''}
    ${st.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(st.error)}</p>` : ''}
    <details class="cx-steps"${stateOf(d) === 'on' ? '' : ' open'}><summary>${I('book')}How to connect</summary><ol>${(d.steps || []).map(x => `<li>${esc(x)}</li>`).join('')}</ol>
      ${d.oauth ? `<p class="sub">${d.id === 'x' ? 'Callback URI' : 'Redirect URL'}: <code>${esc(redirectOf(d.id))}</code> <button type="button" class="act" data-copy="${esc(redirectOf(d.id))}">${I('copy')}</button></p>` : ''}</details>
    <form class="fb" data-save="${d.id}">${(d.fields || []).map(f => `<label class="fld"><span>${esc(f.l)}${f.opt ? ' <small>optional</small>' : ''}</span><input name="${f.k}" ${f.secret ? 'type="password" autocomplete="off"' : ''} value="${esc(d.values?.[f.k] || '')}" placeholder="${esc(f.placeholder || '')}" spellcheck="false">${f.help ? `<small class="muted">${esc(f.help)}</small>` : ''}</label>`).join('')}
      <div class="row"><button class="hbtn primary sm" type="submit">${I('check')}Save &amp; test</button>${d.oauth ? `<button type="button" class="hbtn ghost sm" data-oauth="${d.id}">${I(d.id === 'x' ? 'xlogo' : 'link')}${d.id === 'cws' ? 'Sign in with Google' : d.id === 'x' ? 'Sign in with X' : 'Connect LinkedIn'}</button>` : ''}<button type="button" class="hbtn ghost sm" data-test="${d.id}">${I('zap')}Test</button>${stateOf(d) !== 'off' ? `<span class="sp"></span><button type="button" class="hbtn ghost sm danger" data-forget="${d.id}">Disconnect</button>` : ''}</div></form>
    <p class="muted small">${I('lock')} Keys stay on this computer and are only sent to ${esc(d.name)}.</p></div>`;
}
function usedByCard(d) {
  const rules = C.events.filter(ev => (C.rules[ev.id]?.platforms || []).includes(d.id));
  const posted = C.history.filter(p => p.platform === d.id).length;
  return `<div class="card"><h3>${I('zap')}Automation</h3>${rules.length ? `<div class="cx-list">${rules.map(ev => `<div class="cx-li"><span class="cx-dot ${C.rules[ev.id].enabled ? 'on' : ''}"></span><span>${esc(ev.label)}</span><span class="sp"></span><small>${C.rules[ev.id].mode === 'auto' ? 'automatic' : 'review'}</small></div>`).join('')}</div>` : `<p class="sub">No automation posts here yet.</p>`}
    <div class="row"><button type="button" class="hbtn ghost sm" data-go="automation">${I('zap')}Automation</button><span class="sp"></span><small class="muted">${posted} post${posted === 1 ? '' : 's'} sent</small></div></div>`;
}
const redirectOf = id => C.redirects[id === 'cws' ? 'google' : id] || '';
const chk = (k, v, label, attr = 'data-def') => `<label class="switch"><input type="checkbox" ${attr}="${k}"${v ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">${esc(label)}</span></label>`;
const sel = (k, v, opts, label, attr = 'data-def') => `<label class="fld"><span>${esc(label)}</span><select ${attr}="${k}">${opts.map(([val, l]) => `<option value="${esc(val)}"${String(v ?? '') === String(val) ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`;
const txt = (k, v, label, ph = '', attr = 'data-def') => `<label class="fld"><span>${esc(label)}</span><input ${attr}="${k}" value="${esc(v ?? '')}" placeholder="${esc(ph)}"></label>`;
const area = (k, v, label, ph = '', attr = 'data-def', rows = 3) => `<label class="fld"><span>${label}</span><textarea ${attr}="${k}" rows="${rows}" placeholder="${esc(ph)}">${esc(v ?? '')}</textarea></label>`;
const defaultsCard = (id, body, title = 'Posting defaults') => `<div class="card" data-defs="${id}"><div class="card-head"><h3>${I('sliders')}${esc(title)}</h3><button type="button" class="hbtn ghost sm" data-savedefs="${id}">${I('save')}Save</button></div>${body}</div>`;
// added to every post on this platform when it's drafted (you still see and can edit the result)
const extrasFields = (id, o) => `<div class="cx-extras"><h4>${I('hash')}Added to every post</h4>
  ${id === 'devto' ? '' : txt('hashtags', o.hashtags, 'Hashtags', 'indiedev buildinpublic')}
  ${txt('footer', o.footer, id === 'devto' ? 'Closing line for articles' : 'Sign-off line', id === 'devto' ? 'e.g. Follow along at pylerium.github.io' : 'e.g. Built by Pylerium Studio')}
  ${chk('utm', o.utm, 'Tag links to my site with UTM tracking (utm_source = this platform)')}</div>`;

const xPanel = o => defaultsCard('x', `<div class="cx-cols"><div class="cx-sw">${chk('thread', o.thread !== false, 'Split long posts into a numbered thread')}${chk('image', o.image !== false, 'Attach the app’s cover image')}${chk('premium', o.premium, 'X Premium account: posts up to 25,000 characters')}</div>
  <div>${sel('replySettings', o.replySettings || '', [['', 'Everyone can reply'], ['following', 'People you follow'], ['mentionedUsers', 'Only people you mention'], ['subscribers', 'Your subscribers'], ['verified', 'Verified accounts']], 'Who can reply')}</div></div>
  ${extrasFields('x', o)}
  <p class="note"><span>${I('info')}</span>Links count as 23 characters. The X API is pay-per-use: your developer account needs credits (console → Billing).</p>`);
const linkedinPanel = (d, o) => defaultsCard('linkedin', `<div class="f2">${sel('visibility', o.visibility || 'PUBLIC', [['PUBLIC', 'Anyone'], ['CONNECTIONS', 'Connections only']], 'Who can see it')}${sel('asOrg', o.asOrg ? '1' : '', [['', 'Me'], ['1', 'Company page']], 'Post as')}</div>
  <div class="cx-sw">${chk('card', o.card !== false, 'Show a link preview card')}${chk('noReshare', o.noReshare, 'Turn off resharing')}</div>
  ${extrasFields('linkedin', o)}
  ${txt('version', d.settings?.version || '', 'API version (advanced)', 'auto: two months ago, e.g. 202609', 'data-setting')}
  <p class="note"><span>${I('info')}</span>LinkedIn sign-ins last 60 days. The status here shows how long is left; press Connect LinkedIn again before it runs out.</p>`);
function mastodonPanel(d, o) {
  const posts = extra.mastodon;
  return defaultsCard('mastodon', `<div class="f2">${sel('visibility', o.visibility || 'public', [['public', 'Public'], ['unlisted', 'Unlisted (quiet public)'], ['private', 'Followers only'], ['direct', 'Mentioned people only']], 'Visibility')}${txt('language', o.language, 'Language', 'en')}</div>
    ${txt('cw', o.cw, 'Content warning', 'optional')}
    <div class="cx-sw">${chk('image', o.image !== false, 'Attach the app’s cover image')}${chk('sensitive', o.sensitive, 'Mark media as sensitive')}${chk('thread', o.thread !== false, 'Split long posts into a thread')}</div>
    ${extrasFields('mastodon', o)}`) +
    (stateOf(d) === 'on' ? `<div class="card"><div class="card-head"><h3>${I('chart')}Your recent posts</h3>${posts?.items?.length ? `<span class="muted small">${posts.items.length} latest</span>` : ''}</div>${!posts ? '<p class="muted"><span class="spinner sm"></span> Loading…</p>' : posts.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(posts.error)}</p>` : posts.items.length ? `<div class="cx-table c4"><div class="cx-tr h"><span>Post</span><span>Likes</span><span>Boosts</span><span>Replies</span></div>${posts.items.map(x => `<div class="cx-tr"><a href="${esc(x.url)}" target="_blank" rel="noopener">${esc((x.text || '').slice(0, 90) || '(image)')}</a><span>${x.stats?.likes || 0}</span><span>${x.stats?.shares || 0}</span><span>${x.stats?.replies || 0}</span></div>`).join('')}</div>` : '<p class="muted">No public posts yet.</p>'}</div>` : '');
}
function telegramPanel(d, o) {
  const chats = extra.telegram;
  return defaultsCard('telegram', `<div class="cx-sw">${chk('photo', o.photo !== false, 'Send with the app’s cover image')}${chk('silent', o.silent, 'Send silently (no notification)')}${chk('pin', o.pin, 'Pin the message')}${chk('noPreview', o.noPreview, 'Turn off link previews')}</div>
    <div class="f2">${txt('button', o.button, 'Button label', 'Get it')}${txt('buttonUrl', o.buttonUrl, 'Button link', 'the post’s link')}</div>${extrasFields('telegram', o)}`) +
    `<div class="card"><div class="card-head"><h3>${I('users')}Chats &amp; channels</h3><button type="button" class="hbtn ghost sm" data-findchats>${I('search')}Find chats</button></div>
      <p class="sub">Posting to: <b>${esc(d.values?.chats || 'no chats yet')}</b>. Post anything in your group or channel (with the bot added as admin), then press Find chats.</p>
      ${chats ? (chats.length ? `<div class="cx-list">${chats.map(c => `<div class="cx-li"><b>${esc(c.title)}</b><small>${esc(c.type)} · ${esc(c.username ? '@' + c.username : c.id)}</small><span class="sp"></span><button type="button" class="hbtn ghost sm" data-addchat="${esc(c.username ? '@' + c.username : c.id)}">${I('plus')}Add</button></div>`).join('')}</div>` : '<p class="muted small">No chats found yet. Post a message where the bot is, then try again.</p>') : ''}</div>`;
}
function itchPanel(d) {
  const g = extra.itch, maps = d.settings?.maps || [];
  return `<div class="card"><div class="card-head"><h3>${I('chart')}Your games</h3>${g?.butler ? `<span class="dc-pill ok">${I('check')}${esc(g.butler)}</span>` : g ? `<span class="dc-pill warn">butler not found</span>` : ''}</div>
      ${!g ? (stateOf(d) === 'on' ? '<p class="muted"><span class="spinner sm"></span> Loading…</p>' : '<p class="sub">Connect itch.io to see your games.</p>') : g.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(g.error)}</p>` : g.games.length ? `<div class="cx-table"><div class="cx-tr h"><span>Game</span><span>Views</span><span>Downloads</span><span>Purchases</span><span>Earnings</span></div>${g.games.map(x => `<div class="cx-tr"><a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.title)}</a><span>${x.views.toLocaleString()}</span><span>${x.downloads.toLocaleString()}</span><span>${x.purchases.toLocaleString()}</span><span>${esc(x.earnings || '—')}</span></div>`).join('')}</div>` : '<p class="muted">No games on this account yet.</p>'}</div>
    <div class="card"><div class="card-head"><h3>${I('upload')}Builds with butler</h3><button type="button" class="hbtn ghost sm" data-addmap="itch">${I('plus')}Add an app</button></div>
      <p class="sub">On a new release, the hub downloads the matching file from the app’s GitHub release and pushes it to itch.io with butler.</p>
      ${maps.map((m, i) => `<div class="cx-map" data-mapi="${i}" data-mapof="itch">${sel('appId', m.appId, appOpts(), 'App', 'data-map')}${txt('target', m.target, 'itch.io page', 'yourname/game', 'data-map')}${txt('channel', m.channel, 'Channel', 'windows', 'data-map')}${txt('pattern', m.pattern, 'File name contains', 'win, .zip', 'data-map')}
        <div class="row cx-mapf">${chk('auto', m.auto, 'Push new releases automatically', 'data-map')}<span class="sp"></span><button type="button" class="hbtn ghost sm" data-pushnow="${esc(m.appId)}">${I('upload')}Push latest now</button><button type="button" class="act" data-delmap="${i}" data-mapof2="itch" title="Remove">${I('trash')}</button></div></div>`).join('') || '<p class="muted small">No apps mapped yet.</p>'}
      ${maps.length ? `<div class="row"><button type="button" class="hbtn primary sm" data-savemaps="itch">${I('save')}Save mappings</button></div>` : ''}</div>
    <div class="card" data-defs="itch"><div class="card-head"><h3>${I('globe')}On your website</h3><button type="button" class="hbtn ghost sm" data-saveweb="itch">${I('save')}Save</button></div>
      <div class="cx-sw">${chk('profile', d.settings?.profile !== false, 'Show an itch.io Follow link in the site’s social links', 'data-web')}</div>
      ${txt('profileUrl', d.settings?.profileUrl, 'Profile link', d.settings?.url || 'https://you.itch.io', 'data-web')}</div>`;
}
function cwsPanel(d) {
  const items = d.settings?.items || [], live = extra.cws;
  const lbl = st => ({ PENDING_REVIEW: 'In review', STAGED: 'Approved, staged', PUBLISHED: 'Published', PUBLISHED_TO_TESTERS: 'Published to testers', REJECTED: 'Rejected', CANCELLED: 'Submission cancelled', NOT_PUBLISHED: 'Not published yet' })[st] || st || '';
  return `<div class="card"><div class="card-head"><h3>${I('chrome')}Extensions</h3><button type="button" class="hbtn ghost sm" data-addmap="cws">${I('plus')}Add an extension</button></div>
      <p class="sub">Uses the Chrome Web Store API v2. Map an app to its extension: new releases upload the .zip from the app’s GitHub release and can be submitted straight away, or staged to publish when you choose.</p>
      ${items.map((m, i) => { const L = live?.find(x => x.itemId === m.itemId)?.live; return `<div class="cx-map" data-mapi="${i}" data-mapof="cws">${sel('appId', m.appId, appOpts(), 'App', 'data-map')}${txt('itemId', m.itemId, 'Extension ID', '32 letters from the store URL', 'data-map')}${txt('pattern', m.pattern || '.zip', 'File name contains', '.zip', 'data-map')}${txt('percent', m.percent, 'Rollout %', '100', 'data-map')}
        <div class="row cx-mapf">${chk('auto', m.auto, 'Upload new releases automatically', 'data-map')}${chk('publish', m.publish, 'Submit for review after upload', 'data-map')}${chk('staged', m.staged, 'Stage when approved (publish later)', 'data-map')}${chk('skipReview', m.skipReview, 'Skip review when allowed', 'data-map')}${chk('blockOnWarnings', m.blockOnWarnings, 'Stop on warnings', 'data-map')}</div>
        ${L ? (L.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(L.error)}</p>` : `<div class="row cx-wrap cx-cwsst"><span class="dc-pill${L.state === 'PUBLISHED' ? ' ok' : L.state === 'REJECTED' || L.takenDown ? ' bad' : ' warn'}">${esc(lbl(L.state))}</span>${L.version ? `<span class="dc-pill">Live v${esc(L.version)}${L.published?.channels?.[0]?.percent != null && L.published.channels[0].percent < 100 ? ` · ${L.published.channels[0].percent}%` : ''}</span>` : ''}${L.submitted && L.published ? `<span class="dc-pill">Submitted v${esc(L.submitted.channels?.[0]?.version || '?')}</span>` : ''}${L.takenDown ? '<span class="dc-pill bad">Taken down</span>' : ''}${L.warned ? '<span class="dc-pill warn">Warning from Google</span>' : ''}</div>`) : ''}
        <div class="row cx-wrap"><button type="button" class="hbtn ghost sm" data-cwsdeploy="${esc(m.appId)}">${I('upload')}Upload latest release</button><label class="hbtn ghost sm cx-file">${I('folder')}Upload a .zip<input type="file" accept=".zip" data-cwszip="${esc(m.itemId)}" hidden></label><button type="button" class="hbtn ghost sm" data-cwspub="${esc(m.itemId)}">${I('rocket')}Submit for review</button>${L?.state === 'PENDING_REVIEW' ? `<button type="button" class="hbtn ghost sm" data-cwscancel="${esc(m.itemId)}">Cancel submission</button>` : ''}${L?.version ? `<button type="button" class="hbtn ghost sm" data-cwsroll="${esc(m.itemId)}">${I('chart')}Raise rollout</button>` : ''}<span class="sp"></span><button type="button" class="act" data-delmap="${i}" data-mapof2="cws" title="Remove">${I('trash')}</button></div></div>`; }).join('') || '<p class="muted small">No extensions mapped yet.</p>'}
      ${items.length ? `<div class="row"><button type="button" class="hbtn primary sm" data-savemaps="cws">${I('save')}Save mappings</button></div>` : ''}</div>`;
}
function devtoPanel(d, o) {
  const a = extra.devto;
  return defaultsCard('devto', `<div class="cx-sw">${chk('published', o.published, 'Publish immediately (off: save as a draft on dev.to)')}${chk('cover', o.cover !== false, 'Use the app’s cover as the article cover')}${chk('canonical', o.canonical, 'Point the canonical link at the app’s page')}</div>
      <div class="f2">${txt('tags', o.tags, 'Tags (up to 4)', 'showdev, webdev, opensource')}${txt('series', o.series, 'Series', 'optional')}</div>
      <div class="f2">${txt('orgId', o.orgId, 'Organization ID', 'optional: post under your org')}${txt('description', o.description, 'Description', 'optional: the app’s tagline')}</div>${extrasFields('devto', o)}`) +
    `<div class="card"><div class="card-head"><h3>${I('chart')}Your articles</h3>${a?.length ? `<span class="muted small">${a.length} latest</span>` : ''}</div>
      ${!a ? (stateOf(d) === 'on' ? '<p class="muted"><span class="spinner sm"></span> Loading…</p>' : '<p class="sub">Connect DEV to see your articles.</p>') : a.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(a.error)}</p>` : a.length ? `<div class="cx-table"><div class="cx-tr h"><span>Article</span><span>Views</span><span>Reactions</span><span>Comments</span><span>Status</span></div>${a.map(x => `<div class="cx-tr"><a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.title)}</a><span>${x.views.toLocaleString()}</span><span>${x.reactions.toLocaleString()}</span><span>${x.comments.toLocaleString()}</span><span>${x.published ? 'Live' : `<a href="https://dev.to/dashboard" target="_blank" rel="noopener">Draft</a>`}</span></div>`).join('')}</div>` : '<p class="muted">No articles yet.</p>'}</div>`;
}
// what this platform adds to the website: posts in the "Latest posts" section and a Follow link
function websiteCard(d) {
  const s = d.settings || {}, f = s.feed || {}, fetchable = C.feed.fetchable.includes(d.id);
  const prof = C.feed.profiles.find(p => p.platform === d.id);
  return `<div class="card" data-defs="${d.id}"><div class="card-head"><h3>${I('globe')}On your website</h3><button type="button" class="hbtn ghost sm" data-saveweb="${d.id}">${I('save')}Save</button></div>
    <div class="cx-cols"><div class="cx-sw">${chk('feed.enabled', f.enabled, `Show my ${d.name} posts in “Latest posts” on the home page`, 'data-web')}
      ${fetchable ? chk('feed.external', f.external !== false, 'Include posts I made outside the hub', 'data-web') : ''}
      ${chk('profile', s.profile !== false, `Add a ${d.name} Follow link to the site`, 'data-web')}</div>
    <div>${sel('feed.count', f.count || 3, [1, 2, 3, 4, 6, 9, 12].map(n => [n, `Up to ${n} post${n > 1 ? 's' : ''}`]), 'How many', 'data-web')}
      ${txt('profileUrl', s.profileUrl, d.id === 'linkedin' ? 'Profile or page link (needed for the Follow link)' : 'Profile link (optional override)', prof?.url || (d.id === 'linkedin' ? 'https://www.linkedin.com/in/you' : 'detected from your account'), 'data-web')}</div></div>
    <p class="muted small">${I('info')} ${esc(FEED_NOTE[d.id] || '')} ${prof ? `Follow link: ${esc(prof.url)}.` : ''} <a href="#/connectors/feed">Website feed settings</a></p></div>`;
}

// ---------- Ollama ----------
function ollamaPanel(d) {
  const s = d.settings || {}, models = extra.ollama, ctxs = extra.octx || {};
  const seg = (k, v, opts) => `<div class="seg" data-oseg="${k}">${opts.map(([val, l]) => `<button type="button" data-osegv="${val}" class="${String(v) === String(val) ? 'on' : ''}">${esc(l)}</button>`).join('')}</div>`;
  const about = S.site?.hero?.lead || '';
  return `<div class="card" data-defs="ollama"><div class="card-head"><h3>${I('cpu')}Model</h3><button type="button" class="hbtn ghost sm" data-saveollama>${I('save')}Save</button></div>
      ${models?.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(models.error)} Is Ollama running?</p>` : ''}
      <div class="f2"><label class="fld"><span>Model</span><select data-oset="model">${(models?.models || []).map(m => `<option value="${esc(m.name)}"${m.name === s.model ? ' selected' : ''}>${esc(m.name)}${m.params ? ` · ${esc(m.params)}` : ''}${m.quant ? ` · ${esc(m.quant)}` : ''}</option>`).join('') || `<option>${models ? 'No models: run ollama pull qwen3:4b-instruct' : 'Loading…'}</option>`}</select></label>
        <label class="fld"><span>Creativity <small>${esc(String(s.temperature ?? 0.7))}</small></span><input type="range" min="0" max="1.2" step="0.1" value="${esc(String(s.temperature ?? 0.7))}" data-oset="temperature"></label></div>
      <div class="f3">${sel('numCtx', s.numCtx || 8192, [[4096, '4K (fastest)'], [8192, '8K (default)'], [16384, '16K (long articles)']], 'Context size', 'data-oset')}${sel('keepAlive', s.keepAlive || '10m', [['5m', '5 minutes'], ['10m', '10 minutes'], ['30m', '30 minutes'], ['-1', 'Always']], 'Keep the model loaded', 'data-oset')}${txt('language', s.language, 'Write in', 'English', 'data-oset')}</div>
      <p class="note"><span>${I('lock')}</span>Drafts are written on this computer by your own model. Nothing is sent to an online AI.</p></div>
    <div class="card" data-defs="ollama-voice"><div class="card-head"><h3>${I('mic')}Studio &amp; voice</h3><button type="button" class="hbtn ghost sm" data-saveollama>${I('save')}Save</button></div>
      <p class="sub">The writer always knows your studio name (${esc(C.brand)}), your website, and every published app’s name and tagline, so names are spelled exactly right.</p>
      ${area('about', s.about, 'About the studio <small>what you make and for whom</small>', about || 'An independent studio making fast, privacy-respecting desktop apps and browser extensions.', 'data-oset', 2)}
      ${area('voice', s.voice, 'Your voice', 'friendly, precise, no hype, an indie developer talking to other makers', 'data-oset', 2)}
      <div class="f2">${txt('cta', s.cta, 'Usual call to action', 'Try it free at the link', 'data-oset')}${txt('avoid', s.avoid, 'Never use', 'revolutionary, game-changer, unlock', 'data-oset')}</div>
      <div class="f3"><div class="fld"><span>Length</span>${seg('length', s.length || 'standard', [['short', 'Short'], ['standard', 'Standard'], ['long', 'Long']])}</div><div class="fld"><span>Emoji</span>${seg('emoji', s.emoji || 'few', [['none', 'None'], ['few', 'A few'], ['more', 'More']])}</div><div class="fld"><span>Hashtags</span>${seg('hashtags', s.hashtags || 'platform', [['none', 'None'], ['few', 'A couple'], ['platform', 'Per platform']])}</div></div>
      ${chk('catalog', s.catalog !== false, 'Tell the writer about all my apps (names and taglines)', 'data-oset')}</div>
    <div class="card" data-defs="ollama-plat"><div class="card-head"><h3>${I('sliders')}Per platform</h3><button type="button" class="hbtn ghost sm" data-saveollama>${I('save')}Save</button></div>
      <p class="sub">Extra instructions for one platform, added to its built-in style.</p>
      <div class="cx-pnotes">${POSTERS.map(p => `<label class="fld"><span><span class="cx-ni b-${p}">${I(def(p)?.icon || 'plug')}</span>${esc(nameOf(p))}</span><input data-pnote="${p}" value="${esc(s.platformNotes?.[p] || '')}" placeholder="${esc({ x: 'e.g. lead with the benefit, not the name', devto: 'e.g. include a short “how it’s built” section', linkedin: 'e.g. speak to studio owners and freelancers', mastodon: 'e.g. mention it’s open about privacy', telegram: 'e.g. keep it to three lines', discord: 'e.g. thank the community' }[p])}"></label>`).join('')}</div></div>
    <div class="card" data-defs="ollama-apps"><div class="card-head"><h3>${I('package')}App knowledge</h3><button type="button" class="hbtn ghost sm" data-saveollama>${I('save')}Save</button></div>
      <p class="sub">For each app the writer gets its tagline, description, highlights, price, platforms and latest release notes from your catalogue. Add anything else it should know: who it’s for, how to say the name, what not to promise.</p>
      <div class="cx-apps">${C.apps.map(a => `<div class="cx-appk"><div class="row"><span class="cx-aico">${a.iconImage ? `<img src="${esc(mediaUrl(a.iconImage))}" alt="">` : I(a.glyph || 'package')}</span><div><b>${esc(a.name)}</b><small>${esc(a.tagline || '')}</small></div><span class="sp"></span><button type="button" class="hbtn ghost sm" data-actx="${esc(a.id)}">${I('eye')}${ctxs[a.id] ? 'Hide' : 'What it’s told'}</button></div>
        ${ctxs[a.id] ? `<pre class="cx-facts">${esc(ctxs[a.id])}</pre>` : ''}
        <textarea data-anote="${esc(a.id)}" rows="2" placeholder="Notes for the writer about ${esc(a.name)} (optional)">${esc(s.appNotes?.[a.id] || '')}</textarea></div>`).join('') || '<p class="muted">Publish an app to see it here.</p>'}</div></div>
    <div class="card"><h3>${I('sparkle')}Try it</h3><form class="fb" data-otry><div class="f2">${sel('platform', extra.otry?.platform || 'x', POSTERS.map(p => [p, nameOf(p)]), 'Platform', 'name')}${sel('appId', extra.otry?.appId || '', [['', 'No app: just the topic'], ...C.apps.map(a => [a.id, a.name])], 'About an app', 'name')}</div>
      <label class="fld"><span>Write a post about</span><input name="brief" placeholder="what’s new this week" value="${esc(extra.otry?.brief || '')}"></label>
      <div class="row"><button class="hbtn primary sm" type="submit"${busy === 'otry' ? ' disabled' : ''}>${busy === 'otry' ? '<span class="spinner sm"></span>Writing…' : `${I('sparkle')}Write it`}</button></div></form>
      ${extra.otry?.text ? `<div class="cx-out">${extra.otry.title ? `<b>${esc(extra.otry.title)}</b>\n\n` : ''}${esc(extra.otry.text)}</div>` : ''}</div>`;
}

// ---------- compose ----------
function compose() {
  const ok = POSTERS.filter(p => def(p)?.status?.ok), app = C.apps.find(a => a.id === draft.appId);
  const linkOpts = [['page', 'Its page on my site'], ...(app?.primaryUrl ? [['primary', `Its own link: ${app.primaryLabel || app.primaryUrl}`]] : []), ['home', 'My home page'], ['custom', 'Another link…']];
  return `${pageHead('sparkle', 'Compose a post', 'Write once for every platform. Your own model drafts each post in that platform’s style; edit, rewrite, preview, then post, schedule or queue it.')}
  <div class="cx-compose"><div class="card"><h3>${I('edit')}What’s it about?</h3>
      <div class="seg wide">${[['app', 'An app'], ['topic', 'Anything'], ['video', 'A video']].map(([v, l]) => `<button type="button" data-src="${v}" class="${draft.source === v ? 'on' : ''}">${l}</button>`).join('')}</div>
      ${draft.source === 'app' ? `<div class="f2">${sel('appId', draft.appId, appOpts(), 'App', 'data-dr')}${sel('event', draft.event, ANGLES, 'Angle', 'data-dr')}</div>
        <div class="f2">${sel('link', draft.link, linkOpts, 'Link to', 'data-dr')}${draft.link === 'custom' ? txt('customLink', draft.customLink, 'Link', 'https://…', 'data-dr') : `<div class="fld"><span>Picture</span>${chk('image', draft.image, 'Attach the app’s cover', 'data-dr')}</div>`}</div>` : ''}
      ${draft.source === 'video' ? sel('videoId', draft.videoId, [['', 'Choose…'], ...(S.site?.youtube?.videos || []).slice(0, 30).map(v => [v.id, v.title])], 'Video', 'data-dr') : ''}
      ${draft.source === 'topic' ? txt('customLink', draft.customLink, 'Link (optional)', C.siteUrl || 'https://…', 'data-dr') : ''}
      <label class="fld"><span>${draft.source === 'topic' ? 'Topic' : 'Anything to mention'} </span><textarea data-dr="brief" rows="3" placeholder="${draft.source === 'topic' ? 'We just hit 1,000 downloads: thank everyone and tease what’s next' : 'optional: a discount code, a thank-you, a question for the community'}">${esc(draft.brief)}</textarea></label>
      <div class="f2">${sel('tone', draft.tone, TONES.map(t => [t, t[0].toUpperCase() + t.slice(1)]), 'Tone', 'data-dr')}${txt('extra', draft.extra, 'Extra instructions', 'e.g. end with a question', 'data-dr')}</div></div>
    <div class="card"><h3>${I('send')}Post to</h3>
      <div class="cx-plats">${POSTERS.map(p => { const d = def(p); const on = draft.platforms.includes(p); return `<button type="button" class="cx-chip${on ? ' on' : ''}${d?.status?.ok ? '' : ' dis'}" data-plat="${p}" title="${d?.status?.ok ? '' : 'Not connected'}">${I(d?.icon || 'plug')}<span>${esc(d?.name || p)}<small>${p === 'devto' ? 'article' : `${LIM[p].toLocaleString()} chars`}</small></span></button>`; }).join('')}</div>
      ${ok.length ? '' : `<p class="sub">Connect a social account first (left).</p>`}
      <div class="row cx-wrap"><button type="button" class="hbtn primary" data-draft="ai"${!aiOn() || busy === 'draft' ? ' disabled' : ''} title="${aiOn() ? '' : 'Connect Ollama first'}">${busy === 'draft' ? '<span class="spinner sm"></span>Writing drafts…' : `${I('ollama')}Draft with Ollama`}</button><button type="button" class="hbtn ghost" data-draft="tpl">${I('edit')}Start from a template</button></div>
      ${busy === 'draft' ? `<p class="muted small">Your local model is writing one post per platform (about 20–40 seconds each).</p>` : ''}
      <details class="cx-know"${draft.factsOpen ? ' open' : ''}><summary>${I('cpu')}What Ollama knows for this post</summary>
        ${draft.facts == null ? '<p class="muted small"><span class="spinner sm"></span> Loading…</p>' : `<pre class="cx-facts">${esc(draft.facts || 'Only your topic, your studio and your app names.')}</pre>`}
        <p class="muted small">Change the studio profile, voice and per-app notes in <a href="#/connectors/ollama">Ollama</a>.</p></details></div></div>
    ${draftsSection()}`;
}
function draftsSection() {
  const plats = draft.platforms.filter(p => draft.posts[p]);
  if (!plats.length) return `<div class="card"><div class="emptystate">${I('sparkle')}<h4>No drafts yet</h4><p>Pick platforms and press Draft with Ollama, or start from a template. Each draft gets a live preview and one-click rewrites.</p></div></div>`;
  const app = draft.source === 'app' ? C.apps.find(a => a.id === draft.appId) : null;
  return `<div class="cx-drafts">${plats.map(p => { const d = def(p), post = draft.posts[p], n = (post.text || '').length, lim = LIM[p];
      return `<div class="card cx-draft" data-dcard="${p}"><div class="row"><span class="cx-ni b-${p}">${I(d.icon)}</span><b>${esc(d.name)}</b>${post.ai ? `<span class="dc-pill violet">${I('sparkle')}AI</span>` : ''}<span class="sp"></span><small class="cx-count${n > lim ? ' over' : ''}">${n.toLocaleString()}/${lim.toLocaleString()}${p === 'x' || p === 'mastodon' ? (n > lim ? ' · thread' : '') : ''}</small><button type="button" class="act" data-dcopy="${p}" title="Copy">${I('copy')}</button><button type="button" class="act" data-ddel="${p}" title="Remove">${I('x')}</button></div>
        ${p === 'devto' ? `<input data-post="${p}" data-pf="title" value="${esc(post.title || '')}" placeholder="Article title" class="cx-in cx-title">` : ''}
        <textarea class="cx-in${p === 'devto' ? ' mono' : ''}" data-post="${p}" data-pf="text" rows="${p === 'devto' ? 12 : p === 'linkedin' ? 8 : 5}">${esc(post.text || '')}</textarea>
        ${p === 'devto' ? `<input class="cx-in mono" data-post="${p}" data-pf="tags" value="${esc(post.options?.tags ?? def('devto').settings?.defaults?.tags ?? '')}" placeholder="Tags, up to 4: showdev, webdev">` : ''}
        ${aiOn() ? `<div class="cx-rw">${busy === 'rw-' + p ? '<span class="muted small"><span class="spinner sm"></span> Rewriting…</span>' : `<button type="button" class="cx-mini" data-regen="${p}">${I('refresh')}New draft</button>${REWRITES.map(([k, l]) => `<button type="button" class="cx-mini" data-rw="${p}:${k}">${esc(l)}</button>`).join('')}`}</div>` : ''}
        <div class="cx-pv" data-pv="${p}">${previewHTML(p, post, app)}</div></div>`; }).join('')}</div>
    <div class="card cx-sendbar"><div class="seg">${[['review', 'Queue for review'], ['now', 'Post now'], ['later', 'Schedule']].map(([v, l]) => `<button type="button" data-when="${v}" class="${draft.when === v ? 'on' : ''}">${l}</button>`).join('')}</div>
      ${draft.when === 'later' ? `<input type="datetime-local" class="cx-in" data-dr="at" value="${esc(draft.at)}">` : ''}<span class="sp"></span>
      <button type="button" class="hbtn primary" data-send>${I('send')}${draft.when === 'now' ? `Post to ${plats.length} platform${plats.length > 1 ? 's' : ''}` : draft.when === 'later' ? 'Schedule' : 'Add to the queue'}</button></div>`;
}
// roughly how the post will look on the platform
function previewHTML(p, post, app) {
  const showImg = app && draft.image && app.cover && !(p === 'devto' && def('devto').settings?.defaults?.cover === false);
  const who = p === 'discord' ? C.brand : def(p)?.status?.account || C.brand;
  if (p === 'devto') return `<div class="pv-dev">${showImg ? `<img src="${esc(mediaUrl(app.cover))}" alt="">` : ''}<h4>${esc(post.title || 'Untitled')}</h4><div class="pv-tags">${String(post.options?.tags ?? def('devto').settings?.defaults?.tags ?? '').split(/[,\s]+/).filter(Boolean).slice(0, 4).map(t => `<span>#${esc(t.replace(/^#/, ''))}</span>`).join('')}</div><p>${linkify((post.text || '').replace(/[#*_`>]/g, '').slice(0, 280))}…</p></div>`;
  if (p === 'discord' && app && def('discord').settings?.defaults?.card !== false) return `<div class="pv-post pv-discord"><div class="pv-who"><span class="pv-av">${esc(C.brand[0] || 'P')}</span><b>${esc(who)}</b></div><p>${linkify(post.text || '')}</p><div class="pv-embed"><b>${esc(post.title || app.name)}</b><span>${esc(app.tagline || '')}</span>${showImg ? `<img src="${esc(mediaUrl(app.cover))}" alt="">` : ''}</div></div>`;
  return `<div class="pv-post pv-${p}"><div class="pv-who"><span class="pv-av">${esc(C.brand[0] || 'P')}</span><b>${esc(who)}</b><small>now</small></div><p>${linkify(post.text || '')}</p>${showImg && p !== 'linkedin' ? `<img src="${esc(mediaUrl(app.cover))}" alt="">` : ''}${p === 'linkedin' && post.link ? `<div class="pv-embed">${showImg ? `<img src="${esc(mediaUrl(app.cover))}" alt="">` : ''}<b>${esc(post.title || app?.name || post.link)}</b><span>${esc((post.link || '').replace(/^https?:\/\//, '').split('/')[0])}</span></div>` : ''}</div>`;
}

// ---------- automation ----------
function automation() {
  const appEv = ev => ev.startsWith('app.');
  return `${pageHead('zap', 'Automation', 'When something happens in the hub, post about it: written from a template or by Ollama, posted automatically or held for you to approve. New releases can also be pushed to itch.io and the Chrome Web Store (set that up in their tabs).', `<button type="button" class="hbtn primary sm" data-saverules>${I('save')}Save automation</button>`)}
    ${C.events.map(ev => { const r = C.rules[ev.id] || {}; const plats = (r.platforms || []).filter(p => POSTERS.includes(p)); const pv = extra.preview?.[ev.id];
      const tplTab = extra.tplTab?.[ev.id] || 'all';
      return `<div class="card cx-rule${r.enabled ? ' on' : ''}" data-rule="${ev.id}"><div class="row"><label class="switch"><input type="checkbox" data-r="enabled"${r.enabled ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl"><b>${esc(ev.label)}</b></span></label><span class="sp"></span>${r.enabled ? `<span class="dc-pill${r.mode === 'auto' ? ' ok' : ''}">${r.mode === 'auto' ? 'Posts automatically' : 'Held for review'}</span>${r.ai ? `<span class="dc-pill violet">${I('sparkle')}Ollama</span>` : ''}` : ''}<code class="muted small">${esc(ev.id)}</code></div>
      ${r.enabled ? `<div class="row cx-wrap">${POSTERS.map(p => { const d = def(p); return `<button type="button" class="cx-chip${plats.includes(p) ? ' on' : ''}${d?.status?.ok ? '' : ' dis'}" data-rplat="${p}">${I(d?.icon || 'plug')}${esc(d?.name || p)}</button>`; }).join('')}</div>
        <div class="f3">${sel('mode', r.mode || 'review', [['review', 'Hold for my review'], ['auto', 'Post automatically']], 'Posting', 'data-r')}${txt('delayMin', r.delayMin, 'Delay (minutes)', '0', 'data-r')}${sel('ai', r.ai ? '1' : '', [['', 'Template'], ['1', `Ollama writes it${aiOn() ? '' : ' (not running)'}`]], 'Writer', 'data-r')}</div>
        ${appEv(ev.id) ? `<div class="f2">${sel('link', r.link || 'page', [['page', 'The app’s page on my site'], ['primary', 'The app’s own link (its main button)'], ['home', 'My home page']], 'Link to', 'data-r')}<div class="fld"><span>Picture</span>${chk('image', r.image !== false, 'Attach the app’s cover', 'data-r')}</div></div>
          <div class="fld"><span>Only for these apps <small>${(r.apps || []).length ? '' : '(none picked: every app)'}</small></span><div class="row cx-wrap">${C.apps.map(a => `<button type="button" class="cx-chip sm${(r.apps || []).includes(a.id) ? ' on' : ''}" data-rapp="${esc(a.id)}">${esc(a.name)}</button>`).join('')}</div></div>` : ''}
        ${r.ai ? `<div class="f2">${sel('tone', r.tone || 'friendly', TONES.map(t => [t, t[0].toUpperCase() + t.slice(1)]), 'Tone', 'data-r')}${txt('prompt', r.prompt, 'Extra instructions', 'e.g. mention it’s on sale', 'data-r')}</div><p class="muted small">${I('info')} If Ollama isn’t running when the event happens, the template is used instead.</p>` : ''}
        <div class="fld"><span>${r.ai ? 'Fallback template' : 'Template'} <small>{name} {tagline} {version} {notes} {url} {title} {text} {amount} {brand}</small></span>
          ${plats.length > 1 ? `<div class="seg cx-tpltabs">${[['all', 'All platforms'], ...plats.map(p => [p, nameOf(p)])].map(([k, l]) => `<button type="button" data-tpltab="${ev.id}:${k}" class="${tplTab === k ? 'on' : ''}">${esc(l)}${k !== 'all' && r.templates?.[k] ? ' •' : ''}</button>`).join('')}</div>` : ''}
          ${tplTab === 'all' || !plats.includes(tplTab) ? `<textarea data-r="template" rows="3">${esc(r.template || C.defaults.templates[ev.id] || '')}</textarea>` : `<textarea data-rtpl="${tplTab}" rows="3" placeholder="Empty: use the template for all platforms">${esc(r.templates?.[tplTab] || '')}</textarea>`}</div>
        <div class="row cx-wrap">${appEv(ev.id) ? sel('pvApp', extra.pvApp?.[ev.id] || C.apps[0]?.id || '', C.apps.map(a => [a.id, a.name]), 'Preview with', 'data-pvapp') : ''}<button type="button" class="hbtn ghost sm" data-preview="${ev.id}:tpl">${I('eye')}Preview</button>${r.ai && aiOn() ? `<button type="button" class="hbtn ghost sm" data-preview="${ev.id}:ai">${busy === 'pv-' + ev.id ? '<span class="spinner sm"></span>Writing…' : `${I('sparkle')}Preview with Ollama`}</button>` : ''}</div>
        ${pv ? `<div class="cx-pvlist">${pv.aiError ? `<p class="note lock"><span>${I('alert')}</span>Ollama failed, so the template was used: ${esc(pv.aiError)}</p>` : ''}${pv.matches === false ? `<p class="note"><span>${I('info')}</span>This app isn’t in the rule’s app list, so the event would be skipped.</p>` : ''}${pv.posts.map(p => `<div class="cx-pvi"><div class="row"><span class="cx-ni b-${p.platform}">${I(def(p.platform)?.icon || 'plug')}</span><b>${esc(nameOf(p.platform))}</b>${p.ai ? `<span class="dc-pill violet">AI</span>` : ''}</div>${p.title && p.platform === 'devto' ? `<b>${esc(p.title)}</b>` : ''}<p>${linkify(p.text)}</p></div>`).join('') || '<p class="muted small">Pick a platform above.</p>'}</div>` : ''}` : ''}</div>`; }).join('')}
    <div class="row"><button type="button" class="hbtn primary" data-saverules>${I('save')}Save automation</button></div>`;
}

// ---------- queue ----------
function queue() {
  const Q = C.queue, groups = [['review', 'Waiting for your review', 'eye'], ['scheduled', 'Scheduled', 'calendar'], ['approved', 'Sending', 'send'], ['posting', 'Sending', 'send'], ['retry', 'Retrying', 'refresh'], ['failed', 'Failed', 'alert']];
  const localDT = iso => { if (!iso) return ''; const d = new Date(iso); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
  const item = p => { const d = def(p.platform); const editing = p.status === 'review' || p.status === 'failed' || p.status === 'scheduled';
    return `<div class="cx-q ${p.status}" data-q="${p.id}"><div class="row"><span class="cx-ni b-${p.platform}">${I(d?.icon || 'plug')}</span><b>${esc(d?.name || p.platform)}</b>${p.ai ? `<span class="dc-pill violet">${I('sparkle')}AI</span>` : ''}<small class="muted">${esc(p.source?.app?.name || p.source?.video?.title || (p.source?.event === 'manual' ? 'Composed' : C.events.find(e => e.id === p.source?.event)?.label || p.source?.event || ''))}${p.status === 'retry' && p.at ? ` · next try ${esc(new Date(p.at).toLocaleTimeString([], { timeStyle: 'short' }))}` : ''}</small><span class="sp"></span><small class="muted">${esc(rel(p.createdAt))}</small></div>
      ${p.title && p.platform === 'devto' ? (editing ? `<input data-qf="title" value="${esc(p.title)}" class="cx-in cx-title">` : `<b>${esc(p.title)}</b>`) : ''}
      ${editing ? `<textarea class="cx-in" data-qf="text" rows="${p.platform === 'devto' ? 8 : 4}">${esc(p.text)}</textarea>` : `<p class="cx-qt">${linkify(p.text)}</p>`}
      ${p.error ? `<p class="note lock"><span>${I('alert')}</span>${esc(p.error)}</p>` : ''}
      <div class="row cx-wrap">${p.status === 'review' ? `<button type="button" class="hbtn primary sm" data-qa="approve">${I('check')}Approve &amp; post</button>` : ''}${p.status === 'scheduled' ? `<button type="button" class="hbtn primary sm" data-qa="now">${I('send')}Post now</button>` : ''}${p.status === 'failed' ? `<button type="button" class="hbtn primary sm" data-qa="retry">${I('refresh')}Try again</button>` : ''}${editing ? `<button type="button" class="hbtn ghost sm" data-qa="save">${I('save')}Save edits</button><label class="cx-when">${I('calendar')}<input type="datetime-local" data-qf="at" value="${esc(localDT(p.at))}"></label><button type="button" class="hbtn ghost sm" data-qa="schedule">Schedule</button>` : ''}${p.status === 'scheduled' ? `<button type="button" class="hbtn ghost sm" data-qa="hold">Back to review</button>` : ''}<span class="sp"></span>${p.status === 'review' ? `<button type="button" class="hbtn ghost sm" data-qa="reject">Reject</button>` : ''}<button type="button" class="act" data-qa="delete" title="Delete">${I('trash')}</button></div></div>`; };
  const live = groups.map(([st, label, icon]) => { const list = Q.filter(p => p.status === st); return list.length ? `<div class="card"><h3>${I(icon)}${esc(label)} <small class="muted">${list.length}</small></h3>${list.map(item).join('')}</div>` : ''; }).join('');
  const rejected = Q.filter(p => p.status === 'rejected'), hf = extra.hfilter || 'all';
  const hist = C.history.filter(p => hf === 'all' || p.platform === hf);
  const counts = POSTERS.map(p => [p, C.history.filter(h => h.platform === p).length]).filter(([, n]) => n);
  return `${pageHead('list', 'Queue & history', 'Everything waiting, scheduled or sent. Edit anything before it goes out.', `<button type="button" class="hbtn primary sm" data-go="compose">${I('sparkle')}Compose a post</button>`)}
    ${live || `<div class="card"><div class="emptystate">${I('check')}<h4>Nothing waiting</h4><p>New posts from Compose and Automation appear here.</p></div></div>`}
    <div class="card"><div class="card-head"><h3>${I('list')}Posted <small class="muted">${C.history.length}</small></h3>${counts.length > 1 ? `<div class="seg">${[['all', 'All'], ...counts.map(([p, n]) => [p, `${nameOf(p)} ${n}`])].map(([k, l]) => `<button type="button" data-hf="${k}" class="${hf === k ? 'on' : ''}">${esc(l)}</button>`).join('')}</div>` : ''}</div>
      ${hist.length ? `<div class="cx-hist">${hist.map(p => { const d = def(p.platform); return `<div class="cx-hi"><span class="cx-ni b-${p.platform}">${I(d?.icon || 'plug')}</span><span class="muted small">${esc(rel(p.postedAt || p.createdAt))}</span><span class="cx-ht">${esc(p.title && p.platform === 'devto' ? p.title : p.text.split('\n')[0])}${p.result?.draft ? ' <em class="dc-pill">draft</em>' : ''}</span><button type="button" class="act" data-reuse="${p.id}" title="Use again in Compose">${I('copy')}</button>${p.result?.url ? `<a href="${esc(p.result.url)}" target="_blank" rel="noopener" class="hbtn ghost sm">${I('external')}Open</a>` : ''}</div>`; }).join('')}</div>` : '<p class="muted">Nothing posted yet.</p>'}
    ${rejected.length ? `<p class="muted small">${rejected.length} rejected draft(s) kept for reference.</p>` : ''}</div>`;
}

// ---------- website feed ----------
function feedPage() {
  const F = C.feed;
  const rows = F.feedable.map(id => { const d = def(id), s = d.settings || {}, f = s.feed || {}, prof = F.profiles.find(p => p.platform === id);
    return `<div class="cx-frow${stateOf(d) === 'on' ? '' : ' off'}" data-frow="${id}"><span class="cx-logo b-${id}">${I(d.icon)}</span><div class="cx-fname"><b>${esc(d.name)}</b><small>${stateOf(d) === 'on' ? esc(d.status.account || '') : 'Not connected'}${prof ? ` · Follow link on` : ''}</small></div>
      ${chk('feed.enabled', f.enabled, 'Posts', 'data-web')}${chk('profile', s.profile !== false, 'Follow link', 'data-web')}
      <label class="cx-fcount">${I('list')}<select data-web="feed.count">${[1, 2, 3, 4, 6, 9, 12].map(n => `<option value="${n}"${(f.count || 3) == n ? ' selected' : ''}>${n}</option>`).join('')}</select></label>
      <button type="button" class="act" data-go="${id}" title="More options">${I('sliders')}</button></div>`; }).join('');
  const items = F.items;
  return `${pageHead('megaphone', 'Website feed', 'Show your latest posts from X, Mastodon, DEV, Telegram and LinkedIn in a “Latest posts” section on your home page, with Follow buttons for each account.', `<button type="button" class="hbtn ghost sm" data-feedrefresh>${I('refresh')}Refresh now</button>`)}
    <div class="st-grid"><div class="st-main">
      <div class="card"><div class="card-head"><h3>${I('globe')}Sources</h3><button type="button" class="hbtn primary sm" data-savefeed>${I('save')}Save</button></div>
        <p class="sub">Mastodon and DEV include posts you made anywhere; the others show what the hub posted. Each platform keeps its own count.</p>
        <div class="cx-frows">${rows}</div></div>
      <div class="card"><div class="card-head"><h3>${I('eye')}Preview <small class="muted">${items.length} post${items.length === 1 ? '' : 's'}</small></h3>${F.updatedAt ? `<small class="muted">updated ${esc(rel(F.updatedAt))}</small>` : ''}</div>
        ${items.length ? `<div class="cx-feed">${items.map(i => { const d = def(i.platform); return `<a class="cx-fcard" href="${esc(i.url)}" target="_blank" rel="noopener"><div class="row"><span class="cx-ni b-${i.platform}">${I(d?.icon || 'globe')}</span><b>${esc(d?.name || i.platform)}</b><span class="sp"></span><small class="muted">${esc(i.date ? new Date(i.date).toLocaleDateString() : '')}</small></div>${i.image ? `<img src="${esc(/^https?:/.test(i.image) ? i.image : '/media/' + i.image.replace(/^assets\/apps\//, ''))}" alt="">` : ''}${i.title ? `<h4>${esc(i.title)}</h4>` : ''}<p>${esc(i.text)}</p></a>`; }).join('')}</div>` : `<div class="emptystate">${I('megaphone')}<h4>No posts to show yet</h4><p>Switch on Posts for a connected platform, then post something (or press Refresh now for Mastodon and DEV).</p></div>`}</div>
    </div><div class="st-side">
      <div class="card"><h3>${I('layers')}On the home page</h3>
        <div class="cx-sw">${chk('section', F.sectionOn, 'Show the “Latest posts” section', 'data-fset')}${chk('autoPublish', F.autoPublish, 'Publish the site by itself when new posts appear', 'data-fset')}</div>
        ${sel('max', F.max || 6, [3, 6, 9, 12].map(n => [n, `${n} posts`]), 'Most posts shown', 'data-fset')}
        <div class="row"><button type="button" class="hbtn primary sm" data-savefeedset>${I('save')}Save</button><a class="hbtn ghost sm" href="#/site/sections">${I('edit')}Heading &amp; order</a></div>
        <p class="muted small">${I('info')} Auto-publish only runs when the feed is the only unpublished change, like YouTube videos.</p></div>
      <div class="card"><h3>${I('users')}Follow links</h3>${F.profiles.length ? `<div class="cx-list">${F.profiles.map(p => `<div class="cx-li"><span class="cx-ni b-${p.platform}">${I(def(p.platform)?.icon || 'globe')}</span><span>${esc(p.handle || p.platform)}</span><span class="sp"></span><a class="act" href="${esc(p.url)}" target="_blank" rel="noopener">${I('external')}</a></div>`).join('')}</div><p class="muted small">Added to your site’s social links (footer, Support, and the hero if it shows socials), next to the ones in Site settings.</p>` : '<p class="sub">Connect a social account to add its Follow link.</p>'}</div>
    </div></div>`;
}

// ============================================================ extra data per tab
async function loadExtra() {
  try {
    if (tab === 'itch' && stateOf(def('itch')) === 'on' && !extra.itch) { extra.itch = await api('GET', '/api/connectors/itch/games').catch(e => ({ error: e.message, games: [] })); render(); }
    if (tab === 'devto' && stateOf(def('devto')) === 'on' && !extra.devto) { extra.devto = (await api('GET', '/api/connectors/devto/articles').catch(e => ({ articles: { error: e.message } }))).articles; render(); }
    if (tab === 'mastodon' && stateOf(def('mastodon')) === 'on' && !extra.mastodon) { extra.mastodon = await api('GET', '/api/connectors/mastodon/recent').catch(e => ({ error: e.message, items: [] })); render(); }
    if (tab === 'ollama' && !extra.ollama) { extra.ollama = await api('GET', '/api/connectors/ollama/models').catch(e => ({ error: e.message, models: [] })); render(); }
    if (tab === 'cws' && stateOf(def('cws')) === 'on' && !extra.cws && (def('cws').settings?.items || []).length) { extra.cws = (await api('GET', '/api/connectors/cws/items').catch(() => ({ items: [] }))).items; render(); }
    if (tab === 'compose') loadFacts();
  } catch {}
}
// "What Ollama knows" for the current subject of the composer
async function loadFacts(force) {
  const q = draft.source === 'app' ? `appId=${encodeURIComponent(draft.appId)}&link=${encodeURIComponent(draft.link === 'custom' ? draft.customLink : draft.link)}` : draft.source === 'video' ? `videoId=${encodeURIComponent(draft.videoId)}` : `text=${encodeURIComponent(draft.brief || 'topic')}${draft.customLink ? `&link=${encodeURIComponent(draft.customLink)}` : ''}`;
  if (!force && draft.factsKey === q && draft.facts != null) return;
  draft.factsKey = q; draft.facts = null;
  const r = await api('GET', `/api/connectors/context?${q}`).catch(() => ({ facts: '' }));
  if (draft.factsKey !== q) return;
  draft.facts = draft.source === 'topic' ? '' : r.facts;
  const box = $('#cxPanel .cx-know');
  if (box && tab === 'compose') box.querySelector('p.muted, pre')?.replaceWith(Object.assign(document.createElement('pre'), { className: 'cx-facts', textContent: draft.facts || 'Only your topic, your studio and your app names.' }));
}

// ============================================================ events
const collect = (root, attr) => { const o = {}; root.querySelectorAll(`[${attr}]`).forEach(el => { const k = el.getAttribute(attr); o[k] = el.type === 'checkbox' ? el.checked : el.type === 'number' || el.type === 'range' ? +el.value : el.value; }); return o; };
// "feed.enabled" style keys → nested objects
const nest = flat => { const o = {}; for (const [k, v] of Object.entries(flat)) { const ks = k.split('.'); let x = o; for (const p of ks.slice(0, -1)) x = x[p] ||= {}; x[ks.at(-1)] = v; } return o; };
async function saveService(id, patch) {
  const r = await api('PUT', `/api/connectors/${id}`, patch);
  const d = def(id); if (d.kind !== 'core') d.status = r.status; d.settings = r.settings;
  navRender(); render();
  return r;
}
const draftLink = () => draft.source === 'app' ? (draft.link === 'custom' ? draft.customLink : draft.link) : draft.customLink;
const draftBody = () => ({ platforms: draft.platforms, brief: draft.brief, tone: draft.tone, extra: draft.extra, event: draft.source === 'app' ? draft.event : draft.source === 'video' ? 'yt.video' : 'manual', appId: draft.source === 'app' ? draft.appId : '', videoId: draft.source === 'video' ? draft.videoId : '', text: draft.source === 'topic' ? draft.brief : '', link: draftLink() });
async function refreshSite() { try { const st = await api('GET', '/api/state'); if (!siteDirty()) { S.site = st.site; S.siteDraft = clone(st.site); emit('site'); } } catch {} }
async function onClick(e) {
  const b = e.target.closest('button, [data-go]'); if (!b) return;
  const P = $('#cxPanel');
  try {
    if (b.dataset.go) { location.hash = '#/connectors/' + b.dataset.go; return; }
    if (b.dataset.recheck != null) { toast('Checking every connection…', 'info'); await load(true); return; }
    if (b.dataset.copy) { await navigator.clipboard.writeText(b.dataset.copy); toast('Copied'); return; }
    if (b.dataset.test) { b.disabled = true; const r = await api('POST', `/api/connectors/${b.dataset.test}/test`); def(b.dataset.test).status = r.status; navRender(); render(); toast(r.status.ok ? `Connected: ${r.status.account}` : (r.status.error || 'Not connected'), r.status.ok ? 'ok' : 'err', 6000); return; }
    if (b.dataset.forget) { if (!(await confirmBox(`Disconnect ${def(b.dataset.forget).name}?`, 'Its keys and settings are removed from this computer. Queued posts for it will fail.', 'Disconnect'))) return; C = await api('DELETE', `/api/connectors/${b.dataset.forget}`); navRender(); render(); return; }
    if (b.dataset.oauth) {
      const r = await api('POST', `/api/connectors/${b.dataset.oauth}/connect`); window.open(r.url, '_blank', 'noopener');
      if (!r.pin) { toast('Finish signing in in the new tab, then press Test here.', 'info', 8000); return; }
      const pin = prompt('Authorise the app in the new tab. X then shows a PIN: type it here.');
      if (!pin) return;
      const v = await api('POST', `/api/connectors/x/pin`, { pin });
      toast(v.status?.ok ? `X is connected${v.status.account ? ` as ${v.status.account}` : ''}` : (v.status?.error || 'X sign-in failed'), v.status?.ok ? 'ok' : 'err', 8000); load(true); return;
    }
    if (b.dataset.savedefs) { const id = b.dataset.savedefs, card = P.querySelector(`[data-defs="${id}"]`); const defaults = { ...(def(id).settings?.defaults || {}), ...collect(card, 'data-def') }; if ('asOrg' in defaults) defaults.asOrg = !!defaults.asOrg; const settings = { ...(def(id).settings || {}), defaults, ...collect(card, 'data-setting') }; await saveService(id, { settings }); toast('Saved'); return; }
    if (b.dataset.saveweb) { const id = b.dataset.saveweb, card = b.closest('[data-defs]'); const w = nest(collect(card, 'data-web')); if (w.feed) w.feed = { ...(def(id).settings?.feed || {}), ...w.feed, count: +w.feed.count || 3 }; await saveService(id, { settings: { ...(def(id).settings || {}), ...w } }); await load(false, true); toast('Saved. The website feed is updated; publish to put it live.', 'ok', 6000); return; }
    if (b.dataset.savefeed != null) {
      for (const row of P.querySelectorAll('[data-frow]')) { const id = row.dataset.frow, w = nest(collect(row, 'data-web')), s = def(id).settings || {}; w.feed = { ...(s.feed || {}), ...w.feed, count: +w.feed.count || 3 };
        if (JSON.stringify({ feed: s.feed || {}, profile: s.profile !== false }) !== JSON.stringify({ feed: w.feed, profile: w.profile })) await api('PUT', `/api/connectors/${id}`, { settings: { ...s, ...w } }); }
      await load(); toast('Feed saved'); return;
    }
    if (b.dataset.savefeedset != null) { const o = collect(P.querySelector('.st-side'), 'data-fset'); C = await api('PUT', '/api/connectors/feed', { section: o.section, autoPublish: o.autoPublish, max: +o.max }); await refreshSite(); navRender(); render(); toast('Saved'); return; }
    if (b.dataset.feedrefresh != null) { b.disabled = true; const r = await api('POST', '/api/connectors/feed/refresh'); C = r; navRender(); render(); const errs = Object.entries(r.errors || {}); toast(errs.length ? `Updated, but ${errs.map(([k, v]) => `${nameOf(k)}: ${v}`).join('; ')}` : `${r.items.length} post${r.items.length === 1 ? '' : 's'} in the feed${r.changed ? ' (changed: publish to put it live)' : ''}`, errs.length ? 'err' : 'ok', 7000); return; }
    if (b.dataset.saveollama != null) {
      const s = { ...(def('ollama').settings || {}) };
      for (const card of P.querySelectorAll('[data-defs^="ollama"]')) Object.assign(s, collect(card, 'data-oset'));
      P.querySelectorAll('[data-oseg]').forEach(g => { const on = g.querySelector('.on'); if (on) s[g.dataset.oseg] = on.dataset.osegv; });
      s.platformNotes = Object.fromEntries([...P.querySelectorAll('[data-pnote]')].map(el => [el.dataset.pnote, el.value.trim()]).filter(([, v]) => v));
      s.appNotes = { ...(s.appNotes || {}), ...Object.fromEntries([...P.querySelectorAll('[data-anote]')].map(el => [el.dataset.anote, el.value.trim()])) };
      for (const k of Object.keys(s.appNotes)) if (!s.appNotes[k]) delete s.appNotes[k];
      s.numCtx = +s.numCtx || 8192;
      await saveService('ollama', { settings: s }); extra.octx = {}; toast('Writer settings saved'); return;
    }
    if (b.dataset.osegv) { b.parentElement.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); return; }
    if (b.dataset.actx) { const id = b.dataset.actx; extra.octx ||= {}; if (extra.octx[id]) delete extra.octx[id]; else extra.octx[id] = (await api('GET', `/api/connectors/context?appId=${encodeURIComponent(id)}`)).facts; render(); return; }
    if (b.dataset.findchats != null) { b.disabled = true; extra.telegram = (await api('GET', '/api/connectors/telegram/chats')).chats; render(); return; }
    if (b.dataset.addchat) { const d = def('telegram'); const cur = String(d.values.chats || '').split(/[,\s]+/).filter(Boolean); if (!cur.includes(b.dataset.addchat)) cur.push(b.dataset.addchat); await saveService('telegram', { values: { chats: cur.join(', ') } }); d.values.chats = cur.join(', '); render(); toast('Chat added'); return; }
    if (b.dataset.addmap) { const id = b.dataset.addmap, d = def(id), key = id === 'itch' ? 'maps' : 'items'; const list = [...(d.settings?.[key] || []), id === 'itch' ? { appId: '', target: '', channel: 'windows', pattern: '', auto: false } : { appId: '', itemId: '', pattern: '.zip', auto: false, publish: false, staged: false }]; d.settings = { ...(d.settings || {}), [key]: list }; render(); return; }
    if (b.dataset.delmap) { const id = b.dataset.mapof2, d = def(id), key = id === 'itch' ? 'maps' : 'items'; const list = [...(d.settings?.[key] || [])]; list.splice(+b.dataset.delmap, 1); await saveService(id, { settings: { ...(d.settings || {}), [key]: list } }); return; }
    if (b.dataset.savemaps) { const id = b.dataset.savemaps, key = id === 'itch' ? 'maps' : 'items'; const list = [...P.querySelectorAll(`[data-mapof="${id}"]`)].map(el => { const o = collect(el, 'data-map'); if ('percent' in o) o.percent = +o.percent || undefined; return o; }).filter(m => m.appId); await saveService(id, { settings: { ...(def(id).settings || {}), [key]: list } }); extra.cws = null; loadExtra(); toast('Mappings saved'); return; }
    if (b.dataset.pushnow) { b.disabled = true; toast('Downloading the release and pushing with butler…', 'info', 8000); const r = await api('POST', '/api/connectors/itch/push', { appId: b.dataset.pushnow }); toast(r.done.length ? `Pushed: ${r.done.join(', ')}` : 'Nothing was pushed', r.done.length ? 'ok' : 'err', 8000); b.disabled = false; return; }
    if (b.dataset.cwsdeploy) { b.disabled = true; toast('Uploading the latest release…', 'info', 8000); const r = await api('POST', '/api/connectors/cws/deploy', { appId: b.dataset.cwsdeploy }); toast(r.done.length ? `Uploaded: ${r.done.join(', ')}` : 'Nothing was uploaded', r.done.length ? 'ok' : 'err', 8000); extra.cws = null; loadExtra(); b.disabled = false; return; }
    if (b.dataset.cwspub) { const m = (def('cws').settings?.items || []).find(x => x.itemId === b.dataset.cwspub); if (!(await confirmBox('Submit the uploaded package for review?', `${m?.staged ? 'When Google approves it, it waits for you to publish it.' : 'It goes live as soon as Google approves it.'}${m?.percent ? ` Rollout: ${m.percent}%.` : ''}`, 'Submit', false))) return; const r = await api('POST', '/api/connectors/cws/publish', { itemId: b.dataset.cwspub, staged: m?.staged, percent: m?.percent, skipReview: m?.skipReview, blockOnWarnings: m?.blockOnWarnings }); toast(`Submitted: ${r.publish.status}${r.publish.warnings.length ? ` · ${r.publish.warnings.join('; ')}` : ''}`, 'ok', 9000); extra.cws = null; loadExtra(); return; }
    if (b.dataset.cwscancel) { if (!(await confirmBox('Cancel the submission?', 'The version in review is withdrawn. The live version stays as it is.', 'Cancel submission'))) return; await api('POST', '/api/connectors/cws/cancel', { itemId: b.dataset.cwscancel }); toast('Submission cancelled'); extra.cws = null; loadExtra(); return; }
    if (b.dataset.cwsroll) { const pct = prompt('Raise the rollout to what percent? (must be higher than now; only for extensions with over 10,000 weekly users)', '50'); if (!pct) return; await api('POST', '/api/connectors/cws/rollout', { itemId: b.dataset.cwsroll, percent: +pct }); toast(`Rollout raised to ${+pct}%`); extra.cws = null; loadExtra(); return; }
    // compose
    if (b.dataset.src) { draft.source = b.dataset.src; render(); loadFacts(); return; }
    if (b.dataset.plat) { const p = b.dataset.plat; if (b.classList.contains('dis')) return toast(`Connect ${nameOf(p)} first`, 'err'); draft.platforms = draft.platforms.includes(p) ? draft.platforms.filter(x => x !== p) : [...draft.platforms, p]; render(); return; }
    if (b.dataset.when) { draft.when = b.dataset.when; render(); return; }
    if (b.dataset.draft) {
      if (!draft.platforms.length) return toast('Pick at least one platform.', 'err');
      if (draft.source === 'app' && !draft.appId) return toast('Choose the app.', 'err');
      if (draft.source === 'video' && !draft.videoId) return toast('Choose the video.', 'err');
      if (draft.source === 'topic' && !draft.brief.trim()) return toast('Write a topic first.', 'err');
      busy = 'draft'; render();
      try {
        const r = await api('POST', '/api/connectors/draft', { ai: b.dataset.draft === 'ai', ...draftBody() });
        for (const [p, v] of Object.entries(r.drafts)) draft.posts[p] = { ...v, ai: b.dataset.draft === 'ai', link: v.link || r.link };
      } finally { busy = ''; render(); }
      return;
    }
    if (b.dataset.regen || b.dataset.rw) {
      const [p, how] = (b.dataset.rw || b.dataset.regen).split(':'), post = draft.posts[p];
      busy = 'rw-' + p; render();
      try {
        if (b.dataset.regen) { const r = await api('POST', '/api/connectors/draft', { ai: true, ...draftBody(), platforms: [p] }); draft.posts[p] = { ...r.drafts[p], ai: true, link: r.drafts[p].link || r.link, options: post.options }; }
        else { const r = await api('POST', '/api/connectors/rewrite', { platform: p, text: post.text, title: post.title, how, link: post.link, tone: draft.tone, appId: draft.source === 'app' ? draft.appId : '', videoId: draft.source === 'video' ? draft.videoId : '', event: draftBody().event }); draft.posts[p] = { ...post, ...r.draft, link: post.link, ai: true }; }
      } finally { busy = ''; render(); }
      return;
    }
    if (b.dataset.dcopy) { await navigator.clipboard.writeText(draft.posts[b.dataset.dcopy]?.text || ''); toast('Copied'); return; }
    if (b.dataset.ddel) { delete draft.posts[b.dataset.ddel]; render(); return; }
    if (b.dataset.send != null) {
      const plats = draft.platforms.filter(p => draft.posts[p]);
      if (draft.when === 'later' && !draft.at) return toast('Choose when to post.', 'err');
      const app = draft.source === 'app' ? C.apps.find(a => a.id === draft.appId) : null;
      const posts = plats.map(p => { const post = draft.posts[p]; return { platform: p, text: post.text, title: post.title, link: post.link || '', image: app && draft.image ? app.cover || app.iconImage : undefined, ai: post.ai,
        options: { ...(def(p).settings?.defaults || {}), ...(post.options || {}), ...(app && !draft.image ? { image: false, photo: false, cover: false } : {}) }, source: { event: draftBody().event, app: app ? { id: app.id, name: app.name, cover: app.cover, tagline: app.tagline } : undefined } }; });
      if (draft.when === 'now' && !(await confirmBox(`Post to ${plats.map(nameOf).join(', ')} now?`, 'They go out one by one in the next minute. You can follow them in Queue & history.', 'Post now', false))) return;
      C = await api('POST', '/api/connectors/queue', { posts, when: draft.when, at: draft.at });
      toast(draft.when === 'now' ? `Posting to ${posts.length} platform(s)…` : draft.when === 'later' ? 'Scheduled' : 'Added to the queue for review');
      draft.posts = {}; location.hash = '#/connectors/queue'; return;
    }
    // automation
    if (b.dataset.rplat) { syncRules(); const ev = b.closest('[data-rule]').dataset.rule, r = { ...(C.rules[ev] || {}) }; const p = b.dataset.rplat; if (b.classList.contains('dis')) return toast(`Connect ${nameOf(p)} first`, 'err'); r.platforms = (r.platforms || []).includes(p) ? r.platforms.filter(x => x !== p) : [...(r.platforms || []), p]; C.rules[ev] = r; render(); return; }
    if (b.dataset.rapp) { syncRules(); const ev = b.closest('[data-rule]').dataset.rule, r = { ...(C.rules[ev] || {}) }; const a = b.dataset.rapp; r.apps = (r.apps || []).includes(a) ? r.apps.filter(x => x !== a) : [...(r.apps || []), a]; C.rules[ev] = r; render(); return; }
    if (b.dataset.tpltab) { syncRules(); const [ev, k] = b.dataset.tpltab.split(':'); extra.tplTab = { ...(extra.tplTab || {}), [ev]: k }; render(); return; }
    if (b.dataset.preview) {
      syncRules(); const [ev, mode] = b.dataset.preview.split(':'); const r = C.rules[ev] || {};
      if (mode === 'ai') { busy = 'pv-' + ev; render(); }
      try {
        const appId = ev.startsWith('app.') ? (extra.pvApp?.[ev] || C.apps[0]?.id) : '';
        const vid = ev.startsWith('yt.') ? (S.site?.youtube?.videos || []).find(v => !!v.short === (ev === 'yt.short'))?.id : '';
        extra.preview = { ...(extra.preview || {}), [ev]: await api('POST', '/api/connectors/rules/preview', { event: ev, rule: r, ai: mode === 'ai', appId, videoId: vid || '', text: ev === 'site.announcement' ? (S.site?.announcement?.text || 'Example announcement') : ev === 'sale.milestone' ? '' : undefined }) };
      } finally { busy = ''; render(); }
      return;
    }
    if (b.dataset.saverules != null) { syncRules(); C.rules = (await api('PUT', '/api/connectors/rules', { rules: C.rules })).rules; toast('Automation saved'); render(); return; }
    // queue
    if (b.dataset.hf) { extra.hfilter = b.dataset.hf; render(); return; }
    if (b.dataset.reuse) { const p = C.history.find(x => x.id === b.dataset.reuse); if (!p) return; draft.platforms = [...new Set([...draft.platforms, p.platform])]; draft.posts[p.platform] = { text: p.text, title: p.title, link: p.link, options: p.options }; if (p.source?.app?.id) { draft.source = 'app'; draft.appId = p.source.app.id; } location.hash = '#/connectors/compose'; toast('Copied into Compose'); return; }
    if (b.dataset.qa) {
      const el = b.closest('[data-q]'), id = el.dataset.q, a = b.dataset.qa;
      if (a === 'delete') { if (!(await confirmBox('Delete this post?', 'It’s removed from the queue (already-posted posts stay on the platform).', 'Delete'))) return; C = await api('DELETE', `/api/connectors/queue/${id}`); render(); navRender(); return; }
      const atv = el.querySelector('[data-qf="at"]')?.value;
      if (a === 'schedule' && !atv) return toast('Pick a date and time first.', 'err');
      const patch = { text: el.querySelector('[data-qf="text"]')?.value, title: el.querySelector('[data-qf="title"]')?.value, ...(atv !== undefined ? { at: atv ? new Date(atv).toISOString() : '' } : {}) };
      if (a !== 'save') patch.action = a;
      C = await api('PUT', `/api/connectors/queue/${id}`, Object.fromEntries(Object.entries(patch).filter(([, v]) => v !== undefined)));
      toast({ approve: 'Approved: posting now', now: 'Posting now', retry: 'Trying again', reject: 'Rejected', schedule: 'Scheduled', hold: 'Back in review' }[a] || 'Saved'); render(); navRender(); return;
    }
  } catch (x) { toast(x.message, 'err', 9000); busy = ''; render(); }
}
function syncRules() {
  $$('#cxPanel [data-rule]').forEach(card => {
    const ev = card.dataset.rule, r = { ...(C.rules[ev] || {}) };
    card.querySelectorAll('[data-r]').forEach(el => { const k = el.dataset.r; r[k] = el.type === 'checkbox' ? el.checked : k === 'ai' ? !!el.value : k === 'delayMin' ? (+el.value || 0) : el.value; });
    card.querySelectorAll('[data-rtpl]').forEach(el => { r.templates = { ...(r.templates || {}) }; if (el.value.trim()) r.templates[el.dataset.rtpl] = el.value; else delete r.templates[el.dataset.rtpl]; });
    C.rules[ev] = r;
  });
}
function onChange(e) {
  const t = e.target;
  if (t.dataset.r === 'enabled' || t.dataset.r === 'ai') { syncRules(); render(); return; }
  if (t.dataset.pvapp) { const ev = t.closest('[data-rule]').dataset.rule; extra.pvApp = { ...(extra.pvApp || {}), [ev]: t.value }; return; }
  if (t.dataset.dr) {
    draft[t.dataset.dr] = t.type === 'checkbox' ? t.checked : t.value;
    if (['appId', 'event', 'link', 'videoId', 'image'].includes(t.dataset.dr)) {
      if (t.dataset.dr === 'appId') { const a = C.apps.find(x => x.id === t.value); if (draft.link === 'primary' && !a?.primaryUrl) draft.link = 'page'; }
      render(); loadFacts();
    }
  }
  if (t.dataset.cwszip) uploadZip(t);
}
function onInput(e) {
  const t = e.target;
  if (t.dataset.dr && t.type !== 'checkbox') draft[t.dataset.dr] = t.value;
  if (t.dataset.post) {
    const p = draft.posts[t.dataset.post]; if (t.dataset.pf === 'tags') p.options = { ...(p.options || {}), tags: t.value }; else p[t.dataset.pf] = t.value;
    const card = t.closest('.cx-draft'), c = card?.querySelector('.cx-count');
    if (c && t.dataset.pf === 'text') { const n = t.value.length, lim = LIM[t.dataset.post]; c.textContent = `${n.toLocaleString()}/${lim.toLocaleString()}${n > lim && (t.dataset.post === 'x' || t.dataset.post === 'mastodon') ? ' · thread' : ''}`; c.classList.toggle('over', n > lim); }
    const pv = card?.querySelector('[data-pv]'); if (pv) pv.innerHTML = previewHTML(t.dataset.post, p, draft.source === 'app' ? C.apps.find(a => a.id === draft.appId) : null);
  }
  if (t.dataset.oset === 'temperature') t.closest('label').querySelector('small').textContent = t.value;
}
async function onSubmit(e) {
  e.preventDefault();
  const f = e.target;
  try {
    if (f.dataset.save) { const btn = f.querySelector('[type=submit]'); btn.disabled = true; const values = Object.fromEntries(new FormData(f)); const r = await saveService(f.dataset.save, { values }); toast(r.status.ok ? `Connected: ${r.status.account}` : (r.status.error || 'Saved, but the test failed'), r.status.ok ? 'ok' : 'err', 8000); extra[f.dataset.save] = null; loadExtra(); return; }
    if (f.dataset.otry != null) {
      const brief = f.elements.brief.value.trim(), platform = f.elements.platform.value, appId = f.elements.appId.value;
      if (!brief && !appId) return toast('Write a topic or pick an app.', 'err');
      extra.otry = { brief, platform, appId }; busy = 'otry'; render();
      try { const r = await api('POST', '/api/connectors/draft', { ai: true, platforms: [platform], brief, appId, text: appId ? '' : brief, event: appId ? 'app.updated' : 'manual' }); Object.assign(extra.otry, { text: r.drafts[platform].text, title: platform === 'devto' ? r.drafts[platform].title : '' }); } finally { busy = ''; render(); }
      return;
    }
  } catch (x) { toast(x.message, 'err', 9000); busy = ''; render(); }
}
function uploadZip(input) {
  const file = input.files?.[0]; if (!file) return;
  const m = (def('cws').settings?.items || []).find(x => x.itemId === input.dataset.cwszip);
  const fr = new FileReader();
  fr.onload = async () => {
    try {
      const data = String(fr.result).split(',')[1];
      const publish = await confirmBox('Upload this package?', `Upload ${file.name}${m?.publish ? ' and submit it for review' : ''}. You can also submit it later from here.`, m?.publish ? 'Upload & submit' : 'Upload', false);
      if (!publish && m?.publish) return;
      toast('Uploading to the Chrome Web Store…', 'info', 8000);
      const r = await api('POST', '/api/connectors/cws/upload', { itemId: input.dataset.cwszip, data, publish: !!m?.publish, staged: m?.staged, percent: m?.percent, skipReview: m?.skipReview, blockOnWarnings: m?.blockOnWarnings });
      toast(`Uploaded v${r.upload.version || '?'} (${String(r.upload.state).toLowerCase()})${r.publish ? ` · ${r.publish.status}` : ''}`, 'ok', 9000);
      extra.cws = null; loadExtra();
    } catch (x) { toast(x.message, 'err', 9000); }
  };
  fr.readAsDataURL(file);
}
