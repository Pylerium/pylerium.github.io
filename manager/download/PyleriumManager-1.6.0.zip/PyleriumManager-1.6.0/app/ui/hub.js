// Pylerium Manager: apps view, editor, publishing and the view router.
import { R, S, $, $$, esc, api, hydrate, toast, confirmBox, rel, today, slug, MEDIA, on, emit, clone, refreshStatus, pendingCount, siteDirty, saveSite } from './core.js';
import * as Media from './media.js';
import * as Community from './community.js';
import * as SiteCfg from './sitecfg.js';
import * as Alerts from './alerts.js';
import * as Connectors from './connectors.js';
import * as Promo from './promo.js';
import * as Settings from './settings.js';
Settings.boot(); // theme, size and formats before anything draws
import * as Live from './live.js';
import * as StoreHub from './storehub.js';
import * as MdEdit from './mdedit.js';
import * as Setup from './setup.js';

const F = Object.assign({ cat: 'all', q: '', vis: 'all', status: 'all', sort: 'order', view: 'grid' }, JSON.parse(localStorage.getItem('hub.filters') || '{}'));
F.q = '';
const saveFilters = () => localStorage.setItem('hub.filters', JSON.stringify({ ...F, q: '' }));
const sorted = () => [...S.apps].sort((a, b) => (a.order ?? 1e9) - (b.order ?? 1e9) || a.name.localeCompare(b.name));
const spill = a => `<span class="spill s-${esc(a.status)}"><i></i>${esc(R.statusOf(a.status).short)}</span>`;

// ---------- load ----------
async function load() {
  const st = await api('GET', '/api/state');
  S.apps = st.apps; S.site = st.site; S.config = st.config;
  // Sites made before perks existed: show the Perks section in Site → Sections (the builder already places it after Community).
  if (Array.isArray(S.site.sections) && !S.site.sections.some(x => x.id === 'perks')) { const i = S.site.sections.findIndex(x => x.id === 'community'); S.site.sections.splice(i + 1, 0, { id: 'perks', enabled: true, kicker: 'Perks', title: 'Unlock perks', subtitle: 'Thank-yous for supporters: some come with an app, some you can buy, and some drop by luck.' }); }
  S.siteDraft = clone(S.site);
  R.setCategories(S.site.categories);
  $('#liveLink').href = S.config.siteUrl;
  $$('.siteLink').forEach(a => { a.href = S.config.siteUrl || '#/settings/github'; a.textContent = S.config.siteUrl ? S.config.siteUrl.replace(/^https?:\/\//, '') : 'your site'; });
  $$('.siteHost').forEach(a => { a.textContent = S.config.siteUrl ? S.config.siteUrl.replace(/^https?:\/\//, '') : 'your site'; });
  $('#liveLink').hidden = !S.config.siteUrl;
  Media.init(); Community.init(); SiteCfg.init(); Alerts.init(); Connectors.init(); Promo.init(); Settings.init({ account: sub => Setup.showSettings(sub) }); Live.init(); StoreHub.init(); MdEdit.attach($('#mdEd')); Setup.init();
  Setup.load().catch(() => {});
  if (!S.config.setupDone || !S.config.repo) Setup.open(0); // no site yet: the wizard resumes at the right step
  renderApps(); navBadges();
  route();
  refreshStatus();
  Community.loadInbox(true);
}
on(what => {
  if (what === 'apps' || what === 'site') { renderApps(); navBadges(); }
  if (what === 'status') renderStatus();
  if (what === 'subs' || what === 'site') navBadges();
});
function navBadges() {
  $('#nApps').textContent = S.apps.length;
  const v = (S.site?.youtube?.videos || []).filter(x => !x.hidden).length;
  $('#nVideos').textContent = v || '';
  const pending = (S.subs?.items || []).filter(i => !i.handled && i.state !== 'closed').length;
  $('#nSubs').hidden = !pending; $('#nSubs').textContent = pending;
}

// ---------- router ----------
function route() {
  const [, view = window.HUB_PREFS?.start || 'live', sub, sub2] = location.hash.match(/^#\/(\w+)(?:\/(\w+))?(?:\/(\w+))?/) || [];
  if (view === 'alerts') { location.replace(`#/connectors/discord${sub ? '/' + sub : ''}`); return; } // the Discord tab moved into Connectors
  if (StoreHub.LEGACY[view]) { location.replace(`#/store/${StoreHub.LEGACY[view]}`); return; }
  const v = ['live', 'apps', 'media', 'community', 'store', 'site', 'connectors', 'promo', 'settings'].includes(view) ? view : 'live';
  $$('main.view').forEach(m => (m.hidden = m.dataset.view !== v));
  $$('#viewNav a').forEach(a => a.classList.toggle('on', a.dataset.view === v));
  if (v === 'site') SiteCfg.show(sub); if (v === 'community') Community.show(sub); if (v === 'media') Media.show(); if (v === 'connectors') Connectors.show(sub, sub2); if (v === 'store') StoreHub.show(sub); if (v === 'settings') Settings.show(sub);
  if (v === 'promo') Promo.show(sub);
  if (v === 'live') Live.show(); else Live.hide();
  scrollTo({ top: 0 });
}
addEventListener('hashchange', route);
document.addEventListener('click', e => { const g = e.target.closest('[data-goto]'); if (g) { e.preventDefault(); const [v, s] = g.dataset.goto.split(':'); if (!$('#editor').hidden) closeEditor(); location.hash = `#/${v}${s ? '/' + s : ''}`; } });

// ---------- apps view ----------
function renderApps() { renderTiles(); renderTabs(); renderBoard(); }
function renderTiles() {
  const pub = S.apps.filter(a => a.published);
  const tiles = [['Projects', S.apps.length, 'in hub'], ['On the website', pub.length, 'published'], ['Drafts', S.apps.length - pub.length, 'private'], ['Community', S.apps.filter(a => a.community).length, 'from supporters']];
  $('#tiles').innerHTML = tiles.map(([l, n, s]) => `<div class="tile"><span>${l}</span><b><span class="grad-text">${n}</span><small>${s}</small></b></div>`).join('');
}
function renderTabs() {
  const tabs = [{ id: 'all', label: 'All', icon: 'layers' }, ...R.categories()];
  const orphan = [...new Set(S.apps.map(a => a.category))].filter(c => !R.categories().some(x => x.id === c));
  $('#catTabs').innerHTML = tabs.map(c => {
    const n = c.id === 'all' ? S.apps.length : S.apps.filter(a => a.category === c.id).length;
    if (c.id !== 'all' && !n && F.cat !== c.id) return '';
    return `<button class="tab${F.cat === c.id ? ' on' : ''}" type="button" data-cat="${esc(c.id)}">${R.icon(c.icon)}${esc(c.label)} <em>${n}</em></button>`;
  }).join('') + orphan.map(c => `<button class="tab warn${F.cat === c ? ' on' : ''}" type="button" data-cat="${esc(c)}" title="This category no longer exists">${R.icon('info')}${esc(c)} <em>${S.apps.filter(a => a.category === c).length}</em></button>`).join('');
}
function visible() {
  const q = F.q.toLowerCase();
  let list = sorted().filter(a =>
    (F.cat === 'all' || a.category === F.cat) &&
    (F.vis === 'all' || (F.vis === 'community' ? a.community : (F.vis === 'public') === !!a.published)) &&
    (F.status === 'all' || a.status === F.status) &&
    (!q || [a.name, a.tagline, a.description, a.platform, a.notes, a.localPath, a.author?.name, ...(a.techStack || [])].join(' ').toLowerCase().includes(q)));
  if (F.sort === 'updated') list.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
  if (F.sort === 'alpha') list.sort((a, b) => a.name.localeCompare(b.name));
  return list;
}
function hubCard(a) {
  const cat = R.categoryOf(a.category);
  const siteUrl = `${S.config.siteUrl}/apps/${encodeURIComponent(a.id)}/`;
  const badge = R.badgeOf(a);
  return `<article class="hc${a.published ? '' : ' draft'}" data-id="${esc(a.id)}" draggable="${F.sort === 'order'}" style="${R.accentStyle(a)}" tabindex="0">
  <div class="hc-media">${R.coverHTML(a, { mediaBase: MEDIA })}<div class="badges">${a.published ? `<span class="vis pub">${R.icon('globe')}ON SITE</span>` : `<span class="vis dr">${R.icon('lock')}DRAFT</span>`}${spill(a)}${a.community ? `<span class="cpill">${R.icon('users')}</span>` : ''}${badge ? `<span class="npill">${esc(badge)}</span>` : ''}</div></div>
  <div class="hc-body">
    <div class="hc-head">${R.appIcon(a, { mediaBase: MEDIA })}<div style="min-width:0"><h3>${esc(a.name)}</h3><div class="meta">${R.icon(cat.icon)}<span>${esc(cat.label)}</span>${a.version ? `<span class="dot">·</span><span class="ver">${esc(a.version)}</span>` : ''}</div></div></div>
    <p class="hc-tag">${esc(a.tagline) || '<i>No tagline yet</i>'}</p>
    ${a.community && a.author?.name ? `<div class="hc-path">${R.icon('users')}<span>by ${esc(a.author.name)}</span></div>` : a.localPath ? `<div class="hc-path">${R.icon('folder')}<span title="${esc(a.localPath)}">${esc(a.localPath)}</span></div>` : ''}
  </div>
  <div class="hc-foot">
    <span class="upd">${a.updatedAt ? esc(R.fmtDate(a.updatedAt)) : ''}</span><span class="sp"></span>
    <button class="act${a.published ? ' on-pub' : ''}" data-act="pub" type="button" title="${a.published ? 'On the website: click to make it a draft' : 'Draft: click to show it on the website'}">${R.icon(a.published ? 'eye' : 'eyeoff')}</button>
    <button class="act${a.featured ? ' on-star' : ''}" data-act="star" type="button" title="${a.featured ? 'Featured' : 'Make featured'}">${R.icon('star')}</button>
    ${a.localPath ? `<button class="act" data-act="folder" type="button" title="Open project folder">${R.icon('folder')}</button>` : ''}
    ${a.repoUrl ? `<a class="act" href="${esc(a.repoUrl)}" target="_blank" rel="noopener" title="Open repository" data-act="link">${R.icon('github')}</a>` : ''}
    ${a.published && S.status && !S.status.changes?.some(c => c.name === a.name) ? `<a class="act" href="${esc(siteUrl)}" target="_blank" rel="noopener" title="View on the website" data-act="link">${R.icon('external')}</a>` : ''}
    <button class="act" data-act="edit" type="button" title="Edit">${R.icon('edit')}</button>
    <button class="act del" data-act="del" type="button" title="Delete">${R.icon('trash')}</button>
  </div>
</article>`;
}
function renderBoard() {
  const list = visible();
  const board = $('#board');
  board.className = 'board ' + F.view;
  board.innerHTML = list.map(hubCard).join('');
  $('#emptyBoard').hidden = list.length > 0;
  $('#orderHint').style.visibility = F.sort === 'order' && list.length > 1 ? 'visible' : 'hidden';
  $$('#visSeg button').forEach(b => b.classList.toggle('on', b.dataset.v === F.vis));
  $$('#viewSeg button').forEach(b => b.classList.toggle('on', b.dataset.v === F.view));
  $('#statusSel').value = F.status; $('#sortSel').value = F.sort;
}
function renderStatus() {
  const s = S.status, chip = $('#siteChip'), n = pendingCount();
  chip.className = 'sitechip ' + (!s ? '' : !s.repoOk ? 'err' : n ? 'pending' : 'ok');
  chip.querySelector('span').textContent = !s ? 'Checking site…' : !s.repoOk ? (s.connected ? 'No site yet: finish setup' : 'GitHub not connected') :
    n ? `${n} change${n > 1 ? 's' : ''} not on the website yet` : `Website up to date${s.lastCommit ? ' · ' + rel(s.lastCommit.date) : ''}`;
  $('#publishBtn').classList.toggle('pending', n > 0);
  $('#pubCount').hidden = !n; $('#pubCount').textContent = n;
  const ban = $('#banner');
  if (s && s.repoOk && n) {
    const items = s.changes.slice(0, 6).map(c => `<span><span class="chg-k ${c.kind}">${c.kind}</span>${esc(c.name)}</span>`).join(' &nbsp; ');
    const extra = !s.changes.length ? `${s.workingFiles || s.ahead} site file change(s) waiting` : s.changes.length > 6 ? ` +${s.changes.length - 6} more` : '';
    ban.innerHTML = `${R.icon('rocket')}<div class="txt"><b>Ready to publish</b><div class="chg">${items}${extra}</div></div><button class="hbtn ghost sm" type="button" data-pv>${R.icon('eye')}Preview</button><button class="hbtn primary sm" type="button" data-pub>${R.icon('rocket')}Publish now</button>`;
    ban.hidden = false;
  } else ban.hidden = true;
  renderBoard();
}

$('#catTabs').addEventListener('click', e => { const t = e.target.closest('.tab'); if (!t) return; F.cat = t.dataset.cat; saveFilters(); renderTabs(); renderBoard(); });
$('#q').addEventListener('input', e => { F.q = e.target.value.trim(); renderBoard(); });
$('#visSeg').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; F.vis = b.dataset.v; saveFilters(); renderBoard(); });
$('#viewSeg').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; F.view = b.dataset.v; saveFilters(); renderBoard(); });
$('#statusSel').addEventListener('change', e => { F.status = e.target.value; saveFilters(); renderBoard(); });
$('#sortSel').addEventListener('change', e => { F.sort = e.target.value; saveFilters(); renderBoard(); });
$('#clearFilters').addEventListener('click', () => { Object.assign(F, { cat: 'all', q: '', vis: 'all', status: 'all' }); $('#q').value = ''; saveFilters(); renderApps(); });
$('#banner').addEventListener('click', e => { if (e.target.closest('[data-pub]')) openPublish(); if (e.target.closest('[data-pv]')) preview(); });

$('#board').addEventListener('click', async e => {
  const card = e.target.closest('.hc'); if (!card) return;
  const id = card.dataset.id, a = S.apps.find(x => x.id === id);
  const act = e.target.closest('[data-act]')?.dataset.act;
  if (act === 'link') return;
  if (!act || act === 'edit') return openEditor(id);
  try {
    if (act === 'pub') { S.apps = (await api('POST', '/api/patch', { id, set: { published: !a.published } })).apps; toast(a.published ? `${a.name} is now a draft` : `${a.name} will appear on the website when you publish`); }
    if (act === 'star') S.apps = (await api('POST', '/api/patch', { id, set: { featured: !a.featured } })).apps;
    if (act === 'folder') { await api('POST', '/api/open', { target: a.localPath }); return; }
    if (act === 'del') {
      if (!(await confirmBox(`Delete ${a.name}?`, a.published ? 'It will be removed from the hub and, after you publish, from the website. A backup is kept in studio-hub/data/backups.' : 'It will be removed from the hub. A backup is kept in studio-hub/data/backups.'))) return;
      S.apps = (await api('DELETE', '/api/apps/' + encodeURIComponent(id))).apps; toast(`Deleted ${a.name}`);
    }
    emit('apps'); refreshStatus();
  } catch (err) { toast(err.message, 'err'); }
});
$('#board').addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.classList.contains('hc')) openEditor(e.target.dataset.id); });

let dragId = null;
$('#board').addEventListener('dragstart', e => {
  const c = e.target.closest('.hc'); if (!c || F.sort !== 'order') return e.preventDefault();
  dragId = c.dataset.id; c.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', dragId);
});
$('#board').addEventListener('dragend', () => { dragId = null; $$('.hc').forEach(c => c.classList.remove('dragging', 'drop-before')); });
$('#board').addEventListener('dragover', e => {
  if (!dragId) return; e.preventDefault();
  const c = e.target.closest('.hc');
  $$('.hc.drop-before').forEach(x => x !== c && x.classList.remove('drop-before'));
  if (c && c.dataset.id !== dragId) c.classList.add('drop-before');
});
$('#board').addEventListener('drop', async e => {
  if (!dragId) return; e.preventDefault();
  const target = e.target.closest('.hc')?.dataset.id;
  const ids = sorted().map(a => a.id).filter(id => id !== dragId);
  const at = target ? ids.indexOf(target) : ids.length;
  ids.splice(at < 0 ? ids.length : at, 0, dragId);
  dragId = null;
  try { S.apps = (await api('POST', '/api/reorder', { ids })).apps; renderBoard(); refreshStatus(); } catch (err) { toast(err.message, 'err'); }
});

// ---------- editor ----------
const DEFAULT = () => ({ id: '', name: '', tagline: '', description: '', category: R.categories()[0]?.id || 'desktop', status: 'dev', version: '', platform: '', price: '', requirements: '', badge: '',
  featured: false, published: false, accent: 'studio', glyph: 'sparkles', iconImage: '', cover: '', screenshots: [], metricLabel: '', metricValue: '', techStack: [], primaryLabel: '', primaryUrl: '',
  pageUrl: '', repoUrl: '', docsUrl: '', videoUrl: '', installCommand: '', features: [], changelog: [], embedTitle: '', embedCode: '', community: false, author: { name: '', url: '' },
  updatedAt: today(), localPath: '', notes: '' });
const ED = { d: null, prevId: null, dirty: false, pv: 'card' };
const form = $('#editForm');
$('#labelChips').innerHTML = ['Download', 'Add to Chrome', 'Get the source', 'Learn more', 'Try it free', 'Watch video', 'Get the mod'].map(l => `<button type="button" class="chip">${l}</button>`).join('');

S.openEditor = id => openEditor(id);
export function openEditor(id) {
  const a = id ? S.apps.find(x => x.id === id) : null;
  ED.d = Object.assign(DEFAULT(), a ? clone(a) : {});
  ED.d.author = { name: '', url: '', ...(ED.d.author || {}) };
  ED.prevId = a ? a.id : null;
  ED.dirty = false;
  $('#edCat').innerHTML = R.categories().map(c => `<option value="${esc(c.id)}">${esc(c.label)}</option>`).join('') +
    (R.categories().some(c => c.id === ED.d.category) ? '' : `<option value="${esc(ED.d.category)}">${esc(ED.d.category)} (missing)</option>`);
  fillForm(); switchTab('basics');
  promoStrip();
  $('#editor').hidden = false; document.body.style.overflow = 'hidden';
  setTimeout(() => form.elements.name.focus(), 50);
}
async function closeEditor(force) {
  if (!force && ED.dirty && !(await confirmBox('Discard changes?', 'You have unsaved changes to this app.', 'Discard'))) return;
  $('#editor').hidden = true; document.body.style.overflow = ''; ED.d = null; ED.dirty = false;
}
function switchTab(t) {
  $$('#edTabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === t));
  $$('.pane').forEach(p => p.classList.toggle('on', p.dataset.pane === t));
}
$('#edTabs').addEventListener('click', e => { const b = e.target.closest('button'); if (b) switchTab(b.dataset.tab); });

function fillForm() {
  const d = ED.d;
  for (const el of form.elements) {
    if (!el.name) continue;
    if (el.name === 'authorName') el.value = d.author?.name || '';
    else if (el.name === 'authorUrl') el.value = d.author?.url || '';
    else if (el.type === 'checkbox') el.checked = !!d[el.name];
    else if (el.name === 'features') el.value = (d.features || []).join('\n');
    else el.value = d[el.name] ?? '';
  }
  renderCustom(); updateHead(); renderPreview(); MdEdit.refresh();
}
function renderCustom() {
  const d = ED.d;
  $('#edStatus').innerHTML = Object.entries(R.STATUS).map(([k, v]) => `<button type="button" data-v="${k}" class="${d.status === k ? 'on' : ''}">${esc(v.label)}</button>`).join('');
  $('#edAccent').innerHTML = Object.entries(R.ACCENTS).map(([k, v]) => `<button type="button" class="sw${d.accent === k ? ' on' : ''}" data-v="${k}" title="${esc(v.label)}" style="--a1:${v.a1};--a2:${v.a2}"></button>`).join('');
  $('#edGlyph').innerHTML = R.GLYPHS.map(g => `<button type="button" class="gl${d.glyph === g ? ' on' : ''}" data-v="${g}" title="${g}">${R.icon(g)}</button>`).join('');
  $('#edGlyph').style.cssText = R.accentStyle(d);
  renderDrop('#coverDrop', d.cover, 'Drop a cover image, or click to choose');
  renderDrop('#iconDrop', d.iconImage, 'Optional square icon');
  renderShots(); renderTech(); renderLog(); updateCounts(); renderVidPick();
  $('#idPreview').textContent = d.id || slug(d.name) || 'id';
  const sub = d.submission;
  $('#subInfo').innerHTML = sub ? `<div class="note"><span>${R.icon('inbox')}</span><div>Community submission${sub.user ? ` from <b>@${esc(sub.user)}</b>` : ''}${sub.supporter ? `, verified supporter <b>${esc(sub.supporter)}</b>` : ', <b>not verified</b>'}. ${sub.url ? `<a href="${esc(sub.url)}" target="_blank" rel="noopener">Open the original</a>` : ''}</div></div>` : '';
}
function renderVidPick() {
  const vids = (S.site?.youtube?.videos || []).slice(0, 8);
  const cur = R.youtubeId(ED.d.videoUrl);
  $('#vidPick').innerHTML = vids.length ? `<small>Pick from your channel:</small><div class="vp">${vids.map(v => `<button type="button" class="${v.id === cur ? 'on' : ''}" data-vid="${esc(v.id)}" title="${esc(v.title)}"><img src="${R.ytThumb(v.id, 'mqdefault')}" alt="">${v.short ? '<em>Short</em>' : ''}</button>`).join('')}</div>` : '';
}
function renderDrop(sel, path, label) {
  $(sel).innerHTML = path
    ? `<img class="full" src="${esc(R.media(path, MEDIA))}" alt=""><div class="ov"><button type="button" data-drop="replace">Replace</button><button type="button" data-drop="remove">Remove</button></div>`
    : `<div class="em">${R.icon('upload')}<span>${esc(label)}</span><small>PNG, JPG, WebP, SVG · or paste</small></div>`;
}
function renderShots() {
  $('#shotList').innerHTML = (ED.d.screenshots || []).map((s, i) => `<div class="shot" draggable="true" data-idx="${i}"><img src="${esc(R.media(s, MEDIA))}" alt=""><button type="button" class="rm" data-rm="${i}" title="Remove">${R.icon('x')}</button><button type="button" class="mk" data-mk="${i}">Use as cover</button></div>`).join('') +
    `<div class="shot add" id="shotAdd"><div class="em">${R.icon('plus')}<span>Add screenshots</span></div></div>`;
}
function renderTech() {
  const box = $('#techIn'), input = box.querySelector('input');
  $$('.tg', box).forEach(t => t.remove());
  (ED.d.techStack || []).forEach((t, i) => { const s = document.createElement('span'); s.className = 'tg'; s.innerHTML = `${esc(t)}<button type="button" data-tg="${i}" aria-label="Remove">${R.icon('x')}</button>`; box.insertBefore(s, input); });
}
function renderLog() {
  $('#logRows').innerHTML = (ED.d.changelog || []).map((c, i) => `<div class="logrow" data-row="${i}"><input data-k="ver" value="${esc(c.ver)}" placeholder="v1.0.0" class="mono"><input data-k="date" value="${esc(c.date)}" placeholder="Nov 2026"><input data-k="note" value="${esc(c.note)}" placeholder="What changed"><button type="button" class="act del" data-lrm="${i}" title="Remove">${R.icon('trash')}</button></div>`).join('');
}
function updateCounts() { $$('[data-count]').forEach(c => { const n = (ED.d[c.dataset.count] || '').length, max = +c.dataset.max; c.textContent = `${n}/${max}`; c.classList.toggle('over', n > max); }); }
function updateHead() {
  const d = ED.d;
  $('#edIcon').innerHTML = `<span style="${R.accentStyle(d)}">${R.appIcon(d, { mediaBase: MEDIA })}</span>`;
  $('#edTitle').textContent = d.name || (ED.prevId ? 'Untitled app' : 'New app');
  $('#edSub').textContent = (ED.prevId ? (d.published ? 'On the website' : 'Draft, only in the hub') : 'Not saved yet') + (d.id ? ` · /apps/${d.id}/` : '');
  $('#edDirty').textContent = ED.dirty ? '● Unsaved changes' : '';
  $('#edDelete').style.visibility = ED.prevId ? 'visible' : 'hidden';
}
let pvRaf = 0;
function renderPreview() {
  cancelAnimationFrame(pvRaf);
  pvRaf = requestAnimationFrame(() => {
    if (!ED.d) return;
    const d = { ...ED.d, id: ED.d.id || slug(ED.d.name) || 'new-app', name: ED.d.name || 'Untitled app' };
    const st = $('#pvStage');
    $$('#pvSeg button').forEach(b => b.classList.toggle('on', b.dataset.v === ED.pv));
    if (ED.pv === 'detail') st.innerHTML = R.detailHTML(d, { mediaBase: MEDIA, preview: true });
    else st.innerHTML = (d.featured ? `<p class="pv-label">Featured row</p>${R.cardHTML(d, { mediaBase: MEDIA, preview: true, wide: true })}` : '') +
      `<p class="pv-label">${d.featured ? 'Catalog grid' : 'Catalog card'}</p>${R.cardHTML(d, { mediaBase: MEDIA, preview: true })}` +
      (!ED.d.published ? `<p class="pv-label" style="color:#FBBF24">This app is a draft. Turn on “Show on website” to publish it.</p>` : '');
  });
}
function touch() { ED.dirty = true; updateHead(); renderPreview(); }

form.addEventListener('input', e => {
  const el = e.target;
  if (el.closest('#techIn')) return;
  if (el.closest('#logRows')) { const r = el.closest('.logrow'); ED.d.changelog[+r.dataset.row][el.dataset.k] = el.value; return touch(); }
  if (!el.name) return;
  if (el.name === 'authorName') ED.d.author.name = el.value;
  else if (el.name === 'authorUrl') ED.d.author.url = el.value;
  else if (el.type === 'checkbox') ED.d[el.name] = el.checked;
  else if (el.name === 'features') ED.d.features = el.value.split('\n').map(s => s.trim()).filter(Boolean);
  else if (el.name === 'id') ED.d.id = slug(el.value);
  else ED.d[el.name] = el.value;
  if (el.name === 'name' || el.name === 'id') $('#idPreview').textContent = ED.d.id || slug(ED.d.name) || 'id';
  if (el.name === 'videoUrl') renderVidPick();
  updateCounts(); touch();
});
form.addEventListener('change', e => { if (e.target.name === 'id') e.target.value = ED.d.id; });
form.addEventListener('click', async e => {
  const t = e.target;
  const pick = (sel, key) => { const b = t.closest(sel + ' [data-v]'); if (b) { ED.d[key] = b.dataset.v; renderCustom(); touch(); return true; } };
  if (pick('#edStatus', 'status') || pick('#edAccent', 'accent') || pick('#edGlyph', 'glyph')) return;
  if (t.closest('[data-close]')) return closeEditor();
  const vid = t.closest('[data-vid]');
  if (vid) { const v = S.site.youtube.videos.find(x => x.id === vid.dataset.vid); ED.d.videoUrl = form.elements.videoUrl.value = v.short ? `https://youtube.com/shorts/${v.id}` : `https://youtu.be/${v.id}`; renderVidPick(); return touch(); }
  const chip = t.closest('#labelChips .chip');
  if (chip) { ED.d.primaryLabel = form.elements.primaryLabel.value = chip.textContent; return touch(); }
  const tg = t.closest('[data-tg]');
  if (tg) { ED.d.techStack.splice(+tg.dataset.tg, 1); renderTech(); return touch(); }
  const lrm = t.closest('[data-lrm]');
  if (lrm) { ED.d.changelog.splice(+lrm.dataset.lrm, 1); renderLog(); return touch(); }
  if (t.closest('#addLog')) { ED.d.changelog.unshift({ ver: ED.d.version || '', date: new Date().toLocaleDateString('en-AU', { month: 'short', year: 'numeric' }), note: '' }); renderLog(); $('#logRows input[data-k="note"]').focus(); return touch(); }
  const rm = t.closest('[data-rm]');
  if (rm) { ED.d.screenshots.splice(+rm.dataset.rm, 1); renderShots(); return touch(); }
  const mk = t.closest('[data-mk]');
  if (mk) { const i = +mk.dataset.mk, s = ED.d.screenshots[i]; ED.d.screenshots.splice(i, 1); if (ED.d.cover) ED.d.screenshots.unshift(ED.d.cover); ED.d.cover = s; renderCustom(); return touch(); }
  if (t.closest('#shotAdd')) return pickFiles(true, paths => { ED.d.screenshots.push(...paths); renderShots(); touch(); });
  const drop = t.closest('#coverDrop, #iconDrop');
  if (drop) {
    const key = drop.id === 'coverDrop' ? 'cover' : 'iconImage';
    if (t.closest('[data-drop="remove"]')) { ED.d[key] = ''; renderCustom(); return touch(); }
    return pickFiles(false, ([p]) => { ED.d[key] = p; renderCustom(); touch(); });
  }
  const op = t.closest('[data-open]');
  if (op) { try { await api('POST', '/api/open', { target: ED.d.localPath, with: op.dataset.open }); } catch (err) { toast(err.message, 'err'); } return; }
  if (t.closest('#ghSync')) return ghSync();
  if (t.closest('#edDelete')) {
    if (!(await confirmBox(`Delete ${ED.d.name}?`, 'This removes it from the hub (a backup is kept). If it is on the website, it disappears after your next publish.'))) return;
    try { S.apps = (await api('DELETE', '/api/apps/' + encodeURIComponent(ED.prevId))).apps; closeEditor(true); emit('apps'); refreshStatus(); toast('Deleted'); } catch (err) { toast(err.message, 'err'); }
  }
});
$('#pvSeg').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { ED.pv = b.dataset.v; renderPreview(); } });
$('#pvStage').addEventListener('click', e => { e.preventDefault(); const b = e.target.closest('.d-thumbs button'); if (b) { $$('.d-thumbs button', $('#pvStage')).forEach(x => x.classList.toggle('on', x === b)); $('.d-stage img', $('#pvStage')).src = b.dataset.src; } });

$('#techIn input').addEventListener('keydown', e => {
  const v = e.target.value.trim().replace(/,$/, '');
  if ((e.key === 'Enter' || e.key === ',') && v) { e.preventDefault(); if (!ED.d.techStack.includes(v)) ED.d.techStack.push(v); e.target.value = ''; renderTech(); touch(); }
  else if (e.key === 'Enter') e.preventDefault();
  else if (e.key === 'Backspace' && !e.target.value && ED.d.techStack.length) { ED.d.techStack.pop(); renderTech(); touch(); }
});
$('#techIn').addEventListener('click', e => { if (e.target.id === 'techIn') e.target.querySelector('input').focus(); });

// uploads
export async function uploadImage(file, appId) {
  if (!file.type.startsWith('image/')) throw new Error(`${file.name} is not an image`);
  const data = await new Promise((ok, fail) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = fail; r.readAsDataURL(file); });
  const name = file.name && file.name !== 'image.png' ? file.name : `pasted-${Date.now().toString(36)}.${(file.type.split('/')[1] || 'png').replace('jpeg', 'jpg').replace('svg+xml', 'svg')}`;
  return (await api('POST', '/api/upload', { appId, name, data })).path;
}
async function uploadAll(files, cb) {
  const paths = [], appId = ED.d.id || slug(ED.d.name) || 'new-app';
  for (const f of files) { try { paths.push(await uploadImage(f, appId)); } catch (err) { toast(err.message, 'err'); } }
  if (paths.length) { cb(paths); toast(paths.length > 1 ? `Added ${paths.length} images` : 'Image added'); }
}
function pickFiles(multi, cb) {
  const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.multiple = multi;
  i.onchange = () => uploadAll([...i.files], cb); i.click();
}
function dropZone(el, multi, cb) {
  el.addEventListener('dragover', e => { if (e.dataTransfer.types.includes('Files')) { e.preventDefault(); el.classList.add('over'); } });
  el.addEventListener('dragleave', () => el.classList.remove('over'));
  el.addEventListener('drop', e => { if (!e.dataTransfer.files.length) return; e.preventDefault(); el.classList.remove('over'); uploadAll([...e.dataTransfer.files].slice(0, multi ? 50 : 1), cb); });
}
// the promo kit strip under the screenshots: kits are made in the background after uploads
function promoStrip(delay = 0) { setTimeout(() => { if (ED.d && !$('#editor').hidden) Promo.editorStrip(ED.d, (as, p) => { if (as === 'cover') ED.d.cover = p; else ED.d.screenshots.push(p); renderCustom(); touch(); }); }, delay); }
dropZone($('#coverDrop'), false, ([p]) => { ED.d.cover = p; renderCustom(); touch(); promoStrip(13500); });
dropZone($('#iconDrop'), false, ([p]) => { ED.d.iconImage = p; renderCustom(); touch(); });
dropZone($('#shotList'), true, ps => { ED.d.screenshots.push(...ps); renderShots(); touch(); promoStrip(13500); });
document.addEventListener('paste', e => {
  if (!ED.d || $('#editor').hidden) return;
  const files = [...(e.clipboardData?.files || [])].filter(f => f.type.startsWith('image/'));
  if (!files.length) return;
  e.preventDefault();
  if (!ED.d.cover) uploadAll(files.slice(0, 1), ([p]) => { ED.d.cover = p; renderCustom(); touch(); });
  else uploadAll(files, ps => { ED.d.screenshots.push(...ps); renderShots(); touch(); });
  switchTab('media');
});
let shotDrag = null;
$('#shotList').addEventListener('dragstart', e => { const s = e.target.closest('.shot:not(.add)'); if (!s) return; shotDrag = +s.dataset.idx; s.classList.add('dragging'); e.dataTransfer.setData('text/plain', 'shot'); });
$('#shotList').addEventListener('dragend', () => { shotDrag = null; $$('#shotList .shot').forEach(s => s.classList.remove('dragging')); });
$('#shotList').addEventListener('dragover', e => { if (shotDrag !== null) e.preventDefault(); });
$('#shotList').addEventListener('drop', e => {
  if (shotDrag === null) return; e.preventDefault();
  const t = e.target.closest('.shot');
  const arr = ED.d.screenshots, [m] = arr.splice(shotDrag, 1);
  const to = !t || t.classList.contains('add') ? arr.length : +t.dataset.idx;
  arr.splice(Math.min(to, arr.length), 0, m);
  shotDrag = null; renderShots(); touch();
});

async function ghSync() {
  const repo = ED.d.repoUrl.trim();
  if (!repo) return toast('Add the GitHub repository URL first', 'err');
  const btn = $('#ghSync'); btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>Syncing…';
  try {
    const g = await api('GET', '/api/github?repo=' + encodeURIComponent(repo));
    const d = ED.d, did = [];
    if (!d.description && g.description) { d.description = g.description; did.push('description'); }
    if (!d.tagline && g.description) { d.tagline = g.description.split(/(?<=\.)\s/)[0].slice(0, 120); did.push('tagline'); }
    if (g.language && !d.techStack.includes(g.language)) { d.techStack.push(g.language); did.push('language'); }
    const isRepoLink = !d.primaryUrl || d.primaryUrl.replace(/\/$/, '') === g.htmlUrl || d.primaryUrl.replace(/\/$/, '') === repo.replace(/\/$/, '');
    if (g.release) {
      if (d.version !== g.release.tag) { d.version = g.release.tag; did.push('version ' + g.release.tag); }
      d.updatedAt = g.release.date.slice(0, 10);
      if (isRepoLink || /\/releases/.test(d.primaryUrl)) { d.primaryUrl = g.htmlUrl + '/releases/latest'; if (!d.primaryLabel || /source|github/i.test(d.primaryLabel)) d.primaryLabel = 'Download'; did.push('download link'); }
      if (!d.changelog.some(c => c.ver === g.release.tag)) {
        const note = (g.release.body || '').split('\n').map(s => s.replace(/^[#*\-\s]+/, '').trim()).find(Boolean) || g.release.name || 'New release';
        d.changelog.unshift({ ver: g.release.tag, date: new Date(g.release.date).toLocaleDateString('en-AU', { month: 'short', year: 'numeric' }), note: note.slice(0, 200) });
        did.push('release notes');
      }
    } else {
      if (g.pushedAt) d.updatedAt = g.pushedAt.slice(0, 10);
      if (!d.primaryUrl) { d.primaryUrl = g.htmlUrl; d.primaryLabel = d.primaryLabel || 'Get the source'; did.push('source link'); }
    }
    fillForm(); ED.dirty = true; updateHead();
    toast(did.length ? `Synced: ${did.join(', ')}` : g.release ? 'Already up to date with the latest release' : 'No releases yet; updated the date');
  } catch (err) { toast(err.message, 'err'); }
  finally { btn.disabled = false; btn.innerHTML = R.icon('refresh') + 'Sync from GitHub'; }
}

form.addEventListener('submit', async e => {
  e.preventDefault();
  if (!ED.d.name.trim()) { switchTab('basics'); form.elements.name.focus(); return toast('Give the app a name', 'err'); }
  try {
    const r = await api('POST', '/api/apps', { app: ED.d, prevId: ED.prevId });
    S.apps = r.apps; ED.d = Object.assign(DEFAULT(), clone(r.app)); ED.d.author = { name: '', url: '', ...(ED.d.author || {}) }; ED.prevId = r.app.id; ED.dirty = false;
    fillForm(); emit('apps'); refreshStatus();
    toast(ED.d.published ? 'Saved. Publish to update the website.' : 'Saved as a draft');
  } catch (err) { toast(err.message, 'err'); }
});
$('#editor').addEventListener('mousedown', e => { if (e.target.id === 'editor') closeEditor(); });

// ---------- publish ----------
async function preview() {
  if (siteDirty() && (await confirmBox('Save site settings first?', 'You have unsaved site settings. Save them so the preview includes them?', 'Save', false))) await saveSite();
  try { const r = await api('POST', '/api/build'); S.status = r.status; emit('status'); window.open('/site/', '_blank'); if (r.missing.length) toast('Missing images: ' + r.missing.join(', '), 'err', 6000); }
  catch (err) { toast(err.message, 'err'); }
}
$('#previewBtn').addEventListener('click', preview);
$('#publishBtn').addEventListener('click', () => openPublish());
$('#siteChip').addEventListener('click', () => openPublish());

async function openPublish() {
  if (siteDirty()) {
    if (await confirmBox('Save site settings first?', 'You have unsaved site settings. Save them so they go live too?', 'Save', false)) await saveSite();
  }
  const dlg = $('#pubDlg'), body = $('#pubBody'), host = S.config.siteUrl.replace(/^https?:\/\//, '');
  body.innerHTML = `<h3>${R.icon('rocket')}Publish to ${esc(host)}</h3><p><span class="spinner" style="display:inline-block;vertical-align:-4px"></span> Checking what changed…</p>`;
  if (!dlg.open) dlg.showModal();
  await refreshStatus();
  const s = S.status;
  if (!s.repoOk) {
    body.innerHTML = s.connected ? `<h3>${R.icon('globe')}Create your site first</h3><p>GitHub is connected, but Pylerium Manager hasn’t created your site’s repository yet. Finish setup to create it, then publish.</p><div class="m-foot"><button class="hbtn ghost" type="button" data-x>Close</button><button class="hbtn primary" type="button" data-x data-setup-site>Finish setup</button></div>`
      : `<h3>${R.icon('github')}Connect GitHub first</h3><p>Pylerium Manager publishes your site to GitHub Pages. Connect your GitHub account and pick your site in Settings.</p><div class="m-foot"><button class="hbtn ghost" type="button" data-x>Close</button><a class="hbtn primary" href="#/settings/github" data-x>Open Settings</a></div>`;
    body.querySelector('[data-setup-site]')?.addEventListener('click', () => Setup.open(3));
    return;
  }
  const n = pendingCount();
  const by = k => s.changes.filter(c => c.kind === k).map(c => c.name);
  const msg = [by('added').length && 'Add ' + by('added').join(', '), by('updated').length && 'Update ' + by('updated').join(', '), by('removed').length && 'Remove ' + by('removed').join(', ')].filter(Boolean).join('; ') || 'Update Pylerium Studio showcase';
  const yt = S.site.youtube?.autoSync && S.site.youtube?.channelUrl;
  body.innerHTML = `<h3>${R.icon('rocket')}Publish to ${esc(host)}</h3>
    <p>${n ? 'These changes will go live on your website:' : 'The website already matches your hub. You can publish again anyway.'}</p>
    <ul class="chglist">${s.changes.length ? s.changes.map(c => `<li><span class="chg-k ${c.kind}">${c.kind}</span>${esc(c.name)}</li>`).join('') : `<li class="none">No changes${s.workingFiles ? ` · ${s.workingFiles} other site file(s) changed` : ''}${s.ahead ? ` · ${s.ahead} commit(s) not pushed` : ''}</li>`}</ul>
    ${yt ? `<p class="note"><span>${R.icon('youtube')}</span>Your latest YouTube videos are fetched automatically as part of publishing.</p>` : ''}
    <label class="fld"><span>Change summary</span><input id="pubMsg" value="${esc(msg.slice(0, 180))}" maxlength="200"></label>
    <div class="m-foot"><button class="hbtn ghost" type="button" data-pv>${R.icon('eye')}Preview first</button><span class="sp"></span><button class="hbtn ghost" type="button" data-x>Cancel</button><button class="hbtn primary" type="button" data-go>${R.icon('rocket')}Publish now</button></div>`;
}
$('#pubDlg').addEventListener('click', async e => {
  const dlg = $('#pubDlg'), body = $('#pubBody');
  if (e.target === dlg || e.target.closest('[data-x]')) return dlg.close();
  if (e.target.closest('[data-pv]')) return preview();
  if (!e.target.closest('[data-go]')) return;
  const message = $('#pubMsg').value.trim();
  body.innerHTML = `<h3><span class="spinner"></span>Publishing…</h3><p>Building your site and uploading the changes to GitHub. Usually a few seconds.</p>`;
  try {
    const r = await api('POST', '/api/publish', { message });
    S.status = r.status; emit('status');
    const st = await api('GET', '/api/state'); S.site = st.site; S.siteDraft = clone(st.site); emit('site');
    body.innerHTML = `<div class="okbig">${R.icon('check')}</div><h3>Published</h3><p>Your changes are on GitHub. GitHub Pages usually updates <b>${esc(S.config.siteUrl.replace(/^https?:\/\//, ''))}</b> within a minute.</p>
      <details><summary style="cursor:pointer;color:var(--muted);font-size:13px">Show log</summary><pre class="logbox">${esc(r.log)}</pre></details>
      <div class="m-foot"><button class="hbtn ghost" type="button" data-x>Close</button><a class="hbtn primary" href="${esc(r.url)}" target="_blank" rel="noopener">${R.icon('external')}Open website</a></div>`;
  } catch (err) {
    body.innerHTML = `<h3>${R.icon('x')}Publish failed</h3><p>${esc(err.message)}</p>${err.data?.log ? `<pre class="logbox">${esc(err.data.log)}</pre>` : ''}<div class="m-foot"><button class="hbtn ghost" type="button" data-x>Close</button></div>`;
    refreshStatus();
  }
});

// ---------- import / export ----------
$('#exportBtn').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(sorted(), null, 2)], { type: 'application/json' });
  const a = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: `pylerium-manager-backup-${today()}.json` });
  a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  toast('Exported the full catalog (includes private notes)');
});
$('#importBtn').addEventListener('click', () => $('#importFile').click());
$('#importFile').addEventListener('change', async e => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  try {
    const apps = JSON.parse(await f.text());
    if (!Array.isArray(apps) || !apps.length) throw new Error('That file is not an exported catalog.');
    if (!(await confirmBox('Replace the catalog?', `Replace all ${S.apps.length} projects with the ${apps.length} in ${f.name}? The current catalog is backed up first.`, 'Replace', false))) return;
    S.apps = (await api('PUT', '/api/apps', { apps })).apps; emit('apps'); refreshStatus(); toast(`Imported ${apps.length} projects`);
  } catch (err) { toast(err.message, 'err'); }
});

// ---------- keyboard ----------
document.addEventListener('keydown', e => {
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName) || document.activeElement?.isContentEditable;
  const edOpen = !$('#editor').hidden;
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
    if (edOpen) { e.preventDefault(); form.requestSubmit(); return; }
    if (siteDirty()) { e.preventDefault(); saveSite().then(() => toast('Site settings saved')).catch(err => toast(err.message, 'err')); return; }
  }
  if (e.key === 'Escape' && edOpen && !$('dialog[open]')) { e.preventDefault(); closeEditor(); return; }
  if (typing || edOpen || $('dialog[open]')) return;
  if (e.key === '/' && !$('main[data-view=apps]').hidden) { e.preventDefault(); $('#q').focus(); }
  if (e.key.toLowerCase() === 'n' && !e.ctrlKey && !e.metaKey) { e.preventDefault(); location.hash = '#/apps'; openEditor(null); }
});
$('#newBtn').addEventListener('click', () => openEditor(null));
addEventListener('beforeunload', e => { if (ED.dirty || siteDirty()) e.preventDefault(); });
addEventListener('focus', () => refreshStatus());

$('#brandMark').innerHTML = R.brandMark('mark');
hydrate();
load().catch(err => toast(err.message, 'err', 8000));
