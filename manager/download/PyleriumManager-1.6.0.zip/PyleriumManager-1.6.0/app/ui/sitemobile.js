// Site settings → Mobile & menu, and Community → Supply caffeine: the controls for the mobile menu, the phone layout
// and every donation-button option. Shared by the Studio Hub and Pylerium Manager (identical in both).
import { R, esc } from './core.js';

const get = (o, p) => p.split('.').reduce((x, k) => x?.[k], o);
// controls bound to S.siteDraft through data-k (the panels' input handlers save them)
const sw = (d, k, label, def = false, help = '') => { const v = get(d, k); const on = v === undefined ? def : !!v; return `<label class="switch"><input type="checkbox" data-k="${k}"${on ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">${esc(label)}${help ? `<small class="muted"> ${esc(help)}</small>` : ''}</span></label>`; };
const sl = (d, k, label, opts, def = '') => { const v = String(get(d, k) ?? def); return `<label class="fld"><span>${esc(label)}</span><select data-k="${k}">${opts.map(([val, l]) => `<option value="${esc(val)}"${String(val) === v ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`; };
const tx = (d, k, label, ph = '', help = '', max = 0) => `<label class="fld"><span>${esc(label)}${help ? ` <small>${esc(help)}</small>` : ''}</span><input data-k="${k}" value="${esc(get(d, k) ?? '')}" placeholder="${esc(ph)}"${max ? ` maxlength="${max}"` : ''}></label>`;
const chip = (on, label) => `<span class="mp-chip${on ? ' on' : ''}">${esc(label)}</span>`;

const NAV_DEFAULT = { featured: 'Featured', apps: 'Apps', videos: 'Videos', embeds: 'Links', news: 'News', community: 'Community', perks: 'Perks', studio: 'About', support: 'Support' };
const NAV_ICON = { featured: 'star', apps: 'grid', videos: 'youtube', embeds: 'link', news: 'megaphone', community: 'crown', perks: 'gift', studio: 'sparkles', support: 'mail' };
const NAV_ON = { featured: true, apps: true, videos: true, news: true, community: true, perks: true, support: true, embeds: false, studio: false };
export const navLabel = s => (s.navLabel || '').trim() || NAV_DEFAULT[s.id] || s.id;
export const navTop = s => s.nav ?? NAV_ON[s.id] ?? false;

// ---------- Sections tab: the label each section gets in the menus ----------
export function sectionNavFields(d, i) {
  const s = d.sections[i];
  if (!NAV_DEFAULT[s.id]) return '';
  return `<div class="f2 sec-nav">${tx(d, `sections.${i}.navLabel`, 'Menu label', NAV_DEFAULT[s.id], '', 24)}<div class="fld"><span>Top bar</span>${sw(d, `sections.${i}.nav`, 'Show in the top links on wide screens', NAV_ON[s.id])}</div></div>`;
}

// ---------- Mobile & menu tab ----------
export function mobileTab(d) {
  return `<div class="cols">
    <div class="card"><h3>${R.icon('menu')}Menu</h3>
      <p class="sub">On phones and narrow windows the top links fold into a menu. It lists the sections that are live on the page right now, with counts, and updates itself as the page changes. Labels come from the Sections tab.</p>
      <div class="f2">${sl(d, 'mobile.menu', 'Style', [['sheet', 'Side panel'], ['full', 'Full screen'], ['drop', 'Drop-down card']], 'sheet')}${sl(d, 'mobile.side', 'Opens from', [['right', 'The right'], ['left', 'The left']], 'right')}</div>
      <div class="f2">${sl(d, 'mobile.breakpoint', 'Use the menu below', [[640, '640 px (phones only)'], [760, '760 px'], [860, '860 px (phones and small tablets)'], [980, '980 px (tablets)'], [1100, '1100 px (tablets and small laptops)']], 860)}${tx(d, 'mobile.title', 'Heading above the links', 'e.g. Explore', 'optional', 30)}</div>
      <div class="stack">${sw(d, 'mobile.counts', 'Show counts next to sections (apps, videos, posts, perks)', true)}${sw(d, 'mobile.spy', 'Highlight the section you’re reading', true)}${sw(d, 'mobile.search', 'Search shortcut at the top', true)}${sw(d, 'mobile.donate', 'Donation button at the bottom', true)}${sw(d, 'mobile.socials', 'Social links at the bottom', true)}${sw(d, 'mobile.external', 'Outside links (like GitHub)', true)}${sw(d, 'mobile.haptics', 'A light tap of vibration on Android phones', true)}</div>
    </div>
    <div class="card"><h3>${R.icon('phone')}Phone layout</h3>
      <p class="sub">Applied automatically on phones (up to 760 px wide). Wide screens stay exactly as they are.</p>
      <div class="stack">${sw(d, 'mobile.bar', 'Bottom bar with quick links and the menu', false, '(like an app)')}${sw(d, 'mobile.toTop', 'Back-to-top button after scrolling', true)}${sw(d, 'mobile.stickyFilters', 'Keep the app search and categories pinned while browsing apps', true)}${sw(d, 'mobile.compactHero', 'Compact hero with full-width buttons', true)}${sw(d, 'mobile.hideStats', 'Hide the stats row', false)}${sw(d, 'mobile.hideAnnounce', 'Hide the announcement bar', false)}${sw(d, 'mobile.calm', 'Calm mode: no background glow or scroll animations (faster on old phones)', false)}</div>
      ${sl(d, 'mobile.cards', 'App cards', [['one', 'One per row (big covers)'], ['two', 'Two per row (see more at once)']], 'one')}
    </div>
    <div class="card"><h3>${R.icon('eye')}Preview</h3><div data-mpv>${mobilePreview(d)}</div>
      <p class="muted small">${R.icon('info')} Publish to put it live. Sections with nothing in them (no videos yet, no posts) are left out of the menu automatically.</p></div>
  </div>`;
}
export function mobilePreview(d) {
  const m = d.mobile || {}, dn = d.donate || {};
  const secs = (d.sections || []).filter(s => s.enabled && NAV_DEFAULT[s.id]);
  return `<div class="mp-phone mp-${esc(m.menu || 'sheet')} mp-${m.side === 'left' ? 'left' : 'right'}"><div class="mp-screen">
    <div class="mp-top"><b>${esc(d.brand?.name || 'Your studio')}</b><span>${R.icon('x')}</span></div>
    ${m.title ? `<small class="mp-title">${esc(m.title)}</small>` : ''}
    ${m.search !== false ? `<div class="mp-search">${R.icon('search')}Search apps</div>` : ''}
    <div class="mp-list">${secs.map((s, i) => `<div class="${i === 1 && m.spy !== false ? 'on' : ''}"><span>${R.icon(NAV_ICON[s.id])}</span>${esc(navLabel(s))}${m.counts !== false && ['apps', 'videos', 'news', 'featured'].includes(s.id) ? '<em>•</em>' : ''}</div>`).join('')}</div>
    ${m.donate !== false && dn.enabled && dn.url && (dn.places?.menu ?? true) ? `<div class="mp-don st-${esc(dn.style || 'amber')}">${R.icon(dn.icon || 'can')}${esc(dn.short || dn.label || 'Supply caffeine')}</div>` : ''}
  </div>${m.bar ? `<div class="mp-bar">${secs.slice(0, 3).map(s => `<i>${R.icon(NAV_ICON[s.id])}</i>`).join('')}<i>${R.icon('menu')}</i></div>` : ''}</div>
  <div class="mp-chips">${chip(m.bar, 'Bottom bar')}${chip(m.toTop !== false, 'Back to top')}${chip(m.stickyFilters !== false, 'Pinned search')}${chip(m.compactHero !== false, 'Compact hero')}${chip(m.cards === 'two', 'Two cards per row')}${chip(m.calm, 'Calm mode')}</div>`;
}

// ---------- Community → Supply caffeine ----------
export const DONATE_ICONS = ['can', 'coffee', 'heart', 'gift', 'star', 'zap', 'crown', 'sparkles', 'rocket', 'music'];
export const DONATE_STYLES = [['amber', 'Energy drink (amber)'], ['violet', 'Violet'], ['pink', 'Pink'], ['teal', 'Teal'], ['mono', 'White'], ['outline', 'Outline']];
export function donateCard(d, help = '') {
  const dn = d.donate || {};
  return `<div class="card don-card"><h3>${R.icon(dn.icon || 'can')}Donation button</h3>
      <p class="sub">A button that links to your Stripe Payment Link. Choose its words, look and where it shows.</p>
      ${sw(d, 'donate.enabled', 'Show the donation button', false)}
      ${tx(d, 'donate.url', 'Stripe Payment Link', 'https://buy.stripe.com/…')}
      <h4 class="don-h">${R.icon('edit')}Text</h4>
      <div class="f2">${tx(d, 'donate.label', 'Button text', 'Supply caffeine', '', 40)}${tx(d, 'donate.short', 'Short text for phones', 'e.g. Donate', 'optional', 22)}</div>
      <div class="f2">${tx(d, 'donate.navLabel', 'Text in the top bar', 'same as the short text', 'optional', 22)}${tx(d, 'donate.floatLabel', 'Text on the floating badge', 'same as the button', 'optional', 30)}</div>
      ${tx(d, 'donate.sub', 'Line under the big buttons', 'e.g. A$10+ unlocks app submissions', 'optional', 90)}
      <div class="f2">${tx(d, 'donate.title', 'Tooltip', 'e.g. Buy me an energy drink', 'optional', 80)}${tx(d, 'donate.thanks', 'Thank-you message after paying', 'Thank you for the caffeine!', 'shown on #thanks', 160)}</div>
      <h4 class="don-h">${R.icon('palette')}Look</h4>
      <div class="f2">${sl(d, 'donate.style', 'Colour', DONATE_STYLES, 'amber')}<div class="fld"><span>Icon</span><div class="don-icons">${DONATE_ICONS.map(k => `<button type="button" class="gl${(dn.icon || 'can') === k ? ' on' : ''}" data-donicon="${k}" title="${k}">${R.icon(k)}</button>`).join('')}</div></div></div>
      <div class="stack">${sw(d, 'donate.steam', 'Steam animation above the icon', true)}${sw(d, 'donate.newTab', 'Open the payment page in a new tab', true)}</div>
      <h4 class="don-h">${R.icon('layers')}Where it shows</h4>
      <div class="stack">${sw(d, 'donate.places.hero', 'Top of the home page (next to the main button)', true)}${sw(d, 'donate.showInNav', 'Top bar on every page', false)}${sw(d, 'donate.places.community', 'Community section', true)}${sw(d, 'donate.places.support', 'Support section', true)}${sw(d, 'donate.places.menu', 'Mobile menu', true)}${sw(d, 'donate.floating', 'Floating badge in the corner (like Buy Me a Coffee)', true)}</div>
      <div class="f3">${sl(d, 'donate.floatSide', 'Badge corner', [['right', 'Bottom right'], ['left', 'Bottom left']], 'right')}${sl(d, 'donate.floatAfter', 'Badge appears', [[0, 'Straight away'], [420, 'After a little scrolling'], [900, 'After the first section'], [1600, 'Further down']], 420)}${sl(d, 'donate.floatMobile', 'Badge on phones', [['mini', 'Icon only'], ['show', 'Icon and text'], ['hide', 'Hidden']], 'mini')}</div>
      ${sl(d, 'donate.floatCollapse', 'Badge shrinks to the icon', [['scroll', 'While scrolling down'], ['always', 'Always (text on hover)'], ['never', 'Never']], 'scroll')}
      <div class="mini-pv center" data-dpv>${donatePreview(d)}</div>
      ${help}
    </div>`;
}
export function donatePreview(d) {
  const dn = d.donate || {}, icon = R.icon(dn.icon || 'can'), steam = dn.steam !== false ? '<span class="steam"><i></i><i></i><i></i></span>' : '';
  const label = dn.label || 'Supply caffeine';
  return `<span class="pv-lbl">Preview</span>
    <div class="don-pvrow"><span class="caffeine-pv st-${esc(dn.style || 'amber')}"${dn.title ? ` title="${esc(dn.title)}"` : ''}>${steam}${icon}${esc(label)}</span>${dn.short ? `<span class="caffeine-pv sm st-${esc(dn.style || 'amber')}">${icon}${esc(dn.short)}</span>` : ''}</div>
    ${dn.sub ? `<small class="muted">${esc(dn.sub)}</small>` : ''}
    ${dn.floating !== false ? `<span class="float-pv st-${esc(dn.style || 'amber')}"><i>${icon}</i>${esc(dn.floatLabel || label)}</span>` : ''}
    ${!dn.url ? `<small class="warn-txt">${R.icon('info')}Hidden on the site until you add the link.</small>` : ''}`;
}
