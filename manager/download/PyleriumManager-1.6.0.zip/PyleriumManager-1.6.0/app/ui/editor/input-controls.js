/** Progressive controls: retain each field's validation, limits and original handlers. */
export function syncControl(input){input.precisionSync?.();}
let scanControls=()=>{};
export function enhanceTree(root){if(root)scanControls(root);}
let controlId=0;
export function enhanceInputs(root=document){
 const pending=new Set();let frame=0,closed=false;
 const labelFor=input=>input.getAttribute('aria-label')||input.labels?.[0]?.textContent.trim().slice(0,100)||input.title||'Value';
 function upgrade(input){
  if(input.dataset.enhanced||input.closest('.precision-control')||input.hidden||input.disabled)return;
  if(input.matches('input[type="number"]')){
   input.dataset.enhanced='1';const label=labelFor(input),owner=input.labels?.[0];if(!input.hasAttribute('aria-label'))input.setAttribute('aria-label',label);if(owner){if(!input.id){let id;do{id='precision-field-'+(++controlId);}while(document.getElementById(id));input.id=id;}owner.htmlFor=input.id;}
   const wrap=document.createElement('span');wrap.className='precision-control';input.replaceWith(wrap);
   const row=document.createElement('span');row.className='precision-row';wrap.append(row);row.append(input);
   const step=Number(input.step)||1,bounded=input.min!==''&&input.max!==''&&Number(input.max)>Number(input.min);
   const commit=value=>{if(!Number.isFinite(value))return;const [coefficient,exponent='0']=String(step).split('e'),digits=input.step==='any'?10:Math.max(0,Math.min(10,(coefficient.split('.')[1]||'').length-Number(exponent)));input.value=Math.max(input.min===''?-Infinity:Number(input.min),Math.min(input.max===''?Infinity:Number(input.max),Number(value.toFixed(digits))));input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));};
   for(const direction of [-1,1]){const b=document.createElement('button');b.type='button';b.className='precision-step';b.textContent=direction<0?'−':'+';b.setAttribute('aria-label',(direction<0?'Decrease ':'Increase ')+label);b.onclick=e=>{e.preventDefault();commit(Number(input.value)+direction*step*(e.shiftKey?10:1));};row.insertBefore(b,direction<0?input:null);}
   if(bounded){const slider=document.createElement('input');slider.type='range';slider.min=input.min;slider.max=input.max;slider.step=input.step||'1';slider.value=input.value;slider.setAttribute('aria-label',label+' slider');slider.className='precision-slider';wrap.append(slider);
    slider.onpointerdown=e=>input.onpointerdown?.(e);
    slider.oninput=()=>{input.value=slider.value;slider.style.setProperty('--fill',100*(Number(slider.value)-Number(slider.min))/(Number(slider.max)-Number(slider.min))+'%');if(input.dataset.live==='1')input.dispatchEvent(new Event('input',{bubbles:true}));};
    input.precisionSync=()=>{slider.value=input.value;};slider.onchange=()=>commit(Number(slider.value));input.addEventListener('input',input.precisionSync);input.addEventListener('change',input.precisionSync);
   }else{const scrub=document.createElement('button');scrub.type='button';scrub.className='precision-scrub';scrub.textContent='↔ Drag to adjust';scrub.setAttribute('aria-label','Scrub '+label);wrap.append(scrub);
    scrub.onpointerdown=e=>{if(e.button!==0)return;e.preventDefault();scrub.setPointerCapture(e.pointerId);const x=e.clientX,value=Number(input.value);let next=value;
     const move=event=>{next=value+Math.round((event.clientX-x)/(event.shiftKey?20:4))*step;input.value=next;};
     const done=()=>{scrub.removeEventListener('pointermove',move);scrub.removeEventListener('pointerup',done);scrub.removeEventListener('pointercancel',cancel);commit(next);};const cancel=()=>{next=value;done();};scrub.addEventListener('pointermove',move);scrub.addEventListener('pointerup',done,{once:true});scrub.addEventListener('pointercancel',cancel,{once:true});};
   }
  }else if(input.matches('input[type="range"]')&&!input.matches('[data-audio-seek],.precision-slider')){
   input.dataset.enhanced='1';const exact=document.createElement('input');exact.type='number';exact.dataset.enhanced='1';exact.className='range-exact';for(const key of ['min','max','step','value'])exact[key]=input[key];exact.setAttribute('aria-label',labelFor(input)+' exact value');input.after(exact);
   input.precisionSync=()=>{if(document.activeElement!==exact)exact.value=input.value;};input.addEventListener('input',input.precisionSync);exact.onchange=()=>{input.value=exact.value;exact.value=input.value;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));};
  }else if(input.matches('select')&&input.options.length>12&&!input.multiple){
   input.dataset.enhanced='1';const search=document.createElement('input');search.type='search';search.className='choice-search';search.placeholder='Filter choices…';search.setAttribute('aria-label','Filter '+labelFor(input));
   search.oninput=()=>{const q=search.value.toLowerCase();for(const option of input.options)option.hidden=option.value!==input.value&&!option.textContent.toLowerCase().includes(q);};input.addEventListener('change',()=>{search.value='';for(const option of input.options)option.hidden=false;});input.before(search);
  }
 }
 const scan=node=>{if(!node.querySelectorAll)return;if(node.matches?.('input[type="number"],input[type="range"],select'))upgrade(node);for(const input of node.querySelectorAll('input[type="number"],input[type="range"],select'))upgrade(input);};
 scanControls=scan;scan(root);const observer=new MutationObserver(records=>{for(const record of records)for(const node of record.addedNodes)if(node.nodeType===1&&!node.closest('.precision-control'))pending.add(node);if(!frame&&pending.size)frame=requestAnimationFrame(()=>{frame=0;if(closed)return;for(const node of pending)if(node.isConnected)scan(node);pending.clear();});});observer.observe(root,{childList:true,subtree:true});
 // A vertical gesture starting on a range must scroll its panel without editing it.
 let touch=null;
 const start=e=>{const input=e.target.closest?.('input[type="range"]');if(e.pointerType!=='touch'||!input||input.disabled)return;e.preventDefault();e.stopImmediatePropagation();touch={input,id:e.pointerId,x:e.clientX,y:e.clientY,value:input.value,editing:false};};
 const move=e=>{if(!touch||e.pointerId!==touch.id)return;const t=touch,dx=e.clientX-t.x,dy=e.clientY-t.y;if(!t.editing){if(Math.abs(dy)>8&&Math.abs(dy)>=Math.abs(dx)){touch=null;return;}if(Math.abs(dx)<8)return;t.editing=true;t.input.focus({preventScroll:true});t.input.onpointerdown?.(e);t.input.setPointerCapture(e.pointerId);}e.preventDefault();const r=t.input.getBoundingClientRect(),min=Number(t.input.min)||0,max=t.input.max===''?100:Number(t.input.max),step=t.input.step==='any'?0:Number(t.input.step)||1;let value=min+Math.max(0,Math.min(1,(e.clientX-r.left)/r.width))*(max-min);if(step)value=min+Math.round((value-min)/step)*step;t.input.value=value;t.input.dispatchEvent(new Event('input',{bubbles:true}));};
 const end=e=>{if(!touch||e.pointerId!==touch.id)return;const t=touch;touch=null;if(t.editing){if(e.type==='pointercancel'){t.input.value=t.value;t.input.dispatchEvent(new Event('input',{bubbles:true}));}t.input.dispatchEvent(new Event('change',{bubbles:true}));}};
 const nativeChange=e=>{if(touch&&e.target===touch.input&&!touch.editing){touch.input.value=touch.value;e.stopImmediatePropagation();}};
 root.addEventListener('input',nativeChange,true);root.addEventListener('change',nativeChange,true);
 root.addEventListener('pointerdown',start,true);window.addEventListener('pointermove',move,{passive:false});window.addEventListener('pointerup',end);window.addEventListener('pointercancel',end);
 const close=()=>{closed=true;touch=null;if(scanControls===scan)scanControls=()=>{};observer.disconnect();cancelAnimationFrame(frame);pending.clear();root.removeEventListener('input',nativeChange,true);root.removeEventListener('change',nativeChange,true);root.removeEventListener('pointerdown',start,true);window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',end);window.removeEventListener('pointercancel',end);window.removeEventListener('pagehide',close);};window.addEventListener('pagehide',close,{once:true});return close;
}
