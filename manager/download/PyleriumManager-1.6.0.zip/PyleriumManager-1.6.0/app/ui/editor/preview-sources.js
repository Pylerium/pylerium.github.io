/** Resolve codec failures once per source, without blocking the animation loop. */
export class PreviewSources {
 constructor(onReady,onError){this.onReady=onReady;this.onError=onError;this.sources=new Map();this.controller=new AbortController();}
 resolve(url){const entry=this.sources.get(url);return entry?entry.url:null;}
 has(url){return this.sources.has(url);}
 prepare(url){
  if(this.sources.has(url))return;
  const match=/^\/api\/video\/media\/([a-z0-9_]+)$/.exec(url);if(!match){this.onError('This media could not be decoded. Reimport the source.');return;}
  const entry={url:null};this.sources.set(url,entry);
  const target='/api/video/preview/'+match[1],signal=this.controller.signal;
  (async()=>{
   while(!signal.aborted){
    const response=await fetch(target,{signal});
    if(response.status===202){await new Promise(resolve=>{const done=()=>{clearTimeout(timer);signal.removeEventListener('abort',done);resolve();};const timer=setTimeout(done,1000);signal.addEventListener('abort',done,{once:true});});continue;}
    if(!response.ok){const error=await response.json();throw Error(error.error||'Preview preparation failed.');}
    // Headers are sufficient; the media element performs its own byte-range requests.
    await response.body?.cancel();entry.url=target;this.onReady();return;
   }
  })().catch(error=>{if(error.name!=='AbortError')this.onError(error.message);});
 }
 dispose(){this.controller.abort();this.sources.clear();}
}
