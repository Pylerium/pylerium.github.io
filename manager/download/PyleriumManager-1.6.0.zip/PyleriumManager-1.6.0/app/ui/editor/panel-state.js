/** Preserve disclosure layout before restoring scroll; browsers otherwise clamp it. */
export function retainPanelState(root){
 const scroll=root.scrollTop,states=new Map();
 const key=node=>node.querySelector(':scope > summary')?.textContent.trim();
 for(const details of root.querySelectorAll('details'))states.set(key(details),details.open);
 return ()=>{for(const details of root.querySelectorAll('details'))if(states.has(key(details)))details.open=states.get(key(details));root.scrollTop=scroll;};
}
