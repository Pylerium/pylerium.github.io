/** Only active picture tracks own decoders; all share the parent playback clock. */
import {duration,fadeGain} from './model.js';
export class LayerPreviews{
 constructor(create){this.create=create;this.entries=new Map();this.visible=[];}
 prepare(project,time,playing,players,width,height){
  this.visible=[];const active=new Set();let ready=true;
  for(const item of [...(project.overlays||[])].sort((a,b)=>a.layer-b.layer)){
   const local=time-item.start;if(local<0||local>=duration(item))continue;active.add(item.id);
   let entry=this.entries.get(item.id);
   const gain=fadeGain(item,local,duration(item));
   const clip={...item,fadeIn:0,fadeOut:0,volume:(item.volume??1)*gain};
   const document={...project,clips:[clip],overlays:[],sounds:[],texts:[],markers:[]};
   if(!entry){entry={document,preview:this.create(()=>entry.document)};this.entries.set(item.id,entry);}
   entry.document=document;const child=entry.preview;child.renderSize={w:Math.max(2,Math.round(width*item.boxW/2)*2),h:Math.max(2,Math.round(height*item.boxH/2)*2)};child.time=local;child.playing=playing;child.ready=true;child.activePlayers=players;child.draw();
   if(!child.ready)ready=false;this.visible.push({item,child,gain});
  }
  for(const [id,entry] of this.entries)if(!active.has(id)){entry.preview.dispose();this.entries.delete(id);}
  return ready;
 }
 draw(ctx,w,h){for(const {item,child,gain} of this.visible){ctx.save();ctx.globalAlpha=item.opacity*gain;ctx.drawImage(child.canvas,w*item.boxX,h*item.boxY,w*item.boxW,h*item.boxH);ctx.restore();}}
 pause(){for(const {preview} of this.entries.values())preview.pause();}
 dispose(){for(const {preview} of this.entries.values())preview.dispose();this.entries.clear();this.visible=[];}
}
