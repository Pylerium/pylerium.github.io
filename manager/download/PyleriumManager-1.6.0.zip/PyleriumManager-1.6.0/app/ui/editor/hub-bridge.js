// Hub extras for the Edit Studio (kept out of the editor's own files):
//  • after an export, "Put on an app" makes the MP4 that app's video on your site
//  • /editor/?find=<text> opens with the media library filtered (Promo Studio links here)
const $ = id => document.getElementById(id);
const params = new URLSearchParams(location.search);

// library filter from the link
if (params.get('find')) {
  const apply = () => { const s = $('media-search'); if (!s) return; s.value = params.get('find'); s.dispatchEvent(new Event('input', { bubbles: true })); };
  setTimeout(apply, 600); setTimeout(apply, 1800);
}

// "Put on an app" next to the download link of a finished export
let apps = null;
async function mountUse() {
  const link = $('download'), job = $('job');
  if (!link || link.hidden || !/\/api\/video\/exports\/[a-f0-9]{32}$/.test(link.getAttribute('href') || '')) { $('hub-use')?.remove(); return; }
  if ($('hub-use')) return;
  apps ||= (await (await fetch('/api/video/apps')).json()).apps || [];
  if (!apps.length) return;
  const box = document.createElement('span'); box.id = 'hub-use'; box.className = 'hub-use';
  box.innerHTML = `<select aria-label="App">${apps.map(a => `<option value="${a.id}">${a.name.replace(/</g, '&lt;')}</option>`).join('')}</select><button type="button" class="primary">Use as this app’s video</button>`;
  box.querySelector('button').onclick = async () => {
    const b = box.querySelector('button'); b.disabled = true; b.textContent = 'Saving…';
    try {
      const id = link.getAttribute('href').split('/').pop();
      const r = await fetch(`/api/video/exports/${id}/use`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ appId: box.querySelector('select').value }) });
      const d = await r.json(); if (!r.ok) throw Error(d.error || 'Could not save it.');
      b.textContent = `✓ ${d.app.name}’s video (publish to put it live)`;
    } catch (e) { b.disabled = false; b.textContent = 'Use as this app’s video'; const s = $('status'); if (s) s.textContent = e.message; }
  };
  job.append(box);
}
new MutationObserver(() => mountUse().catch(() => {})).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['hidden', 'href'] });

// a little hub styling for the extras
const css = document.createElement('style');
css.textContent = `.hub-use{display:inline-flex;gap:8px;align-items:center;margin-left:10px}.hub-use select{max-width:220px}`;
document.head.append(css);
