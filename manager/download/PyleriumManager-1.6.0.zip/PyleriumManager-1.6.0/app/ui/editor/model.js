/** Pure edit operations. Source media is immutable; every operation returns a new edit. */
// getRandomValues also works on HTTP LAN connections used by the phone editor.
// These are project item identifiers; authentication tokens stay on the server.
export function uid(){
 if(typeof globalThis.crypto?.randomUUID==='function')return globalThis.crypto.randomUUID().replaceAll('-','');
 const bytes=new Uint8Array(16);globalThis.crypto.getRandomValues(bytes);
 bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;
 return Array.from(bytes,byte=>byte.toString(16).padStart(2,'0')).join('');
}
export const snap=(value,fps=30)=>Math.round(value*fps)/fps;
export const duration=c=>Math.max(0,(c.out-c.in)/(c.speed||1));
export const sequenceDuration=p=>p.clips.reduce((sum,c)=>sum+duration(c),0);
export const total=p=>Math.max(sequenceDuration(p),...(p.overlays||[]).map(c=>c.start+duration(c)));
export function empty(){return {v:1,name:'Untitled edit',aspect:'9:16',fps:30,clips:[],overlays:[],sounds:[],texts:[],markers:[],output:{resolution:1080,quality:'high'}};}
export function clipFrom(media){return {id:uid(),mediaId:media.id,in:0,out:media.kind==='image'?5:media.duration,speed:1,fit:media.kind==='image'?'contain':'cover',crop:{left:0,right:0,top:0,bottom:0},layout:'single',gap:12,padding:0,background:'#080c10',panels:[],volume:1,fadeIn:0,fadeOut:0,zoom:1,x:.5,y:.5,keyOffset:0,keys:[]};}
export function locate(project,time){if(time>=sequenceDuration(project)&&total(project)>sequenceDuration(project))return null;let start=0;for(let i=0;i<project.clips.length;i++){const clip=project.clips[i],end=start+duration(clip);if(time<end||i===project.clips.length-1)return {clip,index:i,start,local:Math.max(0,Math.min(duration(clip),time-start))};start=end;}return null;}
export function sample(item,channel,time,fallback){time+=item.keyOffset||0;const keys=(item.keys||[]).filter(k=>Number.isFinite(k[channel])).sort((a,b)=>a.time-b.time);if(!keys.length)return item[channel]??fallback;if(time<=keys[0].time)return keys[0][channel];for(let i=1;i<keys.length;i++){const a=keys[i-1],b=keys[i];if(time<b.time){let u=Math.max(0,Math.min(1,(time-a.time)/(b.time-a.time)));const ease=b.easing||'smooth';if(ease==='smooth')u=u*u*(3-2*u);else if(ease==='ease-in')u*=u;else if(ease==='ease-out')u=1-(1-u)**2;else if(ease==='ease-in-out')u=u<.5?2*u*u:1-(-2*u+2)**2/2;else if(ease==='sine')u=(1-Math.cos(Math.PI*u))/2;else if(ease==='cubic')u=u**3;else if(ease==='step')u=0;return a[channel]+(b[channel]-a[channel])*u;}}return keys.at(-1)[channel];}
export const clock=c=>c.continuity||{in:c.in,out:c.out,speed:c.speed||1,offset:0};
export const clockDuration=c=>{const r=clock(c);return (r.out-r.in)/r.speed;};
export function fadeGain(item,time,length){const offset=item.continuity?.offset||0,end=item.continuity?clockDuration(item):length,t=time+offset;return Math.max(0,Math.min(1,item.fadeIn?t/item.fadeIn:1,item.fadeOut?(end-t)/item.fadeOut:1));}
export function split(project,id,time){const category=(project.overlays||[]).some(c=>c.id===id)?'overlays':'clips',items=project[category];const index=items.findIndex(c=>c.id===id);if(index<0)throw Error('The video clip is no longer available.');if(items.length>=(category==='clips'?64:24))throw Error('An edit supports 64 video clips.');if(!Number.isFinite(time))throw Error('Choose a valid split time.');const source=items[index],start=category==='clips'?items.slice(0,index).reduce((sum,c)=>sum+duration(c),0):source.start,local=snap(time,project.fps)-start,length=duration(source);if(local<1/project.fps-1e-9||length-local<1/project.fps-1e-9)throw Error('Place the playhead inside the selected clip.');const cut=source.in+local*source.speed,reference=clock(source);
 if(source.locked)throw Error('Unlock this item before splitting it.');const left={...structuredClone(source),out:cut,continuity:{...reference}};
 const right={...structuredClone(source),id:uid(),in:cut,transition:{type:'cut',duration:.3,color:'#f06413'},continuity:{...reference,offset:reference.offset+local},keyOffset:(source.keyOffset||0)+local,panels:(source.panels||[]).map(p=>({...structuredClone(p),offset:(p.offset||0)+local*source.speed}))};
 if(category==='overlays')right.start=start+local;
 return {...project,[category]:[...items.slice(0,index),left,right,...items.slice(index+1)]};}
export function keyAt(item,time,channels,easing='smooth'){const key={time:time+(item.keyOffset||0),easing};for(const channel of channels)key[channel]=sample(item,channel,time,item[channel]);return {...item,keys:[...(item.keys||[]).filter(k=>Math.abs(k.time-key.time)>.0001),key].sort((a,b)=>a.time-b.time)};}
export function trimKeys(item,length){if(item.continuity)length=clockDuration(item);return {...item,keys:(item.keys||[]),fadeIn:Math.min(item.fadeIn||0,length/2),fadeOut:Math.min(item.fadeOut||0,length/2)};}
export function migrateMedia(project,media){return [...project.clips,...(project.overlays||[]),...[...project.clips,...(project.overlays||[])].flatMap(c=>c.panels||[]),...project.sounds].filter(item=>!media.some(m=>m.id===item.mediaId));}
