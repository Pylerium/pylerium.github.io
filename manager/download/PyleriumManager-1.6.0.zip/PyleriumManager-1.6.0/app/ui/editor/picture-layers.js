/** Timed picture tracks are independent of the magnetic main sequence. */
import {uid,clipFrom,duration,snap} from './model.js';
export const isPicture=category=>category==='clips'||category==='overlays';
export function splitSound(project,id,time){
 if(!Number.isFinite(time))throw Error('Choose a valid split time.');
 const index=project.sounds.findIndex(c=>c.id===id),source=project.sounds[index];
 if(!source||source.locked)throw Error('Select an unlocked sound to split.');
 if(project.sounds.length>=24)throw Error('An edit supports 24 sound layers.');
 const local=snap(time,project.fps)-source.start,length=source.out-source.in;
 if(local<1/project.fps-1e-9||length-local<1/project.fps-1e-9)throw Error('Place the playhead inside the selected sound.');
 const clock=source.continuity||{in:source.in,out:source.out,speed:1,offset:0},cut=source.in+local;
 const left={...structuredClone(source),out:cut,continuity:{...clock}},right={...structuredClone(source),id:uid(),in:cut,start:source.start+local,continuity:{...clock,offset:clock.offset+local}};
 return {...project,sounds:[...project.sounds.slice(0,index),left,right,...project.sounds.slice(index+1)]};
}
export function freeLayer(project,start,length,preferred=1,ignore=null){
 for(let layer=preferred;layer<=8;layer++)if(!(project.overlays||[]).some(c=>c.id!==ignore&&c.layer===layer&&start<c.start+duration(c)-1e-7&&start+length>c.start+1e-7))return layer;
 throw Error('All eight picture tracks are occupied here. Move the clip to a free time range.');
}
export function overlayFrom(project,media,time){
 const clip=clipFrom(media),start=snap(Math.max(0,Math.min(600-duration(clip),time)),project.fps);
 if(duration(clip)>600)throw Error('Trim this source to ten minutes before adding a picture layer.');
 if((project.overlays||[]).length>=24)throw Error('An edit supports 24 picture layers.');
 return {...clip,start,layer:freeLayer(project,start,duration(clip)),boxX:.55,boxY:.05,boxW:.4,boxH:.4,opacity:1};
}
export function movePicture(project,category,id,start,layer){
 const items=project[category],item=items.find(c=>c.id===id);
 if(!item||item.locked)throw Error('Unlock this clip before moving it.');
 start=snap(Math.max(0,Math.min(600-duration(item),start)),project.fps);
 project.overlays??=[];
 if(layer===0){
  if(category==='clips')return;
  let cursor=0;
  const index=project.clips.findIndex(c=>{const at=cursor;cursor+=duration(c);return c.blank&&Math.abs(at-start)<1e-7&&Math.abs(duration(c)-duration(item))<1e-7;});
  const clip={...item,blank:false};for(const key of ['start','layer','boxX','boxY','boxW','boxH','opacity'])delete clip[key];
  if(index>=0)project.clips[index]=clip;else {if(project.clips.length>=64)throw Error('The main sequence supports 64 clips.');project.clips.push(clip);}
  project.overlays=project.overlays.filter(c=>c.id!==id);return;
 }
 if(category==='clips'){
  if(item.blank)throw Error('This is an empty gap. Drag a picture clip instead.');
  if(project.overlays.length>=24)throw Error('An edit supports 24 picture layers.');
  const index=items.indexOf(item);
  // Leave a timed gap so lifting a clip never ripples the other tracks.
  items[index]={...structuredClone(item),id:uid(),blank:true,muted:true,layout:'single',panels:[],padding:0};
  project.overlays.push({...item,blank:false,start,layer:freeLayer(project,start,duration(item),layer),boxX:0,boxY:0,boxW:1,boxH:1,opacity:1});
 }else Object.assign(item,{start,layer:freeLayer(project,start,duration(item),layer,id)});
}
