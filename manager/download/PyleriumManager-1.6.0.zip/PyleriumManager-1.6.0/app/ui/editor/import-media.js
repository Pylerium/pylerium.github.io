/** One streamed upload at a time, with progress and deterministic listener cleanup. */
export function bindMediaImport({input,buttons,status,refresh,onImported}){
 let active=null,disposed=false;
 const pick=()=>{if(!active)input.click();}; // Keep the picker in the user gesture for iOS.
 for(const button of buttons)button.addEventListener('click',pick);
 const change=async()=>{
  const file=input.files[0];if(!file||active||disposed)return;
  try{
   if(!file.size)throw Error('This file is empty. Download the original from your photo library and try again.');
   if(file.size>512*1024*1024)throw Error('Choose media below 512 MB.');
   for(const button of buttons){button.disabled=true;button.setAttribute('aria-busy','true');}
   status('Uploading '+file.name+'…');
   const data=await new Promise((resolve,reject)=>{
    const xhr=new XMLHttpRequest();active=xhr;
    const finish=(error,result)=>{
     xhr.onload=xhr.onerror=xhr.onabort=xhr.ontimeout=xhr.upload.onprogress=null;
     if(active===xhr)active=null;
     error?reject(error):resolve(result);
    };
    xhr.open('POST','/api/video/import');xhr.timeout=180000;
    xhr.upload.onprogress=event=>{
     if(!event.lengthComputable)return;
     const progress=Math.round(event.loaded/event.total*100);
     status(progress===100?'Preparing '+file.name+'…':'Uploading '+file.name+' · '+progress+'%');
    };
    xhr.onload=()=>{
     let result;try{result=JSON.parse(xhr.responseText);}catch{
      finish(Error(xhr.status===413?'Choose media below 512 MB.':'The server returned an unreadable response. Check the connection and try again.'));return;
     }
     if(xhr.status<200||xhr.status>=300){finish(Error(result.error||'Media import failed.'));return;}
     if(!result.media){finish(Error('The server did not return imported media.'));return;}
     finish(null,result);
    };
    xhr.onerror=()=>finish(Error('Upload interrupted. Keep your phone connected to the same Wi-Fi as the computer and try again.'));
    xhr.ontimeout=()=>finish(Error('Import timed out. Check the media library before trying again.'));
    xhr.onabort=()=>finish(Error('Import cancelled.'));
    const form=new FormData();form.append('file',file);
    try{xhr.send(form);}catch(error){finish(error);}
   });
   if(disposed)return;
   onImported(data.media);
   try{await refresh();}catch{status('Imported '+data.media.name+'. Refresh the library when the connection returns.');return;}
   if(!disposed)status('Imported '+data.media.name+'. Choose Add video, Add image or Add sound in the media library.');
  }catch(error){if(!disposed)status(error.message);}
  finally{input.value='';for(const button of buttons){button.disabled=false;button.removeAttribute('aria-busy');}}
 };
 input.addEventListener('change',change);
 return ()=>{disposed=true;active?.abort();input.removeEventListener('change',change);for(const button of buttons)button.removeEventListener('click',pick);};
}
