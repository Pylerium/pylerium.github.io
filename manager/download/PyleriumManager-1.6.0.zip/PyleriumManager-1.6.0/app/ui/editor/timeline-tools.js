import {duration,total,uid} from './model.js';

export function joinPrevious(project,id){
 const category=(project.overlays||[]).some(c=>c.id===id)?'overlays':'clips',items=project[category];const index=items.findIndex(c=>c.id===id);if(index<1)throw Error('Select the right-hand segment of an adjacent split.');const left=items[index-1],right=items[index];
 if(left.locked||right.locked)throw Error('Unlock both segments before joining.');
 const same=(category==='clips'||left.layer===right.layer&&Math.abs(left.start+duration(left)-right.start)<1e-6)&&left.mediaId===right.mediaId&&Math.abs(left.out-right.in)<1e-6&&left.speed===right.speed&&Math.abs((left.keyOffset||0)+duration(left)-(right.keyOffset||0))<1e-6&&(left.panels||[]).every((panel,i)=>Math.abs((panel.offset||0)+duration(left)*left.speed-(right.panels?.[i]?.offset||0))<1e-6);
 const signature=clip=>{const value=structuredClone(clip);for(const key of ['id','in','out','keyOffset','continuity','transition','start'])delete value[key];for(const panel of value.panels||[])delete panel.offset;return JSON.stringify(value);};
 if(!same||signature(left)!==signature(right)||right.transition?.type&&right.transition.type!=='cut')throw Error('Join requires contiguous segments with matching sources, picture settings and keys.');
 return {...project,[category]:[...items.slice(0,index-1),{...structuredClone(left),out:right.out},...items.slice(index+1)]};
}
export function removeItem(project,category,id,ripple=false){
 const next=structuredClone(project),item=next[category].find(c=>c.id===id);if(!item)return next;if(item.locked)throw Error('Unlock this item before removing it.');const index=next[category].indexOf(item),start=category==='clips'?next.clips.slice(0,index).reduce((s,c)=>s+duration(c),0):item.start,length=category==='clips'?duration(item):0;next[category].splice(index,1);
 if(category==='clips'&&ripple){for(const kind of ['sounds','texts','overlays'])for(const layer of (next[kind]||[]))if(!layer.locked&&layer.start>=start+length-1e-8)layer.start-=length;for(const marker of next.markers||[])if(marker.time>=start+length)marker.time-=length;}
 return next;
}
export function newMarker(time){return {id:uid(),time,label:'Marker'};}
export function timecode(seconds,fps=30){const count=Math.max(0,Math.round(seconds*fps));return `${String(Math.floor(count/(3600*fps))).padStart(2,'0')}:${String(Math.floor(count/(60*fps))%60).padStart(2,'0')}:${String(Math.floor(count/fps)%60).padStart(2,'0')}:${String(count%fps).padStart(2,'0')}`;}
