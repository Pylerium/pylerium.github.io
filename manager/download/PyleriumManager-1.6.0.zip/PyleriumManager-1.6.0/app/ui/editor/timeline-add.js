import {CALLOUT_TEMPLATES,createCallout} from './callout-templates.js';
const el=(tag,text)=>{const n=document.createElement(tag);if(text)n.textContent=text;return n;};
export function openTimelineAdd({project,time,insert,action,trigger}){
 const existing=document.querySelector('.timeline-add-dialog');if(existing){existing.focus();return;}
 const dialog=el('dialog');dialog.className='timeline-add-dialog';dialog.setAttribute('aria-label','Add to timeline');
 const header=el('div');header.className='add-dialog-heading';header.append(el('h2','Add to your timeline'));
 const close=el('button','Close');close.type='button';close.onclick=()=>dialog.close();header.append(close);dialog.append(header);
 dialog.append(el('p','Choose an editable callout, or add media, a sound, a caption or a marker. Callouts start at the playhead.'));
 const quick=el('div');quick.className='add-quick-actions';
 for(const [name,key] of [['Import media','media'],['Browse sounds','sound'],['Blank caption','caption'],['Timeline marker','marker']]){
  const b=el('button',name);b.type='button';b.onclick=()=>{dialog.close();action(key);};quick.append(b);
 }dialog.append(quick);
 const controls=el('div');controls.className='add-callout-options';
 const select=(label,choices)=>{const wrap=el('label',label),input=el('select');input.setAttribute('aria-label',label);for(const [value,text] of choices){const option=el('option',text);option.value=value;input.append(option);}wrap.append(input);controls.append(wrap);return input;};
 const position=select('Callout placement',[['lower','Lower third'],['centre','Centre'],['top','Top']]);
 const motion=select('Callout animation',[['pop','Soft pop'],['slide','Slide up'],['fade','Fade'],['none','No animation']]);
 const label=el('label','Callout duration (seconds)'),duration=el('input');duration.type='number';duration.min=.5;duration.max=10;duration.step=.5;duration.value=3;duration.setAttribute('aria-label','Callout duration (seconds)');label.append(duration);controls.append(label);dialog.append(controls);
 const search=el('input');search.type='search';search.placeholder='Find Like, Subscribe, titles…';search.setAttribute('aria-label','Search callout templates');dialog.append(search);
 const message=el('p');message.className='add-callout-message';message.setAttribute('role','status');dialog.append(message);
 const grid=el('div');grid.className='callout-template-grid';dialog.append(grid);
 const draw=()=>{grid.replaceChildren();const query=search.value.trim().toLowerCase();for(const preset of CALLOUT_TEMPLATES.filter(p=>`${p.name} ${p.category} ${p.text}`.toLowerCase().includes(query))){
  const card=el('article'),preview=el('div');preview.className='callout-template-preview';preview.style.backgroundColor=preset.boxColor;preview.style.color=preset.color;
  const [title,...lines]=preset.text.split('\n');preview.append(el('strong',title),el('span',lines.join(' ')));
  const name=el('h3',preset.name),add=el('button','Add '+preset.name);add.type='button';add.onclick=()=>{try{const item=createCallout(project(),time(),preset,{position:position.value,motion:motion.value,duration:duration.value});insert(item);dialog.close();}catch(error){message.textContent=error.message;}};card.append(preview,name,add);grid.append(card);
 }if(!grid.children.length)grid.append(el('p','No matching templates. Try another word.'));};
 search.oninput=draw;draw();dialog.onclose=()=>{dialog.remove();trigger?.focus();};
 dialog.onclick=e=>{const rect=dialog.getBoundingClientRect();if(e.target===dialog&&(e.clientX<rect.left||e.clientX>rect.right||e.clientY<rect.top||e.clientY>rect.bottom))dialog.close();};
 document.body.append(dialog);dialog.showModal();search.focus();
}
