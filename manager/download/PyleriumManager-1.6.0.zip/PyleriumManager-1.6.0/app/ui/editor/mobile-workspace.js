/** Phone panels share the lower workspace; the preview never leaves the screen. */
export function bindMobileWorkspace(){
 const nav=document.createElement('nav');nav.id='mobile-workspace';nav.setAttribute('aria-label','Editor panels');
 const show=panel=>{document.body.dataset.mobilePanel=panel;for(const button of nav.querySelectorAll('button'))button.setAttribute('aria-pressed',String(button.dataset.panel===panel));};
 for(const [panel,text] of [['edit','Timeline'],['library','Media'],['inspector','Inspector'],['monitor','Monitor']]){
  const button=document.createElement('button');button.type='button';button.textContent=text;button.dataset.panel=panel;button.setAttribute('aria-controls',panel==='edit'?'timeline':panel==='monitor'?'viewer':panel);button.onclick=()=>show(panel);nav.append(button);
 }
 document.body.append(nav);show('edit');
 const heading=document.querySelector('.timeline-heading'),more=document.createElement('details');more.className='timeline-more';
 const summary=document.createElement('summary');summary.textContent='More';more.append(summary);const actions=document.createElement('div');actions.className='timeline-more-actions';more.append(actions);
 for(const selector of ['.segmented','#duplicate-item','#join-item','#add-marker','#fit-timeline','label:has(#snap-edits)','label:has(#ripple-layers)']){const item=heading.querySelector(selector);if(item)actions.append(item);}
 heading.insertBefore(more,heading.querySelector('.timeline-zoom'));
 const split=document.createElement('button');split.id='timeline-split';split.textContent='Split';split.type='button';split.onclick=()=>document.getElementById('split').click();heading.insertBefore(split,document.getElementById('delete-item'));
 const edit=document.createElement('button');edit.textContent='Edit clip';edit.type='button';edit.id='inspect-item';edit.onclick=()=>{if(matchMedia('(max-width:950px)').matches)show('inspector');else document.getElementById('inspector').scrollIntoView({block:'nearest'});};heading.insertBefore(edit,more);
 document.addEventListener('keydown',event=>{if(event.key==='Escape'){show('edit');more.open=false;}});
 return {show};
}
