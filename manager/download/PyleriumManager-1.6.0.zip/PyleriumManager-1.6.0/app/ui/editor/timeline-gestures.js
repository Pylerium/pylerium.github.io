/** Pointer gestures share one commit path for mouse, pen and touch. */
import {snap} from './model.js';
export function bindClipGesture(block,{category,item,start,length,fps,zoom,seek,select,commit,redraw,razor,split,boundaries,snapping,status}){
 block.onpointerdown=e=>{
  if(e.button!==0)return;e.preventDefault();e.stopPropagation();select();
  const scroll=block.closest('#timeline-scroll'),content=block.closest('#timeline-content');
  const at=event=>snap(Math.max(0,(event.clientX-content.getBoundingClientRect().left)/zoom),fps);
  if(razor()){try{split(at(e));}catch(error){status(error.message);}return;}
  if(item.locked){seek(Math.max(start,Math.min(start+length-1/fps,at(e))));status('Unlock this item before editing.');return;}
  const trim=e.target.dataset.trim,x=e.clientX,y=e.clientY,scrollX=scroll.scrollLeft;
  let pointer=e,delta=0,moved=false,frame=0,target=category==='clips'?0:item.layer,highlight=null;
  block.setPointerCapture(e.pointerId);block.classList.add('dragging');
  const magnet=value=>{
   if(!snapping())return value;let best=value,distance=8/zoom;
   for(const t of boundaries())if(Math.abs(t-value)<distance){distance=Math.abs(t-value);best=t;}return best;
  };
  const paint=()=>{
   frame=0;if(!moved)return;
   const box=scroll.getBoundingClientRect();
   if(pointer.clientX<box.left+28)scroll.scrollLeft-=12;
   else if(pointer.clientX>box.right-28)scroll.scrollLeft+=12;
   if(!trim){if(pointer.clientY<box.top+26)scroll.scrollTop-=8;else if(pointer.clientY>box.bottom-26)scroll.scrollTop+=8;}
   delta=snap((pointer.clientX-x+scroll.scrollLeft-scrollX)/zoom,fps);
   if(!trim)delta=snap(magnet(start+delta)-start,fps);
   if(category==='clips'||category==='overlays'){
    const lane=[...content.querySelectorAll('[data-picture-track]')].find(row=>{const r=row.getBoundingClientRect();return pointer.clientY>=r.top&&pointer.clientY<r.bottom;});
    highlight?.classList.remove('drop-target');highlight=lane;highlight?.classList.add('drop-target');target=lane?Number(lane.dataset.pictureTrack):category==='clips'?0:item.layer;
   }
   if(trim){
    const edge=trim==='in'?Math.min(length-1/fps,Math.max(-item.in/(item.speed||1),delta)):Math.max(-length+1/fps,delta);
    block.style.width=Math.max(12,(length+(trim==='in'?-edge:edge))*zoom)+'px';
    if(trim==='in')block.style.left=(start+edge)*zoom+'px';
    seek(Math.max(0,start+(trim==='in'?edge:length+edge)-1/fps));
   }else {block.style.transform=`translate(${delta*zoom}px,${pointer.clientY-y}px)`;seek(Math.max(0,start+delta));}
   frame=requestAnimationFrame(paint);
  };
  const move=event=>{pointer=event;if(Math.hypot(event.clientX-x,event.clientY-y)>5)moved=true;if(moved&&!frame)frame=requestAnimationFrame(paint);};
  const finish=cancelled=>{
   cancelAnimationFrame(frame);highlight?.classList.remove('drop-target');block.classList.remove('dragging');
   block.removeEventListener('pointermove',move);block.removeEventListener('pointerup',up);block.removeEventListener('pointercancel',cancel);block.removeEventListener('lostpointercapture',cancel);
   if(block.hasPointerCapture(e.pointerId))block.releasePointerCapture(e.pointerId);
   if(cancelled){redraw();return;}
   try{if(moved)commit({delta,target,trim});else seek(Math.max(start,Math.min(start+length-1/fps,at(e))));}catch(error){status(error.message);}
   redraw();
  };
  const up=event=>{pointer=event;if(moved){cancelAnimationFrame(frame);paint();}finish(false);},cancel=()=>finish(true);
  block.addEventListener('pointermove',move);block.addEventListener('pointerup',up);block.addEventListener('pointercancel',cancel);block.addEventListener('lostpointercapture',cancel);
 };
}
