/** Images share the compositor's media contract without opening video decoders. */
export function imageMedia(){
 const image=new Image();image.decoding='async';
 Object.defineProperties(image,{videoWidth:{get:()=>image.naturalWidth},videoHeight:{get:()=>image.naturalHeight},readyState:{get:()=>image.complete&&image.naturalWidth?4:0},duration:{get:()=>Infinity},seeking:{get:()=>false},ended:{get:()=>true}});
 image.error=null;image.addEventListener('error',()=>{image.error=Error('Image could not be loaded');});image.addEventListener('load',()=>{image.error=null;});image.currentTime=0;image.pause=()=>{};image.load=()=>{};return image;
}
