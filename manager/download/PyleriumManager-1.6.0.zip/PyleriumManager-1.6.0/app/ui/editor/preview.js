import {imageMedia} from './media.js';
import {LayerPreviews} from './layer-preview.js';
import {PreviewSources} from './preview-sources.js';
import {applyBoundary,boundaryEffect,finishFilter} from './finish.js';
import {duration,total,locate,sample,fadeGain} from './model.js';
import {cells,rectangles,sourceRect} from './layout.js';
const ratios={'9:16':9/16,'16:9':16/9,'1:1':1,'4:5':4/5};
const fade=fadeGain;
export class Preview{
 constructor(canvas,project,media,onTime,onError){
  this.canvas=canvas;this.ctx=canvas.getContext('2d');this.composition=document.createElement('canvas');this.project=project;this.media=media;this.onTime=onTime;this.onError=onError;
  this.time=0;this.playing=false;this.ready=true;this.frame=0;this.sounds=new Map();this.panels=new Map();this.bases=[];this.oriented=[];this.rate=1;this.playPending=new WeakSet();this.activePlayers=new Set();
  this.sources=new PreviewSources(()=>this.request(),message=>{this.pause();this.onError(message);this.request();});
  this.still=this.createMedia('img',true);this.video=this.createMedia('video');this.standby=this.createMedia('video',true);this.lastDraw=0;
  this.layers=new LayerPreviews(project=>{const child=new Preview(document.createElement('canvas'),project,this.media,()=>{},message=>{this.pause();this.onError(message);});child.request=()=>this.request();child.monitorMuted=this.monitorMuted;child.transparent=true;return child;});
 }
 createMedia(tag,muted=false){const element=tag==='img'?imageMedia():document.createElement(tag);element.preload='auto';element.playsInline=true;element.muted=muted;
  if(tag!=='img'){element.style.cssText='position:fixed;width:1px;height:1px;left:0;bottom:0;opacity:.001;pointer-events:none';element.setAttribute('aria-hidden','true');document.body.append(element);}
  for(const event of ['load','loadedmetadata','loadeddata','seeked','canplay','error'])element.addEventListener(event,()=>{if(event==='error'&&!this.disposed){const url=element.dataset.originalUrl||element.dataset.url;if(tag!=='img'&&url&&!this.sources.has(url))this.sources.prepare(url);else if(!this.sources.has(url)||this.sources.resolve(url)){this.pause();this.onError('This media could not be decoded. Reimport the source.');}}if(event==='loadedmetadata'&&element.dataset.preloadAt!==undefined)element.currentTime=Number(element.dataset.preloadAt);this.request();});return element;
 }
 request(){if(this.disposed)return;if(!this.frame)this.frame=requestAnimationFrame(now=>this.tick(now));}
 seek(time){this.pause();this.ready=false;this.time=Math.max(0,Math.min(total(this.project()),time));this.request();this.onTime(this.time);}
 play(){if(!this.project().clips.length)return;const end=total(this.project());if(this.time>=end)this.time=0;this.playing=true;this.ready=true;this.activePlayers.clear();this.draw();this.startPlayers();this.started=performance.now();this.offset=this.time;this.request();}
 pause(){this.playing=false;this.video.pause();this.standby.pause();this.layers.pause();for(const player of [...this.sounds.values(),...this.panels.values()])player.pause();}
 toggle(){this.playing?this.pause():this.play();this.request();}
 sync(element,url,time,speed,volume){
  element.dataset.originalUrl=url;
  if(this.sources.has(url)){const resolved=this.sources.resolve(url);if(!resolved){this.ready=false;return;}url=resolved;}
  this.activePlayers.add(element);
  if(element.dataset.url!==url){delete element.dataset.preloadAt;element.pause();if(element.tagName==='IMG')element.error=null;element.dataset.url=url;element.src=url;element.load();}
  element.playbackRate=speed*(this.rate||1);element.volume=Math.max(0,Math.min(1,volume));
  if(element.error){this.ready=false;return;}
  if(element.readyState<2||element.seeking){this.ready=false;return;}
  if(element.tagName==='IMG')return;
  const target=Math.max(0,Math.min(Number.isFinite(element.duration)?Math.max(0,element.duration-.001):time,time));
  if(Math.abs(element.currentTime-target)>(this.playing?.12:.001)){element.pause();element.currentTime=target;this.ready=false;}
 }
 startPlayers(){for(const player of this.activePlayers){if(player.ended||!player.paused||this.playPending.has(player))continue;this.playPending.add(player);player.play().then(()=>{if(!this.playing||!this.ready)player.pause();}).catch(error=>{if(this.disposed||error.name==='AbortError')return;if(error.name==='NotSupportedError'){this.sources.prepare(player.dataset.originalUrl||player.dataset.url);return;}this.pause();this.onError(error.name==='NotAllowedError'?'Playback was blocked. Press Play again to allow audio.':error.message);this.request();}).finally(()=>this.playPending.delete(player));}}
 tick(now){this.frame=0;
  if(!this.playing||now-this.lastDraw>=1000/30){const previous=this.time;if(this.playing)this.time=Math.min(total(this.project()),this.offset+(now-this.started)/1000*(this.rate||1));this.ready=true;this.activePlayers.clear();this.draw();
   if(this.playing&&!this.ready){this.time=previous;this.offset=previous;this.started=now;for(const player of this.activePlayers)player.pause();}
   else if(this.playing&&this.time>=total(this.project()))this.pause();
   else if(this.playing)this.startPlayers();
   this.onTime(this.time);this.lastDraw=now;
  }
  if(this.playing)this.request();
 }
 draw(){const p=this.project(),ratio=ratios[p.aspect],w=this.renderSize?.w||540,h=this.renderSize?.h||Math.round(w/ratio);if(this.canvas.width!==w||this.canvas.height!==h){this.canvas.width=w;this.canvas.height=h;}const ctx=this.ctx;const at=locate(p,this.time);
  const activePanels=new Set();
  if(at&&!at.clip.blank){const c=at.clip,m=this.media(c.mediaId);if(m){
   if(m.kind!=='image'&&this.video.dataset.originalUrl!==m.url&&this.standby.dataset.originalUrl===m.url){const previous=this.video;previous.pause();previous.muted=true;this.video=this.standby;this.standby=previous;this.video.muted=false;}
   const primary=m.kind==='image'?this.still:this.video;this.activeFinish=c;if(m.kind==='image')this.video.pause();const gain=(c.muted||this.monitorMuted?0:c.volume)*fade(c,at.local,duration(c))*boundaryEffect(p,this.time).audio;this.sync(primary,m.url,c.in+at.local*c.speed,c.speed,gain);
   if(this.composition.width!==w||this.composition.height!==h){this.composition.width=w;this.composition.height=h;}const composite=this.composition.getContext('2d');if(this.transparent&&(c.layout||'single')==='single'&&!c.padding)composite.clearRect(0,0,w,h);else{composite.fillStyle=c.background||'#080c10';composite.fillRect(0,0,w,h);}
   const rects=rectangles(c,w*2,h*2);
   cells(c).forEach((panel,index)=>{let video=primary;
    if(index){activePanels.add(index);const asset=this.media(panel.mediaId);if(!asset)return;video=this.panels.get(index);if(video&&((asset.kind==='image')!==(video.tagName==='IMG'))){video.pause();video.removeAttribute('src');video.load();video.remove();video=null;}if(!video){video=this.createMedia(asset.kind==='image'?'img':'video',true);this.panels.set(index,video);}this.sync(video,asset.url,Math.min(asset.duration-.02,panel.in+(panel.offset||0)+at.local*c.speed),c.speed,0);}
    const r=rects[index];this.drawCell(video,panel,index?0:at.local,{x:r.x/2,y:r.y/2,w:r.w/2,h:r.h/2},index===0,index);
   });
   const next=p.clips[at.index+1],nextMedia=next&&this.media(next.mediaId);if(nextMedia&&nextMedia.kind!=='image'&&nextMedia.url!==m.url&&this.standby.dataset.originalUrl!==nextMedia.url){this.standby.pause();this.standby.muted=true;this.standby.dataset.originalUrl=nextMedia.url;this.standby.dataset.url=nextMedia.url;this.standby.dataset.preloadAt=String(next.in);this.standby.src=nextMedia.url;this.standby.load();}
  }}
  for(const [id,video] of this.panels)if(!activePanels.has(id)){video.pause();video.removeAttribute('src');video.load();video.remove();this.panels.delete(id);}
  const active=new Set();for(const item of p.sounds){const length=item.out-item.in;if(this.time<item.start||this.time>=item.start+length)continue;const media=this.media(item.mediaId);if(!media)continue;active.add(item.id);let player=this.sounds.get(item.id);if(!player){player=this.createMedia('audio');this.sounds.set(item.id,player);}this.sync(player,media.url,item.in+this.time-item.start,1,(item.muted||this.monitorMuted?0:item.volume)*fade(item,this.time-item.start,length));}for(const [id,player] of this.sounds)if(!active.has(id)){player.pause();if(!p.sounds.some(s=>s.id===id)){player.removeAttribute('src');player.load();player.remove();this.sounds.delete(id);}}
  for(const {preview} of this.layers.entries.values())preview.monitorMuted=this.monitorMuted;
  if(!this.layers.prepare(p,this.time,this.playing,this.activePlayers,w,h))this.ready=false;
  if(!at||at.clip.blank){this.video.pause();this.standby.pause();}
  if(!this.ready)return;if(this.transparent)ctx.clearRect(0,0,w,h);else{ctx.fillStyle='#000';ctx.fillRect(0,0,w,h);}if(at&&!at.clip.blank){ctx.globalAlpha=fade(at.clip,at.local,duration(at.clip));ctx.filter=finishFilter(at.clip);ctx.drawImage(this.composition,0,0);ctx.filter='none';ctx.globalAlpha=1;}applyBoundary(ctx,p,this.time,w,h);
  this.layers.draw(ctx,w,h);
  for(const item of p.texts){if(item.muted)continue;const local=this.time-item.start;if(local<0||local>item.duration)continue;const scale=sample(item,'scale',local,1),size=w*item.size*scale,x=w*sample(item,'x',local,.5),y=h*sample(item,'y',local,.75);ctx.save();ctx.globalAlpha=sample(item,'opacity',local,1);ctx.font=`${['bold','neon','label'].includes(item.style)?700:400} ${size}px ${item.font||'Arial'}`;ctx.textAlign='center';ctx.textBaseline='middle';const lines=[];for(const paragraph of item.text.split('\n')){let line='';for(const word of paragraph.split(/\s+/)){const next=(line+' '+word).trim();if(line&&ctx.measureText(next).width>w*.88*scale){lines.push(line);line=word;}else line=next;}lines.push(line);}const boxWidth=Math.min(w,Math.max(...lines.map(line=>ctx.measureText(line).width))+size*.7),boxHeight=lines.length*size*1.15+size*.5;if(['subtitle','label'].includes(item.style)){const box=item.boxColor||'#080c10';ctx.fillStyle=box;ctx.globalAlpha*=item.boxOpacity??.86;ctx.beginPath();ctx.roundRect(x-boxWidth/2,y-boxHeight/2,boxWidth,boxHeight,size*(item.boxRadius??.18));ctx.fill();ctx.globalAlpha=sample(item,'opacity',local,1);}ctx.fillStyle=item.color;ctx.strokeStyle='#080b10';ctx.lineWidth=(item.stroke??2)*w/1080*2;if(item.style==='neon'){ctx.shadowColor=item.color;ctx.shadowBlur=size*.12;}lines.forEach((line,i)=>{const yy=y+(i-(lines.length-1)/2)*size*1.15;ctx.textAlign=item.align||'center';const xx=item.align==='left'?x-boxWidth/2+size*.35:item.align==='right'?x+boxWidth/2-size*.35:x;if((item.stroke??2)>0)ctx.strokeText(line,xx,yy);ctx.fillText(line,xx,yy);});ctx.restore();}
  if(this.guides){ctx.save();ctx.strokeStyle='#ffffff75';ctx.lineWidth=1;ctx.setLineDash([5,5]);for(const n of [1,2]){ctx.beginPath();ctx.moveTo(w*n/3,0);ctx.lineTo(w*n/3,h);ctx.moveTo(0,h*n/3);ctx.lineTo(w,h*n/3);ctx.stroke();}ctx.strokeStyle='#ffab60';ctx.strokeRect(w*.06,h*.08,w*.78,h*.7);ctx.fillStyle='#0009';ctx.fillRect(0,h*.8,w,h*.2);ctx.fillStyle='#ffc18b';ctx.font='12px Arial';ctx.fillText('Preview guide · leave room for Shorts controls',w*.06,h*.86);ctx.restore();}
 }
 drawCell(video,panel,time,rect,animated,index){
  if(video.readyState<2||!video.videoWidth)return;
  const source=sourceRect(video,panel.crop),base=this.bases[index]||(this.bases[index]=document.createElement('canvas'));
  const settings=this.activeFinish||{},rotation=settings.rotation||0;let drawable=video,sx=source.x,sy=source.y,sw=source.w,sh=source.h;
  if(rotation||settings.flipX||settings.flipY){
   const proxy=Math.min(1,1920/Math.max(sw,sh)),iw=Math.max(2,Math.round(sw*proxy)),ih=Math.max(2,Math.round(sh*proxy)),ow=rotation%180?ih:iw,oh=rotation%180?iw:ih,oriented=this.oriented[index]||(this.oriented[index]=document.createElement('canvas'));
   if(oriented.width!==ow||oriented.height!==oh){oriented.width=ow;oriented.height=oh;}const o=oriented.getContext('2d');o.clearRect(0,0,ow,oh);o.save();o.translate(ow/2,oh/2);o.scale(settings.flipX?-1:1,settings.flipY?-1:1);o.rotate(rotation*Math.PI/180);o.drawImage(video,sx,sy,sw,sh,-iw/2,-ih/2,iw,ih);o.restore();drawable=oriented;sx=0;sy=0;sw=ow;sh=oh;
  }
  if(base.width!==rect.w||base.height!==rect.h){base.width=rect.w;base.height=rect.h;}
  const b=base.getContext('2d');if(this.transparent)b.clearRect(0,0,base.width,base.height);else{b.fillStyle='#000';b.fillRect(0,0,base.width,base.height);}
  const pose=animated?panel:{...panel,keys:[],keyOffset:0},zoom=sample(pose,'zoom',time,1),cw=rect.w/zoom,ch=rect.h/zoom,x=sample(pose,'x',time,.5),y=sample(pose,'y',time,.5);
  const factor=panel.fit==='contain'?Math.min(rect.w/sw,rect.h/sh):Math.max(rect.w/sw,rect.h/sh),dw=sw*factor,dh=sh*factor;
  b.drawImage(drawable,sx,sy,sw,sh,(rect.w-dw)*x,(rect.h-dh)*y,dw,dh);

  this.composition.getContext('2d').drawImage(base,(rect.w-cw)*x,(rect.h-ch)*y,cw,ch,rect.x,rect.y,rect.w,rect.h);
 }
 dispose(){this.disposed=true;this.sources.dispose();this.pause();this.layers.dispose();cancelAnimationFrame(this.frame);for(const video of [this.video,this.standby,this.still,...this.sounds.values(),...this.panels.values()]){video.removeAttribute('src');video.load();video.remove();}this.sounds.clear();this.panels.clear();this.bases=[];this.oriented=[];}
}
