/** Editable recipes emit ordinary keys; no second animation engine. */
export function motionRecipes(item,category,length,{action,patch}){
 const root=document.createElement('div');root.className='preset-chips';const x=item.x??.5,y=item.y??.5;
 const camera={
  'Slow push':[[0,1,x,y],[1,1.2,x,y]],'Pull back':[[0,1.3,x,y],[1,1,x,y]],
  'Pan left':[[0,1.3,.85,y],[1,1.3,.15,y]],'Pan right':[[0,1.3,.15,y],[1,1.3,.85,y]],
  'Vertical reveal':[[0,1.3,x,.9],[1,1.3,x,.1]],'Quick impact':[[0,1,x,y],[.12,1.35,x,y],[.3,1.16,x,y],[1,1.22,x,y]],
  'Hold then push':[[0,1,x,y],[.5,1,x,y],[1,1.3,x,y]]};
 const titles={
  'Fade on / off':[[0,1,0,x,y],[.15,1,1,x,y],[.85,1,1,x,y],[1,1,0,x,y]],
  'Slide up':[[0,1,0,x,Math.min(1,y+.15)],[.2,1,1,x,y],[1,1,1,x,y]],
  'Slide from left':[[0,1,0,0,y],[.25,1,1,x,y],[1,1,1,x,y]],
  'Slow grow':[[0,.85,1,x,y],[1,1.1,1,x,y]],'Float':[[0,1,1,x,y],[.5,1,1,x,Math.max(0,y-.05)],[1,1,1,x,y]],
  'Shrink away':[[0,1,1,x,y],[.8,1,1,x,y],[1,.5,0,x,y]]};
 for(const [label,values] of Object.entries(category==='clips'?camera:titles)){root.append(action(label,()=>{const keys=values.map(([time,a,b,c,d])=>category==='clips'?{time:time*length,zoom:a,x:b,y:c,easing:'smooth'}:{time:time*length,scale:a,opacity:b,x:c,y:d,easing:'smooth'});patch({keys,keyOffset:0});}));}return root;
}
