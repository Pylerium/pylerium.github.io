import {retainPanelState} from './panel-state.js';

/** Keep controls alive through pointer-up/click, including blur-triggered commits. */
export class InspectorRenderer {
 constructor(root,paint){
  this.root=root;this.paint=paint;this.pointers=new Set();this.pending=false;this.rendering=false;this.timer=0;this.closed=false;
  this.down=e=>{if(root.contains(e.target))this.pointers.add(e.pointerId);};
  this.up=e=>{if(!this.pointers.delete(e.pointerId))return;clearTimeout(this.timer);this.timer=setTimeout(()=>{if(this.pending)this.request();},0);};
  this.blur=()=>{this.pointers.clear();if(this.pending)this.request();};
  document.addEventListener('pointerdown',this.down,true);window.addEventListener('pointerup',this.up);window.addEventListener('pointercancel',this.up);window.addEventListener('blur',this.blur);
 }
 request(){
  if(this.closed)return;
  if(this.pointers.size||this.rendering){this.pending=true;return;}
  this.pending=false;this.rendering=true;
  const restore=retainPanelState(this.root),scroll=[];
  for(let node=this.root.parentElement;node;node=node.parentElement)scroll.push([node,node.scrollLeft,node.scrollTop]);
  const x=window.scrollX,y=window.scrollY,active=document.activeElement;
  const controls=()=>[...this.root.querySelectorAll('input,select,textarea,button')];
  const key=n=>[n.tagName,n.type,n.getAttribute('aria-label')||n.name||n.textContent.trim()].join(':');
  const focused=this.root.contains(active)?{key:key(active),index:controls().filter(n=>key(n)===key(active)).indexOf(active),start:active.selectionStart,end:active.selectionEnd}:null;
  try{
   this.paint();restore();
   if(focused&&!active.isConnected){const next=controls().filter(n=>key(n)===focused.key)[focused.index];next?.focus({preventScroll:true});if(next&&focused.start!=null&&(next.tagName==='TEXTAREA'||['text','search','url','tel','password'].includes(next.type)))next.setSelectionRange(focused.start,focused.end);}
   for(const [node,left,top] of scroll){node.scrollLeft=left;node.scrollTop=top;}
   window.scrollTo(x,y);
  }finally{this.rendering=false;}
 }
 dispose(){this.closed=true;clearTimeout(this.timer);this.pointers.clear();document.removeEventListener('pointerdown',this.down,true);window.removeEventListener('pointerup',this.up);window.removeEventListener('pointercancel',this.up);window.removeEventListener('blur',this.blur);}
}
