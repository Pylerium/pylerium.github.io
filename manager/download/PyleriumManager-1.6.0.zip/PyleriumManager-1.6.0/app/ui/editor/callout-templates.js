import {uid,snap,total} from './model.js';
/** Ordinary caption layers: existing timing, keys, undo, preview and export apply. */
export const CALLOUT_TEMPLATES=[
 ['like','Like','Engagement','ENJOYING THIS?\nTap Like','#ffffff','#183d68'],
 ['comment','Comment','Engagement','YOUR TURN\nLeave a comment','#ffffff','#4a2865'],
 ['subscribe','Subscribe','Engagement','SUBSCRIBE\nMore ideas coming your way','#ffffff','#b82032'],
 ['bell','Notifications','Engagement','STAY IN THE LOOP\nTurn on notifications','#fff2cb','#594114'],
 ['share','Share','Engagement','PASS IT ON\nShare with a friend','#ffffff','#126052'],
 ['save','Save for later','Engagement','SAVE THIS\nCome back when you need it','#ffffff','#274e69'],
 ['follow','Follow','Engagement','FOLLOW ALONG\nBe part of the next chapter','#ffffff','#66314c'],
 ['question','Question','Engagement','WHAT WOULD YOU BUILD?\nTell us below','#ffffff','#39446e'],
 ['next','Watch next','Engagement','KEEP WATCHING\nThe next part is on the way','#ffffff','#85411b'],
 ['link','Link in description','Engagement','TRY IT YOURSELF\nLink in the description','#ffffff','#255343'],
 ['thanks','Thank you','Titles','THANKS FOR WATCHING\nSee you in the next one','#ffe1c2','#3e2b24'],
 ['title','Opening title','Titles','YOUR NEXT BIG IDEA\nStarts here','#ffffff','#172936'],
 ['lower-third','Name & role','Titles','YOUR NAME\nCreator / Developer','#ffffff','#1e3645'],
 ['chapter','Chapter card','Titles','01 / THE BEGINNING\nA new perspective','#ffffff','#35284b'],
].map(([id,name,category,text,color,boxColor])=>({id,name,category,text,color,boxColor}));

export function createCallout(project,time,template,options={}){
 if(!project.clips.length)throw Error('Add a video or image before placing a callout.');
 if(project.texts.length>=40)throw Error('An edit supports 40 caption and callout layers.');
 const preset=CALLOUT_TEMPLATES.find(p=>p.id===template?.id);if(!preset)throw Error('Choose a callout template.');
 const fps=project.fps,start=snap(Math.max(0,time),fps),remaining=(Math.floor(total(project)*fps+1e-7)-Math.round(start*fps))/fps;
 if(remaining<1/fps)throw Error('Move the playhead before the end of the edit.');
 const requested=Number(options.duration),duration=Math.min(remaining,Math.max(1/fps,snap(Number.isFinite(requested)?Math.max(.5,Math.min(10,requested)):3,fps)));
 const y={top:.2,centre:.5,lower:.76}[options.position]??.76;
 const item={id:uid(),text:preset.text,start,duration,color:preset.color,size:.052,x:.5,y,scale:1,opacity:1,style:'label',font:'Arial',align:'center',boxColor:preset.boxColor,boxOpacity:.96,boxRadius:.45,stroke:0,keys:[]};
 if(options.motion!=='none' && duration>=3/fps){
  const ramp=Math.min(.25,duration/3),hold=duration-ramp,slide=options.motion==='slide';
  item.keys=[{time:0,scale:options.motion==='fade'||slide?1:.85,opacity:0,y:slide?Math.min(.95,y+.06):y,easing:'smooth'},
   {time:ramp,scale:1,opacity:1,y,easing:'ease-out'},{time:hold,scale:1,opacity:1,y,easing:'smooth'},
   {time:duration,scale:options.motion==='fade'||slide?1:.94,opacity:0,y,easing:'ease-in'}];
 }
 return item;
}
