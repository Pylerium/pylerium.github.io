// Promo Studio: promo images and videos for any app, designed live and rendered at exact sizes (promo.mjs on the server).
// The preview is the real thing: promo/poster.html in an iframe with the same spec the renderer uses.
import { R, S, $, esc, api, toast, confirmBox, rel, MEDIA } from './core.js';

const I = n => R.icon(n);
let P = null, appId = '', style = {}, specs = {}, focus = 'cover', busy = '', dirty = false, poll = null, previewTimer = null, previewSeq = 0;
const ACC = { studio: '#2DD4BF', violet: '#A78BFA', sky: '#38BDF8', rose: '#FB7185', amber: '#FBBF24', emerald: '#34D399', lime: '#A3E635', orange: '#FB923C', indigo: '#818CF8', fuchsia: '#E879F9', cyan: '#22D3EE', red: '#F87171' };
const media = p => (p ? R.media(p, MEDIA) : '');
const ver = f => (f?.at ? `?v=${f.at}` : '');
const app = () => P?.apps.find(a => a.id === appId);
const fmt = id => P.formats.find(f => f.id === id);

export function init() {
  const root = $('#promoPanel');
  root.addEventListener('click', onClick);
  root.addEventListener('input', onInput);
  root.addEventListener('change', onInput);
  addEventListener('message', e => { if (e.data?.promoReady) e.source?.frameElement?.closest('.pm-frame')?.classList.add('ready'); });
}
export async function show(sub) {
  if (sub && sub !== appId) { appId = sub; style = null; }
  await load();
}
async function load(quiet) {
  try { P = await api('GET', '/api/promo'); } catch (e) { if (!quiet) toast(e.message, 'err'); return; }
  if (!P.apps.find(a => a.id === appId)) appId = (P.apps.find(a => a.published && a.shots.length) || P.apps[0])?.id || '';
  if (!style) style = structuredClone(app()?.style || {});
  render(); refreshSpecs(); watchJobs();
}

// ---------- the page ----------
function render() {
  const root = $('#promoPanel'); if (!P) return;
  const a = app();
  if (!a) { root.innerHTML = `<div class="card"><div class="emptystate">${I('image')}<h4>Add an app first</h4><p>Promo Studio makes images and videos from an app’s screenshots, icon and details.</p></div></div>`; return; }
  const jobsOn = P.jobs.filter(j => ['queued', 'running'].includes(j.state));
  root.innerHTML = `
  <div class="pm-top">
    <div class="pm-apps">${P.apps.map(x => `<button type="button" class="pm-app${x.id === appId ? ' on' : ''}" data-app="${esc(x.id)}" title="${esc(x.tagline || '')}"><span class="pm-ai">${x.iconImage ? `<img src="${esc(media(x.iconImage))}" alt="">` : I(x.glyph || 'package')}</span><span>${esc(x.name)}<small>${Object.keys(x.files).length ? `${Object.keys(x.files).length} images` : x.shots.length ? 'ready to design' : 'needs screenshots'}</small></span></button>`).join('')}</div>
    <div class="pm-tools">${tool('Images', P.tools.chrome, P.tools.chrome ? 'Chrome/Edge found' : 'Install Chrome or Edge')}${tool('Videos', P.tools.ffmpeg, P.tools.ffmpeg ? 'FFmpeg found' : 'Install FFmpeg (winget install ffmpeg)')}<a class="hbtn ghost sm" href="/editor/" target="_blank" rel="noopener">${I('film')}Edit Studio</a><button type="button" class="hbtn ghost sm" data-pm="settings">${I('sliders')}Settings</button></div>
  </div>
  ${jobsOn.length ? `<div class="pm-jobs">${jobsOn.map(j => `<div class="pm-job"><span class="spinner sm"></span><b>${esc(j.label)}</b><progress max="1" value="${j.progress}"></progress><small>${Math.round(j.progress * 100)}%</small><button type="button" class="act" data-cancel="${esc(j.id)}" title="Cancel">${I('x')}</button></div>`).join('')}</div>` : ''}
  ${!a.shots.length ? `<p class="note"><span>${I('info')}</span>${esc(a.name)} has no screenshots or cover yet, so designs use its icon and text. Add screenshots in the app’s Media tab and a kit is made for you automatically.</p>` : ''}
  <div class="pm-main">
    <div class="card pm-design">${designPanel(a)}</div>
    <div class="pm-stage">
      <div class="card pm-hero"><div class="card-head"><h3>${I('eye')}${esc(fmt(focus).label)} <small class="muted">${fmt(focus).w} × ${fmt(focus).h}</small></h3>
        <div class="row">${a.files[focus] ? `<a class="hbtn ghost sm" href="${esc(media(a.files[focus].file) + ver(a.files[focus]))}" download="${esc(a.id)}-${focus}.png">${I('download')}Download</a>` : ''}<button type="button" class="hbtn primary sm" data-render="${focus}"${P.tools.chrome ? '' : ' disabled'}>${busy === 'r-' + focus ? '<span class="spinner sm"></span>' : I('image')}Render this</button></div></div>
        ${frame(focus, true)}
        <p class="muted small">${esc(fmt(focus).use)}. ${a.files[focus] ? `Rendered ${esc(rel(new Date(a.files[focus].at).toISOString()))}${a.files[focus].template ? ` · ${esc(a.files[focus].template)}` : ''}.` : 'Not rendered yet.'} The preview is exactly what’s saved.</p>
      </div>
    </div>
  </div>
  <div class="card"><div class="card-head"><h3>${I('grid')}The kit <small class="muted">${Object.keys(a.files).length} of ${P.formats.length} rendered</small></h3>
    <div class="row"><button type="button" class="hbtn ghost sm" data-pick="auto">Select recommended</button><button type="button" class="hbtn ghost sm" data-pick="all">Select all</button><button type="button" class="hbtn primary sm" data-renderpick${P.tools.chrome ? '' : ' disabled'}>${I('rocket')}Render selected</button></div></div>
    <p class="sub">Click a format to design it large. Recommended for ${esc(a.name)}: ${a.auto.map(id => esc(fmt(id)?.label || id)).join(', ')}.</p>
    ${[...new Set(P.formats.map(f => f.group))].map(g => `<h4 class="pm-g">${esc(g)}</h4><div class="pm-kit">${P.formats.filter(f => f.group === g).map(f => kitCard(a, f)).join('')}</div>`).join('')}
  </div>
  ${videosCard(a)}`;
}
const tool = (l, ok, t) => `<span class="pm-tool ${ok ? 'ok' : ok === false ? 'bad' : ''}" title="${esc(t)}">${I(ok ? 'check' : 'alert')}${esc(l)}</span>`;
const picked = new Set();
function kitCard(a, f) {
  const file = a.files[f.id], on = picked.has(f.id);
  return `<div class="pm-card${f.id === focus ? ' focus' : ''}"><button type="button" class="pm-thumb" data-focus="${f.id}" style="aspect-ratio:${f.w}/${f.h}">${frame(f.id)}</button>
    <div class="pm-meta"><label class="pm-check"><input type="checkbox" data-pick1="${f.id}"${on ? ' checked' : ''}><b>${esc(f.label)}</b></label><small>${f.w}×${f.h}${file ? ` · ${I('check')}saved` : ''}</small></div>
    ${file ? `<div class="pm-acts"><a class="act" href="${esc(media(file.file) + ver(file))}" download="${esc(a.id)}-${f.id}.png" title="Download">${I('download')}</a>${f.w / f.h > 1.5 && f.w >= 1200 ? `<button type="button" class="act" data-use="cover:${esc(file.file)}" title="Use as the app’s cover">${I('image')}</button>` : ''}${f.id === 'social' ? `<button type="button" class="act" data-use="social:${esc(file.file)}" title="Use for link previews and social posts">${I('share')}</button>` : `<button type="button" class="act" data-use="screenshot:${esc(file.file)}" title="Add to the app’s screenshots">${I('plus')}</button>`}<button type="button" class="act" data-del="${esc(file.file)}" title="Delete">${I('trash')}</button></div>` : ''}</div>`;
}
// the live preview: poster.html scaled into a box of the format's shape
function frame(id, big = false) {
  const f = fmt(id), spec = specs[id];
  return `<div class="pm-frame${big ? ' big' : ''}" data-frame="${id}" style="aspect-ratio:${f.w}/${f.h}">${spec ? `<iframe tabindex="-1" loading="${big ? 'eager' : 'lazy'}" title="${esc(f.label)}" style="width:${f.w}px;height:${f.h}px" src="/promo/poster.html?r=${previewSeq}#${encodeURIComponent(JSON.stringify(spec))}"></iframe>` : '<span class="spinner"></span>'}</div>`;
}
// every preview is sized to fit its slot at the format's exact shape, then the page inside is scaled to match
function fitFrames() {
  for (const box of document.querySelectorAll('#promoPanel .pm-frame')) {
    const f = fmt(box.dataset.frame), slot = box.parentElement, big = box.classList.contains('big');
    const cs = getComputedStyle(slot), maxW = slot.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight), maxH = big ? Math.min(innerHeight * .7, 760) : 170;
    const s = Math.min(maxW / f.w, maxH / f.h);
    box.style.width = Math.floor(f.w * s) + 'px'; box.style.height = Math.floor(f.h * s) + 'px';
    const fr = box.querySelector('iframe'); if (fr) fr.style.transform = `scale(${s})`;
  }
}
addEventListener('resize', () => fitFrames());

function designPanel(a) {
  const s = style, t = s.template || 'hero';
  const seg = (k, opts, v) => `<div class="seg wide">${opts.map(([val, l]) => `<button type="button" data-set="${k}" data-v="${esc(val)}" class="${String(v) === String(val) ? 'on' : ''}">${esc(l)}</button>`).join('')}</div>`;
  const txt = (k, label, ph, hint = '') => `<label class="fld"><span>${esc(label)}${hint ? ` <small>${esc(hint)}</small>` : ''}</span><input data-k="${k}" value="${esc(s[k] ?? '')}" placeholder="${esc(ph)}"></label>`;
  const sp = specs[focus] || {};
  return `<div class="card-head"><h3>${I('palette')}Design</h3><div class="row">${dirty ? '<span class="dc-pill warn">Unsaved</span>' : ''}<button type="button" class="hbtn ghost sm" data-pm="reset" title="Back to the app’s own text and colours">${I('refresh')}Reset</button><button type="button" class="hbtn primary sm" data-pm="save">${I('save')}Save design</button></div></div>
    <div class="fld"><span>Template</span><div class="pm-tpls">${P.templates.map(x => `<button type="button" data-set="template" data-v="${x.id}" class="${t === x.id ? 'on' : ''}"><b>${esc(x.label)}</b><small>${esc(x.blurb)}</small></button>`).join('')}</div></div>
    <div class="fld"><span>Look</span>${seg('style', P.styles, s.style || 'midnight')}</div>
    <div class="fld"><span>Frame</span>${seg('frame', P.frames, s.frame || 'window')}</div>
    <div class="fld"><span>Colours</span><div class="pm-sw">${P.accents.map(k => `<button type="button" class="${(s.accent || a.accent || 'violet') === k ? 'on' : ''}" data-set="accent" data-v="${k}" style="--c:${ACC[k]}" title="${k}"></button>`).join('')}</div></div>
    ${a.shots.length ? `<div class="fld"><span>Screenshot</span><div class="pm-shots">${a.shots.map((p, i) => `<button type="button" class="${(+s.shot || 0) === i ? 'on' : ''}" data-set="shot" data-v="${i}"><img src="${esc(media(p))}" alt="" loading="lazy"></button>`).join('')}</div></div>` : ''}
    ${t === 'feature' && a.features.length ? `<label class="fld"><span>Feature</span><select data-k="featureIndex">${a.features.map((f, i) => `<option value="${i}"${(+s.featureIndex || 0) === i ? ' selected' : ''}>${esc(f.slice(0, 80))}</option>`).join('')}</select></label>
      <div class="f3"><label class="fld"><span>Zoom <small>${s.zoom || 1.6}×</small></span><input type="range" min="1" max="3" step=".1" data-k="zoom" value="${s.zoom || 1.6}"></label><label class="fld"><span>Focus left–right</span><input type="range" min="0" max="1" step=".02" data-k="fx" value="${s.fx ?? .5}"></label><label class="fld"><span>Focus top–bottom</span><input type="range" min="0" max="1" step=".02" data-k="fy" value="${s.fy ?? .25}"></label></div>` : ''}
    ${txt('headline', 'Headline', String(sp.headline || ''), 'wrap words in *stars* to highlight them')}
    ${txt('sub', 'Supporting line', String(sp.sub ?? ''))}
    <div class="f2">${txt('kicker', 'Small label', String(sp.kicker ?? 'e.g. NEW'))}${txt('pill', 'Highlight pill', String(sp.pill ?? 'e.g. Free · Pro'))}</div>
    <div class="f2">${txt('badge', 'Corner badge', 'e.g. Just launched')}${txt('url', 'Link text', String(sp.url ?? ''))}</div>
    <div class="cx-sw">${['showBrand', 'texture', 'listFeatures'].map(k => `<label class="switch"><input type="checkbox" data-k="${k}"${(k === 'listFeatures' ? s[k] : s[k] !== false) ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">${{ showBrand: 'Show the app icon', texture: 'Background grid and grain', listFeatures: 'List highlights (wide and tall formats)' }[k]}</span></label>`).join('')}</div>`;
}
function videosCard(a) {
  const v = a.videos || {};
  return `<div class="card"><div class="card-head"><h3>${I('film')}Promo videos</h3><div class="row"><label class="switch"><input type="checkbox" id="pmMusic" checked><span class="track"><i></i></span><span class="sw-lbl">Music</span></label>
    <button type="button" class="hbtn ghost sm" data-video="16:9"${P.tools.ffmpeg && P.tools.chrome ? '' : ' disabled'}>${I('monitor')}Make 16:9</button><button type="button" class="hbtn ghost sm" data-video="9:16"${P.tools.ffmpeg && P.tools.chrome ? '' : ' disabled'}>${I('phone')}Make 9:16 Short</button><button type="button" class="hbtn primary sm" data-video="both"${P.tools.ffmpeg && P.tools.chrome ? '' : ' disabled'}>${I('rocket')}Make both</button></div></div>
    <p class="sub">A 20–35 second promo from ${esc(a.name)}’s title, screenshots (slow zoom), highlights and an end card with its button, with music made on your computer. Fine-tune it in the <a href="/editor/?find=${encodeURIComponent(a.name)}" target="_blank" rel="noopener">Edit Studio</a>: cut, add captions, sounds and more.</p>
    ${!P.tools.ffmpeg ? `<p class="note lock"><span>${I('info')}</span>Videos need FFmpeg. Windows: <code>winget install ffmpeg</code> · macOS: <code>brew install ffmpeg</code>. Restart the app afterwards, or set its path in Settings.</p>` : ''}
    <div class="pm-vids">${['16:9', '9:16'].map(k => v[k] ? `<div class="pm-vid ${k === '9:16' ? 'tall' : ''}"><video src="${esc(media(v[k].file) + ver(v[k]))}" controls preload="metadata" playsinline></video><div class="pm-meta"><b>${k === '9:16' ? 'Vertical Short' : 'Widescreen'}</b><small>${Math.round(v[k].duration || 0)}s · ${esc(rel(new Date(v[k].at).toISOString()))}</small></div>
      <div class="pm-acts"><a class="act" href="${esc(media(v[k].file) + ver(v[k]))}" download="${esc(a.id)}-promo-${k === '9:16' ? 'vertical' : 'wide'}.mp4" title="Download">${I('download')}</a>${k === '16:9' ? `<button type="button" class="act" data-use="video:${esc(v[k].file)}" title="Use as the app’s video on your site">${I('video')}</button>` : ''}<a class="act" href="/editor/?find=${encodeURIComponent('promo')}" target="_blank" rel="noopener" title="Edit in the Edit Studio">${I('film')}</a><button type="button" class="act" data-del="${esc(v[k].file)}" title="Delete">${I('trash')}</button></div></div>` : '').join('') || `<p class="muted">No promo videos yet.</p>`}</div></div>`;
}

// ---------- live specs ----------
function refreshSpecs() {
  clearTimeout(previewTimer);
  previewTimer = setTimeout(async () => {
    if (!appId) return;
    try { specs = (await api('POST', '/api/promo/preview', { appId, style })).specs; } catch (e) { toast(e.message, 'err'); return; }
    previewSeq++;
    const keep = document.activeElement?.dataset?.k;
    for (const box of document.querySelectorAll('#promoPanel .pm-frame')) { const tmp = document.createElement('div'); tmp.innerHTML = frame(box.dataset.frame, box.classList.contains('big')); box.replaceWith(tmp.firstElementChild); }
    fitFrames();
    // placeholders that depend on the spec (default headline etc.)
    if (!keep) { const d = document.querySelector('#promoPanel .pm-design'); if (d) { d.innerHTML = designPanel(app()); } }
  }, 220);
}

// ---------- jobs ----------
function watchJobs() {
  clearInterval(poll);
  if (!P.jobs.some(j => ['queued', 'running'].includes(j.state))) return;
  poll = setInterval(async () => {
    if ($('main[data-view="promo"]').hidden) return;
    const was = P.jobs.filter(j => ['queued', 'running'].includes(j.state)).map(j => j.id);
    const { jobs } = await api('GET', '/api/promo/jobs').catch(() => ({ jobs: P.jobs }));
    P.jobs = jobs;
    const finished = jobs.filter(j => was.includes(j.id) && !['queued', 'running'].includes(j.state));
    for (const j of finished) toast(j.state === 'complete' ? `${j.label}: done` : j.state === 'failed' ? `${j.label}: ${j.error}` : `${j.label}: cancelled`, j.state === 'complete' ? 'ok' : 'err', 7000);
    if (finished.length || !jobs.some(j => ['queued', 'running'].includes(j.state))) { clearInterval(poll); await load(true); return; }
    for (const el of document.querySelectorAll('#promoPanel .pm-job')) { const j = jobs.find(x => el.querySelector(`[data-cancel="${x.id}"]`)); if (j) { el.querySelector('progress').value = j.progress; el.querySelector('small').textContent = Math.round(j.progress * 100) + '%'; } }
  }, 1000);
}

// ---------- events ----------
function setStyle(k, v) { style = { ...style, [k]: v }; if (v === '' || v == null) delete style[k]; dirty = true; refreshSpecs(); }
async function onClick(e) {
  const b = e.target.closest('button, [data-focus]'); if (!b) return;
  try {
    if (b.dataset.app) { if (dirty && !(await confirmBox('Leave without saving the design?', 'Your design changes for this app are not saved.', 'Leave', false))) return; appId = b.dataset.app; style = structuredClone(app().style || {}); dirty = false; picked.clear(); location.hash = '#/promo/' + appId; render(); refreshSpecs(); return; }
    if (b.dataset.focus) { focus = b.dataset.focus; render(); fitFrames(); refreshSpecs(); $('#promoPanel .pm-hero').scrollIntoView({ behavior: 'smooth', block: 'nearest' }); return; }
    if (b.dataset.set) { const v = b.dataset.set === 'shot' ? +b.dataset.v : b.dataset.v; b.parentElement.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); setStyle(b.dataset.set, v); if (b.dataset.set === 'template') { const d = document.querySelector('#promoPanel .pm-design'); d.innerHTML = designPanel(app()); } return; }
    if (b.dataset.pm === 'save') { style = (await api('PUT', '/api/promo/app/' + appId, { style })).style; dirty = false; app().style = style; toast('Design saved. Automatic kits use it too.'); document.querySelector('#promoPanel .pm-design').innerHTML = designPanel(app()); return; }
    if (b.dataset.pm === 'reset') { style = {}; dirty = true; refreshSpecs(); document.querySelector('#promoPanel .pm-design').innerHTML = designPanel(app()); return; }
    if (b.dataset.pm === 'settings') return settings();
    if (b.dataset.render) { busy = 'r-' + b.dataset.render; await renderNow([b.dataset.render]); busy = ''; return; }
    if (b.dataset.renderpick != null) { const ids = picked.size ? [...picked] : app().auto; await renderNow(ids); return; }
    if (b.dataset.pick) { picked.clear(); (b.dataset.pick === 'all' ? P.formats.map(f => f.id) : app().auto).forEach(id => picked.add(id)); render(); fitFrames(); return; }
    if (b.dataset.cancel) { await api('POST', `/api/promo/jobs/${b.dataset.cancel}/cancel`); toast('Cancelling…', 'info'); return; }
    if (b.dataset.video) {
      const aspects = b.dataset.video === 'both' ? ['16:9', '9:16'] : [b.dataset.video];
      const r = await api('POST', '/api/promo/video', { appId, aspects, music: $('#pmMusic')?.checked !== false, style });
      P.jobs.unshift(r.job); render(); fitFrames(); watchJobs(); toast('Making the promo video. Keep the app open; it takes a minute or two.', 'info', 7000); return;
    }
    if (b.dataset.use) {
      const [as, file] = b.dataset.use.split(/:(.+)/);
      const what = { cover: 'the app’s cover image', social: 'the image for link previews and social posts', screenshot: 'a new screenshot', video: 'the app’s video' }[as];
      if (!(await confirmBox(`Use this as ${what}?`, as === 'social' ? 'Links to the app (X, LinkedIn, Discord…) and posts from Connectors will show it. Publish to put it live.' : 'It’s copied into the app. Publish to put it live.', 'Use it', false))) return;
      const r = await api('POST', '/api/promo/use', { appId, file, as });
      const i = S.apps.findIndex(x => x.id === appId); if (i >= 0) S.apps[i] = r.app;
      toast('Done. Publish when you’re ready.'); load(true); return;
    }
    if (b.dataset.del) { if (!(await confirmBox('Delete this render?', 'Only the promo file is deleted; anything you already used it for keeps its copy.'))) return; P = await api('POST', '/api/promo/file/delete', { appId, file: b.dataset.del }); render(); refreshSpecs(); return; }
  } catch (x) { busy = ''; toast(x.message, 'err', 9000); }
}
async function renderNow(ids) {
  const r = await api('POST', '/api/promo/render', { appId, formats: ids, style });
  dirty = false; app().style = style;
  P.jobs.unshift(r.job); render(); fitFrames(); refreshSpecs(); watchJobs();
}
function onInput(e) {
  const t = e.target, k = t.dataset.k;
  if (t.dataset.pick1) { t.checked ? picked.add(t.dataset.pick1) : picked.delete(t.dataset.pick1); return; }
  if (!k) return;
  if (t.type === 'checkbox') return setStyle(k, t.checked);
  if (t.type === 'range') { const lbl = t.closest('label').querySelector('small'); if (lbl && k === 'zoom') lbl.textContent = t.value + '×'; return setStyle(k, +t.value); }
  if (k === 'featureIndex') return setStyle(k, +t.value);
  setStyle(k, t.value);
}
async function settings() {
  const s = P.settings, root = $('#promoPanel');
  const box = document.createElement('div'); box.className = 'overlay'; box.innerHTML = `<div class="modal pm-set"><h3>${I('sliders')}Promo settings</h3>
    <label class="switch"><input type="checkbox" id="pmAuto"${s.auto ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Make a promo kit when I upload screenshots or a cover</span></label>
    <label class="switch"><input type="checkbox" id="pmAutoV"${s.autoVideo ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">…and promo videos too (needs FFmpeg; takes a few minutes)</span></label>
    <label class="switch"><input type="checkbox" id="pmSocial"${s.useSocial ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">Use the Link preview image for link previews and social posts</span></label>
    <div class="fld"><span>Every app gets <small>plus store formats for its kind of app</small></span><div class="pm-fmts">${P.formats.map(f => `<label><input type="checkbox" value="${f.id}"${(s.formats || P.autoBase).includes(f.id) ? ' checked' : ''}>${esc(f.label)}</label>`).join('')}</div></div>
    <label class="fld"><span>FFmpeg path <small>optional, if it isn’t on PATH</small></span><input id="pmFf" value="${esc(s.ffmpegPath || '')}" placeholder="C:\\ffmpeg\\bin\\ffmpeg.exe"></label>
    <div class="row"><span class="sp"></span><button type="button" class="hbtn ghost" data-x>Cancel</button><button type="button" class="hbtn primary" data-ok>${I('save')}Save</button></div></div>`;
  document.body.append(box);
  box.addEventListener('click', async e => {
    if (e.target === box || e.target.closest('[data-x]')) return box.remove();
    if (!e.target.closest('[data-ok]')) return;
    P = await api('PUT', '/api/promo/settings', { auto: $('#pmAuto').checked, autoVideo: $('#pmAutoV').checked, useSocial: $('#pmSocial').checked, formats: [...box.querySelectorAll('.pm-fmts input:checked')].map(i => i.value), ffmpegPath: $('#pmFf').value });
    box.remove(); toast('Saved'); load(true);
  });
}

// ---------- the strip in the app editor's Media tab ----------
// Shows this app's promo kit, live progress after uploads, and one-click "use as cover / add as screenshot".
export async function editorStrip(d, onUse) {
  const box = $('#promoStrip'); if (!box) return;
  if (!d?.id) { box.innerHTML = `<p class="muted small">${I('sparkles')}Save the app, then add screenshots: a promo kit is made for it automatically.</p>`; return; }
  let o; try { o = await api('GET', '/api/promo'); } catch { box.innerHTML = ''; return; }
  const a = o.apps.find(x => x.id === d.id), job = o.jobs.find(j => j.appId === d.id && ['queued', 'running'].includes(j.state));
  const files = Object.entries(a?.files || {});
  box.innerHTML = `<div class="pm-strip"><div class="row"><b>${I('sparkles')}Promo kit</b><small class="muted">${job ? `<span class="spinner sm"></span> ${esc(job.label)} · ${Math.round(job.progress * 100)}%` : files.length ? `${files.length} images · made from these screenshots` : o.settings.auto ? 'Made automatically when you add screenshots' : 'Automatic kits are off (Promo → Settings)'}</small><span class="sp"></span><a class="hbtn ghost sm" href="#/promo/${esc(d.id)}" data-goto="promo:${esc(d.id)}">${I('palette')}Open Promo Studio</a></div>
    ${files.length ? `<div class="pm-strip-row">${files.slice(0, 8).map(([id, f]) => `<figure><img src="${esc(media(f.file) + ver(f))}" alt="" loading="lazy"><figcaption>${esc(o.formats.find(x => x.id === id)?.label || id)}</figcaption>${id === 'cover' ? `<button type="button" class="hbtn ghost sm" data-pmuse="cover:${esc(f.file)}">Use as cover</button>` : `<button type="button" class="hbtn ghost sm" data-pmuse="screenshot:${esc(f.file)}">Add as screenshot</button>`}</figure>`).join('')}</div>` : ''}</div>`;
  box.onclick = async e => {
    const b = e.target.closest('[data-pmuse]'); if (!b) return;
    const [as, file] = b.dataset.pmuse.split(/:(.+)/);
    try { const r = await api('POST', '/api/promo/copy', { appId: d.id, file }); onUse(as, r.path); toast(as === 'cover' ? 'Cover set. Save the app to keep it.' : 'Added to screenshots. Save the app to keep it.'); } catch (x) { toast(x.message, 'err'); }
  };
  if (job) setTimeout(() => { if (!$('#editor').hidden) editorStrip(d, onUse); }, 1500);
}
