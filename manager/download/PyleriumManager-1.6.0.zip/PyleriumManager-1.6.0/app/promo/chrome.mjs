// Tiny headless-Chrome driver over the DevTools protocol (no dependencies; Node 22+ for the global WebSocket).
// Renders promo images and videos frame by frame. Uses Chrome or Edge, whichever this computer has.
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const LOCAL = process.env.LOCALAPPDATA || '';
export const CANDIDATES = [
  process.env.CHROME_PATH,
  'C:/Program Files/Google/Chrome/Application/chrome.exe', 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe', LOCAL && `${LOCAL}/Google/Chrome/Application/chrome.exe`,
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', 'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', '/Applications/Chromium.app/Contents/MacOS/Chromium',
  '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge', '/snap/bin/chromium'
].filter(Boolean);
export const findChrome = () => CANDIDATES.find(p => existsSync(p)) || '';
const sleep = ms => new Promise(r => setTimeout(r, ms));

export async function launch({ port = 9333 + Math.floor(Math.random() * 500) } = {}) {
  const exe = findChrome();
  if (!exe) throw new Error('Promo images need Google Chrome or Microsoft Edge. Install either one, then try again.');
  const profile = mkdtempSync(join(tmpdir(), 'promo-chrome-'));
  const proc = spawn(exe, ['--headless=new', `--remote-debugging-port=${port}`, `--user-data-dir=${profile}`, '--hide-scrollbars', '--no-first-run',
    '--no-default-browser-check', '--disable-gpu-vsync', '--force-color-profile=srgb', '--font-render-hinting=none', '--mute-audio', '--disable-extensions', '--disable-background-networking', 'about:blank'], { stdio: 'ignore', windowsHide: true });
  let ver = null;
  for (let i = 0; i < 100 && !ver; i++) { try { ver = await (await fetch(`http://127.0.0.1:${port}/json/version`)).json(); } catch { await sleep(100); } }
  if (!ver) throw new Error('Chrome did not start');
  return {
    async page(width, height, scale = 1, { transparent = false } = {}) {
      const t = await (await fetch(`http://127.0.0.1:${port}/json/new?about:blank`, { method: 'PUT' })).json();
      const p = await connect(t.webSocketDebuggerUrl);
      await p.send('Page.enable'); await p.send('Runtime.enable');
      await p.send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: scale, mobile: false });
      await p.send('Emulation.setDefaultBackgroundColorOverride', { color: transparent ? { r: 0, g: 0, b: 0, a: 0 } : { r: 7, g: 8, b: 14, a: 1 } });
      p.close = async () => { try { await fetch(`http://127.0.0.1:${port}/json/close/${t.id}`); } catch {} p.ws.close(); };
      return p;
    },
    async close() { try { proc.kill(); } catch {} await sleep(400); try { rmSync(profile, { recursive: true, force: true }); } catch {} }
  };
}

async function connect(url) {
  const ws = new WebSocket(url);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  let id = 0; const pending = new Map(), waiters = [];
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    if (m.id && pending.has(m.id)) { const { res, rej } = pending.get(m.id); pending.delete(m.id); m.error ? rej(new Error(m.error.message)) : res(m.result); }
    else if (m.method) for (const w of [...waiters]) if (w.method === m.method) { waiters.splice(waiters.indexOf(w), 1); w.res(m.params); }
  };
  const send = (method, params = {}) => new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params })); });
  const once = method => new Promise(res => waiters.push({ method, res }));
  return {
    ws, send,
    async goto(url, { wait = 600 } = {}) { const loaded = once('Page.loadEventFired'); await send('Page.navigate', { url }); await Promise.race([loaded, sleep(15000)]); await sleep(wait); },
    async eval(expr) { const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }); if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text); return r.result.value; },
    async shot({ format = 'png', quality, clip } = {}) { const r = await send('Page.captureScreenshot', { format, ...(quality ? { quality } : {}), ...(clip ? { clip: { ...clip, scale: 1 } } : {}), captureBeyondViewport: false }); return Buffer.from(r.data, 'base64'); }
  };
}
