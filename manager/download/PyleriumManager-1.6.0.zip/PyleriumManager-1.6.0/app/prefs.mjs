// Dashboard preferences (data/prefs.json: how the dashboard looks and behaves on this computer) and data backups.
// Backups: every save keeps the previous copy of that file in data/backups (how many: prefs.keepBackups); a full backup
// bundles the data files into one JSON download, and a restore writes them back (each overwritten file is backed up first).
import { readdirSync, statSync, existsSync, readFileSync, rmSync } from 'node:fs';
import { join } from 'node:path';

// data files a backup may contain (never the delivery worker's state or anything outside data/)
const FILES = ['apps.json', 'site.json', 'supporters.json', 'submissions.json', 'connectors.json', 'alerts.json', 'promo.json', 'perks.json', 'delivery.json', 'sync.json', 'tax.json', 'licences.json', 'prefs.json', 'feed.json', 'published.json', 'config.json'];
const SECRET = ['secrets.json'];
export const DEFAULT_PREFS = {
  theme: 'midnight', accent: '', font: 'inter', scale: 100, glow: 100, gridlines: true, motion: 'full',
  start: 'live', hidden: [], toast: 'bottom-right', toastMs: 3200, shortcuts: true,
  money: { term: 'donation', icon: 'can', celebrate: 'confetti', sound: 'chime', volume: 60, notify: false, privacy: false, minAmount: 0 },
  locale: '', hour12: 'auto', keepBackups: 30
};

export function createPrefs(ctx) {
  // ctx: dataDir, backupsDir, readJson, writeJson
  const load = () => { const p = ctx.readJson('prefs.json', {}); return { ...DEFAULT_PREFS, ...p, money: { ...DEFAULT_PREFS.money, ...(p.money || {}) } }; };
  const keep = () => Math.max(3, Math.min(200, +load().keepBackups || 30));
  function backups() {
    if (!existsSync(ctx.backupsDir)) return [];
    return readdirSync(ctx.backupsDir).filter(n => n.endsWith('.json')).map(n => { const st = statSync(join(ctx.backupsDir, n)); return { file: n, of: n.replace(/-\d{4}-\d\d-\d\dT.*$/, '') + '.json', size: st.size, at: st.mtimeMs }; }).sort((a, b) => b.at - a.at);
  }
  function prune() {
    const n = keep(), byFile = new Map();
    for (const b of backups()) { const l = byFile.get(b.of) || []; l.push(b); byFile.set(b.of, l); }
    let removed = 0;
    for (const l of byFile.values()) for (const b of l.slice(n)) { rmSync(join(ctx.backupsDir, b.file), { force: true }); removed++; }
    return removed;
  }
  function summary() {
    const list = backups(), size = list.reduce((s, b) => s + b.size, 0);
    const files = FILES.filter(f => existsSync(join(ctx.dataDir, f))).map(f => ({ file: f, size: statSync(join(ctx.dataDir, f)).size, at: statSync(join(ctx.dataDir, f)).mtimeMs }));
    return { dataDir: ctx.dataDir, keep: keep(), count: list.length, size, latest: list[0]?.at || 0, files, recent: list.slice(0, 12) };
  }
  function bundle(withSecrets) {
    const files = {};
    for (const f of [...FILES, ...(withSecrets ? SECRET : [])]) { const p = join(ctx.dataDir, f); if (existsSync(p)) { try { files[f] = JSON.parse(readFileSync(p, 'utf8')); } catch {} } }
    return { kind: 'hub-backup', v: 1, created: new Date().toISOString(), secrets: !!withSecrets, files };
  }
  function restore(b) {
    if (!b || b.kind !== 'hub-backup' || b.v !== 1 || typeof b.files !== 'object') throw new Error('That file isn’t a backup made by this app.');
    const done = [];
    for (const [f, v] of Object.entries(b.files)) {
      if (![...FILES, ...SECRET].includes(f) || v === null || typeof v !== 'object') continue;
      ctx.writeJson(f, v, true); done.push(f); // the current file is kept in backups first
    }
    if (!done.length) throw new Error('The backup has no files this app can restore.');
    return done;
  }
  function route(path, M, body, url) {
    if (path === '/api/prefs' && M === 'GET') return { prefs: load(), defaults: DEFAULT_PREFS };
    if (path === '/api/prefs' && M === 'PUT') {
      const p = { ...load(), ...(body.prefs || {}) }; p.money = { ...load().money, ...(body.prefs?.money || {}) };
      ctx.writeJson('prefs.json', p, false);
      if ('keepBackups' in (body.prefs || {})) prune();
      return { prefs: load() };
    }
    if (path === '/api/prefs/reset' && M === 'POST') { ctx.writeJson('prefs.json', {}, false); return { prefs: load() }; }
    if (path === '/api/backups' && M === 'GET') return summary();
    if (path === '/api/backups/bundle' && M === 'GET') return bundle(url?.searchParams.get('secrets') === '1');
    if (path === '/api/backups/restore' && M === 'POST') return { restored: restore(body.bundle), ...summary() };
    if (path === '/api/backups/prune' && M === 'POST') return { removed: prune(), ...summary() };
    return undefined;
  }
  return { route, load, keep };
}
