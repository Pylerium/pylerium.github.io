// Edit Studio backend: the Pylerium showcase video editor's service, ported from Python (video_editor_service.py,
// video_edit_model/layout/finish/timing/layers/render.py) to zero-dependency Node.
//
//   Library: media you import + every app's screenshots, covers, videos and Promo Studio renders (read in place, never changed).
//   Edits:   versioned, validated JSON documents (data/video-editor/projects). One render job at a time, cancellable.
//   Export:  one FFmpeg graph (sequenced clips, picture layers, grids/crops, zoom/focus keys, transitions, sounds, captions).
//            Captions are drawn by headless Chrome/Edge as transparent PNGs (the Python version used Pillow).
//
// Routes: GET /editor/* (the editor page), /api/video/* (library, media with byte ranges, projects, render, jobs, exports).
// Auth: the hub token header, or the hub's SameSite=Strict cookie (so <video src> and the editor's own fetches work).
import { spawn } from 'node:child_process';
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, writeFileSync, renameSync, rmSync, statSync, readdirSync, createReadStream, createWriteStream, copyFileSync, linkSync, mkdtempSync } from 'node:fs';
import { join, extname, basename, resolve, sep } from 'node:path';
import { launch } from './promo/chrome.mjs';

const IDENT = /^[a-f0-9]{32}$/, APPID = /^app_[a-f0-9]{24}$/;
const MEDIA_EXT = new Set(['.mp4', '.webm', '.mov', '.mkv', '.mp3', '.m4a', '.wav', '.ogg', '.flac', '.aac', '.png', '.jpg', '.jpeg', '.webp']);
const IMAGE_EXT = new Set(['.png', '.jpg', '.jpeg', '.webp']);
const BROWSER_OK = new Set(['.mp4', '.webm', '.mp3', '.m4a', '.wav', '.ogg', '.png', '.jpg', '.jpeg', '.webp']);
const MIME = { '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.mkv': 'video/x-matroska', '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.wav': 'audio/wav', '.ogg': 'audio/ogg', '.flac': 'audio/flac', '.aac': 'audio/aac', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.html': 'text/html; charset=utf-8' };
const EDITOR_FILES = new Set(['index.html', 'editor.js', 'picture-layers.js', 'layer-preview.js', 'timeline-gestures.js', 'mobile-workspace.js', 'import-media.js', 'model.js', 'preview.js', 'preview-sources.js', 'inspector-state.js', 'editor.css', 'layout.js', 'layout-controls.js', 'crop-tool.js', 'media.js', 'finish.js', 'subtitles.js', 'timeline-tools.js', 'waveforms.js', 'workspace.js', 'motion.js', 'callout-templates.js', 'timeline-add.js', 'input-controls.js', 'input-controls.css', 'panel-state.js', 'hub-bridge.js']);

// ============================================================ model (video_edit_model.py)
export const ASPECTS = { '9:16': [1080, 1920], '16:9': [1920, 1080], '1:1': [1080, 1080], '4:5': [1080, 1350] };
const EASINGS = new Set(['linear', 'smooth', 'ease-in', 'ease-out', 'ease-in-out', 'sine', 'cubic', 'step']);
const HEX = /^#[0-9a-fA-F]{6}$/;
function numeric(v, min, max, name) {
  if (typeof v !== 'number' || !Number.isFinite(v) || v < min || v > max) throw new Error(`${name} must be between ${min} and ${max}.`);
  return v;
}
function cleanKeys(keys, duration, channels) {
  if (!Array.isArray(keys) || keys.length > 128) throw new Error('Use at most 128 keyframes per item.');
  const out = new Map();
  for (const key of keys) {
    if (!key || typeof key !== 'object') throw new Error('Keyframes must be objects.');
    const time = numeric(key.time, 0, duration, 'Keyframe time'), clean = { time, easing: key.easing ?? 'smooth' };
    if (!EASINGS.has(clean.easing)) throw new Error('Unsupported keyframe easing.');
    for (const [name, [a, b]] of Object.entries(channels)) if (name in key) clean[name] = numeric(key[name], a, b, name);
    out.set(time, clean);
  }
  return [...out.keys()].sort((a, b) => a - b).map(t => out.get(t));
}
export function validateProject(raw, media) {
  if (!raw || typeof raw !== 'object' || raw.v !== 1) throw new Error('Choose a version 1 video edit.');
  const fps = raw.fps ?? 30; if (![24, 30, 60].includes(fps)) throw new Error('Choose 24, 30 or 60 fps.');
  const aspect = raw.aspect ?? '9:16'; if (!ASPECTS[aspect]) throw new Error('Unsupported aspect ratio.');
  const clips = raw.clips ?? []; if (!Array.isArray(clips) || clips.length < 1 || clips.length > 64) throw new Error('An edit needs 1–64 video clips.');
  const ids = new Set();
  const ident = item => { const v = String(item.id || randomBytes(16).toString('hex')); if (v.length > 100 || ids.has(v)) throw new Error('Every timeline item needs a unique ID.'); ids.add(v); return v; };
  const result = { v: 1, name: String(raw.name ?? 'Untitled edit').slice(0, 100), fps, aspect, clips: [], sounds: [], texts: [], markers: [], output: cleanOutput(raw.output ?? {}) };
  let total = 0;
  for (const item of clips) {
    if (!item || typeof item !== 'object') throw new Error('Clips must be objects.');
    const asset = media[item.mediaId];
    if (!asset || !['video', 'image'].includes(asset.kind)) throw new Error('A video source is missing. Refresh the library and relink the clip.');
    const start = numeric(item.in ?? 0, 0, asset.duration, 'Video in point'); let end = numeric(item.out ?? asset.duration, 0, asset.duration + .05, 'Video out point');
    const speed = numeric(item.speed ?? 1, .25, 4, 'Playback speed');
    end = Math.min(end, asset.duration); const duration = (end - start) / speed;
    if (duration < 1 / fps - 1e-9) throw new Error('A clip must contain at least one output frame.');
    const fit = item.fit ?? 'cover'; if (!['cover', 'contain'].includes(fit)) throw new Error('Choose cover or contain framing.');
    const clip = { id: ident(item), mediaId: asset.id, in: start, out: Math.min(end, asset.duration), speed, fit, volume: numeric(item.volume ?? 1, 0, 2, 'Clip volume'),
      zoom: numeric(item.zoom ?? 1, 1, 3, 'Zoom'), x: numeric(item.x ?? .5, 0, 1, 'Focus X'), y: numeric(item.y ?? .5, 0, 1, 'Focus Y'), keyOffset: numeric(item.keyOffset ?? 0, 0, 14400, 'Animation source offset'),
      keys: cleanKeys(item.keys ?? [], 14400, { zoom: [1, 3], x: [0, 1], y: [0, 1] }) };
    clip.continuity = cleanClock(item.continuity, clip, asset);
    const fl = clockDuration(clip); clip.fadeIn = numeric(item.fadeIn ?? 0, 0, fl / 2, 'Fade in'); clip.fadeOut = numeric(item.fadeOut ?? 0, 0, fl / 2, 'Fade out');
    clip.blank = !!item.blank; Object.assign(clip, cleanLayout(item, media), cleanFinish(item));
    if (clip.blank) Object.assign(clip, { layout: 'single', panels: [], padding: 0, gap: 0, exposure: 0, contrast: 1, saturation: 1, rotation: 0, flipX: false, flipY: false });
    rectangles(clip, ...outputSize(result));
    result.clips.push(clip); total += duration;
  }
  result.overlays = cleanLayers(raw.overlays ?? [], media, result, ids);
  total = Math.max(total, ...result.overlays.map(c => c.start + (c.out - c.in) / c.speed));
  if (total > 600) throw new Error('Keep edits within ten minutes.');
  result.duration = Math.round(total * 1e6) / 1e6;
  const markers = raw.markers ?? []; if (!Array.isArray(markers) || markers.length > 128) throw new Error('Use at most 128 markers.');
  for (const m of markers) { if (!m || typeof m !== 'object') throw new Error('Markers must be objects.'); result.markers.push({ id: ident(m), time: numeric(m.time, 0, 600, 'Marker time'), label: String(m.label ?? 'Marker').slice(0, 100) }); }
  for (const [category, limit] of [['sounds', 24], ['texts', 40]]) {
    const items = raw[category] ?? []; if (!Array.isArray(items) || items.length > limit) throw new Error(`Use at most ${limit} ${category}.`);
    for (const item of items) {
      if (!item || typeof item !== 'object') throw new Error('Timeline layers must be objects.');
      const start = numeric(item.start ?? 0, 0, 600 - 1 / fps, 'Timeline start'); let clean;
      if (category === 'sounds') {
        const asset = media[item.mediaId]; if (!asset) throw new Error('A sound source is missing.');
        const sin = numeric(item.in ?? 0, 0, asset.duration, 'Sound in'), sout = numeric(item.out ?? asset.duration, 0, asset.duration + .05, 'Sound out');
        const duration = Math.min(Math.min(sout, asset.duration) - sin, 600 - start);
        if (duration < 1 / fps || !asset.hasAudio) throw new Error('Choose a sound source with audio and a valid range.');
        clean = { id: ident(item), mediaId: asset.id, start, in: sin, out: sin + duration, volume: numeric(item.volume ?? .7, 0, 2, 'Sound volume'), fadeIn: 0, fadeOut: 0 };
        clean.continuity = cleanClock(item.continuity, { ...clean, speed: 1 }, asset);
        const fl = clockDuration({ ...clean, speed: 1 });
        clean.fadeIn = numeric(item.fadeIn ?? 0, 0, fl / 2, 'Sound fade in'); clean.fadeOut = numeric(item.fadeOut ?? 0, 0, fl / 2, 'Sound fade out');
      } else {
        const duration = numeric(item.duration ?? 2, 1 / fps, 600 - start, 'Caption duration'), text = String(item.text ?? '').slice(0, 500);
        if (!text.trim()) throw new Error('Captions need text.');
        const color = String(item.color ?? '#ffffff'); if (!HEX.test(color)) throw new Error('Choose a hexadecimal caption colour.');
        clean = { id: ident(item), text, start, duration, color, size: numeric(item.size ?? .065, .02, .16, 'Caption size'), x: numeric(item.x ?? .5, 0, 1, 'Caption X'), y: numeric(item.y ?? .75, 0, 1, 'Caption Y'),
          scale: numeric(item.scale ?? 1, .25, 3, 'Caption scale'), opacity: numeric(item.opacity ?? 1, 0, 1, 'Caption opacity'), style: item.style ?? 'bold',
          keys: cleanKeys(item.keys ?? [], duration, { x: [0, 1], y: [0, 1], scale: [.25, 3], opacity: [0, 1] }) };
        clean.font = item.font ?? 'Arial'; clean.align = item.align ?? 'center'; clean.boxOpacity = numeric(item.boxOpacity ?? .86, 0, 1, 'Caption backplate'); clean.stroke = numeric(item.stroke ?? 2, 0, 8, 'Caption outline');
        clean.boxColor = String(item.boxColor ?? '#080c10'); if (!HEX.test(clean.boxColor)) throw new Error('Choose a hexadecimal caption backplate colour.');
        clean.boxRadius = numeric(item.boxRadius ?? .18, 0, 1, 'Caption corner rounding');
        if (!['Arial', 'Georgia', 'Consolas', 'Impact'].includes(clean.font) || !['left', 'center', 'right'].includes(clean.align)) throw new Error('Choose a supported typeface and alignment.');
        if (!['bold', 'subtitle', 'label', 'neon', 'minimal'].includes(clean.style)) throw new Error('Unsupported caption style.');
      }
      clean.locked = !!item.locked; clean.muted = !!item.muted; result[category].push(clean);
    }
  }
  return result;
}
// the same piecewise interpolation as the browser; the later key's easing controls each segment
export function expression(item, channel, clock, def) {
  clock = `((${clock})+${item.keyOffset ?? 0})`;
  const keys = (item.keys || []).filter(k => channel in k);
  if (!keys.length) return String(Number(item[channel] ?? def));
  let result = String(keys.at(-1)[channel]);
  for (let i = keys.length - 2; i >= 0; i--) {
    const a = keys[i], b = keys[i + 1], u = `max(0,min(1,((${clock})-${a.time})/${b.time - a.time}))`;
    const blend = { linear: u, smooth: `((${u})*(${u})*(3-2*(${u})))`, 'ease-in': `pow(${u},2)`, 'ease-out': `(1-pow(1-(${u}),2))`, 'ease-in-out': `if(lt(${u},0.5),2*pow(${u},2),1-pow(-2*(${u})+2,2)/2)`, sine: `((1-cos(PI*(${u})))/2)`, cubic: `pow(${u},3)`, step: '0' }[b.easing ?? 'smooth'];
    result = `if(lt((${clock}),${b.time}),(${a[channel]}+(${b[channel] - a[channel]})*(${blend})),${result})`;
  }
  return `if(lte((${clock}),${keys[0].time}),${keys[0][channel]},${result})`;
}
// ---------- timing (video_edit_timing.py)
const clock = c => c.continuity || { in: c.in, out: c.out, speed: c.speed, offset: 0 };
const clockDuration = c => { const r = clock(c); return (r.out - r.in) / r.speed; };
function cleanClock(raw, c, asset) {
  if (raw == null) return null;
  if (typeof raw !== 'object') throw new Error('Split timing must contain an original playback range.');
  const r = { in: numeric(raw.in, 0, asset.duration, 'Original source in'), out: numeric(raw.out, 0, asset.duration + .05, 'Original source out'), speed: numeric(raw.speed, .25, 4, 'Original speed'), offset: numeric(raw.offset, 0, 14400, 'Split offset') };
  r.out = Math.min(r.out, asset.duration);
  const length = (r.out - r.in) / r.speed, segment = (c.out - c.in) / c.speed;
  if (length <= 0 || Math.abs(r.speed - c.speed) > 1e-9 || r.offset + segment > length + 1e-6 || Math.abs(r.in + r.offset * r.speed - c.in) > 1e-6) throw new Error('Split timing must stay inside the original source range.');
  return r;
}
// ---------- layout (video_edit_layout.py)
export const LAYOUTS = { single: [[0, 0, 1, 1]], 'split-v': [[0, 0, .5, 1], [.5, 0, .5, 1]], 'split-h': [[0, 0, 1, .5], [0, .5, 1, .5]], 'grid-4': [[0, 0, .5, .5], [.5, 0, .5, .5], [0, .5, .5, .5], [.5, .5, .5, .5]],
  'hero-left': [[0, 0, .64, 1], [.64, 0, .36, .5], [.64, .5, .36, .5]], 'hero-top': [[0, 0, 1, .62], [0, .62, .5, .38], [.5, .62, .5, .38]], triptych: [[0, 0, 1, 1 / 3], [0, 1 / 3, 1, 1 / 3], [0, 2 / 3, 1, 1 / 3]],
  'grid-6': [[0, 0, .5, 1 / 3], [.5, 0, .5, 1 / 3], [0, 1 / 3, .5, 1 / 3], [.5, 1 / 3, .5, 1 / 3], [0, 2 / 3, .5, 1 / 3], [.5, 2 / 3, .5, 1 / 3]] };
function cleanCrop(raw) {
  if (!raw || typeof raw !== 'object') throw new Error('Crop must contain four edge values.');
  const c = Object.fromEntries(['left', 'right', 'top', 'bottom'].map(k => [k, numeric(raw[k] ?? 0, 0, .95, 'Crop ' + k)]));
  if (c.left + c.right > .95 || c.top + c.bottom > .95) throw new Error('Keep at least 5% of the source inside the crop.');
  return c;
}
function rectangles(c, width, height) {
  const even = v => Math.floor(v / 2 + .5) * 2, pad = (c.padding || 0) * width / 1080, gap = (c.gap || 0) * width / 1080;
  return LAYOUTS[c.layout || 'single'].map(([x, y, w, h]) => {
    const left = even(pad + x * (width - 2 * pad) + (x ? gap / 2 : 0)), top = even(pad + y * (height - 2 * pad) + (y ? gap / 2 : 0));
    const right = even(pad + (x + w) * (width - 2 * pad) - (x + w < .999 ? gap / 2 : 0)), bottom = even(pad + (y + h) * (height - 2 * pad) - (y + h < .999 ? gap / 2 : 0));
    if (right - left < 2 || bottom - top < 2) throw new Error('Reduce layout padding or gutter for this output format.');
    return { x: left, y: top, w: right - left, h: bottom - top };
  });
}
function cleanLayout(item, media) {
  const layout = item.layout ?? 'single'; if (!LAYOUTS[layout]) throw new Error('Unsupported showcase layout.');
  const background = item.background ?? '#080c10'; if (typeof background !== 'string' || !HEX.test(background)) throw new Error('Choose a hexadecimal layout background.');
  const r = { layout, gap: numeric(item.gap ?? 0, 0, 80, 'Grid gutter'), padding: numeric(item.padding ?? 0, 0, 120, 'Grid padding'), background, crop: cleanCrop(item.crop ?? {}), panels: [] };
  const panels = item.panels ?? []; if (!Array.isArray(panels) || panels.length > 5) throw new Error('Use at most five additional showcase panels.');
  for (const p of panels) {
    if (!p || typeof p !== 'object') throw new Error('Showcase panels must be objects.');
    const asset = media[p.mediaId]; if (!asset || !['video', 'image'].includes(asset.kind)) throw new Error('A showcase panel video is missing.');
    const fit = p.fit ?? 'cover'; if (!['cover', 'contain'].includes(fit)) throw new Error('Choose cover or contain for each panel.');
    r.panels.push({ mediaId: asset.id, in: numeric(p.in ?? 0, 0, Math.max(0, asset.duration - .05), 'Panel source in'), offset: numeric(p.offset ?? 0, 0, 14400, 'Panel time offset'), fit, crop: cleanCrop(p.crop ?? {}),
      zoom: numeric(p.zoom ?? 1, 1, 3, 'Panel zoom'), x: numeric(p.x ?? .5, 0, 1, 'Panel focus X'), y: numeric(p.y ?? .5, 0, 1, 'Panel focus Y') });
  }
  return r;
}
// ---------- finish (video_edit_finish.py)
function cleanFinish(item) {
  const t = item.transition ?? {};
  if (typeof t !== 'object' || !['cut', 'dip-black', 'dip-white', 'flash', 'dip-color'].includes(t.type ?? 'cut')) throw new Error('Choose a supported cut transition.');
  const color = t.color ?? '#f06413'; if (typeof color !== 'string' || !HEX.test(color)) throw new Error('Choose a hexadecimal transition colour.');
  const rotation = item.rotation ?? 0; if (![0, 90, 180, 270].includes(rotation)) throw new Error('Choose a quarter-turn orientation.');
  return { exposure: numeric(item.exposure ?? 0, -2, 2, 'Exposure'), contrast: numeric(item.contrast ?? 1, .5, 2, 'Contrast'), saturation: numeric(item.saturation ?? 1, 0, 2, 'Saturation'), rotation, flipX: !!item.flipX, flipY: !!item.flipY, muted: !!item.muted, locked: !!item.locked,
    transition: { type: t.type ?? 'cut', duration: numeric(t.duration ?? .3, .06, 1, 'Transition duration'), color } };
}
function cleanOutput(raw) {
  if (!raw || typeof raw !== 'object') throw new Error('Choose an export profile.');
  const resolution = raw.resolution ?? 1080, quality = raw.quality ?? 'high';
  if (![720, 1080, 1440, 2160].includes(resolution) || !['draft', 'balanced', 'high'].includes(quality)) throw new Error('Unsupported export profile.');
  return { resolution, quality };
}
const outputSize = p => { const s = (p.output?.resolution ?? 1080) / 1080; return ASPECTS[p.aspect].map(v => Math.round(v * s / 2) * 2); };
function* transitionWindows(p) {
  let cursor = 0;
  for (let i = 0; i < p.clips.length - 1; i++) {
    const left = p.clips[i], right = p.clips[i + 1], length = (left.out - left.in) / left.speed; cursor += length; const t = right.transition;
    if (t.type === 'cut') continue;
    const half = Math.min(t.duration / 2, length / 2, (right.out - right.in) / right.speed / 2);
    const color = t.type === 'dip-black' ? '#000000' : ['dip-white', 'flash'].includes(t.type) ? '#ffffff' : t.color;
    yield [cursor, half, t, color];
  }
}
function pictureFilter(item) {
  const f = [];
  if (item.rotation === 90) f.push('transpose=clock'); else if (item.rotation === 270) f.push('transpose=cclock'); else if (item.rotation === 180) f.push('hflip', 'vflip');
  if (item.flipX) f.push('hflip'); if (item.flipY) f.push('vflip');
  return f.join(',');
}
function gradeFilter(item) {
  const e = item.exposure ?? 0, c = item.contrast ?? 1, s = item.saturation ?? 1;
  if (e === 0 && c === 1 && s === 1) return '';
  const tr = `clip((val*${2 ** e}-127.5)*${c}+127.5,0,255)`, r = .2126 * (1 - s), g = .7152 * (1 - s), b = .0722 * (1 - s);
  return `format=gbrp,lutrgb=r='${tr}':g='${tr}':b='${tr}',colorchannelmixer=rr=${r + s}:rg=${g}:rb=${b}:gr=${r}:gg=${g + s}:gb=${b}:br=${r}:bg=${g}:bb=${b + s}`;
}
// ---------- picture layers (video_edit_layers.py)
function cleanLayers(items, media, project, ids) {
  if (!Array.isArray(items) || items.length > 24) throw new Error('Use at most 24 picture layers across eight tracks.');
  const result = [];
  for (const item of items) {
    if (!item || typeof item !== 'object') throw new Error('Picture layers must be objects.');
    const c = validateProject({ v: 1, clips: [item], fps: project.fps, aspect: project.aspect, output: project.output }, media).clips[0];
    if (ids.has(c.id)) throw new Error('Every timeline item needs a unique ID.'); ids.add(c.id);
    const layer = item.layer ?? 1; if (!Number.isInteger(layer) || layer < 1 || layer > 8) throw new Error('Choose picture track 1–8.');
    const length = (c.out - c.in) / c.speed;
    Object.assign(c, { start: numeric(item.start ?? 0, 0, 600 - length, 'Picture layer start'), layer, boxW: numeric(item.boxW ?? .4, .05, 1, 'Layer width'), boxH: numeric(item.boxH ?? .4, .05, 1, 'Layer height'), opacity: numeric(item.opacity ?? 1, 0, 1, 'Layer opacity') });
    c.boxX = numeric(item.boxX ?? .55, 0, 1 - c.boxW + 1e-9, 'Layer left'); c.boxY = numeric(item.boxY ?? .05, 0, 1 - c.boxH + 1e-9, 'Layer top'); c.blank = false;
    result.push(c);
  }
  for (let l = 1; l <= 8; l++) { let prev = 0; for (const c of result.filter(x => x.layer === l).sort((a, b) => a.start - b.start)) { if (c.start < prev - 1e-7) throw new Error('Clips on the same picture track cannot overlap. Choose another track.'); prev = c.start + (c.out - c.in) / c.speed; } }
  return result;
}

// ============================================================ the service
export function createVideoEditor(ctx) {
  // ctx: root (data folder), uiDir (copied editor), mediaDir, loadApps, saveApps, token, ffmpeg() → path, log
  const ROOT = ctx.root;
  for (const d of ['media', 'projects', 'exports', 'work', 'previews']) mkdirSync(join(ROOT, d), { recursive: true });
  const ffmpeg = () => ctx.ffmpeg?.() || 'ffmpeg', ffprobe = () => (ctx.ffmpeg?.() ? ctx.ffmpeg().replace(/ffmpeg(\.exe)?$/i, m => m.replace('ffmpeg', 'ffprobe')) : 'ffprobe');
  const cache = new Map(), jobs = new Map();
  let closed = false;
  const run = (bin, args, { timeout = 20000, input } = {}) => new Promise((res, rej) => {
    const p = spawn(bin, args, { windowsHide: true }); const out = [], err = [];
    const t = setTimeout(() => { p.kill(); rej(new Error(`${basename(bin)} timed out.`)); }, timeout);
    p.stdout.on('data', d => out.push(d)); p.stderr.on('data', d => err.push(d));
    p.on('error', e => { clearTimeout(t); rej(e.code === 'ENOENT' ? new Error('FFmpeg and FFprobe are needed for video editing. Install them (Windows: winget install ffmpeg · macOS: brew install ffmpeg) and restart.') : e); });
    p.on('close', code => { clearTimeout(t); code ? rej(new Error(Buffer.concat(err).toString().trim().split('\n').pop() || `${basename(bin)} failed`)) : res(Buffer.concat(out)); });
    if (input) p.stdin.end(input);
  });
  let toolsOk = null;
  const tools = () => toolsOk ??= Promise.all([run(ffmpeg(), ['-version']), run(ffprobe(), ['-version'])]).then(() => true, () => { setTimeout(() => { toolsOk = null; }, 30000); return false; });

  async function probe(path) {
    const st = statSync(path), key = `${path}|${st.mtimeMs}|${st.size}`;
    if (cache.has(key)) return { ...cache.get(key) };
    let info;
    const raw = JSON.parse((await run(ffprobe(), ['-v', 'error', '-show_entries', 'format=duration:stream=codec_type,width,height', '-of', 'json', path])).toString());
    const video = (raw.streams || []).find(s => s.codec_type === 'video');
    if (IMAGE_EXT.has(extname(path).toLowerCase())) {
      if (!video?.width || !video?.height || Math.min(video.width, video.height) < 2) throw new Error('Images must be at least two pixels wide and high.');
      if (video.width * video.height > 40e6) throw new Error('Choose an image below 40 megapixels.');
      info = { duration: 600, kind: 'image', hasAudio: false, width: video.width, height: video.height };
    } else {
      const duration = parseFloat(raw.format?.duration);
      if (!Number.isFinite(duration) || duration <= 0 || duration > 3600) throw new Error('Media must have a finite duration up to one hour.');
      info = { duration, kind: video ? 'video' : 'audio', hasAudio: (raw.streams || []).some(s => s.codec_type === 'audio'), width: video?.width || 0, height: video?.height || 0 };
      if (!video && !info.hasAudio) throw new Error('No playable audio or video was found.');
    }
    if (cache.size > 2048) cache.clear(); cache.set(key, info);
    return { ...info };
  }
  const atomic = (file, data) => { const tmp = `${file}.${randomBytes(6).toString('hex')}.tmp`; writeFileSync(tmp, JSON.stringify(data)); renameSync(tmp, file); };
  const pub = d => { const { filename, _path, ...rest } = d; return { ...rest, url: '/api/video/media/' + d.id, extension: extname(d.filename || d._path || '.webm'), poster: ['video', 'image'].includes(d.kind) ? '/api/video/poster/' + d.id : '' }; };

  async function ingest(path, name, origin = 'import') {
    const ext = extname(path).toLowerCase(); if (!MEDIA_EXT.has(ext)) throw new Error('Unsupported media container.');
    const info = await probe(path), id = randomBytes(16).toString('hex'), folder = join(ROOT, 'media', id), target = join(folder, 'source' + ext);
    mkdirSync(folder);
    try {
      try { if (resolve(path).startsWith(resolve(ROOT, 'exports'))) linkSync(path, target); else copyFileSync(path, target); } catch { copyFileSync(path, target); }
      const data = { id, name: String(name).slice(0, 150), filename: 'source' + ext, origin, created: Date.now() / 1000, ...info };
      if (info.kind === 'image') {
        await run(ffmpeg(), ['-v', 'error', '-nostdin', '-y', '-i', target, '-frames:v', '1', join(folder, 'render.png')]).catch(() => {});
        await run(ffmpeg(), ['-v', 'error', '-nostdin', '-y', '-i', target, '-frames:v', '1', '-vf', 'scale=480:-2', '-q:v', '4', join(folder, 'poster.jpg')]).catch(() => {});
      }
      if (info.kind === 'video') await run(ffmpeg(), ['-v', 'error', '-nostdin', '-y', '-ss', String(Math.min(.3, info.duration / 3)), '-i', target, '-frames:v', '1', '-vf', 'scale=320:-2', '-threads', '1', join(folder, 'poster.jpg')]).catch(() => {});
      atomic(join(folder, 'media.json'), data);
      return pub(data);
    } catch (e) { rmSync(folder, { recursive: true, force: true }); throw e; }
  }

  // your apps' own media and Promo Studio renders, read in place
  const appMediaId = rel => 'app_' + createHash('sha1').update(rel).digest('hex').slice(0, 24);
  function appFiles() {
    const out = new Map();
    for (const a of ctx.loadApps()) {
      const add = (rel, origin, label) => { if (!rel || /^https?:/i.test(rel) || !MEDIA_EXT.has(extname(rel).toLowerCase())) return; const f = join(ctx.mediaDir, rel); if (existsSync(f)) out.set(appMediaId(rel), { rel, path: f, name: `${a.name} · ${label}`, origin, app: a.id }); };
      add(a.cover, 'app media', 'cover'); (a.screenshots || []).forEach((s, i) => add(s, 'app media', `screenshot ${i + 1}`)); add(a.videoUrl, 'app media', 'video'); add(a.socialImage, 'app media', 'link preview');
      const promo = join(ctx.mediaDir, a.id, 'promo');
      if (existsSync(promo)) for (const n of readdirSync(promo)) if (!n.includes('.part.')) add(`${a.id}/promo/${n}`, 'promo studio', `promo ${basename(n, extname(n))}`);
    }
    return out;
  }
  async function media() {
    const result = [];
    for (const d of readdirSync(join(ROOT, 'media'))) {
      try { const data = JSON.parse(readFileSync(join(ROOT, 'media', d, 'media.json'), 'utf8')); asset(data.id); result.push(pub(data)); } catch {}
    }
    // probed eight at a time (cached by size and date, so later loads are instant)
    const entries = [...appFiles()];
    for (let i = 0; i < entries.length; i += 8) {
      await Promise.all(entries.slice(i, i + 8).map(async ([id, f]) => {
        try { const info = await probe(f.path); result.push({ id, name: f.name, origin: f.origin, app: f.app, created: statSync(f.path).mtimeMs / 1000, ...info, url: '/api/video/media/' + id, extension: extname(f.path), poster: ['video', 'image'].includes(info.kind) ? '/api/video/poster/' + id : '' }); } catch {}
      }));
    }
    return result.sort((a, b) => (b.created || 0) - (a.created || 0)).slice(0, 2000);
  }
  function asset(id) {
    id = String(id);
    if (APPID.test(id)) { const f = appFiles().get(id); if (!f) throw new Error('Media is unavailable.'); return f.path; }
    if (!IDENT.test(id)) throw new Error('Invalid media ID.');
    const folder = join(ROOT, 'media', id), rec = JSON.parse(readFileSync(join(folder, 'media.json'), 'utf8')), p = resolve(folder, rec.filename);
    if (!p.startsWith(resolve(ROOT, 'media') + sep) || !existsSync(p)) throw new Error('Media is unavailable.');
    return p;
  }
  const mediaMap = async () => Object.fromEntries((await media()).map(m => [m.id, m]));

  function saveProject(raw, media, id) {
    const data = validateProject(raw, media); id ||= randomBytes(16).toString('hex');
    if (!IDENT.test(id)) throw new Error('Invalid edit ID.');
    atomic(join(ROOT, 'projects', id + '.json'), { id, updated: Date.now() / 1000, project: data });
    return { id, project: data };
  }
  function projects() {
    const out = [];
    for (const n of readdirSync(join(ROOT, 'projects'))) if (n.endsWith('.json')) { try { const d = JSON.parse(readFileSync(join(ROOT, 'projects', n), 'utf8')); out.push({ id: d.id, name: d.project.name, updated: d.updated, duration: d.project.duration }); } catch {} }
    return out.sort((a, b) => b.updated - a.updated);
  }

  // ---------- captions: drawn by Chrome as transparent PNGs, matching the Python/Pillow layout ----------
  let chromeP = null;
  async function captionImages(texts, width, folder) {
    if (!texts.length) return [];
    const c = await (chromeP ||= launch());
    const out = [];
    for (const [i, t] of texts.entries()) {
      const size = Math.max(12, Math.round(width * t.size)), bold = ['bold', 'neon', 'label'].includes(t.style), stroke = Math.round((t.stroke ?? 2) * width / 1080);
      const family = { Arial: 'Arial, Helvetica, sans-serif', Georgia: 'Georgia, serif', Consolas: 'Consolas, Menlo, monospace', Impact: 'Impact, "Arial Black", sans-serif' }[t.font] || 'Arial, sans-serif';
      const box = ['subtitle', 'label'].includes(t.style), rgb = [1, 3, 5].map(k => parseInt((t.boxColor || '#080c10').slice(k, k + 2), 16));
      const p = await c.page(width, Math.max(64, size * 20), 1, { transparent: true });
      try {
        const html = `<!doctype html><meta charset="utf-8"><style>html,body{margin:0;background:transparent}#t{display:inline-block;max-width:${Math.round(width * .88)}px;padding:${Math.round(size * .35)}px;font:${bold ? 700 : 400} ${size}px/${1.15} ${family};color:${t.color};text-align:${t.align || 'center'};white-space:pre-wrap;word-wrap:break-word;
          ${stroke ? `-webkit-text-stroke:${stroke}px #080b10;paint-order:stroke fill;` : ''}${box ? `background:rgba(${rgb.join(',')},${t.boxOpacity ?? .86});border-radius:${Math.round(size * (t.boxRadius ?? .18))}px;` : ''}${t.style === 'neon' ? `text-shadow:0 0 ${Math.round(size * .12)}px ${t.color},0 0 ${Math.round(size * .3)}px ${t.color};padding:${Math.round(size * .6)}px;` : ''}}</style><div id="t"></div>`;
        await p.send('Page.navigate', { url: 'about:blank' });
        await p.eval(`document.open();document.write(${JSON.stringify(html)});document.close();document.getElementById('t').textContent=${JSON.stringify(t.text)};document.fonts.ready.then(()=>1)`);
        const r = await p.eval(`(()=>{const b=document.getElementById('t').getBoundingClientRect();return {w:Math.ceil(b.width),h:Math.ceil(b.height)}})()`);
        if (r.h > 8192) throw new Error('Reduce caption line count or font size before exporting.');
        const file = join(folder, `caption-${i}.png`);
        writeFileSync(file, await p.shot({ format: 'png', clip: { x: 0, y: 0, width: Math.max(2, r.w), height: Math.max(2, r.h) } }));
        out.push(file);
      } finally { await p.close(); }
    }
    return out;
  }
  const closeChrome = async () => { const c = chromeP; chromeP = null; if (c) (await c.catch(() => null))?.close(); };

  // ---------- the FFmpeg graph (video_edit_render.py) ----------
  let scriptOpt = null;
  const scriptOption = async () => scriptOpt ??= (await run(ffmpeg(), ['-hide_banner', '-h', 'full'], { timeout: 10000 }).catch(() => Buffer.from(''))).includes('-filter_complex_script') ? '-filter_complex_script' : '-/filter_complex';
  const tempo = speed => { const v = []; while (speed > 2) { v.push('atempo=2'); speed /= 2; } while (speed < .5) { v.push('atempo=0.5'); speed /= .5; } v.push('atempo=' + speed); return v.join(','); };
  async function renderCommand(project, media, folder, output) {
    let [width, height] = outputSize(project); const fps = project.fps, duration = project.duration;
    const base = project.clips.length, layers = [...(project.overlays || [])].sort((a, b) => a.layer - b.layer), clips = [...project.clips, ...layers];
    const sounds = project.sounds.filter(s => !s.muted && s.start < duration), texts = project.texts.filter(t => !t.muted && t.start < duration);
    const cmd = ['-hide_banner', '-loglevel', 'error', '-nostdin', '-y', '-filter_complex_threads', '1'];
    const inputOptions = (id, threads = '2') => {
      let p = asset(id);
      if (media[id].kind === 'image') { const norm = join(p, '..', 'render.png'); if (IDENT.test(id) && existsSync(norm)) p = norm; return ['-loop', '1', '-framerate', String(fps), '-threads', threads, '-i', p]; }
      return ['-threads', threads, '-i', p];
    };
    for (const c of clips) cmd.push(...(c.blank ? ['-f', 'lavfi', '-i', `color=c=black:s=${width}x${height}:r=${fps}`] : inputOptions(c.mediaId)));
    const panelIdx = new Map();
    clips.forEach((c, i) => { for (let cell = 1; cell < LAYOUTS[c.layout].length; cell++) { const panel = cell <= c.panels.length ? c.panels[cell - 1] : c; panelIdx.set(`${i},${cell}`, clips.length + panelIdx.size); cmd.push(...inputOptions(panel.mediaId, '1')); } });
    const extra = panelIdx.size;
    for (const s of sounds) cmd.push('-threads', '2', '-i', asset(s.mediaId));
    for (const f of await captionImages(texts, width, folder)) cmd.push('-loop', '1', '-framerate', String(fps), '-i', f);
    const graph = [];
    clips.forEach((c, i) => {
      let [w, h] = outputSize(project);
      if (i >= base) { w = Math.max(2, Math.round(w * c.boxW / 2) * 2); h = Math.max(2, Math.round(h * c.boxH / 2) * 2); }
      const length = (c.out - c.in) / c.speed, ref = clock(c), offset = ref.offset, originalLength = clockDuration(c), rects = rectangles(c, w, h);
      const edgeHalf = index => {
        if (i >= base || index <= 0 || index >= base) return 0;
        const prev = project.clips[index - 1], cur = project.clips[index], t = cur.transition;
        if (['cut', 'flash'].includes(t.type)) return 0;
        return Math.min(t.duration / 2, (prev.out - prev.in) / prev.speed / 2, (cur.out - cur.in) / cur.speed / 2);
      };
      let previous = null;
      if (c.layout !== 'single' || c.padding) { graph.push(`color=c=${c.background}:s=${w}x${h}:r=${fps}:d=${length},setsar=1[grid${i}]`); previous = `grid${i}`; }
      rects.forEach((rect, cell) => {
        const panel = cell === 0 || cell > c.panels.length ? c : c.panels[cell - 1], index = cell === 0 ? i : panelIdx.get(`${i},${cell}`);
        const size = `${rect.w}:${rect.h}`, crop = panel.crop, animated = cell === 0 ? panel : { ...panel, keys: [], keyOffset: 0 };
        const fx = expression(animated, 'x', 't', .5), fy = expression(animated, 'y', 't', .5);
        const framing = `scale=${size}:force_original_aspect_ratio=` + (panel.fit === 'cover' ? 'increase' : 'decrease');
        const end = cell === 0 ? `:end=${ref.out}` : '';
        const panelIn = panel === c ? ref.in : panel.in + (panel.offset || 0) - offset * c.speed;
        const sourceIn = cell ? Math.max(0, Math.min(Math.max(0, media[panel.mediaId].duration - .05), panelIn)) : panelIn;
        const delay = Math.max(0, -panelIn) / c.speed, firstFrame = Math.floor(offset * fps + .5), frameCount = Math.max(1, Math.ceil(length * fps - 1e-7));
        const pf = pictureFilter(c);
        let filters = `trim=start=${sourceIn}${end},setpts=(PTS-STARTPTS)/${c.speed}+${delay}/TB,fps=${fps}:start_time=0,tpad=stop_mode=clone:stop_duration=${originalLength},trim=start_frame=${firstFrame}:end_frame=${firstFrame + frameCount},setpts=PTS-STARTPTS`;
        filters += `,crop=w='max(2,trunc(iw*${1 - crop.left - crop.right}/2)*2)':h='max(2,trunc(ih*${1 - crop.top - crop.bottom}/2)*2)':x='trunc(iw*${crop.left}/2)*2':y='trunc(ih*${crop.top}/2)*2',${pf ? pf + ',' : ''}${framing},setsar=1`;
        let input = `[${index}:v]`;
        if (panel.fit === 'cover') filters += `,crop=${size}:x='(iw-ow)*(${fx})':y='(ih-oh)*(${fy})'`;
        else {
          const scaled = `fit${i}_${cell}`, bg = `fitbg${i}_${cell}`, fitted = `fitted${i}_${cell}`;
          graph.push(input + filters + `[${scaled}]`);
          graph.push(`color=c=${i >= base ? 'black@0' : 'black'}:s=${rect.w}x${rect.h}:r=${fps}:d=${frameCount / fps},format=rgba[${bg}]`);
          graph.push(`[${bg}][${scaled}]overlay=x='(W-w)*(${fx})':y='(H-h)*(${fy})':shortest=1[${fitted}]`);
          input = `[${fitted}]`; filters = 'null';
        }
        const zoom = expression(animated, 'zoom', `on/${fps}`, 1), x = expression(animated, 'x', `on/${fps}`, .5), y = expression(animated, 'y', `on/${fps}`, .5);
        if ((animated.keys || []).length || panel.zoom !== 1) filters += `,zoompan=z='${zoom}':x='(iw-iw/zoom)*(${x})':y='(ih-ih/zoom)*(${y})':d=1:s=${rect.w}x${rect.h}:fps=${fps}`;
        graph.push(`${input}${filters},format=${i >= base ? 'rgba' : 'yuv420p'}[tile${i}_${cell}]`);
        if (previous === null) previous = `tile${i}_${cell}`;
        else { const l = `grid${i}_${cell}`; graph.push(`[${previous}][tile${i}_${cell}]overlay=x=${rect.x}:y=${rect.y}:shortest=1[${l}]`); previous = l; }
      });
      const fadeFrame = Math.floor(offset * fps + .5), alpha = i >= base ? ':alpha=1' : '';
      let fades = `settb=expr=1/${fps},setpts=PTS+${fadeFrame}`;
      if (alpha) fades += ',format=rgba';
      if (c.fadeIn) fades += `,fade=t=in:st=0:d=${c.fadeIn}${alpha}`;
      if (c.fadeOut) fades += `,fade=t=out:st=${originalLength - c.fadeOut}:d=${c.fadeOut}${alpha}`;
      let grade = gradeFilter(c); if (i >= base) grade = grade.replace('format=gbrp', 'format=gbrap');
      if (i >= base) graph.push(`[${previous}]` + (grade ? grade + ',' : '') + `${fades},setpts=PTS-${fadeFrame},format=rgba[v${i}]`);
      else graph.push(`[${previous}]${fades},setpts=PTS-${fadeFrame}` + (grade ? ',' + grade : '') + `,format=yuv420p[v${i}]`);
      let audio;
      if (media[c.mediaId]?.hasAudio && !c.muted && !c.blank) {
        audio = `[${i}:a]atrim=start=${ref.in}:end=${ref.out},asetpts=PTS-STARTPTS,${tempo(c.speed)},aresample=48000,aformat=channel_layouts=stereo,apad,atrim=duration=${originalLength}`;
        if (c.fadeIn) audio += `,afade=t=in:st=0:d=${c.fadeIn}`;
        if (c.fadeOut) audio += `,afade=t=out:st=${originalLength - c.fadeOut}:d=${c.fadeOut}`;
        audio += `,atrim=start=${offset}:duration=${length},asetpts=PTS-STARTPTS,volume=${c.muted ? 0 : c.volume}`;
      } else audio = `anullsrc=r=48000:cl=stereo,atrim=duration=${length}`;
      if (edgeHalf(i)) audio += `,afade=t=in:st=0:d=${edgeHalf(i)}`;
      if (edgeHalf(i + 1)) audio += `,afade=t=out:st=${length - edgeHalf(i + 1)}:d=${edgeHalf(i + 1)}`;
      graph.push(audio + `[a${i}]`);
    });
    [width, height] = outputSize(project);
    graph.push(`${Array.from({ length: base }, (_, i) => `[v${i}][a${i}]`).join('')}concat=n=${base}:v=1:a=1[basev][basea]`);
    const seqLen = project.clips.reduce((s, c) => s + (c.out - c.in) / c.speed, 0);
    graph.push(`[basea]apad,atrim=duration=${duration}[sequencea]`);
    const mixes = ['[sequencea]'];
    layers.forEach((l, j) => { graph.push(`[a${base + j}]adelay=${Math.round(l.start * 1000)}:all=1[la${j}]`); mixes.push(`[la${j}]`); });
    sounds.forEach((s, i) => {
      const index = clips.length + extra + i, length = s.out - s.in, ref = clock({ ...s, speed: 1 }), ol = ref.out - ref.in;
      let chain = `[${index}:a]atrim=start=${ref.in}:end=${ref.out},asetpts=PTS-STARTPTS,aresample=48000,aformat=channel_layouts=stereo,volume=${s.muted ? 0 : s.volume}`;
      if (s.fadeIn) chain += `,afade=t=in:st=0:d=${s.fadeIn}`;
      if (s.fadeOut) chain += `,afade=t=out:st=${ol - s.fadeOut}:d=${s.fadeOut}`;
      chain += `,atrim=start=${ref.offset}:duration=${length},asetpts=PTS-STARTPTS,adelay=${Math.round(s.start * 1000)}:all=1[s${i}]`;
      graph.push(chain); mixes.push(`[s${i}]`);
    });
    graph.push(mixes.join('') + `amix=inputs=${mixes.length}:duration=first:normalize=0,alimiter=limit=0.95:latency=1[audio]`);
    let previous = 'basev';
    if (duration > seqLen) { graph.push(`[basev]tpad=stop_mode=add:stop_duration=${duration - seqLen}:color=black[paddedv]`); previous = 'paddedv'; }
    let ti = 0;
    for (const [cut, half, t, color] of transitionWindows(project)) {
      const cl = `cutcolor${ti}`, ol = `cutout${ti}`;
      let effect = `color=c=${color}:s=${width}x${height}:r=${fps}:d=${2 * half},format=rgba,fade=t=in:st=0:d=${half}:alpha=1,fade=t=out:st=${half}:d=${half}:alpha=1`;
      if (t.type === 'flash') effect += `,geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='alpha(X,Y)*alpha(X,Y)/255'`;
      graph.push(effect + `,setpts=PTS+${cut - half}/TB[${cl}]`);
      graph.push(`[${previous}][${cl}]overlay=eof_action=pass:enable='between(t,${cut - half},${cut + half})'[${ol}]`); previous = ol; ti++;
    }
    layers.forEach((l, j) => {
      const index = base + j, label = `layer${j}`, out = `layerout${j}`, w = Math.max(2, Math.round(width * l.boxW / 2) * 2), h = Math.max(2, Math.round(height * l.boxH / 2) * 2);
      graph.push(`[v${index}]scale=${w}:${h},format=rgba,colorchannelmixer=aa=${l.opacity},setpts=PTS+${l.start}/TB[${label}]`);
      const end = l.start + (l.out - l.in) / l.speed;
      graph.push(`[${previous}][${label}]overlay=x=${Math.round(width * l.boxX)}:y=${Math.round(height * l.boxY)}:eof_action=pass:enable='gte(t,${l.start})*lt(t,${end})'[${out}]`); previous = out;
    });
    texts.forEach((t, i) => {
      const index = clips.length + extra + sounds.length + i, ck = `(t-${t.start})`, local = `(T-${t.start})`;
      const scale = expression(t, 'scale', ck, 1), opacity = expression(t, 'opacity', local, 1);
      let chain = `[${index}:v]format=rgba,geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='alpha(X,Y)*(${opacity})'`;
      chain += `,scale=w='max(2,trunc(iw*(${scale})/2)*2)':h='max(2,trunc(ih*(${scale})/2)*2)':eval=frame,setsar=1[text${i}]`;
      const x = expression(t, 'x', ck, .5), y = expression(t, 'y', ck, .75);
      graph.push(chain); graph.push(`[${previous}][text${i}]overlay=x='W*(${x})-w/2':y='H*(${y})-h/2':enable='between(t,${t.start},${t.start + t.duration})':eof_action=pass[out${i}]`); previous = `out${i}`;
    });
    const script = join(folder, 'filters.txt'); writeFileSync(script, graph.join(';\n'));
    cmd.push(await scriptOption(), script, '-map', `[${previous}]`, '-map', '[audio]', '-t', String(duration), '-r', String(fps), '-c:v', 'libx264', '-preset', 'veryfast',
      '-crf', String({ draft: 26, balanced: 21, high: 18 }[project.output?.quality || 'high']), '-threads', '2', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', output);
    return cmd;
  }

  // ---------- jobs: one at a time, cancellable, with progress from ffmpeg -progress ----------
  const statusOf = id => { const j = jobs.get(id); if (!j) throw new Error('That editor job is unavailable.'); const { proc, ...rest } = j; return rest; };
  async function launchJob(kind, payload) {
    if (!payload || typeof payload !== 'object') throw new Error('Choose a valid edit or sound range.');
    if (closed) throw new Error('The editor is closing.');
    if ([...jobs.values()].some(j => ['queued', 'running', 'cancelling'].includes(j.state))) throw new Error('An editor job is already running. Finish or cancel it first.');
    if (!(await tools())) throw new Error('FFmpeg and FFprobe are needed for video editing. Install them (Windows: winget install ffmpeg · macOS: brew install ffmpeg) and restart.');
    const media = await mediaMap();
    if (kind === 'render') payload = validateProject(payload, media);
    else {
      const a = media[payload.mediaId]; if (!a || !a.hasAudio) throw new Error('Choose media containing audio.');
      const start = Number(payload.in ?? 0), end = Number(payload.out ?? a.duration);
      if (![start, end].every(Number.isFinite) || !(start >= 0 && start < end && end <= a.duration + .05)) throw new Error('Choose a valid sound range.');
      payload = { ...payload, in: start, out: Math.min(end, a.duration) };
    }
    const id = randomBytes(16).toString('hex'), job = { id, state: 'queued', progress: 0, kind, error: '', created: Date.now() / 1000 };
    jobs.set(id, job);
    for (const [k, j] of [...jobs].slice(0, -32)) if (!['queued', 'running', 'cancelling'].includes(j.state)) jobs.delete(k);
    runJob(job, payload, media);
    return statusOf(id);
  }
  async function runJob(job, payload, media) {
    const folder = mkdtempSync(join(ROOT, 'work', job.id + '-'));
    try {
      job.state = 'running';
      let output, duration, cmd;
      if (job.kind === 'sound') { output = join(folder, 'sound.m4a'); duration = payload.out - payload.in; cmd = ['-hide_banner', '-loglevel', 'error', '-nostdin', '-y', '-threads', '2', '-ss', String(payload.in), '-i', asset(payload.mediaId), '-t', String(duration), '-vn', '-c:a', 'aac', '-b:a', '192k', output]; }
      else { output = join(folder, 'edit.mp4'); duration = payload.duration; cmd = await renderCommand(payload, media, folder, output); }
      if (job.state === 'cancelling') throw Object.assign(new Error('Export cancelled.'), { cancelled: true });
      const progress = join(folder, 'progress.txt');
      cmd.splice(cmd.length - 1, 0, '-progress', progress, '-nostats');
      await new Promise((res, rej) => {
        const p = spawn(ffmpeg(), cmd, { windowsHide: true }); job.proc = p; let err = '';
        p.stderr.on('data', d => { err = (err + d).slice(-1600); });
        const t0 = Date.now(), tick = setInterval(() => {
          if (job.state === 'cancelling') { p.kill(); return; }
          if (Date.now() - t0 > 1800000) { p.kill(); err = 'Export exceeded 30 minutes.'; }
          try { const v = Object.fromEntries(readFileSync(progress, 'utf8').split('\n').filter(l => l.includes('=')).map(l => l.split('=', 2))); job.progress = Math.min(.99, (Number(v.out_time_us || 0) / 1e6) / Math.max(duration, .001)); } catch {}
        }, 250);
        p.on('error', e => { clearInterval(tick); rej(e); });
        p.on('close', code => { clearInterval(tick); job.proc = null; if (job.state === 'cancelling') rej(Object.assign(new Error('Export cancelled.'), { cancelled: true })); else if (code) rej(new Error('FFmpeg could not render this edit: ' + err.trim().slice(-1200))); else res(); });
      });
      let result;
      if (job.kind === 'sound') result = await ingest(output, payload.name || 'Saved sound', 'saved sound');
      else {
        const final = join(ROOT, 'exports', job.id + '.mp4'); copyFileSync(output, final);
        const saved = await ingest(final, payload.name, 'edited export');
        result = { url: '/api/video/exports/' + job.id, name: payload.name + '.mp4', mediaId: saved.id, exportId: job.id };
      }
      Object.assign(job, { state: 'complete', progress: 1, result });
    } catch (e) { Object.assign(job, e.cancelled ? { state: 'cancelled', error: 'Cancelled.' } : { state: 'failed', error: e.message }); }
    finally { rmSync(folder, { recursive: true, force: true }); closeChrome(); }
  }

  // ---------- previews (browser-friendly sources are served as they are; others get a cached WebM proxy) ----------
  const previewJobs = new Map();
  function preview(source, kind) {
    if (kind === 'image' || BROWSER_OK.has(extname(source).toLowerCase())) return source;
    const st = statSync(source), key = createHash('sha256').update(`${source}:${st.mtimeMs}:${st.size}:v1`).digest('hex');
    const target = join(ROOT, 'previews', key + (kind === 'audio' ? '.ogg' : '.webm'));
    if (existsSync(target)) return target;
    if (!previewJobs.has(key)) {
      if (previewJobs.size >= 8) throw new Error('Preview preparation is busy. Try again shortly.');
      const tmp = target.replace(/(\.\w+)$/, '-partial$1');
      const args = ['-v', 'error', '-nostdin', '-y', '-threads', '2', '-i', source, ...(kind === 'audio' ? ['-vn', '-c:a', 'libvorbis', '-q:a', '4'] : ['-map', '0:v:0', '-map', '0:a:0?', '-vf', "scale='min(960,iw)':-2", '-c:v', 'libvpx', '-deadline', 'realtime', '-cpu-used', '8', '-threads', '2', '-crf', '12', '-b:v', '1500k', '-c:a', 'libvorbis', '-q:a', '4']), tmp];
      previewJobs.set(key, run(ffmpeg(), args, { timeout: 600000 }).then(() => renameSync(tmp, target)).catch(e => { rmSync(tmp, { force: true }); ctx.log?.('editor preview:', e.message); }).finally(() => setTimeout(() => previewJobs.delete(key), 30000)));
    }
    return null;
  }
  // waveform peaks (512 points) from 8 kHz mono PCM
  const waves = new Map();
  async function waveform(path) {
    const st = statSync(path), key = `${path}|${st.mtimeMs}|${st.size}`;
    if (waves.has(key)) return waves.get(key);
    const pcm = await run(ffmpeg(), ['-v', 'error', '-nostdin', '-threads', '1', '-i', path, '-vn', '-t', '3600', '-ac', '1', '-ar', '8000', '-f', 's16le', 'pipe:1'], { timeout: 120000 });
    const n = Math.floor(pcm.length / 2), peaks = new Array(512).fill(0), per = Math.max(1, n / 512);
    for (let i = 0; i < n; i++) { const b = Math.min(511, Math.floor(i / per)), v = Math.abs(pcm.readInt16LE(i * 2)) / 32768; if (v > peaks[b]) peaks[b] = v; }
    const max = Math.max(.001, ...peaks), data = { duration: n / 8000, peaks: peaks.map(p => Math.round(p / max * 1000) / 1000) };
    if (waves.size > 128) waves.delete(waves.keys().next().value); waves.set(key, data);
    return data;
  }

  // ---------- HTTP ----------
  const json = (res, code, v) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(v)); };
  function sendFile(req, res, file, { type, download } = {}) {
    const st = statSync(file), total = st.size, mime = type || MIME[extname(file).toLowerCase()] || 'application/octet-stream';
    const head = { 'Content-Type': mime, 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store', ...(download ? { 'Content-Disposition': `attachment; filename="${download.replace(/[^\w.-]+/g, '-')}"` } : {}) };
    const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
    if (m && total) {
      let start = m[1] === '' ? Math.max(0, total - Number(m[2])) : Number(m[1]), end = m[1] !== '' && m[2] !== '' ? Math.min(total - 1, Number(m[2])) : total - 1;
      if (start >= total || start > end) { res.writeHead(416, { 'Content-Range': `bytes */${total}` }); return res.end(); }
      res.writeHead(206, { ...head, 'Content-Range': `bytes ${start}-${end}/${total}`, 'Content-Length': end - start + 1 });
      return createReadStream(file, { start, end }).pipe(res);
    }
    res.writeHead(200, { ...head, 'Content-Length': total });
    createReadStream(file).pipe(res);
  }
  const cookieToken = req => (/(?:^|;\s*)hub_t=([^;]+)/.exec(req.headers.cookie || '') || [])[1];
  const authed = req => req.headers['x-hub-token'] === ctx.token() || cookieToken(req) === ctx.token();
  const readJsonBody = (req, limit) => new Promise((ok, fail) => { const c = []; let n = 0; req.on('data', d => { n += d.length; if (n > limit) { fail(new Error('Edit metadata exceeds 2 MB.')); req.destroy(); } else c.push(d); }); req.on('end', () => { try { ok(c.length ? JSON.parse(Buffer.concat(c).toString('utf8')) : {}); } catch { fail(new Error('Invalid JSON.')); } }); req.on('error', fail); });
  // streamed multipart upload of one file (no buffering of the whole file in memory)
  function receiveUpload(req) {
    return new Promise((ok, fail) => {
      const type = req.headers['content-type'] || '', bm = /boundary=(?:"([^"]+)"|([^;]+))/.exec(type);
      if (!/multipart\/form-data/.test(type) || !bm) return fail(new Error('Choose an audio or video file.'));
      if (Number(req.headers['content-length'] || 0) > 512 * 1024 * 1024 + 65536) return fail(Object.assign(new Error('Choose media below 512 MB.'), { code: 413 }));
      const boundary = Buffer.from('\r\n--' + (bm[1] || bm[2])), folder = mkdtempSync(join(ROOT, 'work', 'upload-'));
      let head = Buffer.alloc(0), out = null, file = '', name = '', size = 0, tail = Buffer.alloc(0), failed = false;
      const bail = e => { if (failed) return; failed = true; out?.destroy(); req.destroy(); rmSync(folder, { recursive: true, force: true }); fail(e); };
      req.on('data', chunk => {
        if (failed) return;
        if (!out) {
          head = Buffer.concat([head, chunk]); const i = head.indexOf('\r\n\r\n'); if (i < 0) { if (head.length > 16384) bail(new Error('Malformed upload.')); return; }
          const h = head.slice(0, i).toString('utf8'); name = (/filename="([^"]*)"/.exec(h) || [])[1] || 'Imported media';
          const ext = extname(name).toLowerCase(); if (!MEDIA_EXT.has(ext)) return bail(new Error('Unsupported media container.'));
          file = join(folder, 'upload' + ext); out = createWriteStream(file); chunk = head.slice(i + 4); head = null;
        }
        const data = Buffer.concat([tail, chunk]), keep = boundary.length + 8;
        if (data.length > keep) { out.write(data.slice(0, data.length - keep)); tail = data.slice(data.length - keep); } else tail = data;
        size += chunk.length; if (size > 512 * 1024 * 1024) bail(Object.assign(new Error('Media exceeds 512 MB.'), { code: 413 }));
      });
      req.on('end', () => {
        if (failed) return; if (!out) return bail(new Error('Choose an audio or video file.'));
        const end = tail.indexOf(boundary); out.end(end >= 0 ? tail.slice(0, end) : tail);
        out.on('finish', () => ok({ file, name, folder }));
      });
      req.on('error', bail);
    });
  }

  // returns true when it handled the request
  async function handle(req, res, url) {
    const path = url.pathname, M = req.method;
    if (path === '/editor' || path === '/editor/') { res.writeHead(200, { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-store', 'Set-Cookie': `hub_t=${ctx.token()}; Path=/; HttpOnly; SameSite=Strict` }); res.end(readFileSync(join(ctx.uiDir, 'index.html'))); return true; }
    if (path.startsWith('/editor/')) { const n = path.slice(8); if (!EDITOR_FILES.has(n) || !existsSync(join(ctx.uiDir, n))) { json(res, 404, { error: 'Not found' }); return true; } res.writeHead(200, { 'Content-Type': MIME[extname(n)] || 'text/plain', 'Cache-Control': 'no-store' }); res.end(readFileSync(join(ctx.uiDir, n))); return true; }
    if (!path.startsWith('/api/video/')) return false;
    if (!authed(req)) { json(res, 403, { error: 'Open the editor from the hub (Promo → Edit Studio).' }); return true; }
    try {
      let m;
      if (path === '/api/video/library' && M === 'GET') return json(res, 200, { media: await media(), projects: projects(), available: await tools() }), true;
      if ((m = /^\/api\/video\/waveform\/([\w]+)$/.exec(path))) return json(res, 200, await waveform(asset(m[1]))), true;
      if ((m = /^\/api\/video\/media\/([\w]+)$/.exec(path))) return sendFile(req, res, asset(m[1])), true;
      if ((m = /^\/api\/video\/preview\/([\w]+)$/.exec(path))) {
        const src = asset(m[1]), kind = (await probe(src)).kind, p = preview(src, kind);
        if (!p) { res.writeHead(202, { 'Content-Type': 'application/json', 'Retry-After': '1' }); res.end('{"state":"preparing"}'); return true; }
        return sendFile(req, res, p, p === src ? {} : { type: kind === 'audio' ? 'audio/ogg' : 'video/webm' }), true;
      }
      if ((m = /^\/api\/video\/poster\/([\w]+)$/.exec(path))) {
        const src = asset(m[1]);
        const poster = IDENT.test(m[1]) ? join(ROOT, 'media', m[1], 'poster.jpg') : IMAGE_EXT.has(extname(src).toLowerCase()) ? src : null;
        if (poster && existsSync(poster)) return sendFile(req, res, poster), true;
        if (APPID.test(m[1])) { // app videos: make a poster once
          const out = join(ROOT, 'previews', m[1] + '-poster.jpg');
          if (!existsSync(out)) await run(ffmpeg(), ['-v', 'error', '-nostdin', '-y', '-ss', '0.3', '-i', src, '-frames:v', '1', '-vf', 'scale=320:-2', out]).catch(() => {});
          if (existsSync(out)) return sendFile(req, res, out), true;
        }
        res.writeHead(404); res.end(); return true;
      }
      if (path === '/api/video/import' && M === 'POST') {
        if (!(await tools())) throw new Error('FFmpeg and FFprobe are needed for video editing. Install them (Windows: winget install ffmpeg · macOS: brew install ffmpeg) and restart.');
        const up = await receiveUpload(req);
        try { return json(res, 200, { media: await ingest(up.file, basename(up.name, extname(up.name)) || 'Imported media') }), true; } finally { rmSync(up.folder, { recursive: true, force: true }); }
      }
      if (path === '/api/video/projects' && M === 'POST') { const raw = await readJsonBody(req, 2 * 1024 * 1024); return json(res, 200, saveProject(raw.project, await mediaMap(), raw.id)), true; }
      if ((m = /^\/api\/video\/projects\/(\w+)$/.exec(path)) && M === 'GET') { if (!IDENT.test(m[1])) throw new Error('Invalid edit ID.'); return json(res, 200, JSON.parse(readFileSync(join(ROOT, 'projects', m[1] + '.json'), 'utf8'))), true; }
      if ((m = /^\/api\/video\/projects\/(\w+)$/.exec(path)) && M === 'DELETE') { if (!IDENT.test(m[1])) throw new Error('Invalid edit ID.'); rmSync(join(ROOT, 'projects', m[1] + '.json'), { force: true }); return json(res, 200, { projects: projects() }), true; }
      if (path === '/api/video/render' && M === 'POST') return json(res, 200, await launchJob('render', await readJsonBody(req, 2 * 1024 * 1024))), true;
      if (path === '/api/video/sounds' && M === 'POST') return json(res, 200, await launchJob('sound', await readJsonBody(req, 65536))), true;
      if ((m = /^\/api\/video\/jobs\/(\w+)$/.exec(path))) return json(res, 200, statusOf(m[1])), true;
      if ((m = /^\/api\/video\/jobs\/(\w+)\/cancel$/.exec(path)) && M === 'POST') { const j = jobs.get(m[1]); if (!j) throw new Error('That editor job is unavailable.'); if (['queued', 'running'].includes(j.state)) { j.state = 'cancelling'; j.proc?.kill(); } return json(res, 200, statusOf(m[1])), true; }
      if ((m = /^\/api\/video\/exports\/(\w+)$/.exec(path)) && M === 'GET') { if (!IDENT.test(m[1])) throw new Error('Invalid export ID.'); return sendFile(req, res, join(ROOT, 'exports', m[1] + '.mp4'), { download: 'edit.mp4' }), true; }
      // hub extras: the apps an export can go to, and putting an export on an app (its video on your site)
      if (path === '/api/video/apps' && M === 'GET') return json(res, 200, { apps: ctx.loadApps().map(a => ({ id: a.id, name: a.name, videoUrl: a.videoUrl || '' })) }), true;
      if ((m = /^\/api\/video\/exports\/(\w+)\/use$/.exec(path)) && M === 'POST') {
        if (!IDENT.test(m[1])) throw new Error('Invalid export ID.');
        const body = await readJsonBody(req, 4096), apps = ctx.loadApps(), a = apps.find(x => x.id === body.appId); if (!a) throw new Error('Choose an app.');
        const src = join(ROOT, 'exports', m[1] + '.mp4'); if (!existsSync(src)) throw new Error('That export is gone.');
        const rel = `${a.id}/video-${Date.now().toString(36)}.mp4`; mkdirSync(join(ctx.mediaDir, a.id), { recursive: true }); copyFileSync(src, join(ctx.mediaDir, rel));
        a.videoUrl = rel; ctx.saveApps(apps); ctx.onChange?.(a.id);
        return json(res, 200, { app: { id: a.id, name: a.name, videoUrl: rel } }), true;
      }
      json(res, 404, { error: 'Unknown editor route' }); return true;
    } catch (e) {
      if (!res.headersSent) json(res, e.code === 413 ? 413 : 400, { error: e.message || String(e) });
      return true;
    }
  }
  function close() { closed = true; for (const j of jobs.values()) if (['queued', 'running'].includes(j.state)) { j.state = 'cancelling'; j.proc?.kill(); } closeChrome(); }
  return { handle, close, tools, media, _test: { validateProject, expression, renderCommand, mediaMap } };
}
