// Site kit: the donation button, the navigation built from the sections that are live, and the mobile options.
// Shared by the Studio Hub and Pylerium Manager builders (this file is identical in both). Never shipped to the site.

export const DONATE_ICONS = ['can', 'coffee', 'heart', 'gift', 'star', 'zap', 'crown', 'sparkles', 'rocket', 'music'];
export const DONATE_STYLES = { amber: 'Energy drink (amber)', violet: 'Violet', pink: 'Pink', teal: 'Teal', mono: 'White', outline: 'Outline' };
const PLACES = ['hero', 'community', 'support', 'menu'];

// Every donation setting with its default, so old site.json files keep working unchanged.
export function donateOf(site) {
  const d = site?.donate || {};
  const places = { hero: true, community: true, support: true, menu: true, ...(d.places || {}) };
  return {
    enabled: !!d.enabled && !!d.url, url: d.url || '',
    label: (d.label || 'Supply caffeine').trim(), short: (d.short || '').trim(), navLabel: (d.navLabel || '').trim(), floatLabel: (d.floatLabel || '').trim(),
    sub: (d.sub || '').trim(), title: (d.title || '').trim(), thanks: (d.thanks || '').trim(),
    icon: DONATE_ICONS.includes(d.icon) ? d.icon : 'can', style: DONATE_STYLES[d.style] ? d.style : 'amber', steam: d.steam !== false, newTab: d.newTab !== false,
    nav: !!d.showInNav, floating: d.floating !== false, floatSide: d.floatSide === 'left' ? 'left' : 'right', floatAfter: Number.isFinite(+d.floatAfter) && d.floatAfter !== '' ? Math.max(0, +d.floatAfter) : 420,
    floatMobile: ['show', 'mini', 'hide'].includes(d.floatMobile) ? d.floatMobile : 'mini', floatCollapse: ['scroll', 'always', 'never'].includes(d.floatCollapse) ? d.floatCollapse : 'scroll',
    places
  };
}

// The button itself. place: hero | community | support | nav | menu (each can be switched off on its own).
export function donateBtn(R, site, cls = 'caffeine', place = '') {
  const d = donateOf(site);
  if (!d.enabled) return '';
  if (place === 'nav' ? !d.nav : place && PLACES.includes(place) && d.places[place] === false) return '';
  const label = place === 'nav' ? d.navLabel || d.short || d.label : d.label;
  const tgt = d.newTab ? ' target="_blank" rel="noopener"' : '';
  const short = d.short && d.short !== label ? ` data-short="${R.esc(d.short)}"` : '';
  const btn = `<a class="${cls} st-${d.style}${d.steam ? '' : ' no-steam'}" href="${R.esc(d.url)}"${tgt}${short}${d.title ? ` title="${R.esc(d.title)}"` : ''} data-donate>${d.steam ? '<span class="steam"><i></i><i></i><i></i></span>' : ''}${R.icon(d.icon)}<span class="cf-l">${R.esc(label)}</span>${d.short && d.short !== label ? `<span class="cf-s">${R.esc(d.short)}</span>` : ''}</a>`;
  return d.sub && /\blg\b/.test(cls) ? `<span class="cafe-wrap">${btn}<small class="cafe-sub">${R.esc(d.sub)}</small></span>` : btn;
}

// The floating badge in the corner.
export function donateFloat(R, site) {
  const d = donateOf(site);
  if (!d.enabled || !d.floating) return '';
  const label = d.floatLabel || d.label;
  return `<a class="cafe-float st-${d.style} side-${d.floatSide} fm-${d.floatMobile} fc-${d.floatCollapse}" href="${R.esc(d.url)}"${d.newTab ? ' target="_blank" rel="noopener"' : ''} aria-label="${R.esc(label)}" data-after="${d.floatAfter}" data-donate><span class="cf-cup">${d.steam ? '<span class="steam"><i></i><i></i><i></i></span>' : ''}${R.icon(d.icon)}</span><span class="cf-txt">${R.esc(label)}</span></a>`;
}

// What the site script needs about the button (the thank-you message, labels for the mobile menu).
export function donateData(site) {
  const d = donateOf(site);
  return d.enabled ? { label: d.label, short: d.short, url: d.url, icon: d.icon, style: d.style, newTab: d.newTab, menu: d.places.menu !== false, thanks: d.thanks, sub: d.sub } : null;
}

// ---------- navigation ----------
export const NAV_DEFAULT = { featured: 'Featured', apps: 'Apps', videos: 'Videos', embeds: 'Links', news: 'News', community: 'Community', perks: 'Perks', studio: 'About', support: 'Support' };
export const NAV_ICON = { featured: 'star', apps: 'grid', videos: 'youtube', embeds: 'link', news: 'megaphone', community: 'crown', perks: 'gift', studio: 'sparkles', support: 'mail' };
const NAV_ON = { featured: true, apps: true, videos: true, news: true, community: true, perks: true, support: true, embeds: false, studio: false };
// live: the ids of the home-page sections that actually rendered (a section with nothing in it is left out)
export function navOf(site, sections, live) {
  return (sections || []).filter(s => s.enabled && NAV_DEFAULT[s.id] && (!live || live.has(s.id)))
    .map(s => ({ id: s.id, href: `#${s.id}`, label: (s.navLabel || '').trim() || NAV_DEFAULT[s.id], icon: NAV_ICON[s.id], top: s.nav ?? NAV_ON[s.id] }));
}

// ---------- mobile ----------
export function mobileOf(site) {
  const m = site?.mobile || {};
  const pick = (k, list, d) => (list.includes(m[k]) ? m[k] : d);
  return {
    menu: pick('menu', ['sheet', 'full', 'drop'], 'sheet'), side: m.side === 'left' ? 'left' : 'right', breakpoint: [640, 760, 860, 980, 1100].includes(+m.breakpoint) ? +m.breakpoint : 860,
    title: (m.title || '').trim(), counts: m.counts !== false, socials: m.socials !== false, search: m.search !== false, donate: m.donate !== false, spy: m.spy !== false, external: m.external !== false,
    bar: !!m.bar, toTop: m.toTop !== false, stickyFilters: m.stickyFilters !== false, compactHero: m.compactHero !== false, hideStats: !!m.hideStats,
    cards: pick('cards', ['one', 'two'], 'one'), hideAnnounce: !!m.hideAnnounce, calm: !!m.calm, haptics: m.haptics !== false
  };
}
// classes on <body> so the CSS can apply the mobile choices without waiting for the script
export function bodyClass(site) {
  const m = mobileOf(site);
  return [`mm-${m.menu}`, `mm-${m.side}`, `bp-${m.breakpoint}`, m.compactHero && 'm-compact', m.hideStats && 'm-nostats', `m-cards-${m.cards}`, m.hideAnnounce && 'm-noann', m.calm && 'm-calm', m.stickyFilters && 'm-sticky', m.bar && 'm-bar'].filter(Boolean).join(' ');
}
