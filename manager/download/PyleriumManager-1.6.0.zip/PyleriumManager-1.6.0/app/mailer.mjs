// Tiny zero-dependency SMTP client for Gmail app passwords (implicit TLS on port 465).
// Used by the notifier's outbox to send supporter-code and thank-you emails automatically.
import tls from 'node:tls';
import { randomBytes } from 'node:crypto';

export const EMAIL_RE = /^[^\s@<>"',;]+@[^\s@<>"',;]+\.[a-z]{2,}$/i;

function friendly(code, text) {
  if (code === 535 || code === 534) return 'Gmail rejected the login. Use a 16-letter App Password (Google Account → Security → 2-Step Verification → App passwords), not your normal password, and make sure the address matches that Google account.';
  if (code === 550 || code === 553) return `Gmail refused the address: ${text}`;
  if (code === 552 || code === 554) return `Gmail refused the message: ${text}`;
  if (code === 421 || code === 454) return 'Gmail is busy or rate-limiting this account. The hub will try again shortly.';
  return `Mail server said ${code}: ${text}`;
}

// One SMTP conversation. Replies are read as complete (possibly multi-line) responses.
function connect(host, port, timeout) {
  return new Promise((resolve, reject) => {
    const sock = tls.connect({ host, port, servername: host });
    let buf = '', lines = [];
    const replies = [], waiters = [];
    let dead = null;
    const push = r => { const w = waiters.shift(); if (w) w.ok(r); else replies.push(r); };
    sock.setTimeout(timeout, () => sock.destroy(new Error('Timed out talking to Gmail.')));
    sock.on('data', d => {
      buf += d.toString('utf8');
      let i;
      while ((i = buf.indexOf('\r\n')) >= 0) {
        const l = buf.slice(0, i); buf = buf.slice(i + 2);
        lines.push(l);
        if (/^\d{3}(?: |$)/.test(l)) { push({ code: +l.slice(0, 3), text: lines.map(x => x.slice(4)).join(' ').trim() }); lines = []; }
      }
    });
    sock.on('error', e => { dead = e; while (waiters.length) waiters.shift().fail(e); });
    sock.on('close', () => { dead ||= new Error('Gmail closed the connection.'); while (waiters.length) waiters.shift().fail(dead); });
    const read = () => (replies.length ? Promise.resolve(replies.shift()) : dead ? Promise.reject(dead) : new Promise((ok, fail) => waiters.push({ ok, fail })));
    async function cmd(line, expect) {
      if (line != null) sock.write(line + '\r\n');
      const r = await read();
      if (expect && !expect.includes(r.code)) throw Object.assign(new Error(friendly(r.code, r.text)), { smtpCode: r.code });
      return r;
    }
    sock.once('secureConnect', () => resolve({ cmd, write: s => sock.write(s), end: () => { try { sock.end(); } catch {} } }));
    sock.once('error', reject);
  });
}

const b64 = s => Buffer.from(s, 'utf8').toString('base64');
const wrap = s => s.replace(/.{1,76}/g, '$&\r\n');
const encWord = s => (/^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${b64(s)}?=`);
const addr = (name, email) => {
  if (!name) return `<${email}>`;
  const n = String(name).replace(/["\r\n]/g, '');
  return /^[\x20-\x7e]*$/.test(n) ? `"${n}" <${email}>` : `${encWord(n)} <${email}>`; // encoded words must not be quoted
};

export function buildMessage({ from, fromName, to, toName, replyTo, subject, text, html }) {
  const boundary = 'b_' + randomBytes(12).toString('hex');
  const domain = String(from).split('@')[1] || 'localhost';
  const head = [
    `From: ${addr(fromName, from)}`,
    `To: ${addr(toName, to)}`,
    replyTo ? `Reply-To: ${replyTo}` : '',
    `Subject: ${encWord(subject)}`,
    `Date: ${new Date().toUTCString().replace('GMT', '+0000')}`,
    `Message-ID: <${Date.now().toString(36)}.${randomBytes(8).toString('hex')}@${domain}>`,
    'MIME-Version: 1.0',
    html ? `Content-Type: multipart/alternative; boundary="${boundary}"` : 'Content-Type: text/plain; charset=UTF-8',
    html ? '' : 'Content-Transfer-Encoding: base64'
  ].filter(Boolean).join('\r\n');
  if (!html) return `${head}\r\n\r\n${wrap(b64(text))}`;
  const part = (type, body) => `--${boundary}\r\nContent-Type: ${type}; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${wrap(b64(body))}`;
  return `${head}\r\n\r\n${part('text/plain', text)}\r\n${part('text/html', html)}\r\n--${boundary}--\r\n`;
}

// verifyOnly: log in and quit (used by "Test connection").
export async function smtpSend(o) {
  const { host = 'smtp.gmail.com', port = 465, user, pass, timeout = 25000, verifyOnly = false } = o;
  if (!user || !pass) throw new Error('Add your Gmail address and App Password first.');
  const c = await connect(host, port, timeout);
  try {
    await c.cmd(null, [220]);
    await c.cmd('EHLO pylerium-manager', [250]);
    await c.cmd('AUTH PLAIN ' + b64(`\0${user}\0${String(pass).replace(/\s+/g, '')}`), [235]);
    if (verifyOnly) { await c.cmd('QUIT').catch(() => {}); return { ok: true }; }
    const rcpts = [o.to, ...(o.bcc || [])].filter(Boolean);
    for (const r of rcpts) if (!EMAIL_RE.test(r)) throw new Error(`“${r}” isn’t a valid email address.`);
    await c.cmd(`MAIL FROM:<${user}>`, [250]);
    for (const r of rcpts) await c.cmd(`RCPT TO:<${r}>`, [250, 251]);
    await c.cmd('DATA', [354]);
    const msg = buildMessage({ ...o, from: o.from || user }).replace(/\r\n\./g, '\r\n..');
    c.write(msg + '\r\n.\r\n');
    const r = await c.cmd(null, [250]);
    await c.cmd('QUIT').catch(() => {});
    return { ok: true, response: r.text };
  } finally { c.end(); }
}

// ---------- branded HTML version of a plain-text email ----------
const escH = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const linkify = s => s.replace(/(https?:\/\/[^\s<]+[^\s<.,;:!?)\]'"])/g, '<a href="$1" style="color:#0D9488;font-weight:600;text-decoration:none">$1</a>');
export function htmlEmail(text, { brand = 'My Studio', siteUrl = '', logo = '', accent = '#2DD4BF' } = {}) {
  const blocks = String(text).replace(/\r/g, '').split(/\n{2,}/);
  const body = blocks.map(b => {
    if (/^ {4}\S/.test(b) && !b.includes('\n')) // indented line = the code box
      return b.trim().length > 32
        ? `<div style="margin:18px 0;padding:14px 16px;border-radius:12px;background:#0B1120;color:#5EEAD4;font:600 13px/1.5 Consolas,Menlo,monospace;word-break:break-all">${escH(b.trim())}</div>`
        : `<div style="margin:18px 0;padding:16px;border-radius:12px;background:#0B1120;color:#5EEAD4;font:700 22px/1.3 Consolas,Menlo,monospace;letter-spacing:.06em;text-align:center">${escH(b.trim())}</div>`;
    return `<p style="margin:0 0 14px">${linkify(escH(b)).replace(/\n/g, '<br>')}</p>`;
  }).join('');
  const host = siteUrl.replace(/^https?:\/\//, '').replace(/\/$/, '');
  return `<!DOCTYPE html><html><body style="margin:0;padding:0;background:#EEF2F7">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#EEF2F7;padding:28px 12px"><tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#FFFFFF;border-radius:18px;overflow:hidden;font:15px/1.6 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#1E293B">
<tr><td style="padding:22px 28px;background:linear-gradient(120deg,#7C3AED,#0EA5E9 60%,${accent});color:#fff">
${logo ? `<img src="${escH(logo)}" width="36" height="36" alt="" style="vertical-align:middle;border-radius:10px;margin-right:10px">` : ''}<b style="font-size:18px;vertical-align:middle">${escH(brand)}</b></td></tr>
<tr><td style="padding:26px 28px 10px">${body}</td></tr>
${host ? `<tr><td style="padding:6px 28px 26px"><a href="${escH(siteUrl)}" style="display:inline-block;padding:11px 18px;border-radius:10px;background:#0F172A;color:#fff;font-weight:600;text-decoration:none">Visit ${escH(host)}</a></td></tr>` : ''}
</table>
<p style="margin:14px 0 0;font:12px Segoe UI,Arial,sans-serif;color:#64748B">${escH(brand)}${host ? ` · <a href="${escH(siteUrl)}" style="color:#64748B">${escH(host)}</a>` : ''}</p>
</td></tr></table></body></html>`;
}

// ---------- the designed email (v2): hero, app card, code cards with a Copy button, real buttons, perk cards, footer ----------
// Email apps don't run scripts, so "Copy code" opens the site's /copy/ page, which copies with one tap. The code rides in the
// link's #fragment, which browsers never send to the server.
// o: { text, brand, siteUrl, logo, accent, kind, preheader, hero: { image, emoji, title, subtitle }, app: { name, tagline, icon, version, url },
//      codes: [{ value, label, copyUrl, hint }], buttons: { [url]: label }, perks: [{ name, tagline }], socials: [{ label, url }], support }
const FONT = "-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
const MONO = "ui-monospace,SFMono-Regular,Consolas,Menlo,monospace";
const URL_RE = /^https?:\/\/\S+$/;
export function copyLink(siteUrl, { code, label = 'code', app = '', next = '', nextLabel = '' }) {
  if (!siteUrl || !code) return '';
  const p = new URLSearchParams({ c: code, k: label, ...(app ? { a: app } : {}), ...(next ? { n: next, nl: nextLabel || 'Continue' } : {}) });
  return `${String(siteUrl).replace(/\/$/, '')}/copy/#${p.toString()}`;
}
export function emailHTML(o = {}) {
  const accent = o.accent || '#8B5CF6', brand = o.brand || 'Studio', site = String(o.siteUrl || '').replace(/\/$/, '');
  const host = site.replace(/^https?:\/\//, '');
  const btn = (url, label, primary = true) => `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:6px 0 18px"><tr><td bgcolor="${primary ? accent : '#0F172A'}" style="border-radius:12px;background:${primary ? `linear-gradient(120deg,${accent},#0EA5E9)` : '#0F172A'}">
    <a href="${escH(url)}" style="display:inline-block;padding:13px 22px;font:700 15px ${FONT};color:#FFFFFF;text-decoration:none;border-radius:12px">${escH(label)} &rarr;</a></td></tr></table>`;
  const codeCard = c => {
    const long = c.value.length > 32, mid = c.value.length > 14;
    return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:8px 0 20px;border-collapse:separate"><tr><td bgcolor="#0B1120" style="background:#0B1120;border-radius:16px;padding:18px 20px">
      <div style="font:700 11px ${FONT};letter-spacing:.12em;text-transform:uppercase;color:#94A3B8;margin:0 0 10px">${escH(c.label || 'Your code')}</div>
      <div style="font:${long ? '600 12.5px/1.55' : mid ? '800 19px/1.3' : '800 24px/1.3'} ${MONO};color:#5EEAD4;letter-spacing:${long ? '0' : mid ? '.03em' : '.08em'};white-space:${long ? 'normal' : 'nowrap'};word-break:break-all;-webkit-user-select:all;user-select:all;${long ? '' : 'text-align:center;'}padding:${long ? '0' : '6px 0'}">${escH(c.value)}</div>
      ${c.copyUrl ? `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:14px 0 0"><tr><td bgcolor="#1E293B" style="border-radius:10px;background:#1E293B;border:1px solid #334155">
        <a href="${escH(c.copyUrl)}" style="display:inline-block;padding:9px 16px;font:700 13px ${FONT};color:#E2E8F0;text-decoration:none">&#x2398;&nbsp; Copy ${escH((c.label || 'code').toLowerCase())}</a></td></tr></table>` : ''}
      <div style="font:12px/1.5 ${FONT};color:#64748B;margin:10px 0 0">${escH(c.hint || (long ? 'It’s one long line: copy all of it.' : 'Tap and hold the code to select it, or use the copy button.'))}</div>
    </td></tr></table>`;
  };
  // a link on its own line with no known label: name it from where it goes
  const guess = u => { const x = u.replace(/\/$/, ''), p = x.startsWith(site) ? x.slice(site.length) : null;
    if (p == null) { try { return `Open ${new URL(u).hostname.replace(/^www\./, '')}`; } catch { return 'Open link'; } }
    return ({ '#support': 'Contact support', '#perks': 'Open my perks', '#submit': 'Submit your app', '#apps': 'See the apps', '#community': 'Visit the community', '#videos': 'Watch the videos' })[p] || (/^\/apps\/[^/]+$/.test(p) ? 'View the app' : /^\/download/.test(p) ? 'Download' : `Visit ${host}`); };
  const codes = new Map((o.codes || []).filter(c => c?.value).map(c => [c.value, c]));
  const used = new Set(), rendered = new Set();
  let sigAt = -1;
  // the plain-text body → designed blocks
  const blocks = String(o.text || '').replace(/\r/g, '').split(/\n{2,}/).filter(b => b.trim());
  const out = [];
  blocks.forEach((b, bi) => {
    if (/^ {4}\S/.test(b) && !b.includes('\n')) { const v = b.trim(); used.add(v); out.push(codeCard(codes.get(v) || { value: v, label: 'Your code' })); return; }
    const lines = b.split('\n');
    if (bi === blocks.length - 1 && bi > 0 && lines.length <= 4 && /^(thanks|thank you|cheers|best|warmly)/i.test(lines[0].trim())) sigAt = out.length;
    if (lines.every(l => /^\s*[•\-*]\s/.test(l)) && (o.perks || []).length) { // the perk list → cards
      out.push(o.perks.map(p => `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 10px;border-collapse:separate"><tr>
        <td width="52" valign="top" style="padding:14px 0 14px 14px;background:#F5F3FF;border-radius:14px 0 0 14px"><div style="width:40px;height:40px;border-radius:12px;background:${accent};color:#fff;font:22px/40px ${FONT};text-align:center">🎁</div></td>
        <td style="padding:14px;background:#F5F3FF;border-radius:0 14px 14px 0"><div style="font:700 15px ${FONT};color:#1E1B4B">${escH(p.name)}</div>${p.tagline ? `<div style="font:13.5px/1.5 ${FONT};color:#5B5675">${escH(p.tagline)}</div>` : ''}</td></tr></table>`).join(''));
      return;
    }
    let para = [];
    const flush = () => { if (!para.length) return; const t = para.join('\n'); para = [];
      const first = bi === 0 && /^(hi|hello|hey)\b/i.test(t);
      out.push(`<p style="margin:0 0 16px;font:${first ? '600 17px/1.5' : '15.5px/1.65'} ${FONT};color:${first ? '#0F172A' : '#334155'}">${linkify(escH(t)).replace(/\n/g, '<br>')}</p>`); };
    for (const l of lines) {
      const u = l.trim();
      if (URL_RE.test(u)) {
        flush();
        if (u.replace(/\/$/, '') === site) out.push(`<p style="margin:-8px 0 16px;font:14px ${FONT}"><a href="${escH(u)}" style="color:#64748B;text-decoration:none">${escH(host)}</a></p>`);
        else { rendered.add(u); out.push(o.buttons?.[u] ? btn(u, o.buttons[u]) : btn(u, guess(u), false)); }
      } else para.push(l);
    }
    flush();
  });
  // a code the (edited) text left out still shows, and the main action always gets a button: both above the sign-off
  const extra = [...[...codes.values()].filter(c => !used.has(c.value)).map(codeCard), ...Object.entries(o.buttons || {}).filter(([u]) => !rendered.has(u) && URL_RE.test(u)).map(([u, label]) => btn(u, label))];
  out.splice(sigAt >= 0 ? sigAt : out.length, 0, ...extra);

  const h = o.hero || {};
  const hero = h.image
    ? `<tr><td style="padding:0"><img src="${escH(h.image)}" width="600" alt="${escH(o.app?.name || h.title || '')}" style="display:block;width:100%;max-width:600px;height:auto;border:0;background:#0B1120"></td></tr>`
    : `<tr><td bgcolor="#140F2E" style="padding:34px 32px 30px;background:radial-gradient(120% 140% at 0% 0%,${accent}55,transparent 60%),linear-gradient(160deg,#1A1440,#0B1120);text-align:center">
        ${h.emoji ? `<div style="font:46px/1 ${FONT};margin:0 0 12px">${h.emoji}</div>` : ''}
        ${h.title ? `<div style="font:800 26px/1.25 ${FONT};color:#FFFFFF;letter-spacing:-.01em">${escH(h.title)}</div>` : ''}
        ${h.subtitle ? `<div style="font:15px/1.5 ${FONT};color:#C4B5FD;margin:8px 0 0">${escH(h.subtitle)}</div>` : ''}</td></tr>`;
  const a = o.app;
  const appCard = a?.name ? `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 22px;border-collapse:separate"><tr>
      ${a.icon ? `<td width="64" valign="middle" style="padding:14px 0 14px 14px;background:#F8FAFC;border-radius:16px 0 0 16px;border:1px solid #E2E8F0;border-right:0"><img src="${escH(a.icon)}" width="52" height="52" alt="" style="display:block;border-radius:14px"></td>` : ''}
      <td valign="middle" style="padding:14px 16px;background:#F8FAFC;border-radius:${a.icon ? '0 16px 16px 0' : '16px'};border:1px solid #E2E8F0;${a.icon ? 'border-left:0;' : ''}">
        <div style="font:800 17px ${FONT};color:#0F172A">${escH(a.name)}${a.version ? ` <span style="font:700 11px ${MONO};color:${accent};background:${accent}1A;border-radius:99px;padding:3px 8px;vertical-align:2px">${escH(a.version)}</span>` : ''}</div>
        ${a.tagline ? `<div style="font:13.5px/1.5 ${FONT};color:#64748B;margin:2px 0 0">${escH(a.tagline)}</div>` : ''}
        ${a.url ? `<a href="${escH(a.url)}" style="font:600 13px ${FONT};color:${accent};text-decoration:none">View on ${escH(host || 'the site')} &rarr;</a>` : ''}</td></tr></table>` : '';
  const title = h.image && h.title ? `<div style="font:800 24px/1.25 ${FONT};color:#0F172A;letter-spacing:-.01em;margin:0 0 6px">${escH(h.title)}</div>${h.subtitle ? `<div style="font:15px/1.5 ${FONT};color:#64748B;margin:0 0 20px">${escH(h.subtitle)}</div>` : '<div style="height:14px"></div>'}` : '';
  const socials = (o.socials || []).filter(s => s?.url).slice(0, 8);
  return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><meta name="supported-color-schemes" content="light"><title>${escH(h.title || brand)}</title></head>
<body style="margin:0;padding:0;background:#E9EDF5">
${o.preheader ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent">${escH(o.preheader)}${'&nbsp;&zwnj;'.repeat(40)}</div>` : ''}
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" bgcolor="#E9EDF5" style="background:#E9EDF5"><tr><td align="center" style="padding:28px 12px 36px">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px">
<tr><td style="padding:0 6px 14px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>
  <td valign="middle">${o.logo ? `<img src="${escH(o.logo)}" width="34" height="34" alt="" style="vertical-align:middle;border-radius:10px;margin-right:10px">` : ''}<a href="${escH(site || '#')}" style="font:800 17px ${FONT};color:#0F172A;text-decoration:none;vertical-align:middle">${escH(brand)}</a></td>
  ${o.kindLabel ? `<td align="right" valign="middle" style="font:700 11px ${FONT};letter-spacing:.1em;text-transform:uppercase;color:#64748B">${escH(o.kindLabel)}</td>` : ''}</tr></table></td></tr>
<tr><td><table role="presentation" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" style="background:#FFFFFF;border-radius:22px;overflow:hidden;box-shadow:0 18px 50px -24px rgba(15,23,42,.35)">
  ${hero}
  <tr><td style="padding:28px 32px 14px">${title}${appCard}${out.join('\n')}</td></tr>
  ${o.support ? `<tr><td style="padding:0 32px 26px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td style="padding:14px 16px;border-radius:14px;background:#F1F5F9;font:13.5px/1.55 ${FONT};color:#475569">💬 Need a hand? Just reply to this email${o.support !== true ? ` or write to <a href="mailto:${escH(o.support)}" style="color:${accent};text-decoration:none;font-weight:600">${escH(o.support)}</a>` : ''}. A real person answers.</td></tr></table></td></tr>` : ''}
</table></td></tr>
<tr><td align="center" style="padding:22px 10px 0;font:12.5px/1.7 ${FONT};color:#64748B">
  ${socials.length ? `<div style="margin:0 0 10px">${socials.map(s => `<a href="${escH(s.url)}" style="display:inline-block;margin:0 4px 6px;padding:6px 12px;border-radius:99px;background:#FFFFFF;border:1px solid #D9DFEA;color:#334155;text-decoration:none;font-weight:600">${escH(s.label)}</a>`).join('')}</div>` : ''}
  <b style="color:#334155">${escH(brand)}</b>${host ? ` · <a href="${escH(site)}" style="color:#64748B">${escH(host)}</a>` : ''}<br>${escH(o.footnote || 'You’re getting this email because of a purchase or a gift from us.')}
</td></tr></table></td></tr></table></body></html>`;
}
