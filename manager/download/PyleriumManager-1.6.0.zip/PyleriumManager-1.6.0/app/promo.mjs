// Promo Studio: promo images and videos for any app, made from its own screenshots, icon, name, tagline, features and colours.
//
//   Images: promo/poster.html draws every format from one spec. The hub previews it in an iframe and renders the same page in
//           headless Chrome or Edge at exact pixel size (so the preview is the result). Saved to media/<app>/promo/<format>.png.
//   Videos: promo/engine.html (the scene engine from promo-src) rendered frame by frame into ffmpeg, with music made by ffmpeg.
//   Auto:   uploading screenshots or a cover generates the app's kit in the background (Promo settings → "When I upload…").
//
// Data: data/promo.json { settings, apps: { <id>: { style, files: { <format>: { file, w, h, at, template } }, videos } } }.
import { spawn } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync, statSync, rmSync, openSync, readSync, closeSync } from 'node:fs';
import { join, dirname, extname } from 'node:path';
import { randomBytes } from 'node:crypto';
import { launch, findChrome } from './promo/chrome.mjs';

// ---------- the formats ----------
export const FORMATS = [
  { id: 'cover', label: 'Website cover', w: 1920, h: 1080, group: 'Your site', use: 'The app card and page on your site (16:9)' },
  { id: 'social', label: 'Link preview', w: 1200, h: 630, group: 'Your site', use: 'What X, LinkedIn, Discord and Slack show for links to the app' },
  { id: 'x', label: 'X / LinkedIn post', w: 1600, h: 900, group: 'Social', use: 'Image posts on X, LinkedIn and Mastodon' },
  { id: 'square', label: 'Square post', w: 1080, h: 1080, group: 'Social', use: 'Instagram, Threads, Facebook' },
  { id: 'portrait', label: 'Portrait post', w: 1080, h: 1350, group: 'Social', use: 'Instagram feed (4:5)' },
  { id: 'story', label: 'Story / Short', w: 1080, h: 1920, group: 'Social', use: 'Stories, Reels, Shorts and TikTok covers' },
  { id: 'youtube', label: 'YouTube thumbnail', w: 1280, h: 720, group: 'Video', use: 'Video thumbnails' },
  { id: 'cws-shot', label: 'Chrome Web Store screenshot', w: 1280, h: 800, group: 'Stores', use: 'Store listing screenshots' },
  { id: 'cws-tile', label: 'Chrome Web Store tile', w: 440, h: 280, group: 'Stores', use: 'Small promo tile' },
  { id: 'cws-marquee', label: 'Chrome Web Store marquee', w: 1400, h: 560, group: 'Stores', use: 'Marquee promo banner' },
  { id: 'itch', label: 'itch.io cover', w: 630, h: 500, group: 'Stores', use: 'Game and tool page cover' },
  { id: 'producthunt', label: 'Product Hunt gallery', w: 1270, h: 760, group: 'Stores', use: 'Launch gallery images' },
  { id: 'steam-capsule', label: 'Steam capsule', w: 920, h: 430, group: 'Stores', use: 'Header capsule' },
  { id: 'banner', label: 'Wide banner', w: 1500, h: 500, group: 'Social', use: 'X header, GitHub README banner' }
];
export const TEMPLATES = [
  { id: 'hero', label: 'Hero', blurb: 'Headline, tagline and the app on screen' },
  { id: 'feature', label: 'Feature', blurb: 'One feature, zoomed into the screenshot' },
  { id: 'release', label: 'Release', blurb: 'What’s new in this version' },
  { id: 'showcase', label: 'Showcase', blurb: 'Several screenshots, fanned out' },
  { id: 'minimal', label: 'Minimal', blurb: 'Icon, name and tagline' }
];
export const STYLES = [['midnight', 'Midnight'], ['aurora', 'Aurora'], ['light', 'Light'], ['solid', 'Bold colour']];
export const FRAMES = [['window', 'App window'], ['float', 'Floating'], ['phone', 'Phone'], ['none', 'No frame']];
// what each kind of app gets automatically (plus the basics everyone gets)
const AUTO_BASE = ['cover', 'social', 'square', 'story', 'youtube'];
const AUTO_BY_CATEGORY = { extension: ['cws-shot', 'cws-tile', 'cws-marquee'], games: ['itch', 'steam-capsule'], mods: ['itch'], tv: ['portrait'], mobile: ['portrait'], devtools: ['producthunt', 'banner'], desktop: ['producthunt'] };
const ACCENT = {
  studio: ['#2DD4BF', '#38BDF8', '#A78BFA'], violet: ['#A78BFA', '#818CF8', '#5EEAD4'], sky: ['#38BDF8', '#818CF8', '#5EEAD4'], rose: ['#FB7185', '#F472B6', '#FBBF24'],
  amber: ['#FBBF24', '#FB923C', '#F472B6'], emerald: ['#34D399', '#2DD4BF', '#38BDF8'], lime: ['#A3E635', '#34D399', '#2DD4BF'], orange: ['#FB923C', '#F472B6', '#FBBF24'],
  indigo: ['#818CF8', '#A78BFA', '#38BDF8'], fuchsia: ['#E879F9', '#A78BFA', '#38BDF8'], cyan: ['#22D3EE', '#38BDF8', '#A78BFA'], red: ['#F87171', '#FB923C', '#FBBF24']
};
const clip = (s, n) => (String(s || '').length > n ? String(s).slice(0, n - 1).trimEnd() + '…' : String(s || ''));
const firstSentence = s => (String(s || '').replace(/[#*_`>]/g, '').split(/(?<=[.!?])\s/)[0] || '').trim();
const rid = () => randomBytes(6).toString('hex');
const basenameNoExt = f => String(f).split('/').pop().replace(/[.][^.]+$/, '');

// width × height of a PNG, JPEG, GIF or WebP from its first bytes (no image library needed)
export function imageSize(file) {
  try {
    const fd = openSync(file, 'r'), b = Buffer.alloc(65536); const n = readSync(fd, b, 0, b.length, 0); closeSync(fd);
    if (b.readUInt32BE(0) === 0x89504e47) return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
    if (b.toString('ascii', 0, 3) === 'GIF') return { w: b.readUInt16LE(6), h: b.readUInt16LE(8) };
    if (b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') {
      const t = b.toString('ascii', 12, 16);
      if (t === 'VP8X') return { w: 1 + b.readUIntLE(24, 3), h: 1 + b.readUIntLE(27, 3) };
      if (t === 'VP8L') { const v = b.readUInt32LE(21); return { w: 1 + (v & 0x3fff), h: 1 + ((v >> 14) & 0x3fff) }; }
      if (t === 'VP8 ') return { w: b.readUInt16LE(26) & 0x3fff, h: b.readUInt16LE(28) & 0x3fff };
    }
    if (b[0] === 0xff && b[1] === 0xd8) {
      for (let i = 2; i < n - 9;) {
        if (b[i] !== 0xff) { i++; continue; }
        const m = b[i + 1], len = b.readUInt16BE(i + 2);
        if (m >= 0xc0 && m <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(m)) return { w: b.readUInt16BE(i + 7), h: b.readUInt16BE(i + 5) };
        i += 2 + len;
      }
    }
  } catch {}
  return null;
}

export function createPromo(ctx) {
  // ctx: readJson, writeJson, loadApps, saveApps, loadSite, mediaDir, port, siteUrl(), brand(), log, onChange(appId)
  const load = () => { const d = ctx.readJson('promo.json', {}); return { settings: { auto: true, autoVideo: false, useSocial: true, ...(d.settings || {}) }, apps: d.apps || {} }; };
  const save = d => ctx.writeJson('promo.json', d, false);
  const appOf = id => ctx.loadApps().find(a => a.id === id);
  const isImg = p => /\.(png|jpe?g|webp|gif)$/i.test(p || '');
  const mediaUrl = p => (!p ? '' : /^https?:/i.test(p) ? p : `/media/${p.split('/').map(encodeURIComponent).join('/')}`);
  const hubOrigin = () => `http://127.0.0.1:${ctx.port}`;

  // ---------- the spec for one image ----------
  // Text defaults come from the app; the saved per-app style (Promo Studio) overrides them; per-format overrides win.
  function baseFor(app) {
    const site = ctx.loadSite() || {}, cat = (site.categories || []).find(c => c.id === app.category);
    const shots = [...(app.screenshots || []), app.cover].filter(isImg).filter((v, i, a) => a.indexOf(v) === i && !/\/promo\//.test(v));
    const nameWords = String(app.name || '').trim().split(/\s+/);
    const headline = nameWords.length > 1 ? `${nameWords.slice(0, -1).join(' ')} *${nameWords.at(-1)}*` : `*${app.name || 'Your app'}*`;
    const host = String(ctx.siteUrl() || '').replace(/^https?:\/\//, '').replace(/\/$/, '');
    return {
      name: app.name || 'Untitled app', icon: isImg(app.iconImage) || /\.svg$/i.test(app.iconImage || '') ? mediaUrl(app.iconImage) : '', shots: shots.map(mediaUrl), shotFiles: shots,
      headline, sub: clip(app.tagline || firstSentence(app.description), 140), kicker: cat?.label || '', pill: app.price || (app.status === 'soon' ? 'Coming soon' : app.status === 'beta' ? 'Public beta' : ''),
      chips: [app.platform, app.version].filter(Boolean).slice(0, 2), features: (app.features || []).slice(0, 6).map(f => clip(f, 90)),
      url: host ? `${host}/apps/${app.id}` : '', bar: app.name, accent: app.accent || 'violet'
    };
  }
  function specFor(app, formatId, style = {}) {
    const f = FORMATS.find(x => x.id === formatId) || FORMATS[0];
    const b = baseFor(app), s = { ...style, ...(style.formats?.[formatId] || {}) };
    const tpl = s.template || 'hero';
    const shotIndex = Math.max(0, Math.min(b.shots.length - 1, +s.shot || 0));
    const shots = b.shots.length ? [b.shots[shotIndex], ...b.shots.filter((_, i) => i !== shotIndex)] : [];
    const a = ACCENT[s.accent || b.accent] || ACCENT.violet;
    const spec = { w: f.w, h: f.h, template: tpl, style: s.style || 'midnight', frame: s.frame || 'window', name: b.name, icon: b.icon, shots, bar: s.bar ?? b.bar,
      theme: { a1: s.a1 || a[0], a2: s.a2 || a[1], a3: s.a3 || a[2] }, kicker: s.kicker ?? b.kicker, headline: s.headline || b.headline, sub: s.sub ?? b.sub,
      pill: s.pill ?? b.pill, chips: s.chips ?? b.chips, features: b.features, url: s.url ?? b.url, showBrand: s.showBrand !== false, texture: s.texture !== false, badge: s.badge || '',
      listFeatures: s.listFeatures, shotAspect: s.shotAspect || 1.6 };
    if (tpl === 'feature') {
      const fi = Math.max(0, Math.min((app.features || []).length - 1, +s.featureIndex || 0));
      Object.assign(spec, { kicker: s.kicker ?? app.name, headline: s.headline || clip(app.features?.[fi] || app.tagline, 70), sub: s.sub ?? '', zoom: +s.zoom || 1.6, fx: s.fx ?? .5, fy: s.fy ?? .25 });
    }
    if (tpl === 'release') {
      const c = app.changelog?.[0];
      Object.assign(spec, { kicker: s.kicker ?? 'What’s new', headline: s.headline || `${app.name} *${c?.ver || app.version || 'update'}*`, sub: s.sub ?? clip(c?.note || app.tagline, 160), badge: s.badge ?? (c?.ver || app.version ? 'New version' : '') });
    }
    // shot aspect from the real image, so frames fit it without letterboxing
    const sf = b.shotFiles[shotIndex]; if (sf && !s.shotAspect) { const d = imageSize(join(ctx.mediaDir, sf)); if (d?.w && d?.h) spec.shotAspect = Math.max(.45, Math.min(2.6, d.w / d.h)); }
    return spec;
  }

  // ---------- Chrome (shared, closed when idle) ----------
  let chromeP = null, idle = null;
  const chrome = () => { clearTimeout(idle); return (chromeP ||= launch().catch(e => { chromeP = null; throw e; })); };
  const release = () => { clearTimeout(idle); idle = setTimeout(async () => { const c = chromeP; chromeP = null; if (c) (await c.catch(() => null))?.close(); }, 90000); idle.unref?.(); };
  async function shoot(spec, file, page = 'poster.html') {
    const c = await chrome();
    const p = await c.page(spec.w, spec.h, 1);
    try {
      await p.send('Page.addScriptToEvaluateOnNewDocument', { source: `window.__err = ''; addEventListener('error', e => { window.__err ||= e.message; }); window.SPEC = ${JSON.stringify(spec)};` });
      await p.goto(`${hubOrigin()}/promo/${page}`, { wait: 150 });
      // never save a page that didn't draw
      if (!(await p.eval('window.ready'))) throw new Error(`The promo page didn't draw${(await p.eval('window.__err')) ? `: ${await p.eval('window.__err')}` : ''}.`);
      await new Promise(r => setTimeout(r, 120));
      mkdirSync(dirname(file), { recursive: true });
      writeFileSync(file, await p.shot({ format: 'png', clip: { x: 0, y: 0, width: spec.w, height: spec.h } }));
    } finally { await p.close(); }
  }

  // ---------- ffmpeg ----------
  let ffmpegOk = null;
  const ffmpegBin = () => load().settings.ffmpegPath || 'ffmpeg';
  const hasFfmpeg = () => ffmpegOk ??= new Promise(res => { const p = spawn(ffmpegBin(), ['-version'], { windowsHide: true }); p.on('error', () => res(false)); p.on('close', c => res(c === 0)); }).then(v => { if (!v) setTimeout(() => { ffmpegOk = null; }, 60000); return v; });

  // ---------- jobs: one at a time, in order ----------
  const jobs = new Map(), queue = [];
  let running = false;
  function enqueue(kind, appId, label, run) {
    const job = { id: rid(), kind, appId, label, state: 'queued', progress: 0, created: Date.now(), done: [], error: '' };
    jobs.set(job.id, job); queue.push({ job, run });
    for (const [k, j] of jobs) if (jobs.size > 40 && !['queued', 'running'].includes(j.state)) jobs.delete(k);
    pump(); return job;
  }
  async function pump() {
    if (running) return; running = true;
    try {
      while (queue.length) {
        const { job, run } = queue.shift();
        if (job.state === 'cancelled') continue;
        job.state = 'running'; job.started = Date.now();
        try { await run(job); job.state = job.state === 'cancelled' ? 'cancelled' : 'complete'; job.progress = 1; }
        catch (e) { job.state = 'failed'; job.error = e.message; ctx.log?.('promo:', e.message); }
        job.finished = Date.now();
        ctx.onChange?.(job.appId);
      }
    } finally { running = false; release(); }
  }
  const publicJob = j => ({ id: j.id, kind: j.kind, appId: j.appId, label: j.label, state: j.state, progress: j.progress, done: j.done, error: j.error, created: j.created, finished: j.finished });

  // ---------- image kits ----------
  const outDir = appId => join(ctx.mediaDir, appId, 'promo');
  function renderKit(appId, formatIds, style, label) {
    const app = appOf(appId); if (!app) throw new Error('That app is gone.');
    const ids = (formatIds?.length ? formatIds : defaultFormats(app)).filter(id => FORMATS.some(f => f.id === id));
    if (!ids.length) throw new Error('Choose at least one format.');
    if (!findChrome()) throw new Error('Promo images need Google Chrome or Microsoft Edge on this computer.');
    return enqueue('images', appId, label || `${ids.length} image${ids.length > 1 ? 's' : ''} for ${app.name}`, async job => {
      const st = style || load().apps[appId]?.style || {};
      for (const [i, id] of ids.entries()) {
        if (job.state === 'cancelled') return;
        const spec = specFor(appOf(appId) || app, id, st), rel = `${appId}/promo/${id}.png`;
        await shoot(spec, join(ctx.mediaDir, rel));
        const d = load(); d.apps[appId] ||= {}; d.apps[appId].files ||= {};
        d.apps[appId].files[id] = { file: rel, w: spec.w, h: spec.h, at: Date.now(), template: spec.template };
        save(d); job.done.push(id); job.progress = (i + 1) / ids.length;
      }
      if (load().settings.useSocial && ids.includes('social')) useAs(appId, `${appId}/promo/social.png`, 'social', true);
    });
  }
  const defaultFormats = app => [...new Set([...(load().settings.formats || AUTO_BASE), ...(AUTO_BY_CATEGORY[app.category] || [])])];

  // ---------- promo videos: the promo-src scene engine, frame by frame into ffmpeg ----------
  function videoSpec(app, aspect, style = {}) {
    const vertical = aspect === '9:16', b = baseFor(app), a = ACCENT[style.accent || b.accent] || ACCENT.violet;
    const files = b.shotFiles.slice(0, 6), feats = app.features || [];
    const title = String(style.headline || b.headline).replace(/\*([^*]+)\*/g, '<span class="grad">$1</span>');
    const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
    const slides = [{ type: 'title', dur: 3.4, kicker: style.kicker ?? (b.kicker || app.version || ''), html: title, sub: esc(b.sub) }];
    // on-screen captions: a feature cut at its first natural clause, never mid-word
    const caption = t => { t = String(t || '').trim(); if (t.length <= 50) return t; const c = t.split(/,\s| — | – |: |; | \(/)[0].trim(); if (c.length >= 16 && c.length <= 56) return c; return t.slice(0, 50).replace(/\s+\S*$/, '') + '…'; };
    files.forEach((f, i) => {
      const d = imageSize(join(ctx.mediaDir, f)), aspectRatio = d?.w && d?.h ? d.w / d.h : 1.6;
      const fx = [.5, .3, .7, .4, .62, .5][i], fy = [.32, .45, .4, .6, .3, .5][i];
      slides.push({ type: 'shot', src: mediaUrl(f), aspect: aspectRatio, title: caption(feats[i] || (i ? app.name : app.tagline)), text: '', bar: app.name, dur: 3.3, z1: 1.18 + (i % 3) * .07, fx, fy,
        ...(vertical ? { cover: true, viewAspect: .78, zRel: 1.08, fx0: fx, fy0: .4 } : {}) });
    });
    if (feats.length > files.length) slides.push({ type: 'features', dur: 4.2, kicker: 'Highlights', title: app.name, items: feats.slice(0, vertical ? 4 : 6).map((t, j) => ({ icon: String(j + 1), t: caption(t), d: '' })), cols: vertical ? 1 : 2 });
    const host = String(ctx.siteUrl() || '').replace(/^https?:\/\//, '').replace(/\/$/, '');
    slides.push({ type: 'end', dur: 4, html: style.endHeadline ? esc(style.endHeadline) : `Get <span class="grad">${esc(app.name)}</span>`, sub: esc(app.price || b.sub), buttons: [app.primaryLabel || 'Learn more', app.platform].filter(Boolean).slice(0, 2), url: host ? `${host}/apps/${app.id}` : '' });
    return { w: vertical ? 1080 : 1920, h: vertical ? 1920 : 1080, name: app.name, logo: b.icon, theme: { a1: a[0], a2: a[1], a3: a[2], bg: '#07080E' }, slides };
  }
  function music(duration, volume = .22) {
    const bar = 3, chords = [[220, 277.18, 329.63, 415.3], [196, 246.94, 293.66, 369.99], [174.61, 220, 261.63, 329.63], [196, 246.94, 293.66, 392]];
    const note = k => chords.map((c, ci) => `${c[k]}*eq(mod(floor(t/${bar}),${chords.length}),${ci})`).join('+');
    const env = `(0.5-0.5*cos(2*PI*min(1,mod(t,${bar})/${bar})))`;
    const expr = `(${[0, 1, 2, 3].map(k => `sin(2*PI*(${note(k)})*t)*${[.32, .22, .2, .14][k]}`).join('+')})*(0.55+0.45*${env})*0.5`;
    return { inputs: ['-f', 'lavfi', '-t', String(duration), '-i', `aevalsrc=exprs='${expr}|${expr}':s=48000`],
      filter: `[1:a]lowpass=f=1400,aecho=0.8:0.7:60|120:0.25|0.18,afade=t=in:d=2,afade=t=out:st=${Math.max(0, duration - 3)}:d=3,volume=${volume},alimiter=limit=0.95[aout]` };
  }
  function renderVideo(appId, aspects = ['16:9'], opts = {}) {
    const app = appOf(appId); if (!app) throw new Error('That app is gone.');
    if (!findChrome()) throw new Error('Promo videos need Google Chrome or Microsoft Edge on this computer.');
    return enqueue('video', appId, `Promo video${aspects.length > 1 ? 's' : ''} for ${app.name}`, async job => {
      if (!(await hasFfmpeg())) throw new Error('Promo videos need FFmpeg. Install it (Windows: winget install ffmpeg · macOS: brew install ffmpeg), restart the app, then try again.');
      const style = { ...(load().apps[appId]?.style || {}), ...(opts.style || {}) };
      for (const [ai, aspect] of aspects.entries()) {
        const spec = videoSpec(appOf(appId) || app, aspect, style), fps = 30;
        const rel = `${appId}/promo/promo-${aspect === '9:16' ? 'vertical' : 'wide'}.mp4`, out = join(ctx.mediaDir, rel), tmp = out + '.part.mp4';
        const c = await chrome(), p = await c.page(spec.w, spec.h, 1);
        try {
          await p.send('Page.addScriptToEvaluateOnNewDocument', { source: `window.SPEC = ${JSON.stringify(spec)};` });
          await p.goto(`${hubOrigin()}/promo/engine.html`, { wait: 200 });
          if (!(await p.eval('window.ready'))) throw new Error('The promo video page didn’t draw.');
          const total = await p.eval('window.TOTAL'), frames = Math.round(total * fps);
          mkdirSync(dirname(out), { recursive: true });
          const audio = opts.music === false ? null : music(total);
          const args = ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'mjpeg', '-i', '-', ...(audio ? audio.inputs : []),
            '-c:v', 'libx264', '-preset', 'medium', '-crf', '19', '-pix_fmt', 'yuv420p', '-movflags', '+faststart',
            ...(audio ? ['-filter_complex', audio.filter, '-map', '0:v', '-map', '[aout]', '-c:a', 'aac', '-b:a', '192k', '-shortest'] : []), tmp];
          const ff = spawn(ffmpegBin(), args, { stdio: ['pipe', 'ignore', 'pipe'], windowsHide: true });
          let err = ''; ff.stderr.on('data', d => { err = (err + d).slice(-1500); });
          const done = new Promise((res, rej) => { ff.on('error', rej); ff.on('close', code => (code ? rej(new Error('FFmpeg could not encode the video: ' + err.trim().split('\n').pop())) : res())); });
          for (let i = 0; i < frames; i++) {
            if (job.state === 'cancelled') { ff.kill(); throw new Error('Cancelled.'); }
            await p.eval(`render(${i / fps})`);
            const jpg = await p.shot({ format: 'jpeg', quality: 92 });
            if (!ff.stdin.write(jpg)) await new Promise(r => ff.stdin.once('drain', r));
            job.progress = (ai + i / frames) / aspects.length;
          }
          ff.stdin.end(); await done;
          rmSync(out, { force: true }); writeFileSync(out, readFileSync(tmp)); rmSync(tmp, { force: true });
          const d = load(); d.apps[appId] ||= {}; d.apps[appId].videos ||= {};
          d.apps[appId].videos[aspect] = { file: rel, w: spec.w, h: spec.h, at: Date.now(), duration: total };
          save(d); job.done.push(aspect);
        } finally { await p.close(); rmSync(tmp, { force: true }); }
      }
    });
  }

  // ---------- using a result ----------
  // cover / screenshot / social (link previews + social posts) / video (the app's video on the site)
  function useAs(appId, file, as, quiet = false) {
    if (!String(file).startsWith(appId + '/promo/') || !existsSync(join(ctx.mediaDir, file))) throw new Error('That promo file is gone.');
    const apps = ctx.loadApps(), a = apps.find(x => x.id === appId); if (!a) throw new Error('That app is gone.');
    // a fresh copy with a new name, so the site and browsers never show a cached old image
    const keep = () => { const ext = extname(file), rel = `${appId}/${as}-${Date.now().toString(36)}${ext}`; writeFileSync(join(ctx.mediaDir, rel), readFileSync(join(ctx.mediaDir, file))); return rel; };
    if (as === 'cover') a.cover = keep();
    else if (as === 'screenshot') a.screenshots = [...(a.screenshots || []), keep()];
    else if (as === 'social') { if (a.socialImage && a.socialImage.startsWith(appId + '/social-')) rmSync(join(ctx.mediaDir, a.socialImage), { force: true }); a.socialImage = keep(); }
    else if (as === 'video') a.videoUrl = keep();
    else throw new Error('Choose cover, screenshot, social or video.');
    ctx.saveApps(apps);
    if (!quiet) ctx.onChange?.(appId);
    return a;
  }

  // ---------- automatic kits when media is uploaded ----------
  const timers = new Map();
  function onUpload(appId, rel, wait = 12000) {
    const s = load().settings;
    if (!s.auto || !appId || !isImg(rel) || /\/promo\//.test(rel) || !findChrome()) return;
    clearTimeout(timers.get(appId));
    // wait until the uploads settle (several screenshots at once, then the editor saves the app)
    timers.set(appId, setTimeout(() => {
      timers.delete(appId);
      const app = appOf(appId); if (!app || ![...(app.screenshots || []), app.cover].some(isImg)) return;
      if ([...jobs.values()].some(j => j.appId === appId && ['queued', 'running'].includes(j.state))) return;
      try { renderKit(appId, null, null, `Promo kit for ${app.name} (new media)`); if (s.autoVideo) renderVideo(appId, ['16:9', '9:16']); } catch (e) { ctx.log?.('promo auto:', e.message); }
    }, wait));
  }

  // saving an app with a new cover or screenshots refreshes its kit soon after (uploads alone may still be in an unsaved draft)
  function onAppSaved(before, after) {
    if (!after?.id) return;
    const sig = a => JSON.stringify([a?.cover || '', ...(a?.screenshots || [])]);
    if (sig(before) !== sig(after) && [...(after.screenshots || []), after.cover].some(isImg)) {
      const rel = (after.screenshots || []).at(-1) || after.cover;
      onUpload(after.id, rel, 3000);
    }
  }
  function overview() {
    const d = load();
    return { formats: FORMATS, templates: TEMPLATES, styles: STYLES, frames: FRAMES, accents: Object.keys(ACCENT), settings: d.settings, autoBase: AUTO_BASE, autoByCategory: AUTO_BY_CATEGORY,
      tools: { chrome: !!findChrome(), ffmpeg: ffmpegOk === null ? null : undefined },
      apps: ctx.loadApps().map(a => {
        const p = d.apps[a.id] || {}, files = Object.fromEntries(Object.entries(p.files || {}).filter(([, f]) => existsSync(join(ctx.mediaDir, f.file))));
        const videos = Object.fromEntries(Object.entries(p.videos || {}).filter(([, f]) => existsSync(join(ctx.mediaDir, f.file))));
        return { id: a.id, name: a.name, tagline: a.tagline, iconImage: a.iconImage, glyph: a.glyph, accent: a.accent, category: a.category, published: !!a.published, cover: a.cover, socialImage: a.socialImage || '', videoUrl: a.videoUrl || '',
          shots: [...(a.screenshots || []), a.cover].filter(isImg).filter((v, i, arr) => arr.indexOf(v) === i && !/\/promo\//.test(v)), features: a.features || [], style: p.style || {}, files, videos, auto: defaultFormats(a) };
      }),
      jobs: [...jobs.values()].map(publicJob).sort((a, b) => b.created - a.created).slice(0, 20) };
  }

  async function route(path, M, body, url) {
    if (path === '/api/promo' && M === 'GET') { const o = overview(); o.tools.ffmpeg = await hasFfmpeg(); return o; }
    if (path === '/api/promo/settings' && M === 'PUT') { const d = load(); for (const k of ['auto', 'autoVideo', 'useSocial']) if (k in body) d.settings[k] = !!body[k]; if (Array.isArray(body.formats)) d.settings.formats = body.formats.filter(id => FORMATS.some(f => f.id === id)); if ('ffmpegPath' in body) { d.settings.ffmpegPath = String(body.ffmpegPath || '').trim(); ffmpegOk = null; } save(d); return overview(); }
    if (path === '/api/promo/preview' && M === 'POST') {
      const app = appOf(body.appId); if (!app) throw new Error('That app is gone.');
      const ids = body.formats?.length ? body.formats : FORMATS.map(f => f.id);
      return { specs: Object.fromEntries(ids.map(id => [id, specFor(app, id, body.style || load().apps[app.id]?.style || {})])) };
    }
    const am = path.match(/^\/api\/promo\/app\/([\w-]+)$/);
    if (am && M === 'PUT') { const d = load(); d.apps[am[1]] ||= {}; d.apps[am[1]].style = body.style || {}; save(d); return { style: d.apps[am[1]].style }; }
    if (path === '/api/promo/render' && M === 'POST') {
      if (body.style) { const d = load(); d.apps[body.appId] ||= {}; d.apps[body.appId].style = body.style; save(d); }
      return { job: publicJob(renderKit(body.appId, body.formats, body.style)) };
    }
    if (path === '/api/promo/video' && M === 'POST') {
      if (!(await hasFfmpeg())) throw new Error('Promo videos need FFmpeg. Install it (Windows: winget install ffmpeg · macOS: brew install ffmpeg), restart the app, then try again.');
      return { job: publicJob(renderVideo(body.appId, (body.aspects || ['16:9']).filter(a => ['16:9', '9:16'].includes(a)), { music: body.music !== false, style: body.style })) };
    }
    if (path === '/api/promo/jobs' && M === 'GET') return { jobs: [...jobs.values()].map(publicJob).sort((a, b) => b.created - a.created).slice(0, 20) };
    const jm = path.match(/^\/api\/promo\/jobs\/(\w+)(\/cancel)?$/);
    if (jm) { const j = jobs.get(jm[1]); if (!j) throw new Error('That job is gone.'); if (jm[2] && M === 'POST' && ['queued', 'running'].includes(j.state)) j.state = 'cancelled'; return { job: publicJob(j) }; }
    if (path === '/api/promo/use' && M === 'POST') { const a = useAs(body.appId, body.file, body.as); return { app: a }; }
    // a copy for the app editor's unsaved draft (the editor saves the app itself)
    if (path === '/api/promo/copy' && M === 'POST') {
      const file = String(body.file || '');
      if (!file.startsWith(body.appId + '/promo/') || !existsSync(join(ctx.mediaDir, file))) throw new Error('That promo file is gone.');
      const rel = `${body.appId}/promo-${basenameNoExt(file)}-${Date.now().toString(36)}${extname(file)}`;
      writeFileSync(join(ctx.mediaDir, rel), readFileSync(join(ctx.mediaDir, file)));
      return { path: rel };
    }
    if (path === '/api/promo/file/delete' && M === 'POST') {
      const d = load(), p = d.apps[body.appId]; if (!p) return overview();
      for (const bag of ['files', 'videos']) for (const [k, f] of Object.entries(p[bag] || {})) if (f.file === body.file) { rmSync(join(ctx.mediaDir, f.file), { force: true }); delete p[bag][k]; }
      save(d); return overview();
    }
    return undefined;
  }

  return { route, onUpload, onAppSaved, renderKit, renderVideo, specFor, overview, FORMATS };
}
