// Connectors: every outside service the hub talks to, in one place.
//
//   Core (already used by the hub, status detected here): Discord, GitHub, Stripe, Cloudflare, Gmail, YouTube
//   Social: X (API v2), LinkedIn, Mastodon, Telegram (Bot API), DEV Community (Forem API v1), Discord (public channel)
//   Stores: itch.io (API + butler), Chrome Web Store (Publish API)
//   AI: Ollama (local models write posts for any platform)
//
// Posts go through one queue (data/connectors.json): drafts waiting for review, scheduled posts, history with links.
// Automation rules turn hub events (new app, release, video, announcement, milestone) into posts per platform,
// written from templates or by an Ollama model, posted straight away or held for review.
// Secrets live in secrets.json → connectors.<id>; nothing here is sent anywhere except the service it belongs to.
import { createHmac, randomBytes, createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { readFileSync, existsSync, writeFileSync, mkdtempSync, rmSync } from 'node:fs';
import { join, extname, basename } from 'node:path';
import { tmpdir } from 'node:os';

const UA = 'PyleriumHub/1.0 (+https://pylerium.github.io)';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const rid = () => randomBytes(6).toString('hex');
const clip = (s, n) => (String(s || '').length > n ? String(s).slice(0, n - 1).trimEnd() + '…' : String(s || ''));
const form = o => new URLSearchParams(Object.entries(o).filter(([, v]) => v !== undefined && v !== null && v !== '').map(([k, v]) => [k, String(v)])).toString();
const pctEnc = s => encodeURIComponent(s).replace(/[!'()*]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
const MIME = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif' };

// ---------- the services ----------
// fields: what the UI asks for (secret: stored in secrets.json, never sent back to the UI in full)
export const DEFS = [
  { id: 'discord', name: 'Discord', icon: 'discord', group: 'Core', kind: 'core', blurb: 'Private alerts, public announcements, the Post tab and buyer emails.' },
  { id: 'github', name: 'GitHub', icon: 'github', group: 'Core', kind: 'core', blurb: 'Publishes your site and keeps paid-download files in private repositories.' },
  { id: 'stripe', name: 'Stripe', icon: 'stripe', group: 'Core', kind: 'core', blurb: 'Payments, products, checkout links, Stripe Tax and sales alerts.' },
  { id: 'cloudflare', name: 'Cloudflare', icon: 'cloudflare', group: 'Core', kind: 'core', blurb: 'Runs your free delivery service for paid downloads and licence checks.' },
  { id: 'gmail', name: 'Gmail', icon: 'mail', group: 'Core', kind: 'core', blurb: 'Sends download links, licence keys, supporter codes and thank-yous.' },
  { id: 'youtube', name: 'YouTube', icon: 'youtube', group: 'Core', kind: 'core', blurb: 'Pulls your latest videos and shorts onto the site and into alerts.' },
  { id: 'x', name: 'X (Twitter)', icon: 'xlogo', group: 'Social', kind: 'social', maxLen: 280, oauth: true, docs: 'https://console.x.com',
    blurb: 'Post to X with API v2: images through the v2 media upload, long posts as numbered threads, reply controls.',
    steps: ['In the X developer console, open your app → User authentication settings → Set up. App permissions: “Read and write”. Type of App: “Web App, Automated App or Bot”. Callback URI: the one below. Website: your site.', 'The X API is pay-per-use: the developer account needs credits (console → Billing), or every call fails with “credits depleted”.', 'Recommended: copy the OAuth 2.0 Client ID and Client Secret (Keys and tokens tab) here and press “Sign in with X”. The hub keeps a refresh token and renews access by itself.', 'Already have a refresh token (from another tool, a backup, or this hub on another computer)? Paste it with the Client ID and Secret of the same X app and press “Use refresh token”: no browser needed.', 'Or use OAuth 1.0a: paste the Consumer Key and Secret and sign in (X shows a PIN if no Callback URI is set), or paste an Access Token and Secret generated after setting Read and write.'],
    fields: [{ k: 'clientId', l: 'OAuth 2.0 Client ID', opt: true, help: 'Recommended: sign-in with a refresh token' }, { k: 'clientSecret', l: 'OAuth 2.0 Client Secret', secret: true, opt: true }, { k: 'refreshToken', l: 'OAuth 2.0 Refresh Token', secret: true, opt: true, help: 'Filled in by Sign in with X, or paste one to sign in without the browser' }, { k: 'apiKey', l: 'Consumer Key', opt: true, help: 'OAuth 1.0a (instead of OAuth 2.0)' }, { k: 'apiSecret', l: 'Consumer Key Secret', secret: true, opt: true }, { k: 'accessToken', l: 'Access Token', opt: true, help: 'OAuth 1.0a: filled in by Sign in with X' }, { k: 'accessSecret', l: 'Access Token Secret', secret: true, opt: true }] },
  { id: 'linkedin', name: 'LinkedIn', icon: 'linkedin', group: 'Social', kind: 'social', maxLen: 3000, oauth: true, docs: 'https://www.linkedin.com/developers/apps',
    blurb: 'Share to your profile (or a company page) with a link preview card.',
    steps: ['Create an app at linkedin.com/developers/apps (a company page is required to create one).', 'Under Products, add “Share on LinkedIn” and “Sign In with LinkedIn using OpenID Connect”.', 'Under Auth, add the redirect URL shown below, then copy the Client ID and Client Secret here and press Connect.', 'Posting as a company page needs the Community Management product (w_organization_social).'],
    fields: [{ k: 'clientId', l: 'Client ID' }, { k: 'clientSecret', l: 'Client secret', secret: true }, { k: 'orgId', l: 'Company page ID', opt: true, help: 'Optional: post as this organization instead of yourself' }] },
  { id: 'mastodon', name: 'Mastodon', icon: 'mastodon', group: 'Social', kind: 'social', maxLen: 500, docs: '',
    blurb: 'Toot to any Mastodon server with visibility, content warnings, language and images.',
    steps: ['On your Mastodon server open Preferences → Development → New application.', 'Give it the scopes read:accounts, write:statuses and write:media, then submit.', 'Open the app and copy “Your access token”, and enter your server address (for example mastodon.social).'],
    fields: [{ k: 'instance', l: 'Server', placeholder: 'mastodon.social' }, { k: 'token', l: 'Access token', secret: true }] },
  { id: 'telegram', name: 'Telegram', icon: 'telegram', group: 'Social', kind: 'social', maxLen: 4096, docs: 'https://t.me/BotFather',
    blurb: 'A bot posts to your channels and groups, with photos, buttons, silent posts and pinning.',
    steps: ['Message @BotFather, send /newbot and follow the steps; copy the token it gives you.', 'Add the bot to your channel or group as an admin (allowed to post, and to pin if you want pinning).', 'Enter the token, then press “Find chats” after posting anything in the chat, or type @channelname.'],
    fields: [{ k: 'token', l: 'Bot token', secret: true }, { k: 'chats', l: 'Chats', placeholder: '@mychannel, -1001234567890', help: 'Comma-separated channel usernames or chat IDs' }] },
  { id: 'itch', name: 'itch.io', icon: 'itch', group: 'Stores', kind: 'store', docs: 'https://itch.io/user/settings/api-keys',
    blurb: 'See views, downloads and purchases for your games, and push builds with butler, automatically on release.',
    steps: ['Open itch.io → Settings → API keys and generate a key.', 'For uploads, install butler (itch.io/docs/butler) or set its path below; it uses the same key.', 'Map each app to its itch.io page (user/game) and channel, and choose whether new releases are pushed automatically.'],
    fields: [{ k: 'apiKey', l: 'API key', secret: true }, { k: 'butlerPath', l: 'butler path', opt: true, placeholder: 'butler (on PATH)' }] },
  { id: 'cws', name: 'Chrome Web Store', icon: 'chrome', group: 'Stores', kind: 'store', oauth: true, docs: 'https://console.cloud.google.com/apis/credentials',
    blurb: 'Upload new extension versions with the Chrome Web Store API v2 and publish them: straight away or staged, with rollout percentage and review status.',
    steps: ['In Google Cloud Console, enable the “Chrome Web Store API” for a project.', 'Create an OAuth client ID of type “Desktop app” and copy its client ID and secret.', 'Copy your Publisher ID from the Chrome Web Store Developer Dashboard → Publisher → Settings.', 'Press “Sign in with Google” with the account that owns your extensions.', 'Map each app to its extension ID (the 32-letter ID in its store URL). The first version of an extension must be uploaded in the dashboard.'],
    fields: [{ k: 'clientId', l: 'OAuth client ID' }, { k: 'clientSecret', l: 'OAuth client secret', secret: true }, { k: 'publisherId', l: 'Publisher ID' }] },
  { id: 'devto', name: 'DEV Community', icon: 'devto', group: 'Social', kind: 'social', maxLen: 100000, docs: 'https://dev.to/settings/extensions',
    blurb: 'Publish articles to dev.to: Markdown, up to four tags, series, cover image and canonical link, as drafts or live.',
    steps: ['Open dev.to → Settings → Extensions → DEV Community API Keys.', 'Give the key a name (for example “Studio Hub”) and press Generate API Key.', 'Paste it here. Articles are saved as drafts unless you switch on “Publish immediately”.'],
    fields: [{ k: 'apiKey', l: 'API key', secret: true }] },
  { id: 'ollama', name: 'Ollama', icon: 'ollama', group: 'AI', kind: 'ai', docs: 'https://ollama.com/download',
    blurb: 'Local AI models write posts for every platform, for any topic, in your voice. Nothing leaves your computer.',
    steps: ['Install Ollama from ollama.com and start it.', 'Pull a model, for example: ollama pull qwen3:4b-instruct (fast) or llama3.1:8b.', 'Pick the model here and describe your voice; posts can then be drafted for any platform.'],
    fields: [{ k: 'host', l: 'Server', placeholder: 'http://127.0.0.1:11434', opt: true }] }
];
const SOCIAL = DEFS.filter(d => d.kind === 'social').map(d => d.id).concat('discord');
export const EVENTS = [
  { id: 'app.new', label: 'New app on the site' }, { id: 'app.available', label: 'App released (coming soon → available)' },
  { id: 'app.updated', label: 'New version or release notes' }, { id: 'app.featured', label: 'App featured' },
  { id: 'yt.video', label: 'New YouTube video' }, { id: 'yt.short', label: 'New YouTube Short' },
  { id: 'site.announcement', label: 'New site announcement' }, { id: 'sale.milestone', label: 'Sales milestone' }
];
const DEFAULT_TPL = {
  'app.new': '🚀 New: {name}. {tagline}\n\n{url}', 'app.available': '{name} is out now! {tagline}\n\n{url}',
  'app.updated': '{name} {version} is out. {notes}\n\n{url}', 'app.featured': '⭐ Featured: {name}. {tagline}\n\n{url}',
  'yt.video': '🎬 New video: {title}\n\n{url}', 'yt.short': '⚡ New Short: {title}\n\n{url}',
  'site.announcement': '📣 {text}\n\n{url}', 'sale.milestone': '🎉 Thank you! Supporters just passed {amount}.\n\n{url}', manual: '{text}'
};
const DEFAULT_TITLE = { 'app.new': '{name}: {tagline}', 'app.available': '{name} is out: {tagline}', 'app.updated': '{name} {version}: {notes}', 'app.featured': '{name}: {tagline}', 'yt.video': '{title}', 'yt.short': '{title}', 'site.announcement': '{text}', 'sale.milestone': 'Thank you, supporters!', manual: '{title}' };
// Platforms whose posts can show in the "Latest posts" section of the website.
// Mastodon and DEV are read from the platform (so posts made elsewhere show too); the others come from what the hub posted.
export const FEEDABLE = ['x', 'mastodon', 'devto', 'telegram', 'linkedin'];
const FETCHABLE = ['mastodon', 'devto'];
const STATUS_WORDS = { live: 'available now', beta: 'in public beta', soon: 'coming soon', dev: 'in development' };
const LENGTH = { short: 'Aim for the short end of that range.', standard: '', long: 'Use the long end of that range.' };
const EMOJI = { none: 'Use no emoji.', few: 'Use at most one or two emoji.', more: 'Emoji are welcome where they fit, never more than one per sentence.' };
const HASHTAGS = { none: 'Do not add any hashtags.', few: 'Use at most two relevant hashtags.', platform: '' };
const REWRITE = { shorter: 'Make it noticeably shorter and tighter. Keep the link.', longer: 'Make it a bit longer with one more concrete detail from the facts. Keep the link.', casual: 'Make it more casual and conversational.', punchy: 'Make the opening line punchier and more attention-grabbing, without hype words.', question: 'End it with a genuine question that invites replies.', formal: 'Make it more professional and polished.' };

export function createConnectors(ctx) {
  // ctx: readJson, writeJson, secrets, saveSecrets, fetchT, loadApps, loadSite, siteUrl(), brand(), port, mediaDir,
  //      core() → statuses of the built-in connections, discordPost(text), releaseAsset({ appId, pattern }), alert(title, desc), log
  const load = () => {
    const d = ctx.readJson('connectors.json', {});
    return { settings: {}, rules: {}, queue: [], history: [], ...d };
  };
  const save = d => ctx.writeJson('connectors.json', d, false);
  const sec = id => (ctx.secrets().connectors || {})[id] || {};
  const setSec = (id, patch) => { const all = { ...(ctx.secrets().connectors || {}) }; all[id] = { ...(all[id] || {}), ...patch }; for (const k of Object.keys(all[id])) if (all[id][k] === '' || all[id][k] == null) delete all[id][k]; ctx.saveSecrets({ connectors: all }); };
  const settings = id => load().settings[id] || {};
  const setSettings = (id, patch) => { const d = load(); d.settings[id] = { ...(d.settings[id] || {}), ...patch }; save(d); };
  const siteUrl = () => String(ctx.siteUrl() || '').replace(/\/$/, '');
  const pending = new Map(); // OAuth state → { id, at, verifier }

  // ---------- per-platform extras: hashtags, a sign-off line, UTM tags on links to your own site ----------
  const tagList = s => String(s || '').split(/[\s,]+/).map(t => t.replace(/^#/, '').replace(/[^\p{L}\p{N}_]/gu, '')).filter(Boolean).slice(0, 8);
  function utm(u, pl, campaign) {
    const site = siteUrl(); if (!site || !u || !String(u).startsWith(site)) return u;
    try { const x = new URL(u); if (x.searchParams.has('utm_source')) return u; x.searchParams.set('utm_source', pl === 'x' ? 'twitter' : pl); x.searchParams.set('utm_medium', 'social'); if (campaign) x.searchParams.set('utm_campaign', campaign); return x.toString(); } catch { return u; }
  }
  // Applied when a draft is made (so you see the final text in review). Running it twice changes nothing.
  function decorate(pl, post) {
    const o = settings(pl).defaults || {}, campaign = String(post.source?.event || 'manual').replace(/\W+/g, '-');
    let text = String(post.text || ''), link = post.link;
    if (o.utm) { text = text.replace(/https?:\/\/[^\s)<>"\]]+/g, u => utm(u, pl, campaign)); link = link ? utm(link, pl, campaign) : link; }
    if (o.footer?.trim() && !text.includes(o.footer.trim())) text = `${text.trimEnd()}\n\n${o.footer.trim()}`;
    if (o.hashtags && pl !== 'devto') {
      const tags = tagList(o.hashtags).filter(t => !new RegExp(`#${t}(?![\\p{L}\\p{N}_])`, 'iu').test(text));
      if (tags.length) text = `${text.trimEnd()}${/(^|\s)#[\p{L}\p{N}_]+\s*$/u.test(text) ? ' ' : '\n\n'}${tags.map(t => '#' + t).join(' ')}`;
    }
    return { ...post, text, link };
  }
  // Where a post about an app links to: its page on your site (default), its own primary link, or your home page.
  function linkFor(app, target) {
    if (!app?.id) return '';
    if (target === 'primary' && /^https?:/.test(app.primaryUrl || '')) return app.primaryUrl;
    if (target === 'home') return siteUrl() + '/';
    return `${siteUrl()}/apps/${app.id}/`;
  }
  const appById = id => (id ? ctx.loadApps().find(a => a.id === id) : null);

  async function http(url, opt = {}, what = 'request') {
    // tests: HUB_CONNECTOR_MOCK=http://127.0.0.1:port sends every service call to a local fake (host kept in the path)
    if (process.env.HUB_CONNECTOR_MOCK && /^https:\/\//.test(url)) url = `${process.env.HUB_CONNECTOR_MOCK}/${url.slice(8)}`;
    const r = await ctx.fetchT(url, { ...opt, headers: { 'User-Agent': UA, ...(opt.headers || {}) } }, opt.timeout || 30000);
    const text = await r.text();
    let j = null; try { j = text ? JSON.parse(text) : {}; } catch { j = { raw: text }; }
    if (!r.ok) {
      const xml = /<error[^>]*>([^<]+)<\/error>/.exec(j?.raw || '')?.[1];
      const m = xml || j?.error_description || j?.message || j?.error?.message || (typeof j?.error === 'string' ? j.error : '') || j?.detail || j?.errors?.[0]?.message || j?.title || j?.description || (/^\s*</.test(j?.raw || '') ? (/<title>([^<]*)<\/title>/i.exec(j.raw)?.[1] || '').trim() : (j?.raw || '').slice(0, 200)) ||`HTTP ${r.status}`;
      throw Object.assign(new Error(`${what}: ${m}`), { status: r.status, body: j });
    }
    return { json: j, headers: r.headers, status: r.status };
  }

  // ================================================================ X (Twitter) API v2, OAuth 1.0a user context
  // tok/tokSecret: the user's access token (posting), a request token (during sign-in) or none (requesting one)
  function oauth1(method, url, c, extra = {}) {
    const tok = 'tok' in extra ? extra.tok : c.accessToken, tokSecret = 'tokSecret' in extra ? extra.tokSecret : c.accessSecret;
    const o = { oauth_consumer_key: c.apiKey, oauth_nonce: randomBytes(16).toString('hex'), oauth_signature_method: 'HMAC-SHA1', oauth_timestamp: String(Math.floor(Date.now() / 1000)), ...(tok ? { oauth_token: tok } : {}), oauth_version: '1.0', ...extra.oauth };
    const u = new URL(url), all = { ...Object.fromEntries(u.searchParams), ...(extra.params || {}), ...o };
    const base = [method.toUpperCase(), pctEnc(u.origin + u.pathname), pctEnc(Object.keys(all).sort().map(k => `${pctEnc(k)}=${pctEnc(all[k])}`).join('&'))].join('&');
    o.oauth_signature = createHmac('sha1', `${pctEnc(c.apiSecret)}&${pctEnc(tokSecret || '')}`).update(base).digest('base64');
    return 'OAuth ' + Object.keys(o).sort().map(k => `${pctEnc(k)}="${pctEnc(o[k])}"`).join(', ');
  }
  const xLen = s => String(s).replace(/https?:\/\/\S+/g, 'x'.repeat(23)).replace(/[\u1100-\u115F\u2E80-\uA4CF\uAC00-\uD7A3\uF900-\uFAFF\uFE30-\uFE4F\uFF00-\uFF60\uFFE0-\uFFE6]/g, 'xx').length;
  const formOf = j => Object.fromEntries(new URLSearchParams(j?.raw ?? ''));
  const x = {
    base: () => (settings('x').apiBase || 'https://api.x.com'),
    redirect: () => `http://127.0.0.1:${ctx.port}/oauth/x`,
    oauth2: () => !!x.clientId(),
    // The Client ID a refresh token belongs to. It is also remembered in settings at every renewal, so clearing the
    // field (or an old form) can never strand a working refresh token again.
    clientId: () => sec('x').clientId || settings('x').oauthClientId || '',
    // OAuth 2.0: access tokens last 2 hours; the refresh token renews them (X rotates it: the new one is saved every time)
    async token(force = false) {
      const s = settings('x');
      if (!force && s.token && s.tokenExp > Date.now() + 60000) return s.token;
      return x._refreshing ||= (async () => {
        const c = sec('x'); if (!c.refreshToken) throw new Error('Press “Sign in with X” (or paste a refresh token) so the hub can post for your account.');
        if (!x.clientId()) throw Object.assign(new Error('X needs the OAuth 2.0 Client ID of the app this refresh token came from to renew it. Paste the Client ID (and Client Secret) from the X developer console → Keys and tokens, then press Save & test.'), { auth: true });
        const j = await x.tokenCall({ grant_type: 'refresh_token', refresh_token: c.refreshToken, client_id: x.clientId() }).catch(e => { throw x.tokenError(e); });
        return j.access_token;
      })().finally(() => { x._refreshing = null; });
    },
    // what went wrong when X refused a token request, in words that say what to do
    tokenError(e) {
      const b = e.body || {}, code = String(b.error || ''), t = `${code} ${b.error_description || ''} ${e.message}`;
      if (e.status >= 500 || !e.status) return e; // X or the network had a moment: the refresh token is untouched, try again later
      let m;
      if (/unauthorized_client|authorization header|client authentication|invalid_client/i.test(t)) m = 'X refused the app keys while renewing the sign-in. Check the OAuth 2.0 Client ID and Client Secret (they must belong to the app the refresh token came from), then press Save & test.';
      else if (/invalid_grant|token was invalid|revoked|expired/i.test(t)) m = 'X ended the sign-in: the refresh token was revoked, already used, or belongs to a different app. Press “Sign in with X” again, or paste a fresh refresh token.';
      else m = `X refused to renew the sign-in (${(b.error_description || code || e.message).replace(/^X sign-in:\s*/, '')}). Press “Sign in with X” again, or paste a fresh refresh token.`;
      return Object.assign(new Error(m), { status: e.status, auth: true });
    },
    async tokenCall(params) {
      const c = sec('x'), id = params.client_id || x.clientId();
      const j = (await http(`${x.base()}/2/oauth2/token`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', ...(c.clientSecret ? { Authorization: 'Basic ' + Buffer.from(`${encodeURIComponent(id)}:${encodeURIComponent(c.clientSecret)}`).toString('base64') } : {}) }, body: form({ ...params, client_id: id }) }, 'X sign-in')).json;
      if (!j.access_token) throw new Error('X didn’t return an access token.');
      if (j.refresh_token) setSec('x', { refreshToken: j.refresh_token }); // saved first: X has already retired the old one
      setSettings('x', { token: j.access_token, tokenExp: Date.now() + (j.expires_in || 7200) * 1000, scope: j.scope || '', oauthClientId: id, renewedAt: Date.now(), authError: '' });
      return j;
    },
    // Sign in with a refresh token pasted by hand: swap it straight away (which also proves it works), then read the account.
    async useRefresh({ refreshToken, clientId, clientSecret } = {}) {
      const rt = String(refreshToken || '').trim();
      if (rt.length < 20 || /\s/.test(rt)) throw new Error('That doesn’t look like an X refresh token. Paste the whole token (it is one long line).');
      if (clientId) setSec('x', { clientId: String(clientId).trim() });
      if (clientSecret && !/^•+/.test(clientSecret)) setSec('x', { clientSecret: String(clientSecret).trim() });
      if (!x.clientId()) throw new Error('Paste the OAuth 2.0 Client ID of the X app this refresh token came from.');
      const before = sec('x').refreshToken;
      setSec('x', { refreshToken: rt });
      try { await x.tokenCall({ grant_type: 'refresh_token', refresh_token: rt, client_id: x.clientId() }); }
      catch (e) { if (before) setSec('x', { refreshToken: before }); throw x.tokenError(e); } // a token X refused never replaces a working one
      const me = await x.call('GET', '/2/users/me').catch(() => null);
      if (me?.data?.username) setSettings('x', { username: me.data.username, userId: me.data.id });
      checks.delete('x');
      activity('connect', `X: signed in with a refresh token${me?.data?.username ? ` as @${me.data.username}` : ''}`);
      return { status: await check('x', true) };
    },
    // keeps the sign-in fresh while the hub runs, so a long gap between posts can't let it lapse
    async keepAlive() {
      const c = sec('x'), s = settings('x');
      if (!c.refreshToken || !x.clientId() || s.authError) return;
      if (Date.now() - (s.renewedAt || 0) < 20 * 3600e3) return;
      try { await x.token(true); } catch (e) { if (e.auth) { setSettings('x', { authError: e.message }); ctx.alert?.('⚠️ X sign-in needs attention', e.message); } }
    },
    // OAuth 2.0 first; when its sign-in is broken and OAuth 1.0a keys are saved too, those carry on posting meanwhile.
    oauth1Ready: c => !!(c.accessToken && c.accessSecret && c.apiKey && c.apiSecret),
    mode: () => { const c = sec('x'), s = settings('x'); return c.refreshToken && !(s.authError && x.oauth1Ready(c)) ? 'oauth2' : x.oauth1Ready(c) ? 'oauth1' : c.refreshToken ? 'oauth2' : ''; },
    async auth(method, url) {
      const c = sec('x');
      if (c.refreshToken && x.mode() === 'oauth2') {
        try { const t = `Bearer ${await x.token()}`; if (settings('x').authError) setSettings('x', { authError: '' }); return t; }
        catch (e) { if (!(e.auth && x.oauth1Ready(c))) { if (e.auth) setSettings('x', { authError: e.message }); throw e; } setSettings('x', { authError: e.message }); }
      }
      if (x.oauth1Ready(c)) return oauth1(method, url, c);
      throw new Error('Press “Sign in with X” (or paste a refresh token) so the hub can post for your account.');
    },
    // every X call: user auth, one silent token renewal on 401, and X's errors in plain words
    async req(method, path, opt = {}) {
      const url = path.startsWith('http') ? path : `${x.base()}${path}`;
      const go = async () => http(url, { method, ...opt, headers: { ...(opt.headers || {}), Authorization: await x.auth(method, url) } }, opt.what || 'X');
      try { return await go(); } catch (e) {
        if (e.status === 401 && sec('x').refreshToken && x.mode() === 'oauth2') { try { await x.token(true); return await go(); } catch (e2) { e = e2; } }
        throw x.explain(e);
      }
    },
    explain(e) {
      if (e.auth) return e;
      const b = e.body || {}, t = `${b.type || ''} ${b.detail || ''} ${b.title || ''} ${b.reason || ''} ${e.message}`;
      let m = '';
      if (e.status === 402 || /credits.depleted/i.test(t)) m = 'Your X developer account has no API credits. The X API is pay-per-use: add credits in the X developer console (Billing), then try again.';
      else if (/client-not-enrolled|not.*enrolled|attached to a project/i.test(t)) m = 'This X app isn’t attached to a Project in the developer console. Move it into a Project, then try again.';
      else if (e.status === 403 && /oauth1-permissions|not permitted|write/i.test(t)) m = 'Your X app is set to Read only. Change App permissions to “Read and write”, then press Sign in with X again (old sign-ins keep the old permission).';
      else if (e.status === 401 && !/ended the sign-in/.test(e.message)) m = 'X refused the saved sign-in: it was revoked, or the keys were regenerated. Press “Sign in with X” again (and paste the new keys if you regenerated them).';
      else if (e.status === 429) m = 'X rate limit reached. The hub tries again later.';
      return m ? Object.assign(new Error(m), { status: e.status, body: e.body }) : e;
    },
    async call(method, path, json) {
      return (await x.req(method, path, { headers: json ? { 'Content-Type': 'application/json' } : {}, body: json ? JSON.stringify(json) : undefined })).json;
    },
    // Sign in with X: OAuth 2.0 PKCE when a Client ID is set (keeps a refresh token), otherwise 3-legged OAuth 1.0a.
    // OAuth 1.0a: if the X app has no Callback URI registered, X only allows PIN sign-in ("oob"): X shows a PIN that the user types into the hub.
    async authUrl() {
      const c = sec('x');
      if (c.clientId) {
        const state = rid(), verifier = randomBytes(32).toString('base64url');
        pending.set(state, { id: 'x', at: Date.now(), verifier });
        return { url: `https://x.com/i/oauth2/authorize?${form({ response_type: 'code', client_id: c.clientId, redirect_uri: x.redirect(), scope: 'tweet.read tweet.write users.read media.write offline.access', state, code_challenge: createHash('sha256').update(verifier).digest('base64url'), code_challenge_method: 'S256' })}`, pin: false };
      }
      if (!c.apiKey || !c.apiSecret) throw new Error('Enter the OAuth 2.0 Client ID and Secret (or the Consumer Key and Secret) first.');
      const url = `${x.base()}/oauth/request_token`;
      const ask = cb => http(url, { method: 'POST', headers: { Authorization: oauth1('POST', url, c, { tok: null, tokSecret: '', oauth: { oauth_callback: cb } }) } }, 'X sign-in').then(r => formOf(r.json));
      let f, pin = false;
      try { f = await ask(x.redirect()); } catch (e) { if (!/oob|callback/i.test(e.message)) throw x.explain(e); f = await ask('oob'); pin = true; }
      if (!f.oauth_token || f.oauth_callback_confirmed !== 'true') throw new Error('X didn’t return a sign-in token. Check the Consumer Key and Secret.');
      pending.set(f.oauth_token, { id: 'x', at: Date.now(), secret: f.oauth_token_secret });
      if (pin) x.pinToken = f.oauth_token;
      return { url: `${x.base()}/oauth/authorize?oauth_token=${encodeURIComponent(f.oauth_token)}`, pin };
    },
    async callback2(code, st) {
      await x.tokenCall({ code, grant_type: 'authorization_code', redirect_uri: x.redirect(), code_verifier: st.verifier, client_id: sec('x').clientId });
      const me = await x.call('GET', '/2/users/me').catch(() => null);
      if (me?.data?.username) setSettings('x', { username: me.data.username, userId: me.data.id });
      activity('connect', `X: signed in${me?.data?.username ? ` as @${me.data.username}` : ''}`);
    },
    async pin(code) {
      const tok = x.pinToken, st = tok && pending.get(tok);
      if (!st || Date.now() - st.at > 15 * 60000) throw new Error('This sign-in expired. Press Sign in with X again.');
      if (!/^\d{4,10}$/.test(String(code || '').trim())) throw new Error('Type the PIN X showed you (digits only).');
      await x.callback(tok, String(code).trim(), st);
      pending.delete(tok); x.pinToken = null; checks.delete('x');
      return { status: await check('x', true) };
    },
    async callback(token, verifier, st) {
      const c = sec('x'), url = `${x.base()}/oauth/access_token`;
      const r = await http(url, { method: 'POST', headers: { Authorization: oauth1('POST', url, c, { tok: token, tokSecret: st.secret, oauth: { oauth_verifier: verifier } }), 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ oauth_verifier: verifier }) }, 'X sign-in');
      const f = formOf(r.json);
      if (!f.oauth_token || !f.oauth_token_secret) throw new Error('X didn’t return an access token.');
      setSec('x', { accessToken: f.oauth_token, accessSecret: f.oauth_token_secret });
      if (f.screen_name) setSettings('x', { username: f.screen_name });
    },
    async test() {
      const c = sec('x');
      if (!c.refreshToken && !x.oauth1Ready(c)) throw new Error(c.clientId || c.apiKey ? 'Keys saved. Press “Sign in with X” (or paste a refresh token) so the hub can post for your account.' : 'Paste your X app keys, then press “Sign in with X”.');
      const r = await x.req('GET', '/2/users/me?user.fields=public_metrics,verified_type,profile_image_url,name');
      const me = r.json, mode = x.mode(), s = settings('x');
      setSettings('x', { username: me.data.username, userId: me.data.id, displayName: me.data.name || '', avatar: me.data.profile_image_url || '', premium: !!me.data.verified_type && me.data.verified_type !== 'none', followers: me.data.public_metrics?.followers_count ?? 0 });
      const level = r.headers.get('x-access-level'), scope = s.scope;
      if (level === 'read' || (mode === 'oauth2' && scope && !/tweet\.write/.test(scope))) throw new Error(`Signed in as @${me.data.username}, but only to read. Set App permissions to “Read and write”, then press Sign in with X again.`);
      const how = mode === 'oauth2' ? 'OAuth 2.0, renews itself' : s.authError ? 'OAuth 1.0a (the OAuth 2.0 sign-in needs attention)' : 'OAuth 1.0a';
      return { ok: true, account: `@${me.data.username}`, detail: `${(me.data.public_metrics?.followers_count ?? 0).toLocaleString()} followers · ${how}`, ...(mode === 'oauth1' && s.authError ? { warn: s.authError } : {}) };
    },
    // what the X tab shows about the sign-in (never the tokens themselves)
    health() {
      const c = sec('x'), s = settings('x');
      return { mode: x.mode(), clientId: !!x.clientId(), clientSecret: !!c.clientSecret, refresh: !!c.refreshToken, oauth1: x.oauth1Ready(c), expires: s.tokenExp || 0, renewedAt: s.renewedAt || 0, scope: s.scope || '', authError: s.authError || '', userId: s.userId || '' };
    },
    // v2 media upload (the v1.1 upload endpoint is retired): one image, multipart, OAuth 2.0 (media.write) or 1.0a
    async uploadImage(file, alt) {
      const fd = new FormData();
      fd.append('media', new Blob([readFileSync(file)], { type: MIME[extname(file).toLowerCase()] || 'image/png' }), basename(file));
      fd.append('media_category', 'tweet_image');
      const j = (await x.req('POST', '/2/media/upload', { body: fd, timeout: 120000, what: 'X media' })).json;
      const id = j?.data?.id || j?.media_id_string || j?.data?.media_id_string;
      if (!id) throw new Error('X media upload returned no id');
      if (alt) await x.call('POST', '/2/media/metadata', { id: String(id), metadata: { alt_text: { text: clip(alt, 1000) } } }).catch(() => {}); // alt text is a nicety: never fails the post
      return String(id);
    },
    // the pictures for a post: the Promo Studio card / cover / icon, or the cover plus screenshots (X allows 4)
    images(p, o) {
      const want = Math.max(1, Math.min(4, +o.maxImages || 1)), src = o.imageSource || 'auto';
      const app = appById(p.source?.app?.id) || p.source?.app || {};
      const local = rel => { if (!rel || /^https?:/.test(rel)) return null; const f = join(ctx.mediaDir, rel); return existsSync(f) && MIME[extname(f).toLowerCase()] ? f : null; };
      if (p.image && src === 'auto') return [local(p.image)].filter(Boolean);
      const pick = src === 'social' ? [app.socialImage, app.cover] : src === 'cover' ? [app.cover, app.socialImage] : src === 'icon' ? [app.iconImage] : src === 'screens' ? [app.socialImage || app.cover, ...(app.screenshots || [])] : [p.image, app.socialImage, app.cover, app.iconImage];
      const out = [...new Set(pick.map(local).filter(Boolean))];
      return src === 'screens' ? out.slice(0, want) : out.slice(0, 1);
    },
    // splits a post into a thread with the chosen numbering, the link placement and an optional closing reply
    parts(p, o) {
      const limit = o.premium || (settings('x').premium && o.premium !== false) ? 25000 : 280;
      let text = String(p.text || '').trim(), linkReply = '';
      const link = p.link || (text.match(/https?:\/\/\S+/) || [])[0];
      if (link && (o.linkPlace === 'reply' || o.linkPlace === 'end') && text.includes(link)) {
        text = text.split(link).join('').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/[:\-–—]\s*$/, '').trim();
        if (o.linkPlace === 'reply') linkReply = fill(o.replyText || '🔗 {url}', { url: link });
        else text = `${text}\n\n${link}`; // "end": the link goes to the last post of the thread
      }
      const STYLES = { paren: (i, n) => ` (${i + 1}/${n})`, thread: (i, n) => i === 0 ? ' 🧵' : ` ${i + 1}/${n}`, none: () => '' };
      let parts = o.thread === false ? [text] : splitThread(text, limit, xLen, STYLES[o.threadStyle]);
      const max = +o.threadMax || 0;
      if (max && parts.length > max) { const raw = splitThread(text, limit, xLen, () => '').slice(0, max); raw[max - 1] = clip(raw[max - 1], limit - 8); parts = raw.map((t, i) => `${t}${(STYLES[o.threadStyle] || ((j, n) => ` ${j + 1}/${n}`))(i, max)}`); }
      if (o.linkPlace === 'end' && link && !parts.at(-1).includes(link)) parts[parts.length - 1] = clip(parts.at(-1), limit - 25) + `\n${link}`;
      if (linkReply) parts.push(linkReply);
      const close = fill(o.closingReply || '', { url: link || siteUrl(), brand: ctx.brand(), handle: settings('x').username ? '@' + settings('x').username : '' });
      if (close) parts.push(clip(close, limit));
      return parts;
    },
    async publish(p) {
      const o = p.options || {}, parts = x.parts(p, o);
      const app = appById(p.source?.app?.id) || p.source?.app || {};
      const media = [], notes = [];
      if (o.image !== false) for (const f of x.images(p, o)) {
        try { media.push(await x.uploadImage(f, o.alt === false ? '' : fill(o.altText || '{name}: {tagline}', { name: app.name || ctx.brand(), tagline: app.tagline || '', version: app.version || '' }).replace(/:\s*$/, ''))); }
        catch (e) { notes.push(`posted without ${media.length ? 'some images' : 'the image'} (${e.message})`); break; }
      }
      let prev = null, first = null;
      for (const [i, t] of parts.entries()) {
        const head = i === 0;
        const body = { text: t, ...(prev ? { reply: { in_reply_to_tweet_id: prev } } : {}),
          ...(o.replySettings && head ? { reply_settings: o.replySettings } : {}),
          ...(media.length && head ? { media: { media_ids: media } } : {}),
          ...(o.communityId && head ? { community_id: String(o.communityId).trim(), ...(o.shareWithFollowers ? { share_with_followers: true } : {}) } : {}),
          ...(o.quoteId && head ? { quote_tweet_id: String(o.quoteId).replace(/^.*status\//, '').replace(/\D.*$/, '') } : {}) };
        const j = await x.call('POST', '/2/tweets', body);
        prev = j.data.id; first ||= prev;
      }
      const me = settings('x').username;
      return { id: first, url: me ? `https://x.com/${me}/status/${first}` : `https://x.com/i/web/status/${first}`, parts: parts.length, images: media.length, ...(notes.length ? { note: notes.join('; ') } : {}) };
    },
    // your latest posts with their numbers (reading costs API credits, so the X tab only loads them on request)
    async recent(n = 10) {
      let id = settings('x').userId;
      if (!id) { const me = await x.call('GET', '/2/users/me'); id = me.data.id; setSettings('x', { userId: id, username: me.data.username }); }
      const j = await x.call('GET', `/2/users/${encodeURIComponent(id)}/tweets?max_results=${Math.max(5, Math.min(50, n))}&exclude=replies,retweets&tweet.fields=created_at,public_metrics`);
      const me = settings('x').username;
      return (j.data || []).map(t => ({ id: t.id, url: `https://x.com/${me || 'i/web'}/status/${t.id}`, date: t.created_at, text: t.text, stats: { likes: t.public_metrics?.like_count || 0, shares: (t.public_metrics?.retweet_count || 0) + (t.public_metrics?.quote_count || 0), replies: t.public_metrics?.reply_count || 0, views: t.public_metrics?.impression_count || 0 } }));
    },
    async remove(id) { const j = await x.call('DELETE', `/2/tweets/${encodeURIComponent(id)}`); return { deleted: !!j?.data?.deleted }; }
  };

  // ================================================================ LinkedIn (OAuth 2.0, Posts API)
  const liVersion = () => settings('linkedin').version || (() => { const d = new Date(); d.setMonth(d.getMonth() - 2); return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}`; })();
  const linkedin = {
    redirect: () => `http://127.0.0.1:${ctx.port}/oauth/linkedin`,
    authUrl() {
      const c = sec('linkedin'); if (!c.clientId) throw new Error('Enter the Client ID and secret first.');
      const state = rid(); pending.set(state, { id: 'linkedin', at: Date.now() });
      const scope = ['openid', 'profile', 'w_member_social', ...(c.orgId ? ['w_organization_social'] : [])].join(' ');
      return `https://www.linkedin.com/oauth/v2/authorization?${form({ response_type: 'code', client_id: c.clientId, redirect_uri: linkedin.redirect(), state, scope })}`;
    },
    async callback(code) {
      const c = sec('linkedin');
      const { json } = await http('https://www.linkedin.com/oauth/v2/accessToken', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ grant_type: 'authorization_code', code, redirect_uri: linkedin.redirect(), client_id: c.clientId, client_secret: c.clientSecret }) }, 'LinkedIn sign-in');
      setSec('linkedin', { accessToken: json.access_token, refreshToken: json.refresh_token || '' });
      const me = (await http('https://api.linkedin.com/v2/userinfo', { headers: { Authorization: `Bearer ${json.access_token}` } }, 'LinkedIn profile')).json;
      setSettings('linkedin', { personUrn: `urn:li:person:${me.sub}`, name: me.name, expiresAt: Date.now() + (json.expires_in || 5184000) * 1000 });
    },
    async test() {
      const c = sec('linkedin'), s = settings('linkedin');
      if (!c.accessToken) throw new Error('Press Connect to sign in to LinkedIn.');
      const me = (await http('https://api.linkedin.com/v2/userinfo', { headers: { Authorization: `Bearer ${c.accessToken}` } }, 'LinkedIn')).json;
      const days = s.expiresAt ? Math.round((s.expiresAt - Date.now()) / 864e5) : null;
      return { ok: true, account: me.name, detail: days != null ? (days > 0 ? `sign-in valid for ${days} more days` : 'sign-in expired: press Connect again') : '' };
    },
    async publish(p) {
      const c = sec('linkedin'), s = settings('linkedin'), o = p.options || {};
      if (!c.accessToken) throw new Error('LinkedIn isn’t connected.');
      const author = o.asOrg && c.orgId ? `urn:li:organization:${c.orgId}` : s.personUrn;
      const body = { author, commentary: clip(p.text, 3000), visibility: o.visibility || 'PUBLIC', distribution: { feedDistribution: 'MAIN_FEED', targetEntities: [], thirdPartyDistributionChannels: [] }, lifecycleState: 'PUBLISHED', isReshareDisabledByAuthor: !!o.noReshare,
        ...(p.link && o.card !== false ? { content: { article: { source: p.link, title: clip(p.title || p.source?.name || p.link, 200), description: clip(p.source?.tagline || '', 250) } } } : {}) };
      const r = await http('https://api.linkedin.com/rest/posts', { method: 'POST', headers: { Authorization: `Bearer ${c.accessToken}`, 'LinkedIn-Version': liVersion(), 'X-Restli-Protocol-Version': '2.0.0', 'Content-Type': 'application/json' }, body: JSON.stringify(body) }, 'LinkedIn');
      const urn = r.headers.get('x-restli-id') || r.headers.get('x-linkedin-id') || '';
      return { id: urn, url: urn ? `https://www.linkedin.com/feed/update/${urn}/` : '' };
    }
  };

  // ================================================================ Mastodon
  const mastodon = {
    // accepts mastodon.social, https://mastodon.social or a profile link like https://mastodon.social/@you
    base() {
      const i = String(sec('mastodon').instance || settings('mastodon').instance || '').trim(); if (!i) throw new Error('Enter your Mastodon server.');
      let h; try { h = new URL(/^https?:\/\//.test(i) ? i : `https://${i}`).host; } catch { throw new Error('That server address isn’t valid. Enter it like mastodon.social'); }
      if (/(^|\.)github\.(io|com)$/.test(h)) throw new Error(`${h} is a website, not a Mastodon server. Enter the server your account is on, like mastodon.social`);
      return `https://${h}`;
    },
    async call(path, opt = {}) {
      const t = sec('mastodon').token; if (!t) throw new Error('Mastodon isn’t set up yet.');
      const b = mastodon.base(), notMasto = () => new Error(`${new URL(b).host} doesn’t look like a Mastodon server. Check the Server field (for example mastodon.social).`);
      let j; try { j = (await http(`${b}${path}`, { ...opt, headers: { Authorization: `Bearer ${t}`, ...(opt.headers || {}) } }, 'Mastodon')).json; } catch (e) { if (/^\s*</.test(e.body?.raw || '')) throw notMasto(); throw e; }
      if (j && typeof j.raw === 'string' && /^\s*</.test(j.raw)) throw notMasto();
      return j;
    },
    async test() { const a = await mastodon.call('/api/v1/accounts/verify_credentials'); setSettings('mastodon', { acct: a.acct, url: a.url, accountId: a.id, avatar: a.avatar_static || a.avatar || '' }); return { ok: true, account: `@${a.acct}@${new URL(mastodon.base()).host}`, detail: `${(a.followers_count ?? 0).toLocaleString()} followers · ${(a.statuses_count ?? 0).toLocaleString()} posts` }; },
    // your own public posts (no replies or boosts), for the website feed and the Mastodon tab
    async recent(n = 6) {
      let id = settings('mastodon').accountId;
      if (!id) { await mastodon.test(); id = settings('mastodon').accountId; }
      const list = await mastodon.call(`/api/v1/accounts/${encodeURIComponent(id)}/statuses?limit=${Math.min(40, n * 2)}&exclude_replies=true&exclude_reblogs=true`);
      return (list || []).filter(s => s.visibility === 'public' && !s.spoiler_text).slice(0, n).map(s => ({ platform: 'mastodon', url: s.url, date: s.created_at, text: htmlText(s.content), image: s.media_attachments?.find(m => m.type === 'image')?.preview_url || s.card?.image || '', stats: { likes: s.favourites_count || 0, shares: s.reblogs_count || 0, replies: s.replies_count || 0 } }));
    },
    async publish(p) {
      const o = p.options || {}, parts = o.thread === false ? [p.text] : splitThread(p.text, settings('mastodon').maxLen || 500);
      let media = [];
      const img = imageFile(p);
      if (img && o.image !== false) {
        const fd = new FormData(); fd.append('file', new Blob([readFileSync(img)], { type: MIME[extname(img).toLowerCase()] || 'image/png' }), basename(img)); if (p.source?.name) fd.append('description', p.source.name);
        try { media = [(await mastodon.call('/api/v2/media', { method: 'POST', body: fd })).id]; } catch { /* post without the image */ }
      }
      let prev = null, first = null;
      for (const [i, t] of parts.entries()) {
        const body = { status: t, visibility: o.visibility || 'public', sensitive: !!o.sensitive, spoiler_text: o.cw || '', language: o.language || undefined, media_ids: i === 0 ? media : [], in_reply_to_id: prev || undefined };
        const s = await mastodon.call('/api/v1/statuses', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Idempotency-Key': `${p.id}-${i}` }, body: JSON.stringify(body) });
        prev = s.id; first ||= s;
      }
      return { id: first.id, url: first.url };
    }
  };

  // ================================================================ Telegram Bot API
  const telegram = {
    async call(method, body, multipart) {
      const t = sec('telegram').token; if (!t) throw new Error('Telegram isn’t set up yet.');
      const r = await http(`https://api.telegram.org/bot${t}/${method}`, multipart ? { method: 'POST', body } : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) }, 'Telegram');
      if (!r.json.ok) throw new Error(`Telegram: ${r.json.description}`);
      return r.json.result;
    },
    chats: () => String(sec('telegram').chats || settings('telegram').chats || '').split(/[,\s]+/).filter(Boolean),
    async test() { const me = await telegram.call('getMe'); setSettings('telegram', { bot: me.username }); return { ok: true, account: `@${me.username}`, detail: `${telegram.chats().length} chat(s)` }; },
    async findChats() {
      const ups = await telegram.call('getUpdates', { limit: 100, allowed_updates: ['message', 'channel_post', 'my_chat_member'] });
      const m = new Map();
      for (const u of ups) { const c = u.message?.chat || u.channel_post?.chat || u.my_chat_member?.chat; if (c && c.type !== 'private') m.set(String(c.id), { id: String(c.id), title: c.title || c.username, type: c.type, username: c.username || '' }); }
      return [...m.values()];
    },
    async publish(p) {
      const o = p.options || {}, chats = o.chats ? String(o.chats).split(/[,\s]+/).filter(Boolean) : telegram.chats();
      if (!chats.length) throw new Error('Add a Telegram chat or channel first.');
      const html = esc(p.text).replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1">$1</a>');
      const markup = o.button && (o.buttonUrl || p.link) ? { inline_keyboard: [[{ text: o.button, url: o.buttonUrl || p.link }]] } : undefined;
      const img = o.photo !== false ? imageFile(p) : null, out = [];
      for (const chat of chats) {
        let msg;
        if (img && html.length <= 1024) {
          const fd = new FormData(); fd.append('chat_id', chat); fd.append('caption', html); fd.append('parse_mode', 'HTML'); if (o.silent) fd.append('disable_notification', 'true');
          if (markup) fd.append('reply_markup', JSON.stringify(markup)); fd.append('photo', new Blob([readFileSync(img)], { type: MIME[extname(img).toLowerCase()] || 'image/png' }), basename(img));
          msg = await telegram.call('sendPhoto', fd, true);
        } else msg = await telegram.call('sendMessage', { chat_id: chat, text: html, parse_mode: 'HTML', link_preview_options: { is_disabled: !!o.noPreview }, disable_notification: !!o.silent, reply_markup: markup });
        if (o.pin) await telegram.call('pinChatMessage', { chat_id: chat, message_id: msg.message_id, disable_notification: true }).catch(() => {});
        const user = msg.chat?.username;
        out.push({ id: `${chat}:${msg.message_id}`, url: user ? `https://t.me/${user}/${msg.message_id}` : '' });
      }
      return { id: out.map(r => r.id).join(','), url: out.find(r => r.url)?.url || '' };
    }
  };

  // ================================================================ Discord (public announcements channel, via the existing notifier)
  // A post about an app goes out as a rich card (cover image, title, link) unless "card" is switched off.
  const discord = {
    async publish(p) {
      const o = p.options || {}, a = p.source?.app;
      const img = a?.socialImage || a?.cover;
      const cover = img && !/^https?:/.test(img) ? `${siteUrl()}/assets/apps/${img}` : (/^https?:/.test(a?.cover || '') ? a.cover : '');
      const card = o.card !== false && (p.link || cover) ? { title: (a?.name ? `${a.name}${a.version ? ` ${a.version}` : ''}` : clip(p.title || '', 256)) || undefined, url: p.link || undefined, description: a?.tagline ? clip(a.tagline, 300) : undefined, color: 0x8B5CF6, image: cover && o.image !== false ? { url: cover } : undefined, footer: { text: ctx.brand() } } : null;
      await ctx.discordPost(`${o.ping ? '@everyone ' : ''}${p.text}`, card, o.button && p.link ? { label: o.button, url: p.link } : null);
      return { id: '', url: '' };
    }
  };

  // ================================================================ itch.io (server API + butler)
  const itch = {
    async api(path) { const k = sec('itch').apiKey; if (!k) throw new Error('itch.io isn’t set up yet.'); return (await http(`https://itch.io/api/1/${encodeURIComponent(k)}${path}`, {}, 'itch.io')).json; },
    async test() { const me = await itch.api('/me'); if (me.errors) throw new Error(me.errors.join(', ')); setSettings('itch', { username: me.user.username, url: me.user.url || '' }); const g = await itch.api('/my-games').catch(() => ({ games: [] })); return { ok: true, account: me.user.username, detail: `${(g.games || []).length} game(s)` }; },
    async games() {
      const g = await itch.api('/my-games');
      return (g.games || []).map(x => ({ id: x.id, title: x.title, url: x.url, cover: x.cover_url, published: !!x.published, views: x.views_count || 0, downloads: x.downloads_count || 0, purchases: x.purchases_count || 0, earnings: (x.earnings || []).map(e => e.amount_formatted).join(', '), type: x.classification, price: x.min_price ? `$${(x.min_price / 100).toFixed(2)}` : 'Free' }));
    },
    butler: () => settings('itch').butlerPath || sec('itch').butlerPath || 'butler',
    run(args, env = {}) {
      return new Promise((res, rej) => {
        const p = spawn(itch.butler(), args, { env: { ...process.env, BUTLER_API_KEY: sec('itch').apiKey || '', ...env }, windowsHide: true });
        let out = ''; p.stdout.on('data', d => out += d); p.stderr.on('data', d => out += d);
        p.on('error', e => rej(new Error(e.code === 'ENOENT' ? 'butler wasn’t found. Install it from itch.io/docs/butler or set its path.' : e.message)));
        p.on('close', c => (c ? rej(new Error(`butler failed: ${out.trim().split('\n').slice(-3).join(' ')}`)) : res(out)));
      });
    },
    async butlerVersion() { try { return (await itch.run(['-V'])).trim().split('\n')[0]; } catch (e) { return ''; } },
    async push({ file, target, channel, version, ifChanged = true }) {
      if (!/^[\w-]+\/[\w-]+$/.test(target || '')) throw new Error('Set the itch.io page as user/game.');
      if (!/^[\w.-]+$/.test(channel || '')) throw new Error('Set a channel, for example windows or html5.');
      const args = ['push', file, `${target}:${channel}`, ...(version ? ['--userversion', version] : []), ...(ifChanged ? ['--if-changed'] : [])];
      const out = await itch.run(args);
      return { url: `https://${target.split('/')[0]}.itch.io/${target.split('/')[1]}`, log: out.trim().split('\n').slice(-4).join('\n') };
    }
  };

  // ================================================================ Chrome Web Store API v2
  // (v1.1 was supported until 15 October 2026; v2 addresses items as publishers/{publisherId}/items/{itemId})
  const CWS = 'https://chromewebstore.googleapis.com';
  const cws = {
    redirect: () => `http://127.0.0.1:${ctx.port}/oauth/google`,
    authUrl() {
      const c = sec('cws'); if (!c.clientId) throw new Error('Enter the OAuth client ID and secret first.');
      const state = rid(), verifier = randomBytes(32).toString('base64url');
      pending.set(state, { id: 'cws', at: Date.now(), verifier });
      return `https://accounts.google.com/o/oauth2/v2/auth?${form({ client_id: c.clientId, redirect_uri: cws.redirect(), response_type: 'code', scope: 'https://www.googleapis.com/auth/chromewebstore', access_type: 'offline', prompt: 'consent', state, code_challenge: createHash('sha256').update(verifier).digest('base64url'), code_challenge_method: 'S256' })}`;
    },
    async callback(code, st) {
      const c = sec('cws');
      const { json } = await http('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ code, client_id: c.clientId, client_secret: c.clientSecret, redirect_uri: cws.redirect(), grant_type: 'authorization_code', code_verifier: st.verifier }) }, 'Google sign-in');
      if (!json.refresh_token) throw new Error('Google didn’t return a refresh token. Remove the app’s access at myaccount.google.com/permissions and connect again.');
      setSec('cws', { refreshToken: json.refresh_token });
      setSettings('cws', { token: json.access_token, tokenExp: Date.now() + (json.expires_in || 3600) * 1000 });
    },
    async token() {
      const c = sec('cws'), s = settings('cws');
      if (s.token && s.tokenExp > Date.now() + 60000) return s.token;
      if (!c.refreshToken) throw new Error('Press “Sign in with Google” first.');
      const { json } = await http('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ client_id: c.clientId, client_secret: c.clientSecret, refresh_token: c.refreshToken, grant_type: 'refresh_token' }) }, 'Google');
      setSettings('cws', { token: json.access_token, tokenExp: Date.now() + (json.expires_in || 3600) * 1000 });
      return json.access_token;
    },
    name(itemId) {
      const pub = String(sec('cws').publisherId || settings('cws').publisherId || '').trim();
      if (!pub) throw new Error('Enter your Publisher ID (Developer Dashboard → Publisher → Settings).');
      if (!/^[a-p]{32}$/.test(itemId || '')) throw new Error('That isn’t a Chrome extension ID (32 letters a–p).');
      return `publishers/${encodeURIComponent(pub)}/items/${itemId}`;
    },
    async call(method, path, body, what) { const t = await cws.token(); return (await http(`${CWS}${path}`, { method, headers: { Authorization: `Bearer ${t}`, ...(body !== undefined && !(body instanceof Uint8Array) ? { 'Content-Type': 'application/json' } : {}) }, body: body === undefined ? undefined : body instanceof Uint8Array ? body : JSON.stringify(body), timeout: 300000 }, what || 'Chrome Web Store')).json; },
    // fetchStatus: what's live, what's in review, the last async upload
    async item(itemId) {
      const j = await cws.call('GET', `/v2/${cws.name(itemId)}:fetchStatus`);
      const rev = r => r ? { state: r.state || '', channels: (r.distributionChannels || []).map(d => ({ version: d.crxVersion, percent: d.deployPercentage })) } : null;
      const pub = rev(j.publishedItemRevisionStatus), sub = rev(j.submittedItemRevisionStatus);
      return { id: j.itemId, published: pub, submitted: sub, version: pub?.channels?.[0]?.version || '', state: sub?.state || pub?.state || 'NOT_PUBLISHED', upload: j.lastAsyncUploadState || '', takenDown: !!j.takenDown, warned: !!j.warned };
    },
    async test() {
      await cws.token();
      const items = (settings('cws').items || []).filter(i => i.itemId);
      if (!items.length) return { ok: true, account: 'Google account connected', detail: 'map an extension to see its status' };
      const it = await cws.item(items[0].itemId);
      return { ok: true, account: 'Google account connected', detail: `${items[0].itemId.slice(0, 8)}… ${stateLabel(it.state)}${it.version ? ` · live v${it.version}` : ''}` };
    },
    async upload(itemId, buffer) {
      let j = await cws.call('POST', `/upload/v2/${cws.name(itemId)}:upload`, new Uint8Array(buffer), 'Chrome Web Store upload');
      // big packages finish asynchronously: poll fetchStatus for up to two minutes
      for (let i = 0; j.uploadState === 'IN_PROGRESS' && i < 24; i++) { await sleep(5000); const st = await cws.item(itemId); if (st.upload && st.upload !== 'IN_PROGRESS') j = { ...j, uploadState: st.upload }; }
      if (j.uploadState === 'FAILED') throw new Error('The Chrome Web Store rejected the package. Check the manifest version is higher than the live one.');
      return { state: j.uploadState, version: j.crxVersion || '' };
    },
    async publish(itemId, { staged = false, percent, skipReview = false, blockOnWarnings = false } = {}) {
      const body = { publishType: staged ? 'STAGED_PUBLISH' : 'DEFAULT_PUBLISH', ...(percent && +percent < 100 ? { deployInfos: [{ deployPercentage: Math.max(0, Math.min(100, Math.round(+percent))) }] } : {}), ...(skipReview ? { skipReview: true } : {}), ...(blockOnWarnings ? { blockOnWarnings: true } : {}) };
      const j = await cws.call('POST', `/v2/${cws.name(itemId)}:publish`, body, 'Chrome Web Store publish');
      return { state: j.state || '', status: stateLabel(j.state), warnings: (j.warningInfo?.warnings || []).map(w => w.description || w.reason) };
    },
    async rollout(itemId, percent) { await cws.call('POST', `/v2/${cws.name(itemId)}:setPublishedDeployPercentage`, { deployPercentage: Math.round(+percent) }, 'Chrome Web Store rollout'); return { percent: Math.round(+percent) }; },
    async cancel(itemId) { await cws.call('POST', `/v2/${cws.name(itemId)}:cancelSubmission`, {}, 'Chrome Web Store'); return { cancelled: true }; }
  };
  function stateLabel(st) { return ({ PENDING_REVIEW: 'in review', STAGED: 'approved, staged', PUBLISHED: 'published', PUBLISHED_TO_TESTERS: 'published to testers', REJECTED: 'rejected', CANCELLED: 'submission cancelled', NOT_PUBLISHED: 'not published yet' })[st] || (st ? st.toLowerCase().replace(/_/g, ' ') : 'unknown'); }

  // ================================================================ DEV Community (Forem API v1)
  const devto = {
    async call(method, path, body) {
      const k = sec('devto').apiKey; if (!k) throw new Error('DEV isn’t set up yet.');
      return (await http(`https://dev.to/api${path}`, { method, headers: { 'api-key': k, Accept: 'application/vnd.forem.api-v1+json', ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined }, 'DEV')).json;
    },
    async test() { const me = await devto.call('GET', '/users/me'); setSettings('devto', { username: me.username }); return { ok: true, account: `@${me.username}`, detail: me.name || '' }; },
    async articles() {
      const list = await devto.call('GET', '/articles/me/all?per_page=30');
      return (list || []).map(a => ({ id: a.id, title: a.title, url: a.url, published: !!a.published, views: a.page_views_count || 0, reactions: a.public_reactions_count ?? a.positive_reactions_count ?? 0, comments: a.comments_count || 0, date: a.published_at || a.created_at || '' }));
    },
    async recent(n = 6) {
      const list = await devto.call('GET', `/articles/me/published?per_page=${Math.min(30, n)}`);
      return (list || []).slice(0, n).map(a => ({ platform: 'devto', url: a.url, date: a.published_at || a.created_at, title: a.title, text: a.description || '', image: a.cover_image || a.social_image || '', stats: { likes: a.public_reactions_count ?? a.positive_reactions_count ?? 0, replies: a.comments_count || 0 } }));
    },
    // "Show DEV, web dev" → showdev, webdev; with no commas, spaces separate tags ("webdev rust")
    tags: t => String(t || '').split(String(t || '').includes(',') ? /,+/ : /[\s#]+/).map(x => x.toLowerCase().replace(/[^a-z0-9]/g, '')).filter(Boolean).slice(0, 4),
    async publish(p) {
      const o = p.options || {}, src = p.source?.app;
      const cover = o.cover !== false && src?.cover && !/^https?:/.test(src.cover) ? `${siteUrl()}/assets/apps/${src.cover}` : (/^https?:/.test(src?.cover || '') ? src.cover : undefined);
      const title = clip(p.title || p.text.split('\n')[0].replace(/^#+\s*/, ''), 128);
      const body = { article: { title, body_markdown: p.text, published: !!o.published, tags: devto.tags(o.tags), series: o.series || undefined,
        canonical_url: o.canonical && p.link ? p.link : undefined, description: clip(o.description || src?.tagline || '', 150) || undefined, main_image: cover, organization_id: o.orgId ? +o.orgId : undefined } };
      const a = await devto.call('POST', '/articles', body);
      return { id: String(a.id), url: a.url || `https://dev.to/dashboard`, draft: !(a.published ?? (a.published_at ? true : !!o.published)) }; // the create answer may leave out "published"
    }
  };

  // ================================================================ Ollama
  const OLLAMA_STYLE = {
    x: 'An X (Twitter) post. At most 260 characters including the link. Punchy, one or two short sentences. No quotation marks.',
    devto: 'A DEV Community article in Markdown. 400 to 900 words, written by the developer for other developers: a short intro, ## headings, what it is, how it works or what you learned building it, code or steps only if they are in the facts, and a closing line with the link. Helpful, not salesy. No hashtags in the body.',
    mastodon: 'A Mastodon post. At most 450 characters including the link. Friendly and genuine, no hype words.',
    linkedin: 'A LinkedIn post. 600 to 1200 characters. A strong first line, short paragraphs, what it does and who it is for, a clear call to action with the link. No emoji spam.',
    telegram: 'A Telegram channel post. 200 to 600 characters. Lead with one emoji, a bold-feeling first line, what is new, then the link.',
    discord: 'A Discord announcement for the studio community server. 150 to 600 characters. Casual and excited, the link on its own line.',
  };
  const PLATFORM_TAGS = { x: 'End with at most two relevant hashtags.', mastodon: 'End with up to three hashtags, each written with capital letters inside, like #IndieDev.', linkedin: 'End with 3 to 5 hashtags.', telegram: 'Do not add hashtags.', discord: 'Do not add hashtags.', devto: '' };
  // what kind of post this is: the writer leads with the right thing (what's new, that it's out, why it's featured)
  const ANGLE = {
    'app.new': 'This post introduces the app for the first time: say what it is, who it is for and the main benefit.',
    'app.available': 'This post announces the app is out now and can be used today: lead with that, then the main benefit.',
    'app.updated': 'This post announces a new version: lead with the version number and what is new in it (the first line under "Recent releases"), then one line on what the app is.',
    'app.featured': 'This post spotlights the app as a featured pick: one line on why it stands out, then what it does.',
    'yt.video': 'This post shares a new YouTube video: make people want to watch it.', 'yt.short': 'This post shares a new YouTube Short: one punchy line.',
    'site.announcement': 'This post shares a studio announcement.', 'sale.milestone': 'This post thanks supporters for a milestone. Warm and genuine.'
  };
  const ollama = {
    host: () => String(sec('ollama').host || settings('ollama').host || 'http://127.0.0.1:11434').replace(/\/$/, ''),
    async models() { const j = (await http(`${ollama.host()}/api/tags`, { timeout: 5000 }, 'Ollama')).json; return (j.models || []).map(m => ({ name: m.name, size: m.size, params: m.details?.parameter_size || '', family: m.details?.family || '', quant: m.details?.quantization_level || '' })); },
    async test() { const m = await ollama.models(); const s = settings('ollama'); return { ok: true, account: ollama.host().replace(/^https?:\/\//, ''), detail: `${m.length} model(s)${s.model ? ` · using ${s.model}` : ''}` }; },
    async chat(messages, { json = false, temperature } = {}) {
      const s = settings('ollama');
      const model = s.model || (await ollama.models())[0]?.name;
      if (!model) throw new Error('No Ollama models installed. Run: ollama pull qwen3:4b-instruct');
      const { json: j } = await http(`${ollama.host()}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, timeout: 300000,
        body: JSON.stringify({ model, messages, stream: false, think: false, format: json ? 'json' : undefined, options: { temperature: temperature ?? s.temperature ?? 0.7, num_ctx: +s.numCtx || 8192, ...(s.topP ? { top_p: +s.topP } : {}) }, keep_alive: s.keepAlive || '10m' }) }, 'Ollama');
      return String(j.message?.content || '').replace(/<think>[\s\S]*?<\/think>/g, '').trim();
    },
    // Who is writing: the studio, its voice, the catalogue (so names are spelled right) and the house rules.
    system({ tone } = {}) {
      const s = settings('ollama'), brand = ctx.brand(), site = ctx.loadSite() || {};
      const about = String(s.about || [site.brand?.tagline, site.hero?.lead].filter(Boolean).join('. ')).trim();
      const apps = ctx.loadApps().filter(a => a.published);
      return [
        `You write social media posts for ${brand}, an independent software studio${siteUrl() ? ` (website: ${siteUrl()})` : ''}.`,
        about && `About the studio: ${clip(about, 400)}`,
        s.catalog !== false && apps.length ? `The studio's apps (spell every name exactly like this, keeping its capital letters): ${apps.map(a => `${a.name}${a.tagline ? ` (${clip(a.tagline, 80)})` : ''}`).join('; ')}.` : '',
        s.voice && `Brand voice: ${s.voice}.`, tone && `Tone for this post: ${tone}.`,
        EMOJI[s.emoji || 'few'], s.cta && `When it fits, the call to action is: ${s.cta}.`,
        s.avoid && `Never use these words or phrases: ${s.avoid}.`,
        'Never invent features, prices, numbers, dates, quotes, testimonials, user counts or facts that are not given, and never claim personal experiences or stories that are not in the facts. If something is not in the facts, leave it out.',
        'Always include the link exactly as given when one is provided. Never use placeholder text like [link] or [Your Name].',
        `Write in ${s.language || 'English'}.`
      ].filter(Boolean).join(' ');
    },
    task(pl, { facts, brief, extra, wantTitle, event }) {
      const s = settings('ollama');
      const tags = pl === 'devto' ? '' : HASHTAGS[s.hashtags || 'platform'] || PLATFORM_TAGS[pl] || 'End with at most two hashtags.';
      return `Write this: ${OLLAMA_STYLE[pl] || 'A short social media post.'} ${LENGTH[s.length || 'standard'] || ''} ${tags}${s.platformNotes?.[pl] ? `\nFor this platform also: ${s.platformNotes[pl]}` : ''}${ANGLE[event] ? `\n${ANGLE[event]}` : ''}

${facts ? `Facts:\n${facts}\n\n` : ''}${brief ? `What to write about: ${brief}\n\n` : ''}${extra ? `Extra instructions: ${extra}\n\n` : ''}${wantTitle ? 'Reply as JSON: {"title": "...", "body": "..."} where the title is at most 120 characters and not clickbait.' : 'Reply with the post text only, exactly as it should be published: no labels, notes or explanations.'}`;
    },
    // Model output → clean post: no wrapping quotes, preambles, label lines ("Hashtags:", "CamelCase:") or trailing spaces.
    parse(raw, wantTitle) {
      const clean = t => String(t || '').replace(/^(Here(’|')s|Sure)[^\n]*:\s*\n+/i, '').replace(/^["“]|["”]$/g, '')
        .replace(/^[ \t]*(?:\*\*)?(?:hashtags?|camel ?case|tags)(?:\*\*)?\s*:\s*/gim, '').replace(/[ \t]+$/gm, '').replace(/\n{3,}/g, '\n\n').trim();
      if (wantTitle) { let j = {}; try { j = JSON.parse(raw); } catch { j = { title: raw.split('\n')[0].replace(/^#+\s*/, ''), body: raw }; } return { title: clip(String(j.title || '').replace(/^["“]|["”]$/g, '').trim(), 300), text: clean(j.body) }; }
      return { text: clean(raw) };
    },
    // Draft one post per platform for an event or any free topic.
    async draft({ platforms, brief, source, tone, extra, event }) {
      const facts = source ? factsFor(source) : '', sys = ollama.system({ tone }), out = {};
      for (const pl of platforms) {
        const wantTitle = pl === 'devto'; // articles need a title
        const raw = await ollama.chat([{ role: 'system', content: sys }, { role: 'user', content: ollama.task(pl, { facts, brief, extra, wantTitle, event }) }], { json: wantTitle });
        out[pl] = ollama.parse(raw, wantTitle);
      }
      return out;
    },
    // Rework one draft: shorter, longer, more casual, punchier, end with a question, more formal, or your own instruction.
    async rewrite({ platform, text, title, how, source, tone }) {
      const facts = source ? factsFor(source) : '', wantTitle = platform === 'devto';
      const ask = REWRITE[how] || String(how || '').trim() || 'Improve it.';
      const raw = await ollama.chat([{ role: 'system', content: ollama.system({ tone }) }, { role: 'user', content: `${OLLAMA_STYLE[platform] || ''}\n\n${facts ? `Facts:\n${facts}\n\n` : ''}Here is the current ${wantTitle ? 'article' : 'post'}${wantTitle && title ? ` (title: ${title})` : ''}:\n"""\n${text}\n"""\n\nRewrite it. ${ask}\n\n${wantTitle ? 'Reply as JSON: {"title": "...", "body": "..."}.' : 'Reply with the new post text only.'}` }], { json: wantTitle });
      return ollama.parse(raw, wantTitle);
    }
  };

  // ---------- facts, templates and images for a post ----------
  function sourceVars(src = {}) {
    const a = src.app || {}, v = src.video || {};
    const url = src.url || (a.id ? `${siteUrl()}/apps/${a.id}/` : v.id ? (v.short ? `https://youtube.com/shorts/${v.id}` : `https://youtu.be/${v.id}`) : siteUrl());
    return { name: a.name || '', tagline: a.tagline || '', version: a.version || '', notes: a.changelog?.[0]?.note || '', price: a.price || '', platform: a.platform || '',
      title: v.title || src.title || '', text: src.text || '', amount: src.amount || '', url, brand: ctx.brand(), site: siteUrl() };
  }
  // What the writer is told about a post's subject: a short, factual brief (what the app does, who it's for, what's new, links).
  function factsFor(src) {
    const v = sourceVars(src), a = src.app?.id ? { ...(appById(src.app.id) || {}), ...src.app } : (src.app || {}), s = settings('ollama');
    const cat = (ctx.loadSite()?.categories || []).find(c => c.id === a.category)?.label;
    const log = (a.changelog || []).slice(0, 3).map(c => `${c.ver || c.version || ''}${c.date ? ` (${c.date})` : ''}: ${clip(c.note || '', 240)}`).filter(x => x.length > 3);
    const desc = String(a.description || '').replace(/\*\*|__|`|^#+\s*/gm, '').replace(/^\s*[-*]\s+/gm, '• ').replace(/\n{2,}/g, '\n').trim();
    return [
      a.name && `App: ${a.name} (spell it exactly like that)`, a.tagline && `Tagline: ${a.tagline}`, cat && `Kind: ${cat}${a.platform ? ` for ${a.platform}` : ''}`, !cat && a.platform && `Platforms: ${a.platform}`,
      a.status && `Status: ${STATUS_WORDS[a.status] || a.status}`, a.version && `Latest version: ${a.version}`, a.price && `Price: ${a.price}`,
      a.metricLabel && a.metricValue && `${a.metricLabel}: ${a.metricValue}`, a.requirements && `Needs: ${clip(a.requirements, 160)}`,
      desc && `What it does: ${clip(desc, 900)}`, (a.features || []).length && `Highlights:\n${a.features.slice(0, 8).map(f => `• ${clip(f, 160)}`).join('\n')}`,
      log.length && `Recent releases:\n${log.join('\n')}`, (a.techStack || []).length && `Built with: ${a.techStack.join(', ')}`,
      a.primaryUrl && a.primaryLabel && `Main button on the site: "${a.primaryLabel}"`,
      s.appNotes?.[a.id] && `Notes from the developer: ${clip(s.appNotes[a.id], 600)}`,
      v.title && `Video title: ${v.title}`, src.video?.description && `Video description: ${clip(src.video.description, 400)}`,
      v.text && `Announcement: ${v.text}`, v.amount && `Milestone: ${v.amount}`, `Link: ${v.url}`
    ].filter(Boolean).join('\n');
  }
  const fill = (t, v) => String(t || '').replace(/\{(\w+)\}/g, (m, k) => v[k] ?? '').replace(/\s+\.\s/g, '. ').replace(/\n{3,}/g, '\n\n').trim();
  function imageFile(p) {
    const rel = p.image || p.source?.app?.socialImage || p.source?.app?.cover || p.source?.app?.iconImage; // the Promo Studio link-preview card first
    if (!rel || /^https?:/.test(rel)) return null;
    const f = join(ctx.mediaDir, rel);
    return existsSync(f) && MIME[extname(f).toLowerCase()] ? f : null;
  }
  function splitThread(text, limit, len = s => s.length, fmt = (i, n) => ` ${i + 1}/${n}`) {
    if (len(text) <= limit) return [text];
    // whole sentences per post where possible, words only when a sentence alone is too long
    const room = limit - Math.max(len(fmt(0, 99)), len(fmt(98, 99))), parts = []; // room for the " 1/9" numbering
    let cur = '';
    const push = () => { if (cur.trim()) parts.push(cur.trim()); cur = ''; };
    for (const s of text.match(/[\s\S]+?(?:[.!?]+(?=\s|$)|\n+|$)\s*/g) || [text]) { // a full stop only ends a sentence before a space, so URLs stay whole
      if (len(cur + s) <= room) { cur += s; continue; }
      push();
      if (len(s) <= room) { cur = s; continue; }
      for (const w of s.split(/(\s+)/)) { if (len(cur + w) > room && cur.trim()) { push(); cur = w.trimStart(); } else cur += w; }
    }
    push();
    return parts.map((p, i) => `${p}${fmt(i, parts.length)}`);
  }

  // ---------- queue ----------
  const PUB = { x, linkedin, mastodon, telegram, devto, discord };
  function addPost(p) {
    const d = load();
    const post = { id: 'p' + rid(), createdAt: new Date().toISOString(), tries: 0, status: 'review', options: {}, ...p };
    d.queue.unshift(post); save(d);
    return post;
  }
  async function publishPost(post) {
    const pub = PUB[post.platform];
    if (!pub) throw new Error(`Unknown platform ${post.platform}`);
    if (post.platform !== 'discord' && !post.text?.trim()) throw new Error('The post is empty.');
    return pub.publish(post);
  }
  let working = false;
  async function work() {
    if (working) return; working = true;
    try {
      // One post at a time, re-reading the queue around each one, so edits and approvals made meanwhile are never lost.
      const tried = new Set();
      for (;;) {
        const d = load(), now = Date.now(), last = d.lastPost || {};
        const post = d.queue.find(p => !tried.has(p.id) && (p.status === 'approved' || ((p.status === 'scheduled' || p.status === 'retry') && Date.parse(p.at) <= now))
          && !(last[p.platform] && now - last[p.platform] < 45000)); // one post per platform every 45 s
        if (!post) break;
        tried.add(post.id);
        post.status = 'posting'; save(d);
        const upd = {};
        try {
          const r = await publishPost(post);
          Object.assign(upd, { status: 'posted', postedAt: new Date().toISOString(), result: r, error: undefined });
        } catch (e) {
          const tries = (post.tries || 0) + 1, permanent = e.status && e.status >= 400 && e.status < 500 && e.status !== 429;
          Object.assign(upd, { tries, error: e.message }, tries < 3 && !permanent ? { status: 'retry', at: new Date(Date.now() + 2 ** tries * 60000).toISOString() } : { status: 'failed' });
          if (upd.status === 'failed') ctx.alert?.(`⚠️ ${DEFS.find(x => x.id === post.platform)?.name || post.platform} post failed`, `${clip(post.text, 200)}\n${e.message}`);
        }
        const d2 = load(), cur = d2.queue.find(p => p.id === post.id);
        if (cur) Object.assign(cur, upd);
        d2.lastPost = { ...(d2.lastPost || {}), ...(upd.status === 'posted' ? { [post.platform]: Date.now() } : {}) };
        d2.history = [...d2.queue.filter(x => x.status === 'posted'), ...d2.history].slice(0, 300);
        d2.queue = d2.queue.filter(x => x.status !== 'posted');
        d2.activity = [{ at: new Date().toISOString(), kind: upd.status === 'posted' ? 'posted' : upd.status === 'failed' ? 'failed' : 'retry', text: `${DEFS.find(x => x.id === post.platform)?.name || post.platform}: ${upd.status === 'posted' ? 'posted' : upd.status === 'failed' ? 'failed' : 'will retry'} “${clip(post.title || post.text.split('\n')[0], 70)}”${upd.error ? `: ${upd.error}` : ''}`, url: upd.result?.url || '' }, ...(d2.activity || [])].slice(0, 50);
        save(d2);
        if (upd.status === 'posted' && FEEDABLE.includes(post.platform) && settings(post.platform).feed?.enabled) feedSoon();
      }
    } finally { working = false; }
  }
  setInterval(() => work().catch(e => ctx.log?.('connectors:', e.message)), 20000).unref?.();

  // ---------- automation: hub events → posts ----------
  // Builds the posts a rule would make for an event without queueing them (used by onEvent and by Automation → Preview).
  async function postsFor(event, src, rule, { useAi = true } = {}) {
    const d = load(), plats = (rule?.platforms || []).filter(p => PUB[p]);
    if (src.app && rule.link && rule.link !== 'page') src = { ...src, url: linkFor(src.app, rule.link) };
    const v = sourceVars(src);
    let drafts = {}, aiError = '';
    if (rule.ai && useAi && plats.length) { try { drafts = await ollama.draft({ platforms: plats, source: src, tone: rule.tone, extra: rule.prompt, event }); } catch (e) { aiError = e.message; ctx.log?.('Ollama draft failed, using templates:', e.message); } }
    const posts = plats.map(pl => {
      const t = rule.templates?.[pl] || rule.template || DEFAULT_TPL[event];
      const text = drafts[pl]?.text || fill(t, v), title = drafts[pl]?.title || fill(rule.titles?.[pl] || DEFAULT_TITLE[event], v);
      const opts = { ...(d.settings[pl]?.defaults || {}), ...(rule.options?.[pl] || {}), ...(rule.image === false ? { image: false, photo: false, cover: false } : {}) };
      return decorate(pl, { platform: pl, text, title, link: v.url, source: { event, ...pickSource(src) }, options: opts, ai: !!drafts[pl] });
    });
    return { posts, aiError };
  }
  const ruleMatches = (rule, src) => !(rule.apps || []).length || !src.app || rule.apps.includes(src.app.id);
  async function onEvent(event, src) {
    const d = load(), rule = d.rules[event];
    const plats = (rule?.platforms || []).filter(p => PUB[p]);
    if (rule?.enabled && plats.length && ruleMatches(rule, src)) {
      const { posts, aiError } = await postsFor(event, src, rule);
      const at = rule.delayMin ? new Date(Date.now() + rule.delayMin * 60000).toISOString() : undefined;
      for (const p of posts) addPost({ ...p, status: rule.mode === 'auto' ? (rule.delayMin ? 'scheduled' : 'approved') : 'review', at });
      const v = sourceVars(src), label = EVENTS.find(e => e.id === event)?.label || event;
      activity('event', `${label}: ${v.name || v.title || clip(v.text, 60)}${v.version ? ` ${v.version}` : ''} → ${posts.length} post${posts.length > 1 ? 's' : ''} (${plats.map(p => DEFS.find(x => x.id === p)?.name || p).join(', ')})${rule.mode === 'auto' ? '' : ', waiting for review'}${aiError ? `. Ollama failed, so templates were used: ${aiError}` : ''}`);
      if (rule.mode !== 'auto') ctx.alert?.(`📝 ${plats.length} post${plats.length > 1 ? 's' : ''} waiting for review`, `${label}: ${v.name || v.title || v.text}. Open Connectors → Queue to approve.`);
      work().catch(() => {});
    }
    // stores: new release → push to itch / upload to the Chrome Web Store
    if (event === 'app.updated' || event === 'app.available') await deploy(src.app).catch(e => ctx.alert?.('⚠️ Store upload failed', e.message));
  }
  // a short activity log for the Overview: events heard, posts sent, feed refreshes
  function activity(kind, text) { const d = load(); d.activity = [{ at: new Date().toISOString(), kind, text }, ...(d.activity || [])].slice(0, 50); save(d); }
  const pickSource = src => ({ app: src.app ? { id: src.app.id, name: src.app.name, tagline: src.app.tagline, version: src.app.version, cover: src.app.cover, socialImage: src.app.socialImage, iconImage: src.app.iconImage } : undefined, video: src.video ? { id: src.video.id, title: src.video.title, short: src.video.short } : undefined, text: src.text, url: src.url });
  async function deploy(app, { force = false } = {}) {
    if (!app) return [];
    const done = [];
    const it = (settings('itch').maps || []).find(m => m.appId === app.id && (m.auto || force));
    if (it && sec('itch').apiKey) {
      const asset = await ctx.releaseAsset({ appId: app.id, pattern: it.pattern || '' });
      const dir = mkdtempSync(join(tmpdir(), 'itch-')); const f = join(dir, asset.name);
      try { writeFileSync(f, asset.buffer); const r = await itch.push({ file: f, target: it.target, channel: it.channel, version: app.version || asset.tag }); done.push(`itch.io ${it.target}:${it.channel}`); ctx.alert?.(`🎮 Pushed ${app.name} ${app.version || ''} to itch.io`, `${it.target}:${it.channel}\n${r.url}`); }
      finally { rmSync(dir, { recursive: true, force: true }); }
    }
    const cw = (settings('cws').items || []).find(m => m.appId === app.id && (m.auto || force));
    if (cw && sec('cws').refreshToken) {
      const asset = await ctx.releaseAsset({ appId: app.id, pattern: cw.pattern || '.zip' });
      const up = await cws.upload(cw.itemId, asset.buffer);
      let pub = null; if (cw.publish) pub = await cws.publish(cw.itemId, { staged: cw.staged, percent: cw.percent, skipReview: cw.skipReview, blockOnWarnings: cw.blockOnWarnings });
      done.push(`Chrome Web Store ${cw.itemId}`);
      ctx.alert?.(`🧩 Uploaded ${app.name} to the Chrome Web Store`, `Package v${up.version || '?'} · upload ${String(up.state).toLowerCase()}${pub ? `\nSubmitted: ${pub.status}${pub.warnings.length ? ` · ${pub.warnings.join('; ')}` : ''}` : '\nNot submitted yet: publish it from the hub or the developer dashboard.'}`);
    }
    return done;
  }

  // ---------- the website's "Latest posts" feed (data/feed.json, read by the site builder) ----------
  // Per platform (settings[id].feed): enabled, count, and for Mastodon/DEV whether posts made outside the hub count too.
  // Profiles (settings[id].profile !== false) add a Follow link on the site for every connected social account.
  const plainOf = t => String(t || '').replace(/https?:\/\/\S+/g, '').replace(/(^|\s)#[\p{L}\p{N}_]+/gu, '').replace(/\s+(\d+\/\d+)$/, '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  function profiles() {
    const out = [], s = id => settings(id), on = id => configured(id) && s(id).profile !== false;
    if (on('x') && s('x').username) out.push({ platform: 'x', handle: '@' + s('x').username, url: `https://x.com/${s('x').username}` });
    if (on('mastodon') && s('mastodon').url) out.push({ platform: 'mastodon', handle: '@' + s('mastodon').acct, url: s('mastodon').url });
    if (on('devto') && s('devto').username) out.push({ platform: 'devto', handle: '@' + s('devto').username, url: `https://dev.to/${s('devto').username}` });
    const tg = telegram.chats().find(c => c.startsWith('@'));
    if (on('telegram') && (s('telegram').profileUrl || tg)) out.push({ platform: 'telegram', handle: tg || 'Telegram', url: s('telegram').profileUrl || `https://t.me/${tg.slice(1)}` });
    if (on('linkedin') && s('linkedin').profileUrl) out.push({ platform: 'linkedin', handle: s('linkedin').name || 'LinkedIn', url: s('linkedin').profileUrl });
    if (configured('itch') && s('itch').profile !== false && (s('itch').profileUrl || s('itch').url)) out.push({ platform: 'itch', handle: s('itch').username ? `${s('itch').username} on itch.io` : 'itch.io', url: s('itch').url });
    for (const p of out) if (s(p.platform).profileUrl) p.url = s(p.platform).profileUrl;
    return out;
  }
  async function buildFeed() {
    const d = load(), F = d.feed || {}, items = [], errors = {};
    for (const pl of FEEDABLE) {
      const f = settings(pl).feed || {}; if (!f.enabled) continue;
      const n = Math.max(1, Math.min(12, +f.count || 3)), mine = [];
      if (FETCHABLE.includes(pl) && f.external !== false && configured(pl)) {
        try { mine.push(...await (pl === 'mastodon' ? mastodon.recent(n) : devto.recent(n))); } catch (e) { errors[pl] = e.message; }
      }
      for (const p of d.history.filter(h => h.platform === pl && h.result?.url && !h.result.draft)) {
        if (mine.length >= n * 2) break;
        const cover = p.source?.app?.cover && !/^https?:/.test(p.source.app.cover) ? `assets/apps/${p.source.app.cover}` : '';
        mine.push({ platform: pl, url: p.result.url, date: p.postedAt || p.createdAt, title: pl === 'devto' || pl === 'linkedin' ? p.title || '' : '', text: plainOf(p.text), image: p.options?.image === false ? '' : cover, app: p.source?.app?.id || '' });
      }
      const seen = new Set();
      items.push(...mine.filter(i => i.url && !seen.has(i.url) && seen.add(i.url)).sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, n));
    }
    items.sort((a, b) => String(b.date).localeCompare(String(a.date)));
    for (const i of items) { i.text = clip(i.text, 320); i.title = clip(i.title || '', 140); }
    return { items: items.slice(0, Math.max(1, Math.min(24, +F.max || 6))), profiles: profiles(), errors };
  }
  let feedTimer = null;
  const feedSoon = () => { clearTimeout(feedTimer); feedTimer = setTimeout(() => refreshFeed('new post').catch(e => ctx.log?.('feed:', e.message)), 15000); };
  async function refreshFeed(reason = 'refresh') {
    const { items, profiles: pr, errors } = await buildFeed();
    const before = ctx.readJson('feed.json', {}), next = { items, profiles: pr };
    const changed = JSON.stringify({ items: before.items || [], profiles: before.profiles || [] }) !== JSON.stringify(next);
    ctx.writeJson('feed.json', { ...next, updatedAt: new Date().toISOString() }, false);
    if (changed) {
      activity('feed', `Website feed updated: ${items.length} post${items.length === 1 ? '' : 's'}, ${pr.length} profile link${pr.length === 1 ? '' : 's'}`);
      if (load().feed?.autoPublish && reason !== 'settings') Promise.resolve(ctx.autoPublish?.('new social posts')).catch(() => {});
    }
    return { items, profiles: pr, errors, changed };
  }
  setTimeout(() => refreshFeed('startup').catch(() => {}), 30000).unref?.();
  setInterval(() => refreshFeed('timer').catch(() => {}), 30 * 60000).unref?.();

  // ---------- status of everything ----------
  const TESTS = { x: x.test, devto: devto.test, linkedin: linkedin.test, mastodon: mastodon.test, telegram: telegram.test, itch: itch.test, cws: cws.test, ollama: ollama.test };
  const configured = id => { const c = sec(id); return id === 'ollama' ? true : id === 'linkedin' ? !!c.accessToken : id === 'cws' ? !!c.refreshToken : id === 'x' ? !!(c.clientId || c.refreshToken || (c.apiKey && c.apiSecret) || c.accessToken) : DEFS.find(d => d.id === id).fields.filter(f => !f.opt).every(f => c[f.k] || settings(id)[f.k]); };
  const checks = new Map(); // id → { at, result }
  async function check(id, force = false) {
    const hit = checks.get(id);
    if (!force && hit && Date.now() - hit.at < 5 * 60000) return hit.result;
    let result;
    if (!configured(id)) result = { ok: false, state: 'off' };
    else try { result = { ...(await TESTS[id]()), state: 'on' }; } catch (e) { result = { ok: false, state: 'error', error: e.message }; }
    checks.set(id, { at: Date.now(), result });
    return result;
  }
  async function overview(force) {
    const core = await ctx.core(force).catch(() => ({}));
    const list = await Promise.all(DEFS.map(async d => {
      const st = d.kind === 'core' ? (core[d.id] || { state: 'off' }) : await check(d.id, force);
      const c = sec(d.id);
      // secrets: dots only (plus the last 4 characters of long keys, so you can tell which key is saved)
      const mask = v => (v ? '•'.repeat(8) + (String(v).length >= 16 ? String(v).slice(-4) : '') : '');
      return { ...d, ...(d.id === 'x' ? { health: x.health() } : {}), status: st, values: Object.fromEntries((d.fields || []).map(f => [f.k, f.secret ? mask(c[f.k]) : (c[f.k] ?? settings(d.id)[f.k] ?? '')])), settings: publicSettings(d.id) };
    }));
    const dd = load();
    dd.queue = dd.queue.filter(p => PUB[p.platform]);
    for (const r of Object.values(dd.rules || {})) if (r.platforms) r.platforms = r.platforms.filter(p => PUB[p]);
    const feed = ctx.readJson('feed.json', {}), feedSec = (ctx.loadSite()?.sections || []).find(s => s.id === 'news');
    return { connectors: list, events: EVENTS, defaults: { templates: DEFAULT_TPL, titles: DEFAULT_TITLE, rewrite: Object.keys(REWRITE) }, rules: dd.rules, port: ctx.port,
      redirects: { linkedin: linkedin.redirect(), google: cws.redirect(), x: x.redirect() }, siteUrl: siteUrl(), brand: ctx.brand(),
      feed: { ...(dd.feed || {}), items: feed.items || [], profiles: feed.profiles || [], updatedAt: feed.updatedAt || '', sectionOn: feedSec ? !!feedSec.enabled : true, feedable: FEEDABLE, fetchable: FETCHABLE },
      activity: (dd.activity || []).slice(0, 25),
      queue: dd.queue, history: dd.history.slice(0, 80), apps: ctx.loadApps().filter(a => a.published).map(a => ({ id: a.id, name: a.name, tagline: a.tagline, version: a.version, cover: a.cover, socialImage: a.socialImage || '', iconImage: a.iconImage, glyph: a.glyph, status: a.status, primaryUrl: a.primaryUrl || '', primaryLabel: a.primaryLabel || '' })) };
  }
  const publicSettings = id => { const { token, tokenExp, ...s } = settings(id); return s; };
  // X sign-in upkeep: renew once a day while the hub runs
  setTimeout(() => x.keepAlive().catch(() => {}), 90000).unref?.();
  setInterval(() => x.keepAlive().catch(() => {}), 3 * 3600e3).unref?.();

  // ---------- OAuth callbacks (no hub token: protected by a one-time state) ----------
  async function oauthCallback(path, url) {
    const page = (ok, msg) => `<!doctype html><meta charset="utf-8"><title>${ok ? 'Connected' : 'Not connected'}</title><body style="font:16px system-ui;background:#07080E;color:#EEF0F8;display:grid;place-items:center;height:100vh;margin:0"><div style="text-align:center;max-width:520px"><div style="font-size:42px">${ok ? '✅' : '⚠️'}</div><h2>${ok ? 'Connected' : 'Something went wrong'}</h2><p style="color:#9AA1BC">${esc(msg)}</p><p style="color:#9AA1BC">You can close this tab and go back to the hub.</p></div><script>setTimeout(()=>{try{window.close()}catch{}},2500)</script>`;
    if (path === '/oauth/x' && !url.searchParams.get('state')) {
      const tok = url.searchParams.get('oauth_token'), ver = url.searchParams.get('oauth_verifier'), sx = pending.get(tok);
      if (url.searchParams.get('denied')) return page(false, 'Sign-in was cancelled on X.');
      if (!sx || Date.now() - sx.at > 15 * 60000) return page(false, 'This sign-in link expired. Press Sign in with X in the hub again.');
      pending.delete(tok);
      try { await x.callback(tok, ver, sx); checks.delete('x'); return page(true, 'X is connected.'); } catch (e) { return page(false, e.message); }
    }
    const state = url.searchParams.get('state'), code = url.searchParams.get('code'), st = pending.get(state);
    if (url.searchParams.get('error')) return page(false, url.searchParams.get('error_description') || url.searchParams.get('error'));
    if (!st || Date.now() - st.at > 15 * 60000) return page(false, 'This sign-in link expired. Press Connect in the hub again.');
    pending.delete(state);
    try {
      if (path === '/oauth/linkedin' && st.id === 'linkedin') await linkedin.callback(code);
      else if (path === '/oauth/google' && st.id === 'cws') await cws.callback(code, st);
      else if (path === '/oauth/x' && st.id === 'x') await x.callback2(code, st);
      else return page(false, 'Unknown sign-in.');
      checks.delete(st.id);
      return page(true, `${DEFS.find(d => d.id === st.id).name} is connected.`);
    } catch (e) { return page(false, e.message); }
  }

  // ---------- API ----------
  // the subject of a draft: an app (with where its link should point), a video, or free text
  function sourceFrom(b = {}) {
    if (b.appId) { const app = appById(b.appId); if (!app) throw new Error('That app is gone.'); return { app, url: /^https?:\/\//.test(b.link || '') ? b.link : linkFor(app, b.link) }; }
    if (b.videoId) { const video = (ctx.loadSite().youtube?.videos || []).find(v => v.id === b.videoId); return video ? { video } : null; }
    if (b.text) return { text: b.text, url: /^https?:\/\//.test(b.link || '') ? b.link : undefined };
    return null;
  }
  async function route(path, M, body, url) {
    const id = path.split('/')[3];
    if (path === '/api/connectors' && M === 'GET') return overview(url?.searchParams.get('force') === '1');
    if (path === '/api/connectors/rules' && M === 'PUT') { const d = load(); d.rules = { ...d.rules, ...(body.rules || {}) }; save(d); return { rules: d.rules }; }
    // what a rule would post for one app, video or announcement, without queueing anything
    if (path === '/api/connectors/rules/preview' && M === 'POST') {
      const rule = body.rule || load().rules[body.event] || {}, src = sourceFrom(body) || { text: 'Example announcement from the studio', url: siteUrl() };
      const { posts, aiError } = await postsFor(body.event, src, { ...rule, platforms: (rule.platforms || []).filter(p => PUB[p]) }, { useAi: !!body.ai });
      return { posts, aiError, matches: ruleMatches(rule, src) };
    }
    if (path === '/api/connectors/context' && M === 'GET') {
      const q = Object.fromEntries(url?.searchParams || []), src = sourceFrom(q);
      return { system: ollama.system({ tone: q.tone }), facts: src ? factsFor(src) : '' };
    }
    if (path === '/api/connectors/draft' && M === 'POST') {
      const src = sourceFrom(body), ev = body.event || 'manual', v = sourceVars(src || {});
      const wrap = (pl, x) => decorate(pl, { text: x.text, title: x.title, link: v.url, source: { event: ev } });
      if (body.ai) {
        const drafts = await ollama.draft({ platforms: body.platforms, brief: body.brief, source: src, tone: body.tone, extra: body.extra, event: ev });
        return { drafts: Object.fromEntries(Object.entries(drafts).map(([pl, x]) => [pl, wrap(pl, x)])), link: v.url };
      }
      const brief = String(body.brief || '').trim();
      return { link: v.url, drafts: Object.fromEntries(body.platforms.map(pl => {
        let text = fill(DEFAULT_TPL[ev] || '{text}', { ...v, text: v.text || brief });
        // a note typed in "Anything to mention" goes in above the link
        if (brief && !text.includes(brief)) { const lines = text.split('\n'), last = lines.at(-1); text = /^https?:\/\//.test(last) ? [...lines.slice(0, -1), brief, '', last].join('\n').replace(/\n{3,}/g, '\n\n') : `${text}\n\n${brief}`; }
        return [pl, wrap(pl, { text, title: fill(DEFAULT_TITLE[ev] || '{title}', { ...v, title: v.title || v.name || clip(brief, 120) }) })];
      })) };
    }
    if (path === '/api/connectors/rewrite' && M === 'POST') {
      const src = sourceFrom(body);
      const r = await ollama.rewrite({ platform: body.platform, text: body.text, title: body.title, how: body.how, source: src, tone: body.tone });
      return { draft: decorate(body.platform, { ...r, link: body.link, source: { event: body.event || 'manual' } }) };
    }
    if (path === '/api/connectors/queue' && M === 'POST') {
      const created = (body.posts || []).map(p => addPost({ platform: p.platform, text: p.text, title: p.title, link: p.link, image: p.image, options: p.options || {}, source: p.source || { event: 'manual' },
        status: body.when === 'now' ? 'approved' : body.when === 'later' ? 'scheduled' : 'review', at: body.when === 'later' ? new Date(body.at).toISOString() : undefined, ai: !!p.ai }));
      work().catch(() => {}); return { created: created.length, ...(await overview(false)) };
    }
    const qm = path.match(/^\/api\/connectors\/queue\/(p[0-9a-f]+)$/);
    if (qm) {
      const d = load(), p = d.queue.find(x => x.id === qm[1]) || d.history.find(x => x.id === qm[1]);
      if (!p) throw new Error('That post is gone.');
      if (M === 'PUT') {
        for (const k of ['text', 'title', 'link', 'options', 'at']) if (k in body) p[k] = body[k];
        if ('at' in body && !body.at) delete p.at;
        if (body.action === 'approve') p.status = p.at && Date.parse(p.at) > Date.now() ? 'scheduled' : 'approved';
        if (body.action === 'now') { p.status = 'approved'; delete p.at; }
        if (body.action === 'schedule' && p.at) p.status = 'scheduled';
        if (body.action === 'hold') p.status = 'review';
        if (body.action === 'reject') p.status = 'rejected';
        if (body.action === 'retry') { p.status = 'approved'; p.tries = 0; }
        save(d); work().catch(() => {});
      }
      if (M === 'DELETE') { d.queue = d.queue.filter(x => x.id !== p.id); d.history = d.history.filter(x => x.id !== p.id); save(d); }
      return overview(false);
    }
    // the website feed: preview, refresh, and its settings (how many, auto-publish, the home page section on or off)
    if (path === '/api/connectors/feed' && M === 'GET') return buildFeed();
    if (path === '/api/connectors/feed/refresh' && M === 'POST') { const r = await refreshFeed('manual'); return { ...r, ...(await overview(false)) }; }
    if (path === '/api/connectors/feed' && M === 'PUT') {
      const d = load(); d.feed = { ...(d.feed || {}), ...(('autoPublish' in body) ? { autoPublish: !!body.autoPublish } : {}), ...(('max' in body) ? { max: Math.max(1, Math.min(24, +body.max || 6)) } : {}) }; save(d);
      if ('section' in body) await ctx.setSiteSection?.('news', !!body.section);
      await refreshFeed('settings').catch(() => {});
      return overview(false);
    }
    if (!id || !DEFS.some(d => d.id === id)) return undefined;
    const def = DEFS.find(d => d.id === id);
    if (path === `/api/connectors/${id}` && M === 'PUT') {
      const patch = {};
      for (const f of def.fields || []) if (f.k in (body.values || {})) { const v = String(body.values[f.k] ?? '').trim(); if (f.secret && /^•+/.test(v)) continue; patch[f.k] = v; }
      // X: a refresh token typed into the form is swapped with X first, so a bad paste never replaces a working sign-in
      let xErr = null;
      if (id === 'x' && 'refreshToken' in patch) { const rt = patch.refreshToken; delete patch.refreshToken; setSec(id, patch); if (rt && rt !== sec('x').refreshToken) { try { await x.useRefresh({ refreshToken: rt }); } catch (e) { xErr = e; } } else if (!rt && sec('x').refreshToken) setSec('x', { refreshToken: '' }); }
      else setSec(id, patch);
      if (body.settings) { const { token, tokenExp, authError, renewedAt, oauthClientId, scope, ...rest } = body.settings; setSettings(id, rest); } // sign-in state is the server's, never a stale copy from the page
      checks.delete(id);
      if (xErr) { checks.set('x', { at: Date.now(), result: { ok: false, state: 'error', error: xErr.message } }); return { status: { ok: false, state: 'error', error: xErr.message }, settings: publicSettings(id), health: x.health() }; }
      const status = def.kind === 'core' ? ((await ctx.core(false).catch(() => ({})))[id] || { state: 'off' }) : await check(id, true);
      if (body.settings && ['feed', 'profile', 'profileUrl'].some(k => k in body.settings)) await refreshFeed('settings').catch(() => {});
      return { status, settings: publicSettings(id), ...(id === 'x' ? { health: x.health() } : {}) };
    }
    if (path === `/api/connectors/${id}` && M === 'DELETE' && url?.searchParams.get('keep') === '1') {
      const keepKeys = { x: ['clientId', 'clientSecret', 'apiKey', 'apiSecret'], linkedin: ['clientId', 'clientSecret'], cws: ['clientId', 'clientSecret', 'publisherId'] }[id];
      if (keepKeys) { const all = { ...(ctx.secrets().connectors || {}) }; all[id] = Object.fromEntries(Object.entries(all[id] || {}).filter(([k]) => keepKeys.includes(k))); ctx.saveSecrets({ connectors: all }); const { token, tokenExp, authError, renewedAt, ...rest } = settings(id); const d = load(); d.settings[id] = rest; save(d); checks.delete(id); activity('connect', `${def.name}: signed out (app keys kept)`); return overview(false); }
    }
    if (path === `/api/connectors/${id}` && M === 'DELETE') { const all = { ...(ctx.secrets().connectors || {}) }; delete all[id]; ctx.saveSecrets({ connectors: all }); const d = load(); delete d.settings[id]; save(d); checks.delete(id); return overview(false); }
    if (path === `/api/connectors/${id}/test` && M === 'POST') return { status: await check(id, true) };
    if (path === `/api/connectors/${id}/connect` && M === 'POST') return id === 'x' ? await x.authUrl() : { url: id === 'linkedin' ? linkedin.authUrl() : cws.authUrl() };
    if (id === 'x' && path.endsWith('/pin') && M === 'POST') return await x.pin(body.pin);
    if (id === 'x' && path.endsWith('/refresh') && M === 'POST') return { ...(await x.useRefresh(body)), health: x.health() };
    if (id === 'x' && path.endsWith('/renew') && M === 'POST') { await x.token(true); checks.delete('x'); return { status: await check('x', true), health: x.health() }; }
    if (id === 'x' && path.endsWith('/refresh-token') && M === 'GET') { const t = sec('x').refreshToken; if (!t) throw new Error('No refresh token is saved.'); return { refreshToken: t, clientId: x.clientId(), note: 'X replaces this token every time the hub renews the sign-in (about every 2 hours while posting, and once a day otherwise). A copy works until then.' }; }
    if (id === 'x' && path.endsWith('/recent') && M === 'GET') return { items: await x.recent(+url?.searchParams.get('n') || 10) };
    if (id === 'x' && path.endsWith('/delete') && M === 'POST') { const r = await x.remove(body.id); const d = load(); for (const h of d.history) if (h.platform === 'x' && h.result?.id === body.id) h.result.deleted = new Date().toISOString(); save(d); activity('posted', `X: deleted post ${body.id}`); return { ...r, ...(await overview(false)) }; }
    if (id === 'devto' && path.endsWith('/articles') && M === 'GET') return { articles: await devto.articles() };
    if (id === 'mastodon' && path.endsWith('/recent') && M === 'GET') return { items: await mastodon.recent(8) };
    if (id === 'telegram' && path.endsWith('/chats') && M === 'GET') return { chats: await telegram.findChats() };
    if (id === 'ollama' && path.endsWith('/models') && M === 'GET') return { models: await ollama.models() };
    if (id === 'itch' && path.endsWith('/games') && M === 'GET') return { games: await itch.games(), butler: await itch.butlerVersion() };
    if (id === 'itch' && path.endsWith('/push') && M === 'POST') {
      const app = ctx.loadApps().find(a => a.id === body.appId); const map = (settings('itch').maps || []).find(m => m.appId === body.appId);
      if (!app || !map) throw new Error('Map this app to an itch.io page first.');
      return { done: await deploy(app, { force: true }) };
    }
    if (id === 'cws' && path.endsWith('/items') && M === 'GET') return { items: await Promise.all((settings('cws').items || []).map(async m => ({ ...m, live: await cws.item(m.itemId).catch(e => ({ error: e.message })) }))) };
    if (id === 'cws' && path.endsWith('/upload') && M === 'POST') {
      const buf = Buffer.from(String(body.data || ''), 'base64'); if (!buf.length) throw new Error('Choose the extension .zip.');
      const up = await cws.upload(body.itemId, buf);
      const pub = body.publish ? await cws.publish(body.itemId, { staged: !!body.staged, percent: +body.percent || undefined, skipReview: !!body.skipReview, blockOnWarnings: !!body.blockOnWarnings }) : null;
      return { upload: up, publish: pub };
    }
    if (id === 'cws' && path.endsWith('/publish') && M === 'POST') return { publish: await cws.publish(body.itemId, { staged: !!body.staged, percent: +body.percent || undefined, skipReview: !!body.skipReview, blockOnWarnings: !!body.blockOnWarnings }) };
    if (id === 'cws' && path.endsWith('/rollout') && M === 'POST') return await cws.rollout(body.itemId, body.percent);
    if (id === 'cws' && path.endsWith('/cancel') && M === 'POST') return await cws.cancel(body.itemId);
    if (id === 'cws' && path.endsWith('/deploy') && M === 'POST') { const app = ctx.loadApps().find(a => a.id === body.appId); return { done: await deploy(app, { force: true }) }; }
    return undefined;
  }

  return { route, onEvent, oauthCallback, overview, work, refreshFeed, _test: { publishX: p => x.publish(p), oauth1, splitThread, xLen, fill, sourceVars, factsFor, decorate, plainOf } };
}
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
// Mastodon statuses are HTML: paragraphs and line breaks become new lines, tags go, entities are decoded.
const htmlText = h => String(h || '').replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>\s*<p>/gi, '\n\n').replace(/<[^>]+>/g, '')
  .replace(/&(amp|lt|gt|quot|#39|apos|nbsp);/g, (m, k) => ({ amp: '&', lt: '<', gt: '>', quot: '"', '#39': "'", apos: "'", nbsp: ' ' })[k]).trim();
