// Pylerium Manager: builds a studio's public site from its data.
// Only apps marked "published" are written. Private fields (notes, local paths, supporter emails) never leave the hub.
// usage: node build.mjs
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, existsSync, readdirSync, statSync, rmSync, rmdirSync } from 'node:fs';
import { join, dirname, resolve, relative, sep } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

export const HUB = dirname(fileURLToPath(import.meta.url));
const R = await import(pathToFileURL(join(HUB, 'shared', 'render.js')).href);
const { cardHTML, detailHTML, brandMark, icon, esc, publicApp, categoryOf, videoCardHTML, shortCardHTML, socialLinksHTML, media, href } = R;

// Everything a customer owns lives in their user profile, so updating the app never touches it.
export const ROOT = process.env.PM_HOME || (process.platform === 'win32' ? join(process.env.APPDATA || join(homedir(), 'AppData', 'Roaming'), 'Pylerium Manager')
  : process.platform === 'darwin' ? join(homedir(), 'Library', 'Application Support', 'Pylerium Manager') : join(process.env.XDG_CONFIG_HOME || join(homedir(), '.config'), 'pylerium-manager'));
export const DATA = join(ROOT, 'data'), MEDIA = join(ROOT, 'media'), SITE = join(ROOT, 'site');
for (const d of [DATA, MEDIA, SITE]) mkdirSync(d, { recursive: true });
export const PRODUCT = JSON.parse(readFileSync(join(HUB, 'product.json'), 'utf8'));
const readJson = (f, d) => { try { return JSON.parse(readFileSync(join(DATA, f), 'utf8')); } catch { return d; } };
export function loadConfig() {
  const c = { port: PRODUCT.port || 4380, branch: 'main', extraPages: [], footerLinks: [], siteUrl: '', githubUrl: '', supportEmail: '', ...readJson('config.json', {}) };
  c.siteDirAbs = SITE;
  return c;
}
export const brandName = site => site.brand?.name || 'My Studio';
const fmtMoney = (v, cur) => { try { return new Intl.NumberFormat('en', { style: 'currency', currency: cur || 'USD', currencyDisplay: 'symbol', minimumFractionDigits: v % 1 ? 2 : 0 }).format(v); } catch { return `${v} ${cur}`; } };
const brandFor = (site, base) => ({ name: brandName(site), logoUrl: site.brand?.logo ? `${base}assets/brand/${site.brand.logo.split('/').pop()}` : '' });
export const DEFAULT_PRINCIPLES = [
  { icon: 'lock', title: 'Local-first', text: 'Our apps do their work on your own device. Your files, libraries and settings stay with you.', a1: '#2DD4BF', a2: '#38BDF8' },
  { icon: 'sparkles', title: 'Crafted interfaces', text: 'Every screen is designed for the way it’s used, whether that’s a mouse, a keyboard, a controller or a TV remote.', a1: '#8B5CF6', a2: '#6366F1' },
  { icon: 'github', title: 'Open by default', text: 'Most of our apps publish their source on GitHub, so you can see exactly how they work.', a1: '#F97316', a2: '#22D3EE' }
];
export const loadApps = () => readJson('apps.json', []);
export const loadSite = () => readJson('site.json', {});
export const loadSupporters = () => readJson('supporters.json', []);
export const loadDelivery = () => readJson('delivery.json', {});
export const sortApps = apps => [...apps].sort((a, b) => (a.order ?? 1e9) - (b.order ?? 1e9) || a.name.localeCompare(b.name));
export const publishedApps = apps => sortApps(apps.filter(a => a.published)).map(publicApp);

const isLocal = p => p && !/^(https?:|data:|blob:)/i.test(p);
const mediaOf = app => [app.cover, app.iconImage, ...(app.screenshots || [])].filter(isLocal);
function walk(dir) { if (!existsSync(dir)) return []; return readdirSync(dir).flatMap(n => { const p = join(dir, n); return statSync(p).isDirectory() ? walk(p) : [p]; }); }
function pruneEmpty(dir) { if (!existsSync(dir)) return; for (const n of readdirSync(dir)) { const p = join(dir, n); if (statSync(p).isDirectory()) { pruneEmpty(p); if (!readdirSync(p).length) rmdirSync(p); } } }
const sec = (site, id) => (site.sections || []).find(s => s.id === id) || { id, enabled: false };
const json = o => JSON.stringify(o).replace(/</g, '\\u003c');
// Cache-busting: GitHub Pages caches CSS/JS for 10 minutes, so every changed file gets a new ?v= stamp.
const VER = {};
const stamp = f => createHash('sha1').update(readFileSync(f)).digest('hex').slice(0, 10);

// Public, non-sensitive data the site script needs. Supporter codes are only present as salted SHA-256 hashes.
export function publicData(pub, site, supporters, cfg) {
  const c = site.community || {};
  return {
    apps: pub, categories: site.categories, socials: site.socials || [], supportEmail: cfg.supportEmail,
    donate: site.donate?.enabled && site.donate.url ? { label: site.donate.label, url: site.donate.url } : null,
    brand: brandName(site),
    community: c.submissionsEnabled ? { salt: c.salt, repo: c.repo, threshold: c.threshold, currency: c.currency, prefix: c.codePrefix || 'CAFE',
      codes: supporters.filter(s => s.codeHash && !s.revoked).map(s => s.codeHash), email: cfg.supportEmail } : null,
    siteUrl: cfg.siteUrl
  };
}

function videosOf(site) {
  const y = site.youtube || {};
  const vis = (y.videos || []).filter(v => !v.hidden).sort((a, b) => (b.pinned - a.pinned) || (b.published || '').localeCompare(a.published || ''));
  return { long: vis.filter(v => !v.short).slice(0, y.maxVideos || 6), shorts: y.showShorts ? vis.filter(v => v.short).slice(0, y.maxShorts || 12) : [], channelUrl: y.channelUrl };
}

function caffeineBtn(site, cls = 'caffeine') {
  const d = site.donate || {};
  if (!d.enabled || !d.url) return '';
  return `<a class="${cls}" href="${esc(d.url)}" target="_blank" rel="noopener"><span class="steam"><i></i><i></i><i></i></span>${icon('can')}<span>${esc(d.label || 'Supply caffeine')}</span></a>`;
}

// ---------- page shell (home + app pages) ----------
function shell({ base, title, desc, canonical, ogImage, body, data, site, cfg, home, head = '', scripts = '' }) {
  R.resetMarks();
  const s = id => sec(site, id).enabled;
  const L = h => (home ? h : base + h);
  const navLinks = [
    s('featured') && ['#featured', 'Featured'], ['#apps', 'Apps'], s('videos') && site.youtube?.videos?.length && ['#videos', 'Videos'],
    s('community') && site.community?.submissionsEnabled && ['#community', 'Community'], s('support') && ['#support', 'Support']
  ].filter(Boolean);
  const ann = site.announcement || {};
  const annKey = 'ann-' + [...(ann.text || '')].reduce((h, c) => (h * 31 + c.charCodeAt(0)) | 0, 7);
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
<meta name="theme-color" content="#07080E">
<link rel="canonical" href="${esc(canonical)}">
<link rel="icon" href="${base}assets/${site.brand?.logo ? 'brand/' + esc(site.brand.logo.split('/').pop()) : 'mark.svg'}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="${esc(brandName(site))}">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(desc)}">
<meta property="og:url" content="${esc(canonical)}">
${ogImage ? `<meta property="og:image" content="${esc(ogImage)}">` : ''}
<meta name="twitter:card" content="summary_large_image">
<link rel="stylesheet" href="${base}css/showcase.css?v=${VER.showcase}">
<link rel="stylesheet" href="${base}css/studio.css?v=${VER.studio}">
${head}</head>
<body${home ? ' class="home"' : ' class="app-page"'}>
<div class="ambient" aria-hidden="true"><span class="orb o1"></span><span class="orb o2"></span><span class="orb o3"></span><span class="gridlines"></span></div>
${ann.enabled && ann.text ? `<div class="announce tone-${esc(ann.tone || 'violet')}" data-key="${annKey}" hidden><div class="wrap">${icon('megaphone')}<span>${esc(ann.text)}</span>${ann.url ? `<a href="${esc(href(ann.url, base))}"${/^https?:/.test(ann.url) ? ' target="_blank" rel="noopener"' : ''}>${esc(ann.linkLabel || 'Learn more')}${icon('arrow')}</a>` : ''}<button type="button" class="ann-x" aria-label="Dismiss">${icon('x')}</button></div></div>` : ''}
<header class="nav">
  <div class="wrap">
    <a class="brand" href="${home ? './' : base}">${brandMark('mark', brandFor(site, base))}<span>${esc(brandName(site))}<small>${esc(site.brand?.tagline || '')}</small></span></a>
    <button class="menu-btn" type="button" aria-label="Menu">${icon('menu')}</button>
    <nav class="nav-links">
      ${navLinks.map(([h, l]) => `<a href="${L(h)}">${l}</a>`).join('')}
      ${cfg.githubUrl ? `<a class="gh" href="${esc(cfg.githubUrl)}" target="_blank" rel="noopener">${icon('github')}GitHub</a>` : ''}
      ${site.donate?.showInNav ? caffeineBtn(site, 'caffeine sm') : ''}
    </nav>
  </div>
</header>
${body}
<footer class="site">
  <div class="wrap">
    <div class="f-brand"><a class="brand" href="${home ? './' : base}">${brandMark('mark', brandFor(site, base))}<span>${esc(brandName(site))}</span></a><span class="copy-note">© ${new Date().getFullYear()} ${esc(brandName(site))}${site.brand?.credit === false ? '' : ' · Made with <a href="https://pylerium.github.io/manager/" target="_blank" rel="noopener">Pylerium Manager</a>'}</span></div>
    ${socialLinksHTML(site.socials)}
    <nav>${(cfg.footerLinks || []).map(l => `<a href="${esc(href(l.url, base))}">${esc(l.label)}</a>`).join('')}${cfg.supportEmail ? `<a href="mailto:${esc(cfg.supportEmail)}">Contact</a>` : ''}</nav>
  </div>
</footer>

<dialog class="app-dlg" id="dlg" aria-labelledby="dlg-title"><button class="dlg-close" type="button" aria-label="Close">${icon('x')}</button><div class="dlg-scroll" id="dlg-body"></div></dialog>
<dialog class="short-dlg" id="shortDlg" aria-label="Short"><button class="dlg-close" type="button" aria-label="Close">${icon('x')}</button><div class="short-stage" id="shortStage"></div></dialog>
<dialog class="app-dlg form-dlg" id="submitDlg" aria-labelledby="sub-title"><button class="dlg-close" type="button" aria-label="Close">${icon('x')}</button><div class="dlg-scroll" id="submitBody"></div></dialog>
${site.donate?.enabled && site.donate.url && site.donate.floating !== false ? `<a class="cafe-float" href="${esc(site.donate.url)}" target="_blank" rel="noopener" aria-label="${esc(site.donate.label || 'Supply caffeine')}"><span class="cf-cup"><span class="steam"><i></i><i></i><i></i></span>${icon('can')}</span><span class="cf-txt">${esc(site.donate.label || 'Supply caffeine')}</span></a>` : ''}
<div class="toast" id="toast"></div>
<script type="application/json" id="site-data">${json(data)}</script>
<script>window.SITE_BASE=${JSON.stringify(base)};</script>
<script type="module" src="${base}js/studio.js?v=${VER.js}"></script>
${scripts}</body>
</html>
`;
}

// ---------- home ----------
function renderHome(pub, site, supporters, cfg) {
  const base = '';
  const now = Date.now();
  const o = { mediaBase: 'assets/apps/', base, now };
  const featured = pub.filter(a => a.featured);
  const used = R.categories().filter(c => pub.some(a => a.category === c.id));
  const community = pub.filter(a => a.community);
  const v = videosOf(site);
  const hero = site.hero || {};
  const stats = [
    [pub.length, 'Apps'],
    [new Set(pub.map(a => a.category)).size, 'Platforms'],
    [pub.filter(a => /github\.com\/[^/]+\/[^/]+/.test(a.repoUrl || '')).length, 'Open source'],
    [pub.filter(a => a.status === 'live' || a.status === 'beta').length, 'Available now']
  ];
  const head = (id, extra = '') => { const s = sec(site, id); return s.title || s.kicker ? `<div class="sec-head reveal"><div>${s.kicker ? `<div class="kicker">${esc(s.kicker)}</div>` : ''}${s.title ? `<h2>${esc(s.title)}</h2>` : ''}${s.subtitle ? `<p>${esc(s.subtitle)}</p>` : ''}</div>${extra}</div>` : ''; };
  const c = site.community || {};
  const wall = c.showWall ? supporters.filter(s => s.wall && (s.wallName || s.name)).map(s => s.wallName || s.name) : [];

  const blocks = {
    featured: () => featured.length ? `<section class="block wrap" id="featured">${head('featured')}<div class="spot" id="spot"><div class="spot-track">${featured.map((a, i) => `<div class="spot-slide" aria-roledescription="slide" aria-label="${i + 1} of ${featured.length}">${cardHTML(a, { ...o, wide: true })}</div>`).join('')}</div>${featured.length > 1 ? `<div class="spot-nav"><button type="button" class="ibtn" data-spot="-1" aria-label="Previous">${icon('chevleft')}</button><div class="spot-dots">${featured.map((a, i) => `<button type="button" data-dot="${i}" aria-label="${esc(a.name)}"${i ? '' : ' class="on"'}></button>`).join('')}</div><button type="button" class="ibtn" data-spot="1" aria-label="Next">${icon('chevron')}</button><span class="spot-bar"><i></i></span></div>` : ''}</div></section>` : '',
    apps: () => `<section class="block wrap" id="apps">${head('apps')}
    <div class="filters reveal">
      <div class="tabs" role="tablist">
        <button class="tab on" type="button" data-cat="all">All <em>${pub.length}</em></button>
        ${used.map(cat => `<button class="tab" type="button" data-cat="${esc(cat.id)}">${icon(cat.icon)}${esc(cat.label)} <em>${pub.filter(a => a.category === cat.id).length}</em></button>`).join('')}
        ${community.length ? `<button class="tab" type="button" data-cat="@community">${icon('users')}Community <em>${community.length}</em></button>` : ''}
      </div>
      <label class="search">${icon('search')}<input id="q" type="search" placeholder="Search apps and features" autocomplete="off" aria-label="Search apps"></label>
    </div>
    <div class="grid" id="all-apps">${pub.map(a => cardHTML(a, o)).join('\n')}</div>
    <div class="empty" id="empty"><p>No apps match that search.</p><button class="btn ghost" id="clear" type="button">Clear filters</button></div></section>`,
    videos: () => (v.long.length || v.shorts.length) ? `<section class="block wrap" id="videos">${head('videos', v.channelUrl ? `<a class="btn yt" href="${esc(v.channelUrl.replace(/\/$/, ''))}?sub_confirmation=1" target="_blank" rel="noopener">${icon('youtube')}Subscribe</a>` : '')}
      ${v.long.length ? `<div class="vgrid reveal">${v.long.map(videoCardHTML).join('')}</div>` : ''}
      ${v.shorts.length ? `<div class="shorts-head reveal"><h3>${icon('zap')}Shorts</h3><div class="rail-btns"><button type="button" class="ibtn" data-rail="-1" aria-label="Scroll left">${icon('chevleft')}</button><button type="button" class="ibtn" data-rail="1" aria-label="Scroll right">${icon('chevron')}</button></div></div><div class="shorts reveal" id="shorts">${v.shorts.map(shortCardHTML).join('')}</div>` : ''}
    </section>` : '',
    embeds: () => { const em = (site.embeds || []).filter(e => e.enabled && e.placement !== 'app' && e.code); return em.length ? `<section class="block wrap" id="embeds">${head('embeds')}${em.map(e => `<div class="embed-block w-${esc(e.width || 'full')} reveal">${e.title ? `<h3>${esc(e.title)}</h3>` : ''}${e.subtitle ? `<p>${esc(e.subtitle)}</p>` : ''}<div class="embed-box">${e.code}</div></div>`).join('')}</section>` : ''; },
    community: () => c.submissionsEnabled ? `<section class="block wrap" id="community">${head('community')}
      <div class="comm reveal">
        <div class="comm-card">
          <span class="comm-ico">${icon('crown')}</span>
          <h3>Supporters can submit their own apps</h3>
          <p>${esc(c.blurb || `Give ${fmtMoney(+c.threshold || 10, c.currency)} or more and you'll get a supporter code that unlocks submissions.`)}</p>
          <ul>${(c.perks || []).map(p => `<li>${icon('check')}<span>${esc(p)}</span></li>`).join('')}</ul>
          <div class="comm-ctas"><button class="btn primary" type="button" data-submit>${icon('send')}Submit your app</button>${caffeineBtn(site, 'caffeine lg')}</div>
          <small class="fine">Already a supporter? You'll find your code in the email we sent you.</small>
        </div>
        <div class="comm-side">
          ${community.length ? `<div class="comm-stat"><b class="grad-text">${community.length}</b><span>community ${community.length === 1 ? 'app' : 'apps'} in the showcase</span><button class="btn ghost sm" type="button" data-cat-jump="@community">Browse them${icon('arrow')}</button></div>` : `<div class="comm-stat"><b class="grad-text">${icon('sparkles')}</b><strong>The community shelf is open</strong><span>No community apps yet. Submit yours and it could be the first one here.</span></div>`}
          ${wall.length ? `<div class="wall"><h4>${icon('can')}${esc(c.wallTitle || 'Caffeine suppliers')}<em>${wall.length}</em></h4><p>${esc(c.wallThanks || `Thank you for supporting ${brandName(site)}.`)}</p><div class="wall-names">${wall.map(n => `<span>${esc(n)}</span>`).join('')}</div></div>` : ''}
        </div>
      </div></section>` : '',
    studio: () => `<section class="block wrap" id="studio">${head('studio')}
      <div class="principles">${(site.principles?.length ? site.principles : DEFAULT_PRINCIPLES).slice(0, 6).map(p => `<div class="pr reveal" style="--a1:${esc(p.a1 || '#2DD4BF')};--a2:${esc(p.a2 || '#38BDF8')}"><span class="app-ico">${icon(p.icon || 'sparkles')}</span><h3>${esc(p.title)}</h3><p>${esc(p.text)}</p></div>`).join('')}</div></section>`,
    support: () => { const s = sec(site, 'support'); return `<section class="block wrap" id="support"><div class="support reveal">
      <div><h2>${esc(s.title || 'Need a hand?')}</h2><p>${esc(s.subtitle || '')}</p>${socialLinksHTML(site.socials)}</div>
      <div class="support-ctas">${cfg.supportEmail ? `<a class="btn primary" href="mailto:${esc(cfg.supportEmail)}">${icon('mail')}${esc(cfg.supportEmail)}</a>` : ''}${caffeineBtn(site, 'caffeine lg')}</div>
    </div></section>`; }
  };

  const body = `<main>
  <section class="hero wrap">
    <span class="eyebrow"><span class="pulse"></span>${esc(hero.eyebrow || `${brandName(site).toUpperCase()} · ${pub.length} ${pub.length === 1 ? 'APP' : 'APPS'}`)}</span>
    <h1>${esc(hero.title || '')} <span class="grad-text">${esc(hero.highlight || '')}</span></h1>
    <p class="lead">${esc(hero.lead || '')}</p>
    <div class="ctas">
      <a class="btn primary" href="#apps">${icon('compass')}${esc(hero.primaryLabel || 'Explore the apps')}</a>
      ${caffeineBtn(site, 'caffeine lg') || (cfg.githubUrl ? `<a class="btn ghost" href="${esc(cfg.githubUrl)}" target="_blank" rel="noopener">${icon('github')}Follow on GitHub</a>` : '')}
    </div>
    ${hero.showSocials && (site.socials || []).length ? socialLinksHTML(site.socials, 'socials center') : ''}
    ${hero.showStats !== false ? `<div class="stats">${stats.map(([n, l]) => `<div class="stat"><b class="grad-text">${n}</b><span>${l}</span></div>`).join('')}</div>` : ''}
  </section>
${(site.sections || []).filter(s => s.enabled && blocks[s.id]).map(s => blocks[s.id]()).join('\n')}
</main>`;
  const url = cfg.siteUrl.replace(/\/$/, '');
  const name = brandName(site);
  return shell({ base, home: true, site, cfg, body, data: publicData(pub, site, supporters, cfg),
    title: `${name} · ${hero.title ? `${hero.title} ${hero.highlight}`.replace(/\.$/, '') : 'Apps'}`,
    desc: hero.lead || `${name}: apps, extensions and tools.`, canonical: url + '/', ogImage: ogOf(site, pub, url) });
}

// ---------- one page per app (shareable links, search engines, social previews) ----------
function renderAppPage(app, pub, site, supporters, cfg) {
  const base = '../../';
  const o = { mediaBase: base + 'assets/apps/', base };
  const url = cfg.siteUrl.replace(/\/$/, '');
  const more = pub.filter(a => a.id !== app.id).sort((a, b) => (b.category === app.category) - (a.category === app.category)).slice(0, 3);
  const og = app.cover && isLocal(app.cover) ? `${url}/assets/apps/${app.cover}` : app.cover || ogOf(site, pub, url);
  const body = `<main class="wrap app-main">
  <a class="back" href="${base}#apps">${icon('chevleft')}All apps</a>
  <article class="app-sheet">${detailHTML(app, o)}</article>
  ${more.length ? `<section class="block"><div class="sec-head"><div><div class="kicker">Keep exploring</div><h2>More from the studio</h2></div></div><div class="grid">${more.map(a => cardHTML(a, o)).join('')}</div></section>` : ''}
</main>`;
  return shell({ base, home: false, site, cfg, body, data: publicData(pub, site, supporters, cfg),
    title: `${app.name} · ${brandName(site)}`, desc: app.tagline || R.clip(R.mdPlain(app.description), 160) || app.name,
    canonical: `${url}/apps/${app.id}/`, ogImage: og });
}

// Social preview image: the studio's own, else the first featured app's cover.
function ogOf(site, pub, url) {
  if (site.brand?.og) return `${url}/assets/brand/${site.brand.og.split('/').pop()}`;
  const a = pub.find(x => x.featured && x.cover) || pub.find(x => x.cover);
  return a ? (isLocal(a.cover) ? `${url}/assets/apps/${a.cover}` : a.cover) : '';
}
// ---------- the page buyers land on after paying for a download ----------
function renderDownloadPage(pub, site, supporters, cfg, delivery) {
  const base = '../';
  const url = String(cfg.siteUrl || '').replace(/\/$/, '');
  const name = site.brand?.name || 'Pylerium Studio';
  const icons = ['download', 'check', 'alert', 'clock', 'mail', 'lock', 'refresh', 'copy'].map(k => `<span data-k="${k}">${icon(k)}</span>`).join('');
  const body = `<main class="wrap dl-main">
  <section class="dl-card" id="dl" data-worker="${esc(delivery.worker.url)}" data-support="${esc(cfg.supportEmail || '')}" data-store="${esc(name)}" aria-live="polite">
    <div class="dl-state"><span class="dl-spin" aria-hidden="true"></span><h1>Getting your download…</h1><p>Checking your purchase.</p></div>
    <noscript><p class="dl-nojs">Turn on JavaScript to see your download.</p></noscript>
  </section>
  <p class="dl-foot">${icon('lock')}<span>Payments are handled by Stripe. Files are delivered privately for each purchase.${cfg.supportEmail ? ` Questions? <a href="mailto:${esc(cfg.supportEmail)}">${esc(cfg.supportEmail)}</a>` : ''}</span></p>
  <template id="dl-icons">${icons}</template>
</main>`;
  return shell({ base, home: false, site, cfg, body, data: publicData(pub, site, supporters, cfg),
    title: `Your download · ${name}`, desc: `Download your purchase from ${name}.`, canonical: `${url}/download/`, ogImage: `${url}/assets/og-studio.png`,
    head: '<meta name="robots" content="noindex, nofollow"><meta name="referrer" content="no-referrer">',
    scripts: `<script type="module" src="${base}js/download.js?v=${VER.dl}"></script>` });
}

export function buildSite() {
  const cfg = loadConfig();
  const site = loadSite();
  R.setCategories(site.categories);
  const supporters = loadSupporters();
  const out = cfg.siteDirAbs;
  const pub = publishedApps(loadApps());
  const delivery = loadDelivery();
  const paid = new Set(delivery.worker?.url ? delivery.apps || [] : []);
  for (const a of pub) if (paid.has(a.id)) a.paid = true;
  for (const d of ['css', 'js', 'assets/apps', 'apps']) mkdirSync(join(out, d), { recursive: true });

  VER.showcase = stamp(join(HUB, 'shared', 'showcase.css'));
  VER.studio = stamp(join(HUB, 'site-src', 'studio.css'));
  VER.render = stamp(join(HUB, 'shared', 'render.js'));
  copyFileSync(join(HUB, 'shared', 'render.js'), join(out, 'js', 'render.js'));
  copyFileSync(join(HUB, 'shared', 'showcase.css'), join(out, 'css', 'showcase.css'));
  copyFileSync(join(HUB, 'site-src', 'studio.css'), join(out, 'css', 'studio.css'));
  const sjs = readFileSync(join(HUB, 'site-src', 'studio.js'), 'utf8').replace("from './render.js'", `from './render.js?v=${VER.render}'`);
  writeFileSync(join(out, 'js', 'studio.js'), sjs);
  VER.js = createHash('sha1').update(sjs).digest('hex').slice(0, 10);
  // Brand: favicon monogram, plus the uploaded logo / social image if there is one.
  R.resetMarks();
  writeFileSync(join(out, 'assets', 'mark.svg'), R.monogram(R.initialsOf(brandName(site))).replace('<svg ', '<svg xmlns="http://www.w3.org/2000/svg" '));
  const brandDir = join(out, 'assets', 'brand');
  rmSync(brandDir, { recursive: true, force: true });
  for (const k of ['logo', 'og']) { const p = site.brand?.[k]; if (p && isLocal(p)) { const src = resolve(MEDIA, p); if (src.startsWith(resolve(MEDIA) + sep) && existsSync(src)) { mkdirSync(brandDir, { recursive: true }); copyFileSync(src, join(brandDir, p.split('/').pop())); } } }

  // Images: copy what published apps use, remove anything else (drafts' images never go public).
  const outMedia = join(out, 'assets', 'apps');
  const keep = new Set(), missing = [];
  for (const a of pub) for (const p of mediaOf(a)) {
    const src = resolve(MEDIA, p);
    if (!src.startsWith(resolve(MEDIA) + sep)) continue;
    if (!existsSync(src)) { missing.push(`${a.name}: ${p}`); continue; }
    const dst = join(outMedia, p);
    mkdirSync(dirname(dst), { recursive: true });
    if (!existsSync(dst) || statSync(dst).size !== statSync(src).size || statSync(dst).mtimeMs < statSync(src).mtimeMs) copyFileSync(src, dst);
    keep.add(resolve(dst));
  }
  for (const f of walk(outMedia)) if (!keep.has(resolve(f))) rmSync(f);
  pruneEmpty(outMedia);

  // App pages: write published, remove pages of apps that were unpublished or deleted.
  const appsDir = join(out, 'apps');
  const ids = new Set(pub.map(a => a.id));
  for (const n of readdirSync(appsDir)) if (!ids.has(n)) rmSync(join(appsDir, n), { recursive: true, force: true });
  for (const a of pub) { mkdirSync(join(appsDir, a.id), { recursive: true }); writeFileSync(join(appsDir, a.id, 'index.html'), renderAppPage(a, pub, site, supporters, cfg)); }

  writeFileSync(join(out, 'index.html'), renderHome(pub, site, supporters, cfg));
  // Paid downloads: the page buyers land on after checkout (only when the delivery service is set up).
  const dlDir = join(out, 'download');
  if (delivery.worker?.url) {
    const djs = readFileSync(join(HUB, 'site-src', 'download.js'), 'utf8');
    writeFileSync(join(out, 'js', 'download.js'), djs);
    VER.dl = createHash('sha1').update(djs).digest('hex').slice(0, 10);
    mkdirSync(dlDir, { recursive: true });
    writeFileSync(join(dlDir, 'index.html'), renderDownloadPage(pub, site, supporters, cfg, delivery));
  } else { rmSync(dlDir, { recursive: true, force: true }); rmSync(join(out, 'js', 'download.js'), { force: true }); }
  writeFileSync(join(out, 'apps.json'), JSON.stringify(pub, null, 2) + '\n');
  writeFileSync(join(out, '.nojekyll'), '');
  const url = cfg.siteUrl.replace(/\/$/, '');
  const pages = ['/', ...pub.map(a => `/apps/${a.id}/`), ...(cfg.extraPages || [])];
  writeFileSync(join(out, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${pages.map(p => `  <url><loc>${esc(url + p)}</loc></url>`).join('\n')}\n</urlset>\n`);
  writeFileSync(join(out, 'robots.txt'), `User-agent: *\nAllow: /\nSitemap: ${url}/sitemap.xml\n`);
  return { published: pub.length, featured: pub.filter(a => a.featured).length, missing, siteDir: out };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const r = buildSite();
  console.log(`Built ${r.published} published app(s) into ${relative(process.cwd(), r.siteDir) || '.'}`);
  if (r.missing.length) console.log('Missing images:\n  ' + r.missing.join('\n  '));
}
