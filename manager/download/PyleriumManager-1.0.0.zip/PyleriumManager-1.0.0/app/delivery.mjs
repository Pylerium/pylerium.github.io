// Paid downloads: sell an app, keep its files in a private GitHub repository, and hand them over after a Stripe purchase.
//
//   private GitHub repo ──(release files)──┐
//   Stripe Payment Link (metadata: repo, tag) ──> buyer pays ──> <site>/download/?session_id=… ──> delivery worker
//                                                                                                   checks Stripe, then
//                                                                                                   302 → signed GitHub file link
//
// The hub sets everything up: creates the private repo, uploads releases, deploys the worker to the owner's Cloudflare
// account (free plan), creates the Stripe product/price/link, puts the buy button on the app, and emails buyers their link.
// Nothing here needs a server of ours. Secrets stay in data/secrets.json and in the worker's encrypted Cloudflare secrets.
import { readFileSync, createReadStream, createWriteStream, statSync, rmSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { randomBytes } from 'node:crypto';
import { request as httpsRequest } from 'node:https';
import { request as httpRequest } from 'node:http';
import { pipeline } from 'node:stream/promises';
import { Transform } from 'node:stream';

const CF = process.env.PM_CF_API || 'https://api.cloudflare.com/client/v4'; // overridable for tests
const STRIPE = process.env.PM_STRIPE_API || 'https://api.stripe.com/v1';
const GH = process.env.PM_GITHUB_API || 'https://api.github.com';
const MAX_FILE = 2 * 1024 ** 3 - 1; // GitHub's limit per release file
const sleep = ms => new Promise(r => setTimeout(r, ms));
const slug = s => String(s || '').toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '').trim().replace(/[\s_]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
const REPO_RE = /^[\w.-]+\/[\w.-]+$/;
const TAG_RE = /^[\w.+-]{1,100}$/;

export function createDelivery(ctx) {
  // ctx: dir, readJson, writeJson, secrets, saveSecrets, fetchT, loadApps, saveApps, loadSite, siteUrl(), supportEmail(), brand(),
  //      store (from store.mjs), alert(title, desc), githubClientId(), label, guard() (throws when selling isn't allowed, e.g. no licence)
  const site = () => String(ctx.siteUrl() || '').replace(/\/$/, '');
  const load = () => ({ worker: null, cf: null, days: 0, workerName: '', apps: [], ...ctx.readJson('delivery.json', {}) });
  const save = d => ctx.writeJson('delivery.json', d, false);
  const workerSrc = () => readFileSync(join(ctx.dir, 'delivery', 'worker.js'), 'utf8');
  const srcVersion = () => workerSrc().match(/const VERSION = '([^']+)'/)?.[1] || '?';
  const defaultWorker = () => `${slug(ctx.brand()).slice(0, 40) || 'studio'}-downloads`;
  const currency = () => String(ctx.loadSite().community?.currency || 'AUD').toUpperCase();

  // ---------- GitHub ----------
  const ghToken = () => ctx.secrets().deliveryGithubToken || ctx.secrets().githubToken || '';
  const ghHead = t => ({ Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28', Authorization: `Bearer ${t}` });
  async function gh(path, { method = 'GET', body, ok404 = false } = {}) {
    const t = ghToken();
    if (!t) throw new Error('Connect GitHub first (step 1).');
    const res = await ctx.fetchT(path.startsWith('http') ? path : GH + path, { method, headers: { ...ghHead(t), ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined }, 30000);
    if (res.status === 204) return {};
    const j = await res.json().catch(() => ({}));
    if ((res.status === 404 || res.status === 409) && ok404) return null;
    if (!res.ok) {
      const m = j.message || `GitHub returned ${res.status}`;
      if (res.status === 401) throw new Error('GitHub rejected the saved sign-in. Connect GitHub again (step 1).');
      if (res.status === 403 && /rate limit/i.test(m)) throw new Error('GitHub’s rate limit was reached. Try again in a few minutes.');
      if (res.status === 403 || res.status === 404) throw new Error(`GitHub refused this (${m}). The GitHub connection needs access to private repositories.`);
      const d = (j.errors || []).map(e => e.message || e.code).filter(Boolean).join('; ');
      throw new Error(`${m}${d ? `: ${d}` : ''}`);
    }
    return j;
  }
  let who = null;
  async function identity(force = false) {
    const t = ghToken();
    if (!t) return { connected: false };
    if (!force && who && who.t === t && Date.now() - who.at < 300000) return who.v;
    let v;
    try {
      const res = await ctx.fetchT(GH + '/user', { headers: ghHead(t) }, 15000);
      const j = await res.json().catch(() => ({}));
      if (!res.ok) v = { connected: false, error: res.status === 401 ? 'GitHub rejected the saved sign-in. Connect again.' : j.message || `GitHub returned ${res.status}` };
      else {
        const sc = res.headers.get('x-oauth-scopes');
        const scopes = (sc || '').split(',').map(s => s.trim()).filter(Boolean);
        v = { connected: true, login: j.login, avatar: j.avatar_url, scopes, fineGrained: sc === null, canPrivate: sc === null || scopes.includes('repo'),
          source: ctx.secrets().deliveryGithubToken ? 'downloads' : 'site' };
      }
    } catch (e) { v = { connected: false, error: `Couldn’t reach GitHub (${e.message}).` }; }
    who = { t, v, at: Date.now() };
    return v;
  }
  async function connectGithub(token) {
    const t = String(token || '').trim();
    if (!/^(gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,})$/.test(t)) throw new Error('That doesn’t look like a GitHub token (they start with ghp_ or github_pat_).');
    const prev = ctx.secrets().deliveryGithubToken || '';
    ctx.saveSecrets({ deliveryGithubToken: t });
    const me = await identity(true);
    if (!me.connected || !me.canPrivate) {
      ctx.saveSecrets({ deliveryGithubToken: prev }); who = null;
      throw new Error(me.connected ? 'That token can’t reach private repositories. Create it with the “repo” permission ticked.' : me.error || 'GitHub rejected that token.');
    }
    return me;
  }
  async function deviceStart() {
    const id = ctx.githubClientId?.();
    if (!id) throw new Error('Sign-in with GitHub isn’t set up in this copy. Use a token instead.');
    const res = await ctx.fetchT('https://github.com/login/device/code', { method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, body: JSON.stringify({ client_id: id, scope: 'repo' }) }, 15000);
    const j = await res.json().catch(() => ({}));
    if (!res.ok || j.error) throw new Error(j.error_description || 'GitHub sign-in isn’t available right now. Use a token instead.');
    return { deviceCode: j.device_code, userCode: j.user_code, url: j.verification_uri, interval: j.interval || 5, expiresIn: j.expires_in };
  }
  async function devicePoll(deviceCode) {
    const res = await ctx.fetchT('https://github.com/login/oauth/access_token', { method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({ client_id: ctx.githubClientId(), device_code: deviceCode, grant_type: 'urn:ietf:params:oauth:grant-type:device_code' }) }, 15000);
    const j = await res.json().catch(() => ({}));
    if (j.access_token) { await connectGithub(j.access_token); return { done: true }; }
    if (j.error === 'authorization_pending' || j.error === 'slow_down') return { pending: true, slow: j.error === 'slow_down' };
    throw new Error(j.error === 'access_denied' ? 'You cancelled the GitHub sign-in.' : j.error === 'expired_token' ? 'The code expired. Start again.' : j.error_description || 'GitHub sign-in failed.');
  }

  async function owners() {
    const me = await identity();
    if (!me.connected) return [];
    let orgs = [];
    try { orgs = (await gh('/user/orgs?per_page=100')).map(o => o.login); } catch {}
    return [me.login, ...orgs.filter(o => o !== me.login)];
  }
  async function repos() {
    const list = await gh('/user/repos?per_page=100&sort=updated&visibility=private&affiliation=owner,organization_member');
    return list.map(r => ({ full: r.full_name, name: r.name, owner: r.owner.login, url: r.html_url, updated: r.pushed_at, empty: r.size === 0 }));
  }
  async function createRepo({ owner, name, description }) {
    const me = await identity(true);
    if (!me.connected) throw new Error('Connect GitHub first (step 1).');
    if (!me.canPrivate) throw new Error('Your GitHub connection can’t create private repositories. Reconnect it with private access (step 1).');
    owner = String(owner || me.login).trim(); name = slug(name).slice(0, 90);
    if (!name) throw new Error('Give the repository a name.');
    const full = `${owner}/${name}`;
    const have = await gh(`/repos/${full}`, { ok404: true });
    if (have) {
      if (!have.private) throw new Error(`${full} already exists and is public. Pick another name: paid files must live in a private repository.`);
      return { full: have.full_name, existed: true };
    }
    const body = { name, description: description || 'Release files for paid downloads. Keep this repository private.', private: true, auto_init: true, has_issues: false, has_wiki: false, has_projects: false };
    const r = owner.toLowerCase() === me.login.toLowerCase() ? await gh('/user/repos', { method: 'POST', body }) : await gh(`/orgs/${owner}/repos`, { method: 'POST', body });
    for (let i = 0; i < 12; i++) { if (await gh(`/repos/${r.full_name}/commits?per_page=1`, { ok404: true }).catch(() => null)) break; await sleep(1500); }
    return { full: r.full_name, created: true, url: r.html_url };
  }
  async function releases(repo) {
    if (!REPO_RE.test(repo || '')) throw new Error('Pick a repository.');
    const list = await gh(`/repos/${repo}/releases?per_page=20`);
    let latest = null;
    try { latest = (await gh(`/repos/${repo}/releases/latest`, { ok404: true }))?.id || null; } catch {}
    return list.map(r => ({ id: r.id, tag: r.tag_name, name: r.name || r.tag_name, draft: r.draft, prerelease: r.prerelease, latest: r.id === latest, date: r.published_at || r.created_at, notes: r.body || '', url: r.html_url,
      files: (r.assets || []).map(a => ({ id: a.id, name: a.name, size: a.size, downloads: a.download_count, state: a.state })) }));
  }
  async function ensureRelease(repo, tag, title, notes) {
    const have = await gh(`/repos/${repo}/releases/tags/${encodeURIComponent(tag)}`, { ok404: true });
    if (have) {
      if ((title && title !== have.name) || (notes && notes !== have.body)) return gh(`/repos/${repo}/releases/${have.id}`, { method: 'PATCH', body: { ...(title ? { name: title } : {}), ...(notes ? { body: notes } : {}) } });
      return have;
    }
    try { return await gh(`/repos/${repo}/releases`, { method: 'POST', body: { tag_name: tag, name: title || tag, body: notes || '', draft: false, prerelease: false, make_latest: 'true' } }); }
    catch (e) { if (/empty|Git Repository is empty|target_commitish/i.test(e.message)) throw new Error(`${repo} has no commits yet, so GitHub can’t tag a release. Add any file to it (a README is enough) and try again.`); throw e; }
  }

  // Uploads: the hub UI streams the file here; it's written to a temp file, then sent to GitHub in the background
  // so big builds don't block anything. The UI polls the job for progress.
  const jobs = new Map();
  const cleanName = n => String(n || '').replace(/[\\/:*?"<>|\x00-\x1f]+/g, '-').replace(/\s+/g, ' ').trim().slice(0, 200);
  async function upload(req, url) {
    const q = k => String(url.searchParams.get(k) || '').trim();
    const repo = q('repo'), tag = q('tag'), name = cleanName(q('name'));
    if (!REPO_RE.test(repo)) throw new Error('Pick a repository first.');
    if (!TAG_RE.test(tag)) throw new Error('Version tags can use letters, numbers, dots and dashes, like v1.2.0.');
    if (!name) throw new Error('The file needs a name.');
    if (+req.headers['content-length'] > MAX_FILE) throw new Error('GitHub stores files up to 2 GB each. Split the download or compress it further.');
    const dir = join(tmpdir(), 'hub-uploads'); mkdirSync(dir, { recursive: true });
    const file = join(dir, `${Date.now()}-${randomBytes(6).toString('hex')}`);
    let n = 0;
    const cap = new Transform({ transform(c, _e, cb) { n += c.length; cb(n > MAX_FILE ? new Error('GitHub stores files up to 2 GB each.') : null, c); } });
    try { await pipeline(req, cap, createWriteStream(file)); } catch (e) { rmSync(file, { force: true }); throw e; }
    if (!n) { rmSync(file, { force: true }); throw new Error('That file is empty.'); }
    const job = { id: 'up-' + randomBytes(5).toString('hex'), repo, tag, name, total: n, sent: 0, state: 'uploading', at: Date.now() };
    jobs.set(job.id, job);
    for (const [k, j] of jobs) if (Date.now() - j.at > 6 * 3600e3) jobs.delete(k);
    (async () => {
      try {
        const rel = await ensureRelease(repo, tag, q('title'), q('notes'));
        const old = (rel.assets || []).find(a => a.name === name);
        if (old) await gh(`/repos/${repo}/releases/assets/${old.id}`, { method: 'DELETE' });
        const a = await sendAsset(rel.upload_url, file, name, job);
        Object.assign(job, { state: 'done', asset: { id: a.id, name: a.name, size: a.size }, release: { id: rel.id, tag: rel.tag_name } });
        relCache.delete(repo);
        ctx.alert?.(`📦 Uploaded **${name}** to ${repo} (${tag})`, `${(n / 1048576).toFixed(1)} MB. Buyers get it from their download page${rel.tag_name ? ` once ${tag} is the release they’re sold` : ''}.`);
      } catch (e) { Object.assign(job, { state: 'error', error: e.message }); }
      finally { rmSync(file, { force: true }); }
    })();
    return { job: job.id };
  }
  function sendAsset(uploadUrl, file, name, job) {
    const u = new URL(String(uploadUrl).replace(/\{[^}]*\}$/, ''));
    u.searchParams.set('name', name);
    const size = statSync(file).size;
    return new Promise((ok, fail) => {
      const rq = (u.protocol === 'http:' ? httpRequest : httpsRequest)(u, { method: 'POST', headers: { ...ghHead(ghToken()), 'Content-Type': 'application/octet-stream', 'Content-Length': size, 'User-Agent': ctx.label || 'studio-hub' } }, res => {
        let b = ''; res.setEncoding('utf8'); res.on('data', c => (b += c));
        res.on('end', () => { let j = {}; try { j = JSON.parse(b); } catch {} res.statusCode >= 200 && res.statusCode < 300 ? ok(j) : fail(new Error(j.message ? `GitHub: ${j.message}${(j.errors || []).map(e => ` (${e.code || e.message})`).join('')}` : `GitHub returned ${res.statusCode}`)); });
      });
      rq.on('error', e => fail(new Error(`Upload failed: ${e.message}`)));
      rq.setTimeout(15 * 60 * 1000, () => rq.destroy(new Error('the connection stalled')));
      const rs = createReadStream(file);
      rs.on('data', c => { job.sent += c.length; });
      rs.on('error', fail);
      rs.pipe(rq);
    });
  }
  const relCache = new Map();

  // ---------- Cloudflare ----------
  async function cf(path, { method = 'GET', body, form, token } = {}) {
    const t = token || ctx.secrets().cfToken;
    if (!t) throw new Error('Connect Cloudflare first (step 2).');
    const res = await ctx.fetchT(CF + path, { method, headers: { Authorization: `Bearer ${t}`, ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: form || (body ? JSON.stringify(body) : undefined) }, 60000);
    const j = await res.json().catch(() => ({}));
    if (!res.ok || j.success === false) {
      const m = (j.errors || []).map(e => e.message).join('; ') || `Cloudflare returned ${res.status}`;
      const err = new Error(res.status === 401 || res.status === 403 || /authenticat|permission/i.test(m) ? `Cloudflare refused this (${m}). The API token needs “Workers Scripts: Edit”. Create it with the “Edit Cloudflare Workers” template.` : m);
      err.status = res.status;
      throw err;
    }
    return j.result;
  }
  async function connectCloudflare(token) {
    const t = String(token || '').trim();
    if (!/^[\w-]{30,}$/.test(t)) throw new Error('That doesn’t look like a Cloudflare API token.');
    const accounts = await cf('/accounts?per_page=50', { token: t });
    if (!accounts?.length) throw new Error('That token can’t see any Cloudflare account. When creating it, set “Account Resources” to include your account.');
    ctx.saveSecrets({ cfToken: t });
    const d = load();
    const keep = accounts.find(a => a.id === d.cf?.accountId) || accounts[0];
    d.cf = { accountId: keep.id, accountName: keep.name, accounts: accounts.map(a => ({ id: a.id, name: a.name })) };
    save(d);
    return d.cf;
  }

  // ---------- Stripe ----------
  const workerStripeKey = () => ctx.secrets().deliveryStripeKey || ctx.secrets().stripeKey || '';
  async function stripeCheck(key) {
    const need = { 'checkout/sessions?limit=1': 'Checkout Sessions', 'payment_links?limit=1': 'Payment Links', 'payment_intents?limit=1': 'PaymentIntents', 'charges?limit=1': 'Charges' };
    const missing = [];
    for (const [p, label] of Object.entries(need)) {
      const r = await ctx.fetchT(`${STRIPE}/${p}`, { headers: { Authorization: `Bearer ${key}` } }, 15000);
      if (r.status === 401) throw new Error('Stripe rejected that key. Check you copied all of it.');
      if (!r.ok) missing.push(label);
    }
    if (missing.length) throw new Error(`The Stripe key needs Read access to ${missing.join(', ')}. In Stripe → Developers → API keys, edit the restricted key (or create one just for downloads) and set those to “Read”.`);
    return { live: /_live_/.test(key) };
  }

  // ---------- the delivery worker ----------
  async function deploy() {
    ctx.guard?.();
    const d = load();
    if (!ctx.secrets().cfToken || !d.cf?.accountId) throw new Error('Connect Cloudflare first (step 2).');
    const me = await identity(true);
    if (!me.connected) throw new Error('Connect GitHub first (step 1).');
    if (!me.canPrivate) throw new Error('Your GitHub connection can’t read private repositories yet. Reconnect it with private access (step 1).');
    const sk = workerStripeKey();
    if (!sk) throw new Error('Add a Stripe key first (step 3).');
    await stripeCheck(sk);
    let admin = ctx.secrets().deliveryAdminKey;
    if (!admin) { admin = randomBytes(24).toString('hex'); ctx.saveSecrets({ deliveryAdminKey: admin }); }
    const name = slug(d.workerName || defaultWorker()).slice(0, 63) || 'studio-downloads';
    const acc = d.cf.accountId;
    const src = workerSrc();
    const vars = { DOWNLOAD_DAYS: String(+d.days || 0), SUPPORT_EMAIL: ctx.supportEmail() || '', STORE_NAME: ctx.brand() || '', SITE_URL: site() };
    const meta = { main_module: 'worker.js', compatibility_date: '2025-01-01',
      bindings: [{ type: 'secret_text', name: 'STRIPE_KEY', text: sk }, { type: 'secret_text', name: 'GITHUB_TOKEN', text: ghToken() }, { type: 'secret_text', name: 'ADMIN_KEY', text: admin },
        ...Object.entries(vars).filter(([, v]) => v).map(([k, v]) => ({ type: 'plain_text', name: k, text: v }))] };
    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(meta)], { type: 'application/json' }));
    form.append('worker.js', new Blob([src], { type: 'application/javascript+module' }), 'worker.js');
    await cf(`/accounts/${acc}/workers/scripts/${name}`, { method: 'PUT', form });
    // Every Cloudflare account gets a free <name>.workers.dev address; new accounts have to pick the <name> once.
    let sub = '';
    try { sub = (await cf(`/accounts/${acc}/workers/subdomain`))?.subdomain || ''; } catch (e) { if (e.status !== 404 && !/subdomain/i.test(e.message)) throw e; }
    if (!sub) {
      let last;
      for (const cand of [slug(ctx.brand()).slice(0, 50) || 'studio', `${slug(ctx.brand()).slice(0, 40) || 'studio'}-${randomBytes(2).toString('hex')}`]) {
        try { sub = (await cf(`/accounts/${acc}/workers/subdomain`, { method: 'PUT', body: { subdomain: cand } }))?.subdomain || cand; break; } catch (e) { last = e; }
      }
      if (!sub) throw new Error(`Couldn’t set up your workers.dev address: ${last?.message}. Open Cloudflare → Workers & Pages once (it asks you to pick a name), then try again.`);
    }
    await cf(`/accounts/${acc}/workers/scripts/${name}/subdomain`, { method: 'POST', body: { enabled: true, previews_enabled: false } });
    const url = process.env.PM_WORKER_BASE || `https://${name}.${sub}.workers.dev`; // override only for local tests
    const prevUrl = d.worker?.url;
    d.worker = { name, url, accountId: acc, deployedAt: new Date().toISOString(), version: srcVersion(), days: +d.days || 0 };
    d.workerName = name;
    save(d);
    let health = null;
    for (let i = 0; i < 12 && !health?.ok; i++) { health = await check().catch(e => ({ ok: false, error: e.message })); if (!health.ok) await sleep(2500); }
    ctx.alert?.(`🔐 Delivery service ${prevUrl ? 'updated' : 'is live'}`, `${url}\n${health?.ok ? 'Self-test passed.' : `Self-test: ${health?.error || 'still starting up'}`}`);
    return { url, health, siteChanged: prevUrl !== url };
  }
  async function check(product) {
    const d = load();
    if (!d.worker?.url) throw new Error('The delivery service isn’t set up yet.');
    const q = product ? `?repo=${encodeURIComponent(product.repo)}&tag=${encodeURIComponent(product.tag || 'latest')}` : '';
    const r = await ctx.fetchT(`${d.worker.url}/health${q}`, { headers: { 'x-admin-key': ctx.secrets().deliveryAdminKey || '' } }, 20000);
    const j = await r.json().catch(() => null);
    if (!j) throw new Error(`The delivery service answered ${r.status}. If you just deployed it, give it a minute.`);
    if (!j.checks) return { ...j, ok: false, error: 'The delivery service doesn’t recognise this hub’s key. Press Update to redeploy it.' };
    const bad = Object.entries(j.checks).filter(([, c]) => !c.ok).map(([k, c]) => `${k === 'stripe' ? 'Stripe' : k === 'github' ? 'GitHub' : 'Files'}: ${c.error}`);
    return { ...j, error: bad.join(' · '), outdated: j.version !== srcVersion() };
  }

  // ---------- products (read straight from Stripe, so price changes in the Store stay in sync) ----------
  async function products(force = false) {
    const o = await ctx.store.overview(force);
    const apps = ctx.loadApps(), code = ctx.store.linkCode;
    const list = o.links.filter(l => l.deliver).map(l => {
      const a = apps.find(x => x.id === l.deliver.app) || apps.find(x => code(x.primaryUrl) && code(x.primaryUrl) === code(l.url));
      return { linkId: l.id, url: l.url, active: l.active, label: l.label, price: l.price, productName: l.product.name, repo: l.deliver.repo, tag: l.deliver.tag,
        appId: a?.id || l.deliver.app, appName: a?.name || l.product.name, onApp: !!a && code(a.primaryUrl) === code(l.url), published: !!a?.published, live: l.livemode };
    });
    const d = load(), ids = list.filter(p => p.active && p.onApp).map(p => p.appId).sort();
    if (JSON.stringify(ids) !== JSON.stringify(d.apps)) { d.apps = ids; save(d); }
    return list;
  }
  async function sell(b) {
    ctx.guard?.();
    const d = load();
    if (!d.worker?.url) throw new Error('Set up the delivery service first (step 4), so buyers have somewhere to download from.');
    if (!site()) throw new Error('Your website address isn’t set yet.');
    const apps = ctx.loadApps(), a = apps.find(x => x.id === b.appId);
    if (!a) throw new Error('Pick the app to sell.');
    const repo = String(b.repo || '').trim(), tag = String(b.tag || 'latest').trim() || 'latest';
    if (!REPO_RE.test(repo)) throw new Error('Pick the private repository that holds the files.');
    if (tag !== 'latest' && !TAG_RE.test(tag)) throw new Error('That version tag isn’t valid.');
    const rel = await gh(`/repos/${repo}/releases/${tag === 'latest' ? 'latest' : `tags/${encodeURIComponent(tag)}`}`, { ok404: true });
    if (!rel?.assets?.length) throw new Error('Upload the file buyers get first. That repository has no release with files in it yet.');
    const S = ctx.store.stripe, cur = currency().toLowerCase();
    const want = ctx.store.validate(b, cur);
    const icon = a.published && a.iconImage && !/^(https?:|data:)/.test(a.iconImage) ? `${site()}/assets/apps/${a.iconImage}` : '';
    const prod = await S('POST', 'products', { name: a.name.slice(0, 250), description: String(a.tagline || '').slice(0, 500) || undefined, images: icon ? [icon] : undefined, metadata: { set_by: ctx.label, deliver_app: a.id } });
    const price = await S('POST', 'prices', { product: prod.id, currency: cur, ...want, metadata: { set_by: ctx.label } });
    await S('POST', `products/${prod.id}`, { default_price: price.id }).catch(() => {});
    const link = await S('POST', 'payment_links', {
      line_items: [{ price: price.id, quantity: 1 }], submit_type: 'pay',
      metadata: { set_by: ctx.label, deliver_app: a.id, deliver_name: a.name.slice(0, 200), deliver_repo: repo, deliver_tag: tag },
      after_completion: { type: 'redirect', redirect: { url: `${site()}/download/?session_id={CHECKOUT_SESSION_ID}` } },
      allow_promotion_codes: b.promo ? true : undefined,
      invoice_creation: b.invoice ? { enabled: true } : undefined,
      custom_text: { after_submit: { message: 'You’ll go straight to your download page. We’ll also email you the link.' } }
    }).catch(async e => { if (/custom_text|invoice_creation/i.test(e.message)) return S('POST', 'payment_links', { line_items: [{ price: price.id, quantity: 1 }], submit_type: 'pay', metadata: { set_by: ctx.label, deliver_app: a.id, deliver_name: a.name.slice(0, 200), deliver_repo: repo, deliver_tag: tag }, after_completion: { type: 'redirect', redirect: { url: `${site()}/download/?session_id={CHECKOUT_SESSION_ID}` } } }); throw e; });
    const label = ctx.store.priceLabel(ctx.store.shapePrice(price));
    a.primaryUrl = link.url; a.primaryLabel = String(b.buttonLabel || '').trim() || `Buy · ${label}`; a.price = label;
    ctx.saveApps(apps);
    ctx.store.invalidate();
    ctx.alert?.(`🔐 **${a.name}** is for sale: ${label}`, `Files come from ${repo} (${tag === 'latest' ? 'latest release' : tag}).\nCheckout: ${link.url}\nPublish the site so the buy button appears.`);
    await products(true).catch(() => {});
    return { link: link.url, label, appName: a.name, siteChanged: true };
  }
  async function retarget({ linkId, repo, tag }) {
    if (!REPO_RE.test(repo || '')) throw new Error('Pick a repository.');
    tag = String(tag || 'latest').trim() || 'latest';
    if (tag !== 'latest' && !TAG_RE.test(tag)) throw new Error('That version tag isn’t valid.');
    await ctx.store.stripe('POST', `payment_links/${encodeURIComponent(linkId)}`, { metadata: { deliver_repo: repo, deliver_tag: tag } });
    ctx.store.invalidate();
    return products(true);
  }
  async function stop({ linkId, keepButton }) {
    const l = await ctx.store.stripe('POST', `payment_links/${encodeURIComponent(linkId)}`, { active: false });
    let siteChanged = false;
    if (!keepButton) {
      const apps = ctx.loadApps(), code = ctx.store.linkCode(l.url);
      for (const a of apps) if (code && ctx.store.linkCode(a.primaryUrl) === code) { a.primaryUrl = ''; a.primaryLabel = ''; a.price = ''; siteChanged = true; }
      if (siteChanged) ctx.saveApps(apps);
    }
    ctx.store.invalidate();
    ctx.alert?.('⏸️ Stopped selling a paid download', `${l.url} is switched off. People who already bought it can still download.`);
    return { siteChanged, products: await products(true) };
  }

  // For the sales watcher: is this payment link a paid download? (cached, so new sales don't cost extra Stripe calls)
  const linkInfo = new Map();
  async function downloadFor(linkId) {
    if (!linkId || !load().worker?.url) return null;
    const hit = linkInfo.get(linkId);
    if (hit && Date.now() - hit.at < 600000) return hit.v;
    const l = await ctx.store.stripe('GET', `payment_links/${encodeURIComponent(linkId)}`);
    const v = l.metadata?.deliver_repo ? { name: l.metadata.deliver_name || 'your download', app: l.metadata.deliver_app || '' } : null;
    linkInfo.set(linkId, { at: Date.now(), v });
    return v;
  }
  const downloadUrl = sessionId => `${site()}/download/?session_id=${encodeURIComponent(sessionId)}`;

  async function state(force = false) {
    const d = load(), s = ctx.secrets();
    const [github, prods] = await Promise.all([identity(force), products(force).catch(e => ({ error: e.message }))]);
    return {
      github, deviceFlow: !!ctx.githubClientId?.(),
      cloudflare: { connected: !!s.cfToken, ...(d.cf || {}) },
      stripe: { key: !!workerStripeKey(), separate: !!s.deliveryStripeKey, write: !!(s.stripeWriteKey || s.stripeKey) },
      worker: d.worker, latestVersion: srcVersion(), days: +d.days || 0, workerName: d.workerName || defaultWorker(),
      products: Array.isArray(prods) ? prods : [], productsError: prods.error || '', currency: currency(), siteUrl: site(),
      apps: ctx.loadApps().map(a => ({ id: a.id, name: a.name, version: a.version, published: !!a.published, iconImage: a.iconImage, glyph: a.glyph, accent: a.accent, primaryUrl: a.primaryUrl, price: a.price }))
    };
  }

  async function route(path, M, body, url) {
    if (path === '/api/delivery' && M === 'GET') return state(url?.searchParams.get('force') === '1');
    if (path === '/api/delivery/check' && M === 'POST') { const p = body.linkId ? (await products()).find(x => x.linkId === body.linkId) : null; return check(p); }
    if (path === '/api/delivery/github' && M === 'PUT') { await connectGithub(body.token); return state(); }
    if (path === '/api/delivery/github' && M === 'DELETE') { ctx.saveSecrets({ deliveryGithubToken: '' }); who = null; return state(); }
    if (path === '/api/delivery/github/device' && M === 'POST') return deviceStart();
    if (path === '/api/delivery/github/poll' && M === 'POST') { const r = await devicePoll(body.deviceCode); return r.done ? { done: true, ...(await state()) } : r; }
    if (path === '/api/delivery/cloudflare' && M === 'PUT') { await connectCloudflare(body.token); return state(); }
    if (path === '/api/delivery/cloudflare' && M === 'DELETE') { ctx.saveSecrets({ cfToken: '' }); const d = load(); d.cf = null; save(d); return state(); }
    if (path === '/api/delivery/cloudflare/account' && M === 'POST') { const d = load(); const a = d.cf?.accounts?.find(x => x.id === body.id); if (!a) throw new Error('Account not found'); Object.assign(d.cf, { accountId: a.id, accountName: a.name }); save(d); return state(); }
    if (path === '/api/delivery/stripe' && M === 'PUT') {
      const k = String(body.key || '').trim();
      if (k) { if (!/^(rk|sk)_(live|test)_\w+$/.test(k)) throw new Error('That doesn’t look like a Stripe key.'); await stripeCheck(k); }
      ctx.saveSecrets({ deliveryStripeKey: k });
      return state();
    }
    if (path === '/api/delivery/stripe/check' && M === 'POST') { const k = workerStripeKey(); if (!k) throw new Error('Add a Stripe key first.'); return stripeCheck(k); }
    if (path === '/api/delivery/settings' && M === 'POST') {
      const d = load();
      if (body.days != null) d.days = Math.max(0, Math.min(3650, Math.round(+body.days || 0)));
      if (body.workerName != null && !d.worker) d.workerName = slug(body.workerName).slice(0, 63);
      save(d);
      const redeploy = d.worker && body.days != null && +d.worker.days !== +d.days;
      return { ...(redeploy ? { deployed: await deploy() } : {}), ...(await state()) };
    }
    if (path === '/api/delivery/deploy' && M === 'POST') { const r = await deploy(); return { result: r, ...(await state()) }; }
    if (path === '/api/delivery/owners' && M === 'GET') return { owners: await owners() };
    if (path === '/api/delivery/repos' && M === 'GET') return { repos: await repos() };
    if (path === '/api/delivery/repos' && M === 'POST') return createRepo(body);
    if (path === '/api/delivery/releases' && M === 'GET') return { releases: await releases(url.searchParams.get('repo')) };
    if (path === '/api/delivery/file' && M === 'DELETE') {
      const repo = url.searchParams.get('repo'), id = +url.searchParams.get('id');
      if (!REPO_RE.test(repo || '') || !id) throw new Error('Bad request');
      await gh(`/repos/${repo}/releases/assets/${id}`, { method: 'DELETE' });
      return { releases: await releases(repo) };
    }
    if (path === '/api/delivery/job' && M === 'GET') { const j = jobs.get(url.searchParams.get('id')); if (!j) throw new Error('That upload is no longer tracked.'); return j; }
    if (path === '/api/delivery/sell' && M === 'POST') { const r = await sell(body); return { result: r, ...(await state()) }; }
    if (path === '/api/delivery/target' && M === 'POST') { await retarget(body); return state(); }
    if (path === '/api/delivery/stop' && M === 'POST') { const r = await stop(body); return { result: { siteChanged: r.siteChanged }, ...(await state()) }; }
    return undefined;
  }

  return { route, upload, downloadFor, downloadUrl, state };
}
