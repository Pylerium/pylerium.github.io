// Pylerium Manager: builds a studio's public site from its data.
// Only apps marked "published" are written. Private fields (notes, local paths, supporter emails) never leave the hub.
// usage: node build.mjs
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, existsSync, readdirSync, statSync, rmSync, rmdirSync } from 'node:fs';
import { join, dirname, resolve, relative, sep } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

export const HUB = dirname(fileURLToPath(import.meta.url));
const R = await import(pathToFileURL(join(HUB, 'shared', 'render.js')).href);
const { perkCardHTML, cardHTML, detailHTML, brandMark, icon, esc, publicApp, categoryOf, videoCardHTML, shortCardHTML, socialLinksHTML, media, href } = R;

// Everything a customer owns lives in their user profile, so updating the app never touches it.
export const ROOT = process.env.PM_HOME || (process.platform === 'win32' ? join(process.env.APPDATA || join(homedir(), 'AppData', 'Roaming'), 'Pylerium Manager')
  : process.platform === 'darwin' ? join(homedir(), 'Library', 'Application Support', 'Pylerium Manager') : join(process.env.XDG_CONFIG_HOME || join(homedir(), '.config'), 'pylerium-manager'));
export const DATA = join(ROOT, 'data'), MEDIA = join(ROOT, 'media'), SITE = join(ROOT, 'site');
for (const d of [DATA, MEDIA, SITE]) mkdirSync(d, { recursive: true });
export const PRODUCT = JSON.parse(readFileSync(join(HUB, 'product.json'), 'utf8'));
const readJson = (f, d) => { try { return JSON.parse(readFileSync(join(DATA, f), 'utf8')); } catch { return d; } };
export function loadConfig() {
  const c = { port: PRODUCT.port || 4380, branch: 'main', extraPages: [], footerLinks: [], siteUrl: '', githubUrl: '', supportEmail: '', ...readJson('config.json', {}) };
  c.siteDirAbs = SITE;
  return c;
}
export const brandName = site => site.brand?.name || 'My Studio';
const fmtMoney = (v, cur) => { try { return new Intl.NumberFormat('en', { style: 'currency', currency: cur || 'USD', currencyDisplay: 'symbol', minimumFractionDigits: v % 1 ? 2 : 0 }).format(v); } catch { return `${v} ${cur}`; } };
const brandFor = (site, base) => ({ name: brandName(site), logoUrl: site.brand?.logo ? `${base}assets/brand/${site.brand.logo.split('/').pop()}` : '' });
export const DEFAULT_PRINCIPLES = [
  { icon: 'lock', title: 'Local-first', text: 'Our apps do their work on your own device. Your files, libraries and settings stay with you.', a1: '#2DD4BF', a2: '#38BDF8' },
  { icon: 'sparkles', title: 'Crafted interfaces', text: 'Every screen is designed for the way it’s used, whether that’s a mouse, a keyboard, a controller or a TV remote.', a1: '#8B5CF6', a2: '#6366F1' },
  { icon: 'github', title: 'Open by default', text: 'Most of our apps publish their source on GitHub, so you can see exactly how they work.', a1: '#F97316', a2: '#22D3EE' }
];
export const loadApps = () => readJson('apps.json', []);
export const loadSite = () => readJson('site.json', {});
export const loadSupporters = () => readJson('supporters.json', []);
export const loadDelivery = () => readJson('delivery.json', {});
// Social feed and profile links, written by the hub's Connectors (connectors.mjs → data/feed.json).
export const loadFeed = () => readJson('feed.json', {});
const NET = { x: ['xlogo', 'X'], mastodon: ['mastodon', 'Mastodon'], devto: ['devto', 'DEV'], telegram: ['telegram', 'Telegram'], linkedin: ['linkedin', 'LinkedIn'], itch: ['itch', 'itch.io'] };
const normUrl = u => String(u || '').toLowerCase().replace(/^https?:\/\/(www\.)?/, '').replace(/\/+$/, '');
// the site's own social links, plus every connected account switched on in Connectors (no duplicates)
export function socialsWithProfiles(site, feed = loadFeed()) {
  const own = site.socials || [], seen = new Set(own.map(x => normUrl(x.url)));
  return [...own, ...(feed.profiles || []).filter(p => p.url && !seen.has(normUrl(p.url)) && !own.some(x => x.type === p.platform)).map(p => ({ type: p.platform, url: p.url, label: `${NET[p.platform]?.[1] || p.platform} ${p.handle || ''}`.trim() }))];
}
const ago = iso => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleDateString('en', { day: 'numeric', month: 'short', year: d.getFullYear() === new Date().getFullYear() ? undefined : 'numeric' }); };
function feedCardHTML(i, base) {
  const [ic, label] = NET[i.platform] || ['globe', i.platform], img = i.image ? (/^https?:/.test(i.image) ? i.image : base + i.image) : '';
  const st = i.stats || {}, stat = (n, ico) => (n ? `<span>${icon(ico)}${n}</span>` : '');
  return `<a class="fcard p-${esc(i.platform)}" href="${esc(i.url)}" target="_blank" rel="noopener">
    <div class="fc-top"><span class="fc-net">${icon(ic)}</span><b>${esc(label)}</b><time datetime="${esc(i.date || '')}">${esc(ago(i.date))}</time></div>
    ${img ? `<div class="fc-img"><img src="${esc(img)}" alt="" loading="lazy"></div>` : ''}
    ${i.title ? `<h3>${esc(i.title)}</h3>` : ''}${i.text ? `<p>${esc(i.text)}</p>` : ''}
    <div class="fc-foot">${stat(st.likes, 'heart')}${stat(st.shares, 'refresh')}${stat(st.replies, 'inbox')}<span class="sp"></span><em>View on ${esc(label)}${icon('arrow')}</em></div></a>`;
}
// An embed can be raw HTML (code) or a card the site draws in its own style (kind "card": Product Hunt, any link).
const PROVIDERS = { producthunt: { icon: 'producthunt', label: 'Product Hunt', button: 'Check it out on Product Hunt' }, link: { icon: 'link', label: '', button: 'Open' } };
function embedCardHTML(e) {
  const c = e.card || {}, p = PROVIDERS[e.provider] || PROVIDERS.link;
  if (!c.url) return '';
  return `<a class="ecard pv-${esc(e.provider || 'link')}" href="${esc(c.url)}" target="_blank" rel="noopener">
    ${c.image ? `<img class="ec-ico" src="${esc(c.image)}" alt="" loading="lazy">` : `<span class="ec-ico gen">${icon(p.icon)}</span>`}
    <span class="ec-body">${p.label || c.kicker ? `<span class="ec-kicker">${icon(p.icon)}${esc(c.kicker || p.label)}</span>` : ''}<b>${esc(c.name || e.title || '')}</b>${c.text ? `<span class="ec-text">${esc(c.text)}</span>` : ''}</span>
    <span class="ec-btn">${esc(c.button || p.button)}${icon('arrow')}</span></a>`;
}
export const sortApps = apps => [...apps].sort((a, b) => (a.order ?? 1e9) - (b.order ?? 1e9) || a.name.localeCompare(b.name));
export const publishedApps = apps => sortApps(apps.filter(a => a.published)).map(publicApp);
// Apps sold as paid downloads get paid: true (price pill + checkout note). Used by the build AND by the publish check,
// so the two always agree (otherwise a paid app shows as "updated" forever).
export function markPaid(pub) {
  const delivery = loadDelivery();
  const paid = new Set(delivery.worker?.url ? delivery.apps || [] : []);
  for (const a of pub) if (paid.has(a.id)) a.paid = true;
  return pub;
}

const isLocal = p => p && !/^(https?:|data:|blob:)/i.test(p);
const mediaOf = app => [app.cover, app.iconImage, app.socialImage, ...(app.screenshots || []), /\.(mp4|webm)$/i.test(app.videoUrl || '') ? app.videoUrl : null].filter(isLocal);
function walk(dir) { if (!existsSync(dir)) return []; return readdirSync(dir).flatMap(n => { const p = join(dir, n); return statSync(p).isDirectory() ? walk(p) : [p]; }); }
function pruneEmpty(dir) { if (!existsSync(dir)) return; for (const n of readdirSync(dir)) { const p = join(dir, n); if (statSync(p).isDirectory()) { pruneEmpty(p); if (!readdirSync(p).length) rmdirSync(p); } } }
// Sites made before perks existed get the Perks section right after Community.
export const PERKS_SECTION = { id: 'perks', enabled: true, kicker: 'Perks', title: 'Unlock perks', subtitle: 'Thank-yous for supporters: some come with an app, some you can buy, and some drop by luck.' };
export function withPerks(sections = []) {
  if (sections.some(s => s.id === 'perks')) return sections;
  const i = sections.findIndex(s => s.id === 'community');
  return [...sections.slice(0, i + 1), { ...PERKS_SECTION }, ...sections.slice(i + 1)];
}
const sec = (site, id) => withPerks(site.sections || []).find(s => s.id === id) || { id, enabled: false };
const json = o => JSON.stringify(o).replace(/</g, '\\u003c');
// Cache-busting: GitHub Pages caches CSS/JS for 10 minutes, so every changed file gets a new ?v= stamp.
const VER = {};
const stamp = f => createHash('sha1').update(readFileSync(f)).digest('hex').slice(0, 10);

// Public, non-sensitive data the site script needs. Supporter codes are only present as salted SHA-256 hashes.
// Perks live in the hub (perks.mjs); it registers itself here so every page gets the perk data.
let PERKS = null;
export const setPerksProvider = p => { PERKS = p; };
export function publicData(pub, site, supporters, cfg) {
  const c = site.community || {};
  const perks = PERKS ? PERKS.publicData(site, supporters, loadApps()) : null;
  return {
    apps: pub, categories: site.categories, socials: site.socials || [], supportEmail: cfg.supportEmail,
    donate: site.donate?.enabled && site.donate.url ? { label: site.donate.label, url: site.donate.url } : null,
    brand: brandName(site),
    community: c.submissionsEnabled ? { salt: c.salt, repo: c.repo, threshold: c.threshold, currency: c.currency, prefix: c.codePrefix || 'CAFE',
      codes: supporters.filter(s => s.codeHash && !s.revoked && (!PERKS || PERKS.submitAllowed(s))).map(s => s.codeHash), email: cfg.supportEmail } : null,
    perks,
    siteUrl: cfg.siteUrl
  };
}

function videosOf(site) {
  const y = site.youtube || {};
  const vis = (y.videos || []).filter(v => !v.hidden).sort((a, b) => (b.pinned - a.pinned) || (b.published || '').localeCompare(a.published || ''));
  return { long: vis.filter(v => !v.short).slice(0, y.maxVideos || 6), shorts: y.showShorts ? vis.filter(v => v.short).slice(0, y.maxShorts || 12) : [], channelUrl: y.channelUrl };
}

function caffeineBtn(site, cls = 'caffeine') {
  const d = site.donate || {};
  if (!d.enabled || !d.url) return '';
  return `<a class="${cls}" href="${esc(d.url)}" target="_blank" rel="noopener"><span class="steam"><i></i><i></i><i></i></span>${icon('can')}<span>${esc(d.label || 'Supply caffeine')}</span></a>`;
}

// ---------- page shell (home + app pages) ----------
function shell({ base, title, desc, canonical, ogImage, body, data, site, cfg, home, head = '', scripts = '' }) {
  R.resetMarks();
  const s = id => sec(site, id).enabled;
  const L = h => (home ? h : base + h);
  const navLinks = [
    s('featured') && ['#featured', 'Featured'], ['#apps', 'Apps'], s('videos') && site.youtube?.videos?.length && ['#videos', 'Videos'],
    s('community') && site.community?.submissionsEnabled && ['#community', 'Community'], s('support') && ['#support', 'Support']
  ].filter(Boolean);
  const ann = site.announcement || {};
  const annKey = 'ann-' + [...(ann.text || '')].reduce((h, c) => (h * 31 + c.charCodeAt(0)) | 0, 7);
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
<meta name="theme-color" content="#07080E">
<link rel="canonical" href="${esc(canonical)}">
<link rel="icon" href="${base}assets/${site.brand?.logo ? 'brand/' + esc(site.brand.logo.split('/').pop()) : 'mark.svg'}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="${esc(brandName(site))}">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(desc)}">
<meta property="og:url" content="${esc(canonical)}">
${ogImage ? `<meta property="og:image" content="${esc(ogImage)}">` : ''}
<meta name="twitter:card" content="summary_large_image">
<link rel="stylesheet" href="${base}css/showcase.css?v=${VER.showcase}">
<link rel="stylesheet" href="${base}css/studio.css?v=${VER.studio}">
${head}</head>
<body${home ? ' class="home"' : ' class="app-page"'}>
<div class="ambient" aria-hidden="true"><span class="orb o1"></span><span class="orb o2"></span><span class="orb o3"></span><span class="gridlines"></span></div>
${ann.enabled && ann.text ? `<div class="announce tone-${esc(ann.tone || 'violet')}" data-key="${annKey}" hidden><div class="wrap">${icon('megaphone')}<span>${esc(ann.text)}</span>${ann.url ? `<a href="${esc(href(ann.url, base))}"${/^https?:/.test(ann.url) ? ' target="_blank" rel="noopener"' : ''}>${esc(ann.linkLabel || 'Learn more')}${icon('arrow')}</a>` : ''}<button type="button" class="ann-x" aria-label="Dismiss">${icon('x')}</button></div></div>` : ''}
<header class="nav">
  <div class="wrap">
    <a class="brand" href="${home ? './' : base}">${brandMark('mark', brandFor(site, base))}<span>${esc(brandName(site))}<small>${esc(site.brand?.tagline || '')}</small></span></a>
    <button class="menu-btn" type="button" aria-label="Menu">${icon('menu')}</button>
    <nav class="nav-links">
      ${navLinks.map(([h, l]) => `<a href="${L(h)}">${l}</a>`).join('')}
      ${cfg.githubUrl ? `<a class="gh" href="${esc(cfg.githubUrl)}" target="_blank" rel="noopener">${icon('github')}GitHub</a>` : ''}
      ${site.donate?.showInNav ? caffeineBtn(site, 'caffeine sm') : ''}
    </nav>
  </div>
</header>
${body}
<footer class="site">
  <div class="wrap">
    <div class="f-brand"><a class="brand" href="${home ? './' : base}">${brandMark('mark', brandFor(site, base))}<span>${esc(brandName(site))}</span></a><span class="copy-note">© ${new Date().getFullYear()} ${esc(brandName(site))}${site.brand?.credit === false ? '' : ' · Made with <a href="https://pylerium.github.io/manager/" target="_blank" rel="noopener">Pylerium Manager</a>'}</span></div>
    ${socialLinksHTML(socialsWithProfiles(site))}
    <nav>${(cfg.footerLinks || []).map(l => `<a href="${esc(href(l.url, base))}">${esc(l.label)}</a>`).join('')}${cfg.supportEmail ? `<a href="mailto:${esc(cfg.supportEmail)}">Contact</a>` : ''}</nav>
  </div>
</footer>

<dialog class="app-dlg" id="dlg" aria-labelledby="dlg-title"><button class="dlg-close" type="button" aria-label="Close">${icon('x')}</button><div class="dlg-scroll" id="dlg-body"></div></dialog>
<dialog class="short-dlg" id="shortDlg" aria-label="Short"><button class="dlg-close" type="button" aria-label="Close">${icon('x')}</button><div class="short-stage" id="shortStage"></div></dialog>
<dialog class="app-dlg form-dlg" id="submitDlg" aria-labelledby="sub-title"><button class="dlg-close" type="button" aria-label="Close">${icon('x')}</button><div class="dlg-scroll" id="submitBody"></div></dialog>
${site.donate?.enabled && site.donate.url && site.donate.floating !== false ? `<a class="cafe-float" href="${esc(site.donate.url)}" target="_blank" rel="noopener" aria-label="${esc(site.donate.label || 'Supply caffeine')}"><span class="cf-cup"><span class="steam"><i></i><i></i><i></i></span>${icon('can')}</span><span class="cf-txt">${esc(site.donate.label || 'Supply caffeine')}</span></a>` : ''}
<div class="toast" id="toast"></div>
<script type="application/json" id="site-data">${json(data)}</script>
<script>window.SITE_BASE=${JSON.stringify(base)};</script>
<script type="module" src="${base}js/studio.js?v=${VER.js}"></script>
${data.perks ? `<script type="module" src="${base}js/perks.js?v=${VER.perks}"></script>` : ''}
${scripts}</body>
</html>
`;
}

// ---------- home ----------
function renderHome(pub, site, supporters, cfg) {
  const base = '';
  const now = Date.now();
  const o = { mediaBase: 'assets/apps/', base, now };
  const featured = pub.filter(a => a.featured);
  const used = R.categories().filter(c => pub.some(a => a.category === c.id));
  const community = pub.filter(a => a.community);
  const v = videosOf(site);
  const hero = site.hero || {};
  const stats = [
    [pub.length, 'Apps'],
    [new Set(pub.map(a => a.category)).size, 'Platforms'],
    [pub.filter(a => /github\.com\/[^/]+\/[^/]+/.test(a.repoUrl || '')).length, 'Open source'],
    [pub.filter(a => a.status === 'live' || a.status === 'beta').length, 'Available now']
  ];
  const head = (id, extra = '') => { const s = sec(site, id); return s.title || s.kicker ? `<div class="sec-head reveal"><div>${s.kicker ? `<div class="kicker">${esc(s.kicker)}</div>` : ''}${s.title ? `<h2>${esc(s.title)}</h2>` : ''}${s.subtitle ? `<p>${esc(s.subtitle)}</p>` : ''}</div>${extra}</div>` : ''; };
  const c = site.community || {};
  const wall = c.showWall ? supporters.filter(s => s.wall && (s.wallName || s.name)).map(s => s.wallName || s.name) : [];

  const blocks = {
    featured: () => featured.length ? `<section class="block wrap" id="featured">${head('featured')}<div class="spot" id="spot"><div class="spot-track">${featured.map((a, i) => `<div class="spot-slide" aria-roledescription="slide" aria-label="${i + 1} of ${featured.length}">${cardHTML(a, { ...o, wide: true })}</div>`).join('')}</div>${featured.length > 1 ? `<div class="spot-nav"><button type="button" class="ibtn" data-spot="-1" aria-label="Previous">${icon('chevleft')}</button><div class="spot-dots">${featured.map((a, i) => `<button type="button" data-dot="${i}" aria-label="${esc(a.name)}"${i ? '' : ' class="on"'}></button>`).join('')}</div><button type="button" class="ibtn" data-spot="1" aria-label="Next">${icon('chevron')}</button><span class="spot-bar"><i></i></span></div>` : ''}</div></section>` : '',
    apps: () => `<section class="block wrap" id="apps">${head('apps')}
    <div class="filters reveal">
      <div class="tabs" role="tablist">
        <button class="tab on" type="button" data-cat="all">All <em>${pub.length}</em></button>
        ${used.map(cat => `<button class="tab" type="button" data-cat="${esc(cat.id)}">${icon(cat.icon)}${esc(cat.label)} <em>${pub.filter(a => a.category === cat.id).length}</em></button>`).join('')}
        ${community.length ? `<button class="tab" type="button" data-cat="@community">${icon('users')}Community <em>${community.length}</em></button>` : ''}
      </div>
      <label class="search">${icon('search')}<input id="q" type="search" placeholder="Search apps and features" autocomplete="off" aria-label="Search apps"></label>
    </div>
    <div class="grid" id="all-apps">${pub.map(a => cardHTML(a, o)).join('\n')}</div>
    <div class="empty" id="empty"><p>No apps match that search.</p><button class="btn ghost" id="clear" type="button">Clear filters</button></div></section>`,
    videos: () => (v.long.length || v.shorts.length) ? `<section class="block wrap" id="videos">${head('videos', v.channelUrl ? `<a class="btn yt" href="${esc(v.channelUrl.replace(/\/$/, ''))}?sub_confirmation=1" target="_blank" rel="noopener">${icon('youtube')}Subscribe</a>` : '')}
      ${v.long.length ? `<div class="vgrid reveal">${v.long.map(videoCardHTML).join('')}</div>` : ''}
      ${v.shorts.length ? `<div class="shorts-head reveal"><h3>${icon('zap')}Shorts</h3><div class="rail-btns"><button type="button" class="ibtn" data-rail="-1" aria-label="Scroll left">${icon('chevleft')}</button><button type="button" class="ibtn" data-rail="1" aria-label="Scroll right">${icon('chevron')}</button></div></div><div class="shorts reveal" id="shorts">${v.shorts.map(shortCardHTML).join('')}</div>` : ''}
    </section>` : '',
    embeds: () => { const em = (site.embeds || []).filter(e => e.enabled && e.placement !== 'app' && (e.kind === 'card' ? e.card?.url : e.code)); return em.length ? `<section class="block wrap" id="embeds">${head('embeds')}<div class="embeds">${em.map(e => `<div class="embed-block w-${esc(e.width || 'full')}${e.kind === 'card' ? ' is-card' : ''} reveal">${e.title ? `<h3>${esc(e.title)}</h3>` : ''}${e.subtitle ? `<p>${esc(e.subtitle)}</p>` : ''}${e.kind === 'card' ? embedCardHTML(e) : `<div class="embed-box">${e.code}</div>`}</div>`).join('')}</div></section>` : ''; },
    news: () => { const F = loadFeed(), items = F.items || [], prof = F.profiles || []; return items.length ? `<section class="block wrap" id="news">${head('news', prof.length ? `<div class="follow">${prof.map(p => `<a class="btn ghost sm" href="${esc(p.url)}" target="_blank" rel="noopener${p.platform === 'mastodon' ? ' me' : ''}" title="${esc(p.handle || '')}">${icon(NET[p.platform]?.[0] || 'globe')}${esc(NET[p.platform]?.[1] || p.platform)}</a>`).join('')}</div>` : '')}<div class="feed reveal">${items.map(i => feedCardHTML(i, base)).join('')}</div></section>` : ''; },
    community: () => c.submissionsEnabled ? `<section class="block wrap" id="community">${head('community')}
      <div class="comm reveal">
        <div class="comm-card">
          <span class="comm-ico">${icon('crown')}</span>
          <h3>Supporters can submit their own apps</h3>
          <p>${esc(c.blurb || `Give ${fmtMoney(+c.threshold || 10, c.currency)} or more and you'll get a supporter code that unlocks submissions.`)}</p>
          <ul>${(c.perks || []).map(p => `<li>${icon('check')}<span>${esc(p)}</span></li>`).join('')}</ul>
          <div class="comm-ctas"><button class="btn primary" type="button" data-submit>${icon('send')}Submit your app</button>${caffeineBtn(site, 'caffeine lg')}</div>
          <small class="fine">Already a supporter? You'll find your code in the email we sent you.</small>
        </div>
        <div class="comm-side">
          ${community.length ? `<div class="comm-stat"><b class="grad-text">${community.length}</b><span>community ${community.length === 1 ? 'app' : 'apps'} in the showcase</span><button class="btn ghost sm" type="button" data-cat-jump="@community">Browse them${icon('arrow')}</button></div>` : `<div class="comm-stat"><b class="grad-text">${icon('sparkles')}</b><strong>The community shelf is open</strong><span>No community apps yet. Submit yours and it could be the first one here.</span></div>`}
          ${wall.length ? `<div class="wall"><h4>${icon('can')}${esc(c.wallTitle || 'Caffeine suppliers')}<em>${wall.length}</em></h4><p>${esc(c.wallThanks || `Thank you for supporting ${brandName(site)}.`)}</p><div class="wall-names">${wall.map(n => `<span>${esc(n)}</span>`).join('')}</div></div>` : ''}
        </div>
      </div></section>` : '',
    perks: () => {
      const P = publicData(pub, site, supporters, cfg).perks;
      if (!P || (!P.list.length && !Object.keys(P.vault).length)) return '';
      const s = sec(site, 'perks'), money = v => fmtMoney(+v, c.currency);
      return `<section class="block wrap" id="perks">${head('perks', `<button class="btn ghost" type="button" data-perks-open>${icon('unlock')}My perks</button>`)}
      ${P.list.length ? `<div class="perk-grid">${P.list.map(p => perkCardHTML(p, { money, base })).join('')}</div>` : ''}
      <div class="perk-cta reveal"><span class="perk-ico">${icon('key')}</span><div><b>${esc(s.ctaTitle || 'Already unlocked something?')}</b><p>${esc(s.ctaText || 'Open your perks with the personal code from your email. Codes work on any device.')}</p></div><button class="btn primary" type="button" data-perks-open>${icon('gift')}Open my perks</button></div>
    </section>`;
    },
    studio: () => `<section class="block wrap" id="studio">${head('studio')}
      <div class="principles">${(site.principles?.length ? site.principles : DEFAULT_PRINCIPLES).slice(0, 6).map(p => `<div class="pr reveal" style="--a1:${esc(p.a1 || '#2DD4BF')};--a2:${esc(p.a2 || '#38BDF8')}"><span class="app-ico">${icon(p.icon || 'sparkles')}</span><h3>${esc(p.title)}</h3><p>${esc(p.text)}</p></div>`).join('')}</div></section>`,
    support: () => { const s = sec(site, 'support'); return `<section class="block wrap" id="support"><div class="support reveal">
      <div><h2>${esc(s.title || 'Need a hand?')}</h2><p>${esc(s.subtitle || '')}</p>${socialLinksHTML(socialsWithProfiles(site))}</div>
      <div class="support-ctas">${cfg.supportEmail ? `<a class="btn primary" href="mailto:${esc(cfg.supportEmail)}">${icon('mail')}${esc(cfg.supportEmail)}</a>` : ''}${caffeineBtn(site, 'caffeine lg')}</div>
    </div></section>`; }
  };

  const body = `<main>
  <section class="hero wrap">
    <span class="eyebrow"><span class="pulse"></span>${esc(hero.eyebrow || `${brandName(site).toUpperCase()} · ${pub.length} ${pub.length === 1 ? 'APP' : 'APPS'}`)}</span>
    <h1>${esc(hero.title || '')} <span class="grad-text">${esc(hero.highlight || '')}</span></h1>
    <p class="lead">${esc(hero.lead || '')}</p>
    <div class="ctas">
      <a class="btn primary" href="#apps">${icon('compass')}${esc(hero.primaryLabel || 'Explore the apps')}</a>
      ${caffeineBtn(site, 'caffeine lg') || (cfg.githubUrl ? `<a class="btn ghost" href="${esc(cfg.githubUrl)}" target="_blank" rel="noopener">${icon('github')}Follow on GitHub</a>` : '')}
    </div>
    ${hero.showSocials && socialsWithProfiles(site).length ? socialLinksHTML(socialsWithProfiles(site), 'socials center') : ''}
    ${hero.showStats !== false ? `<div class="stats">${stats.map(([n, l]) => `<div class="stat"><b class="grad-text">${n}</b><span>${l}</span></div>`).join('')}</div>` : ''}
  </section>
${withPerks(site.sections).filter(s => s.enabled && blocks[s.id]).map(s => blocks[s.id]()).join('\n')}
</main>`;
  const url = cfg.siteUrl.replace(/\/$/, '');
  const name = brandName(site);
  return shell({ base, home: true, site, cfg, body, data: publicData(pub, site, supporters, cfg),
    title: `${name} · ${hero.title ? `${hero.title} ${hero.highlight}`.replace(/\.$/, '') : 'Apps'}`,
    desc: hero.lead || `${name}: apps, extensions and tools.`, canonical: url + '/', ogImage: ogOf(site, pub, url) });
}

// ---------- one page per app (shareable links, search engines, social previews) ----------
function renderAppPage(app, pub, site, supporters, cfg) {
  const base = '../../';
  const o = { mediaBase: base + 'assets/apps/', base };
  const url = cfg.siteUrl.replace(/\/$/, '');
  const more = pub.filter(a => a.id !== app.id).sort((a, b) => (b.category === app.category) - (a.category === app.category)).slice(0, 3);
  // link previews: the Promo Studio link-preview image (1200×630) when there is one, else the cover
  if (app.socialImage && isLocal(app.socialImage)) app = { ...app, ogCover: `${url}/assets/apps/${app.socialImage}` };
  const og = app.ogCover ? app.ogCover : app.cover && isLocal(app.cover) ? `${url}/assets/apps/${app.cover}` : app.cover || ogOf(site, pub, url);
  const body = `<main class="wrap app-main">
  <a class="back" href="${base}#apps">${icon('chevleft')}All apps</a>
  <article class="app-sheet">${detailHTML(app, o)}</article>
  ${more.length ? `<section class="block"><div class="sec-head"><div><div class="kicker">Keep exploring</div><h2>More from the studio</h2></div></div><div class="grid">${more.map(a => cardHTML(a, o)).join('')}</div></section>` : ''}
</main>`;
  return shell({ base, home: false, site, cfg, body, data: publicData(pub, site, supporters, cfg),
    title: `${app.name} · ${brandName(site)}`, desc: app.tagline || R.clip(R.mdPlain(app.description), 160) || app.name,
    canonical: `${url}/apps/${app.id}/`, ogImage: og });
}

// Social preview image: the studio's own, else the first featured app's cover.
function ogOf(site, pub, url) {
  if (site.brand?.og) return `${url}/assets/brand/${site.brand.og.split('/').pop()}`;
  const a = pub.find(x => x.featured && x.cover) || pub.find(x => x.cover);
  return a ? (isLocal(a.cover) ? `${url}/assets/apps/${a.cover}` : a.cover) : '';
}
// ---------- the page buyers land on after paying for a download ----------
function renderDownloadPage(pub, site, supporters, cfg, delivery) {
  const base = '../';
  const url = String(cfg.siteUrl || '').replace(/\/$/, '');
  const name = site.brand?.name || 'Pylerium Studio';
  const icons = ['download', 'check', 'alert', 'clock', 'mail', 'lock', 'refresh', 'copy'].map(k => `<span data-k="${k}">${icon(k)}</span>`).join('');
  const body = `<main class="wrap dl-main">
  <section class="dl-card" id="dl" data-worker="${esc(delivery.worker.url)}" data-support="${esc(cfg.supportEmail || '')}" data-store="${esc(name)}" aria-live="polite">
    <div class="dl-state"><span class="dl-spin" aria-hidden="true"></span><h1>Getting your download…</h1><p>Checking your purchase.</p></div>
    <noscript><p class="dl-nojs">Turn on JavaScript to see your download.</p></noscript>
  </section>
  <p class="dl-foot">${icon('lock')}<span>Payments are handled by Stripe. Files are delivered privately for each purchase.${cfg.supportEmail ? ` Questions? <a href="mailto:${esc(cfg.supportEmail)}">${esc(cfg.supportEmail)}</a>` : ''}</span></p>
  <template id="dl-icons">${icons}</template>
</main>`;
  return shell({ base, home: false, site, cfg, body, data: publicData(pub, site, supporters, cfg),
    title: `Your download · ${name}`, desc: `Download your purchase from ${name}.`, canonical: `${url}/download/`, ogImage: `${url}/assets/og-studio.png`,
    head: '<meta name="robots" content="noindex, nofollow"><meta name="referrer" content="no-referrer">',
    scripts: `<script type="module" src="${base}js/download.js?v=${VER.dl}"></script>` });
}

// ---------- /copy/: "Copy code" from emails (mail apps can't run scripts). The code is in the #fragment, so it never
// reaches the web server, and the page removes it from the address bar after reading it.
function renderCopyPage(site, cfg) {
  const name = site.brand?.name || 'Studio', url = String(cfg.siteUrl || '').replace(/\/$/, '');
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Copy your code · ${esc(name)}</title><meta name="robots" content="noindex,nofollow"><meta name="referrer" content="no-referrer"><meta name="theme-color" content="#07080E">
<link rel="icon" href="../assets/studio-mark.svg" type="image/svg+xml">
<style>
*{box-sizing:border-box}html,body{margin:0;min-height:100%;background:#07080E;color:#EEF0F8;font:16px/1.55 Inter,'Segoe UI',system-ui,-apple-system,sans-serif}
body{display:grid;place-items:center;padding:28px 16px;background:radial-gradient(60% 50% at 15% 0%,rgba(139,92,246,.28),transparent 70%),radial-gradient(50% 45% at 100% 100%,rgba(45,212,191,.18),transparent 70%),#07080E}
.card{width:min(560px,100%);padding:30px 28px;border-radius:24px;background:linear-gradient(170deg,rgba(20,24,41,.95),rgba(11,13,22,.96));border:1px solid rgba(255,255,255,.09);box-shadow:0 40px 90px -40px rgba(0,0,0,.9)}
.top{display:flex;align-items:center;gap:10px;color:#C9CEE0;font-weight:700;text-decoration:none}.top img{width:30px;height:30px}
h1{margin:22px 0 4px;font-size:26px;letter-spacing:-.02em}.sub{margin:0 0 18px;color:#8C93AD}
.code{position:relative;padding:18px;border-radius:16px;background:#05060B;border:1px solid rgba(94,234,212,.25);font:700 22px/1.35 ui-monospace,Consolas,Menlo,monospace;color:#5EEAD4;letter-spacing:.06em;text-align:center;word-break:break-all;user-select:all;cursor:text}
.code.long{font-size:13px;font-weight:600;letter-spacing:0;text-align:left}
.btns{display:flex;flex-wrap:wrap;gap:10px;margin-top:16px}
button,.go{display:inline-flex;align-items:center;justify-content:center;gap:8px;height:48px;padding:0 20px;border-radius:14px;border:0;font-weight:700;font-size:15px;font-family:inherit;cursor:pointer;text-decoration:none}
button{flex:1;min-width:180px;color:#fff;background:linear-gradient(120deg,#8B5CF6,#0EA5E9);box-shadow:0 14px 34px -14px #8B5CF6}
button.ok{background:linear-gradient(120deg,#10B981,#2DD4BF)}
.go{color:#EEF0F8;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12)}
.note{margin:16px 0 0;color:#8C93AD;font-size:13.5px}.empty{display:none}.none .has{display:none}.none .empty{display:block}
svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
</style></head><body>
<main class="card" id="c"><a class="top" href="${esc(url || '../')}/"><img src="../assets/studio-mark.svg" alt="" onerror="this.remove()">${esc(name)}</a>
<div class="has"><h1 id="t">Your code</h1><p class="sub" id="s">Copy it, then paste it where you need it.</p>
<div class="code" id="v"></div>
<div class="btns"><button type="button" id="b"><svg viewBox="0 0 24 24"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg><span>Copy</span></button><a class="go" id="n" hidden></a></div>
<p class="note">This page only shows what was in your email link. Nothing is sent anywhere.</p></div>
<div class="empty"><h1>Nothing to copy</h1><p class="sub">Open the Copy button from your email again, or copy the code straight from the email.</p><a class="go" href="${esc(url || '../')}/">Go to ${esc(name)}</a></div>
</main>
<script>
(function(){
  var KEY='copy.page', p=new URLSearchParams(location.hash.slice(1)), d;
  if(p.get('c')){d={c:p.get('c'),k:p.get('k')||'code',a:p.get('a')||'',n:p.get('n')||'',nl:p.get('nl')||'Continue'};try{sessionStorage.setItem(KEY,JSON.stringify(d))}catch(e){}history.replaceState(null,'',location.pathname)}
  else{try{d=JSON.parse(sessionStorage.getItem(KEY)||'null')}catch(e){}}
  var C=document.getElementById('c');if(!d||!d.c){C.className+=' none';return}
  var v=document.getElementById('v'),b=document.getElementById('b'),lbl=b.querySelector('span');
  v.textContent=d.c;if(d.c.length>32)v.className+=' long';
  document.getElementById('t').textContent='Your '+d.k.toLowerCase()+(d.a?' for '+d.a:'');
  document.getElementById('s').textContent=d.c.length>32?'It\u2019s one long line. Copy it all, then paste it when the app asks.':'Copy it, then paste it where you need it.';
  if(d.n.indexOf('https://')===0){var n=document.getElementById('n');n.href=d.n;n.textContent=d.nl+' \u2192';n.hidden=false}
  function done(){b.className='ok';lbl.textContent='Copied';setTimeout(function(){b.className='';lbl.textContent='Copy again'},2200)}
  function fallback(){var r=document.createRange();r.selectNodeContents(v);var s=getSelection();s.removeAllRanges();s.addRange(r);var ok=false;try{ok=document.execCommand('copy')}catch(e){}if(ok)done();else lbl.textContent=/Mac|iP/.test(navigator.platform)?'Selected: press ⌘C':'Selected: press Ctrl+C'}
  function copy(){var ok=false,t=setTimeout(function(){if(!ok)fallback()},900);if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(d.c).then(function(){ok=true;clearTimeout(t);done()},function(){ok=true;clearTimeout(t);fallback()});else{clearTimeout(t);fallback()}}
  b.addEventListener('click',copy);
  if(document.hasFocus())copy();
})();
</script></body></html>`;
}

export function buildSite() {
  const cfg = loadConfig();
  const site = loadSite();
  R.setCategories(site.categories);
  const supporters = loadSupporters();
  const out = cfg.siteDirAbs;
  const pub = publishedApps(loadApps());
  const delivery = loadDelivery();
  markPaid(pub);
  for (const d of ['css', 'js', 'assets/apps', 'apps']) mkdirSync(join(out, d), { recursive: true });

  VER.showcase = stamp(join(HUB, 'shared', 'showcase.css'));
  VER.studio = stamp(join(HUB, 'site-src', 'studio.css'));
  VER.render = stamp(join(HUB, 'shared', 'render.js'));
  copyFileSync(join(HUB, 'shared', 'render.js'), join(out, 'js', 'render.js'));
  copyFileSync(join(HUB, 'shared', 'showcase.css'), join(out, 'css', 'showcase.css'));
  copyFileSync(join(HUB, 'site-src', 'studio.css'), join(out, 'css', 'studio.css'));
  const sjs = readFileSync(join(HUB, 'site-src', 'studio.js'), 'utf8').replace("from './render.js'", `from './render.js?v=${VER.render}'`);
  writeFileSync(join(out, 'js', 'studio.js'), sjs);
  VER.js = createHash('sha1').update(sjs).digest('hex').slice(0, 10);
  const pjs = readFileSync(join(HUB, 'site-src', 'perks.js'), 'utf8').replace("from './render.js'", `from './render.js?v=${VER.render}'`);
  writeFileSync(join(out, 'js', 'perks.js'), pjs);
  VER.perks = createHash('sha1').update(pjs).digest('hex').slice(0, 10);
  // Brand: favicon monogram, plus the uploaded logo / social image if there is one.
  R.resetMarks();
  writeFileSync(join(out, 'assets', 'mark.svg'), R.monogram(R.initialsOf(brandName(site))).replace('<svg ', '<svg xmlns="http://www.w3.org/2000/svg" '));
  const brandDir = join(out, 'assets', 'brand');
  rmSync(brandDir, { recursive: true, force: true });
  for (const k of ['logo', 'og']) { const p = site.brand?.[k]; if (p && isLocal(p)) { const src = resolve(MEDIA, p); if (src.startsWith(resolve(MEDIA) + sep) && existsSync(src)) { mkdirSync(brandDir, { recursive: true }); copyFileSync(src, join(brandDir, p.split('/').pop())); } } }

  // Images: copy what published apps use, remove anything else (drafts' images never go public).
  const outMedia = join(out, 'assets', 'apps');
  const keep = new Set(), missing = [];
  for (const a of pub) for (const p of mediaOf(a)) {
    const src = resolve(MEDIA, p);
    if (!src.startsWith(resolve(MEDIA) + sep)) continue;
    if (!existsSync(src)) { missing.push(`${a.name}: ${p}`); continue; }
    const dst = join(outMedia, p);
    mkdirSync(dirname(dst), { recursive: true });
    if (!existsSync(dst) || statSync(dst).size !== statSync(src).size || statSync(dst).mtimeMs < statSync(src).mtimeMs) copyFileSync(src, dst);
    keep.add(resolve(dst));
  }
  for (const f of walk(outMedia)) if (!keep.has(resolve(f))) rmSync(f);
  pruneEmpty(outMedia);

  // App pages: write published, remove pages of apps that were unpublished or deleted.
  const appsDir = join(out, 'apps');
  const ids = new Set(pub.map(a => a.id));
  for (const n of readdirSync(appsDir)) if (!ids.has(n)) rmSync(join(appsDir, n), { recursive: true, force: true });
  for (const a of pub) { mkdirSync(join(appsDir, a.id), { recursive: true }); writeFileSync(join(appsDir, a.id, 'index.html'), renderAppPage(a, pub, site, supporters, cfg)); }

  writeFileSync(join(out, 'index.html'), renderHome(pub, site, supporters, cfg));
  // Paid downloads: the page buyers land on after checkout (only when the delivery service is set up).
  const dlDir = join(out, 'download');
  if (delivery.worker?.url) {
    const djs = readFileSync(join(HUB, 'site-src', 'download.js'), 'utf8');
    writeFileSync(join(out, 'js', 'download.js'), djs);
    VER.dl = createHash('sha1').update(djs).digest('hex').slice(0, 10);
    mkdirSync(dlDir, { recursive: true });
    writeFileSync(join(dlDir, 'index.html'), renderDownloadPage(pub, site, supporters, cfg, delivery));
  } else { rmSync(dlDir, { recursive: true, force: true }); rmSync(join(out, 'js', 'download.js'), { force: true }); }
  mkdirSync(join(out, 'copy'), { recursive: true });
  writeFileSync(join(out, 'copy', 'index.html'), renderCopyPage(site, cfg));
  writeFileSync(join(out, 'apps.json'), JSON.stringify(pub, null, 2) + '\n');
  writeFileSync(join(out, '.nojekyll'), '');
  const url = cfg.siteUrl.replace(/\/$/, '');
  const pages = ['/', ...pub.map(a => `/apps/${a.id}/`), ...(cfg.extraPages || [])];
  writeFileSync(join(out, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${pages.map(p => `  <url><loc>${esc(url + p)}</loc></url>`).join('\n')}\n</urlset>\n`);
  writeFileSync(join(out, 'robots.txt'), `User-agent: *\nAllow: /\nSitemap: ${url}/sitemap.xml\n`);
  return { published: pub.length, featured: pub.filter(a => a.featured).length, missing, siteDir: out };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const r = buildSite();
  console.log(`Built ${r.published} published app(s) into ${relative(process.cwd(), r.siteDir) || '.'}`);
  if (r.missing.length) console.log('Missing images:\n  ' + r.missing.join('\n  '));
}
