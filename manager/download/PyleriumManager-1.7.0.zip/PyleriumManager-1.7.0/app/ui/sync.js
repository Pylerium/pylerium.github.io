// Auto-sync card (top of Paid downloads): keeps versions, release notes, prices and buttons current by themselves.
import { R, S, $, esc, api, toast, rel, emit, refreshStatus } from './core.js';

const I = n => R.icon(n);
let Y = null, running = false, open = false;
const OPTS = [['versions', 'Versions & dates from GitHub releases'], ['notes', 'Release notes from GitHub'], ['prices', 'Prices & buy buttons from Stripe'], ['privacy', 'Hide links into private repositories'], ['chrome', 'Extension versions from the Chrome Web Store'], ['autoPublish', 'Publish the site when something changes']];

export function init() {
  const P = $('#syncPanel');
  P.addEventListener('click', onClick);
  P.addEventListener('change', onChange);
}
export async function show() {
  try { Y = await api('GET', '/api/sync'); } catch (e) { Y = { error: e.message }; }
  render();
}

function render() {
  const P = $('#syncPanel'); if (!P) return;
  if (!Y) { P.innerHTML = ''; return; }
  if (Y.error) { P.innerHTML = `<div class="card"><p class="note lock"><span>${I('alert')}</span>${esc(Y.error)}</p></div>`; return; }
  const s = Y.settings, st = Y.state || {};
  const on = s.enabled;
  P.innerHTML = `<div class="card sy-card${on ? ' on' : ''}">
    <div class="sy-head">
      <span class="sy-dot${running || Y.running ? ' spin' : ''}">${I('refresh')}</span>
      <div class="sy-t"><b>Auto-sync ${on ? 'is on' : 'is off'}</b><small>${on ? `Every ${s.everyMinutes} min · last check ${st.lastRun ? esc(rel(st.lastRun)) : 'not yet'}${st.lastChange ? ` · last change ${esc(rel(st.lastChange))}` : ''}${s.autoPublish ? ' · publishes automatically' : ''}` : 'Versions, prices and buttons only change when you edit them.'}</small></div>
      <span class="sp"></span>
      <button type="button" class="hbtn ghost sm" data-run${running ? ' disabled' : ''}>${I('refresh')}${running ? 'Syncing…' : 'Sync now'}</button>
      <button type="button" class="hbtn ghost sm" data-open>${I('sliders')}${open ? 'Hide' : 'Settings'}</button>
      <label class="switch"><input type="checkbox" data-opt="enabled"${on ? ' checked' : ''}><span class="track"><i></i></span></label>
    </div>
    ${st.lastError ? `<p class="note lock"><span>${I('alert')}</span>${esc(st.lastError)}</p>` : ''}
    ${open ? `<div class="sy-body">
      <div class="sy-opts">${OPTS.map(([k, l]) => `<label class="switch"><input type="checkbox" data-opt="${k}"${s[k] ? ' checked' : ''}><span class="track"><i></i></span><span class="sw-lbl">${esc(l)}</span></label>`).join('')}
        <label class="fld sy-every"><span>Check every (minutes)</span><input type="number" min="5" max="1440" data-every value="${esc(s.everyMinutes)}"></label></div>
      <div class="sy-hist"><h4>Recent changes</h4>${(st.history || []).length ? (st.history || []).slice(0, 12).map(h => `<div><span class="muted">${esc(rel(h.at))}</span><b>${esc(h.name)}</b><span>${esc(h.what)}</span></div>`).join('') : '<p class="muted">Nothing yet. Changes appear here when a new release or price is picked up.</p>'}</div>
    </div>` : ''}
  </div>`;
}

async function onClick(e) {
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.open != null) { open = !open; return render(); }
  if (b.dataset.run != null) {
    running = true; render();
    try {
      const r = await api('POST', '/api/sync');
      Y = { ...Y, settings: r.settings, state: r.state };
      const n = r.result.changes?.length || 0;
      toast(n ? `${n} update${n > 1 ? 's' : ''} picked up${r.result.published ? ' and published' : ''}` : 'Everything is already up to date', n ? 'ok' : 'info');
      if (n) { const st = await api('GET', '/api/state'); S.apps = st.apps; emit('apps'); refreshStatus(); }
    } catch (x) { toast(x.message, 'err'); }
    running = false; render();
  }
}
async function onChange(e) {
  const t = e.target;
  const patch = t.dataset.opt ? { [t.dataset.opt]: t.checked } : t.dataset.every != null ? { everyMinutes: +t.value } : null;
  if (!patch) return;
  try { const r = await api('PUT', '/api/sync/settings', patch); Y = { ...Y, ...r }; render(); } catch (x) { toast(x.message, 'err'); }
}
