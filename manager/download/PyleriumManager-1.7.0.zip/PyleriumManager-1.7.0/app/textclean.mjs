// Removes the tell-tale marks of AI-written text from generated posts, without rewriting what was said.
// Used for every Ollama draft and rewrite, every automation post and, as a last check, every generated post before it
// is published. Shared by the Studio Hub and Pylerium Manager (identical in both). Any future AI writer should pass its
// output through humanize() too.
//
//   punctuation   em dashes and spaced en dashes become commas, colons or plain hyphens; "--" asides too
//   wrappers      <think> blocks, code fences, wrapping quotes, "Here's your post:", "Sure!", "Title:" / "Post:" labels
//   sign-offs     "I hope this helps", "Let me know if…", "Feel free to adjust…", trailing "Note: …" explanations
//   placeholders  [link] / [URL] get the real link (or go), [Your Name] and friends go
//   filler        "In today's fast-paced world," style openers (the sentence after them is kept)
//   formatting    **bold**, __bold__ and # headings on platforms that show them as raw symbols
//   invisible     zero-width characters and non-breaking spaces

const MARKDOWN = new Set(['devto', 'discord']); // these render Markdown, so it stays

// em dash (—), horizontal bar (―) and spaced en dash (–), with whatever spaces surround them
function dashes(t, { title = false } = {}) {
  return t.split('\n').map(line => {
    if (/^\s*([-—–_*=])\1{2,}\s*$/.test(line)) return line;                     // a Markdown rule line: keep
    let l = line.replace(/^(\s*)[—―–]\s+/, '$1');                               // a dash used as a bullet
    l = l.replace(/(\d)\s*[—–]\s*(\d)/g, '$1-$2');                              // ranges: 2–3, 2020—2026
    let first = true;
    l = l.replace(/\s*(?:[—―]|\s–\s|\s--\s)\s*/g, (m, off, s) => {
      const before = s.slice(0, off), after = s.slice(off + m.length);
      if (!before.trim()) return '';                                           // at the start of a line
      if (!after.trim()) return /[.!?…]$/.test(before.trim()) ? '' : '.';      // at the end: finish the sentence
      if (title && first) { first = false; return ': '; }                       // "App — what's new" → "App: what's new"
      if (/[.!?:;,]$/.test(before.trim())) return ' ';                           // punctuation already there
      return ', ';
    });
    return l.replace(/[—―]/g, '-');                                             // anything left (word—word)
  }).join('\n');
}

const PREAMBLE = /^\s*(?:(?:sure|certainly|absolutely|of course|okay|ok|great|here you go|here it is)[!,.]?\s*)*(?:here(?:'|’)?s|here is|below is|this is)\b[^\n]{0,80}?(?:post|tweet|draft|version|caption|article|update|announcement|text|rewrite|copy)[^\n]{0,40}:\s*\n+/i;
const OPENER = /^\s*(?:sure|certainly|absolutely|of course|great question|happy to help)[!.,]\s*/i;
const LABEL = /^[ \t]*(?:\*\*)?(?:title|post|tweet|caption|body|text|draft|output|answer|hashtags?|camel ?case|tags)(?:\*\*)?[ \t]*:[ \t]*/gim;
const SIGNOFF = /\n+\s*(?:i hope (?:this|that) helps|let me know if|feel free to (?:adjust|tweak|edit|modify|change)|hope you (?:like|enjoy) it|would you like me to|i can also|happy to (?:adjust|help)|note:|\(note:|please note|this (?:post|tweet|draft|version) (?:is|keeps|highlights|uses|focuses))[^\n]*(?:\n[^\n]*)*$/i;
const PLACEHOLDER = /\[(?:your |insert |add )?(?:name|company|website|email|handle|username|signature)[^\]]*\]/gi;
const LINKHOLDER = /\[(?:link|url|website link|download link|insert link|link here|link to [^\]]+)\]|\((?:link|url)\)/gi;
const FILLER = /(^|[.!?]\s+|\n)(?:in today['’]s (?:fast-paced|digital|modern|ever-changing|busy) (?:world|landscape|age|era)|in the ever-(?:evolving|changing) (?:world|landscape) of [^,.\n]{1,40}|in a world where [^,.\n]{1,60}|let['’]s face it|without further ado),\s*(\w)/gi;

export function humanize(text, { platform = '', link = '', title = false } = {}) {
  let t = String(text ?? '');
  if (!t.trim()) return t.trim();
  t = t.replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/[​-‍⁠﻿]/g, '').replace(/ /g, ' ');
  t = t.replace(/^\s*```[a-z]*\s*\n([\s\S]*?)\n\s*```\s*$/i, '$1');            // the whole answer in a code fence
  t = t.replace(PREAMBLE, '').replace(OPENER, '');
  t = t.replace(LABEL, '');
  t = t.replace(SIGNOFF, '');
  const q = t.trim(); if (/^["“'‘][\s\S]*["”'’]$/.test(q) && !/["“”]/.test(q.slice(1, -1))) t = q.slice(1, -1); // wrapped in quotes
  // a placeholder that is being talked about ("[link] placeholders", "'[link]'") is text, not a slot to fill
  const mentioned = (s, off, m) => /^['"‘’“”`]/.test(s.slice(off + m.length)) || /['"‘’“”`]$/.test(s.slice(0, off)) || /^\s*placeholders?\b/i.test(s.slice(off + m.length));
  t = t.replace(LINKHOLDER, (m, off, s) => (mentioned(s, off, m) ? m : link || '')).replace(PLACEHOLDER, (m, off, s) => (mentioned(s, off, m) ? m : ''));
  t = t.replace(FILLER, (m, lead, c) => lead + c.toUpperCase());
  t = dashes(t, { title });
  if (!MARKDOWN.has(platform) && !title) t = t.replace(/\*\*(.+?)\*\*/g, '$1').replace(/__(.+?)__/g, '$1').replace(/^#{1,6}\s+/gm, '');
  if (title) t = t.replace(/\*\*|__/g, '').replace(/^#+\s*/, '');
  // tidy what the changes may have left: doubled punctuation and spaces, a space before punctuation
  t = t.replace(/,\s*([,.;:!?])/g, '$1').replace(/([!?])\.(?!\.)/g, '$1').replace(/(?<!\.)\.\.(?!\.)/g, '.').replace(/:\s*,/g, ':').replace(/[ \t]+([,.;:!?])(?=\s|$)/g, '$1')
    .replace(/[ \t]{2,}/g, ' ').replace(/[ \t]+$/gm, '').replace(/\n{3,}/g, '\n\n');
  return title ? t.replace(/\s+/g, ' ').trim().replace(/[.:,]$/, '') : t.trim();
}
